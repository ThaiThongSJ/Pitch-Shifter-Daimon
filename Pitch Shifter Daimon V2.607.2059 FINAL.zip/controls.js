/**
 * controls.js - Controls the interface and activation of Pitch Shifter Pro
 * Handles Device ID, key verification, trial mode, and storage of activation.json
 * Sends refreshExtension message to background.js
 * Optimizes key activation and trial mode speed (under 2 seconds) with Web Crypto API
 * Enhanced with stable Device ID, trial mode, and obfuscation
 * Synced Device ID and trial data with chrome.storage.sync
 */
// Configuration
// === CONFIG PRO ACTIVE SECURITY SHIELD - CHỐNG TAMPER TOÀN CỤC (ĐÃ FIX LỖI FREEZE) ===
const CONFIG = (() => {
  const _rawGate = [0x1D, 0x52, 0x0E, 0x5C, 0x15, 0x57, 0x08, 0x51, 0x14, 0x5D, 0x12, 0x56, 0x1F, 0x50, 0x11, 0x54, 0x17, 0x53, 0x1C, 0x55];
  const _salt = 0x65;
  // Tạo mảng Secret Key động dưới dạng mảng số nguyên thường (Array) để có thể đóng băng an toàn
  const secureSecretArray = Object.freeze(_rawGate.map(b => b ^ _salt));
  const baseConfig = {
    CACHE_TIMEOUT: 24 * 60 * 60 * 1000, // Kiểm tra bộ nhớ đệm: 24 giờ
    TRIAL_DURATION: 30 * 24 * 60 * 60 * 1000, // Thử nghiệm 30 ngày (tính bằng mili-giây)
    // CẤU HÌNH ĐƯỜNG DẪN MÁY CHỦ GITHUB (ĐỘC LẬP)
    GITHUB_KEYS_URL: "https://raw.githubusercontent.com/ThaiThongSJ/Pitch-Shifter-Daimon/main/keys.json",
    GITHUB_TIME_API: "https://api.github.com",
    DEBUG_MODE: (
      (location.hostname === "localhost" || location.hostname === "127.0.0.1" || location.protocol === "file:") && chrome.runtime?.getManifest()?.version?.includes("dev")) ? true : false
  };
  Object.defineProperty(baseConfig, "SECRET", {
    get: () => new Uint8Array(secureSecretArray), // Trả về mảng Uint8Array chuẩn khi code cũ gọi tới
    set: () => {}, // Triệt tiêu lệnh cố tình ghi đè từ bên ngoài
    configurable: false, // Không cho phép xóa hoặc cấu hình lại thuộc tính này
    enumerable: true
  });
  // Đóng băng Object tổng để bảo vệ các thuộc tính còn lại (BPM, TRIAL, DEBUG...)
  return Object.freeze(baseConfig);
})();
// Ánh xạ để hiển thị tên cấu hình âm thanh thân thiện
const profileDisplayNames = {
  warm: 'Warm',
  bright: 'Bright',
  bassHeavy: 'Bass Heavy',
  vocal: 'Vocal',
  proNatural: 'Natural',
  karaokeDynamic: 'Karaoke',
  rockMetal: 'Rock/Metal',
  smartStudio: 'Smart Studio'
};
/**
 * Lấy thời gian chuẩn thế giới từ Header Date của GitHub Server
 * Chống triệt để việc người dùng lùi/tiến ngày giờ trên Windows/Mac để gian lận bản quyền
 */
async function fetchRemoteGitHubTime() {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 600); // Tốc độ phản hồi cực nhanh dưới 600ms
    const response = await fetch(CONFIG.GITHUB_TIME_API, {
      method: "HEAD",
      signal: controller.signal
    });
    clearTimeout(timeout);
    const dateHeader = response.headers.get("Date");
    if (dateHeader) {
      const serverMs = new Date(dateHeader).getTime();
      if (!isNaN(serverMs)) return serverMs;
    }
    return null;
  } catch (e) {
    return null; // Trả về null nếu mất kết nối mạng hoặc timeout
  }
}
/**
 * Hàm kiểm tra bảo mật từ xa qua GitHub Server
 * Thực hiện quét danh sách Blacklist ID và các Key bị thu hồi (Revoked)
 */
/**
 * NÂNG CẤP: Quản lý danh sách đen/thu hồi bằng Hash Look-up (Tốc độ O(1))
 * Dùng Githack để xóa bỏ độ trễ cache, cập nhật tức thì.
 */
async function executeGitHubSecurityGate() {
  try {
    const deviceId = await generateDeviceId();
    const remoteTime = await fetchRemoteGitHubTime();
    const systemTime = Date.now();
    // 1. Kiểm tra lệch thời gian (Giữ nguyên logic an toàn)
    if (remoteTime && Math.abs(systemTime - remoteTime) > 300000) {
      const errorMsg = currentLang === 'vi' ? "Thời gian máy tính bị sai lệch! Vui lòng đồng bộ lại giờ hệ thống." : "System time is incorrect! Please resync your device clock.";
      showNotification(errorMsg);
      return {
        blocked: true,
        reason: "time_drift_fraud"
      };
    }
    // 2. Tải tệp cấu hình (Dùng raw.githack.com để bypass cache, cập nhật tức thì)
    // Thay GITHUB_KEYS_URL trong CONFIG thành: 
    // "https://raw.githack.com/ThaiThongSJ/Pitch-Shifter-Daimon/main/keys.json"
    const res = await fetch(CONFIG.GITHUB_KEYS_URL);
    if (!res.ok) return {
      blocked: false,
      status: "github_offline"
    };
    const remoteData = await res.json();
    // 3. CHIẾN THUẬT PHÒNG THỦ SIÊU TỐC (HASH LOOK-UP)
    // remoteData.blacklist và remoteData.revokedKeys bây giờ là Object { "ID": "Reason" }
    // Kiểm tra Blacklist
    if (remoteData.blacklist && remoteData.blacklist[deviceId]) {
      const reason = remoteData.blacklist[deviceId];
      console.warn("Thiết bị bị khóa. Lý do:", reason);
      await Promise.all([
        chrome.storage.local.set({
          trialLocked: true,
          isActivated: false,
          audioSabotage: true
        }),
        chrome.storage.sync.set({
          permanentLock: true
        })
      ]);
      showNotification(currentLang === 'vi' ? "Thiết bị đã bị khóa!" : "Device permanently locked!");
      setTimeout(() => chrome.runtime.reload(), 1000);
      return {
        blocked: true,
        reason: "remote_blacklist"
      };
    }
    // 4. Kiểm tra Revoked Keys
    const localActivation = await new Promise(r => chrome.storage.local.get(["activation"], res => r(res.activation)));
    if (localActivation?.activationKey && remoteData.revokedKeys) {
      if (remoteData.revokedKeys[localActivation.activationKey]) {
        await chrome.storage.local.remove(["activation", "isActivated"]);
        await chrome.storage.sync.remove(["activationBackup"]);
        showNotification(currentLang === 'vi' ? "Mã kích hoạt đã bị thu hồi!" : "Key has been revoked!");
        setTimeout(() => chrome.runtime.reload(), 1000);
        return {
          blocked: true,
          reason: "key_revoked"
        };
      }
    }
    return {
      blocked: false,
      status: "secure"
    };
  } catch (error) {
    console.debug("Security Gate Bypass:", error);
    return {
      blocked: false,
      status: "bypass_on_error"
    };
  }
}
// =========================================================================
// ĐOẠN GÀI CHẠY TỰ ĐỘNG (HOOK): TỐI ƯU HOÁ TỐC ĐỘ (NON-BLOCKING)
// =========================================================================
if (typeof init === "function") {
  const originalInit = init;
  init = function(...args) {
    // 1. Cho phép giao diện (UI) khởi tạo ngay lập tức không cần chờ đợi (0ms)
    originalInit.apply(this, args);
    // 2. Chạy ngầm cổng bảo mật GitHub phía sau.
    executeGitHubSecurityGate().then(gate => {
      if (gate && gate.blocked) {
        // Nếu phát hiện vào Blacklist/Revoked, khoá mõm giao diện lại ngay
        if (typeof toggleControls === "function") toggleControls(false);
        const buyBtn = document.getElementById("buy-btn");
        const licenseStatus = document.getElementById("license-status");
        if (buyBtn) buyBtn.style.display = "inline-block";
        if (licenseStatus) licenseStatus.style.display = "none";
      }
    });
  };
}
// === ANTI-DEBUG + ANTI-TAMPER JS SHIELD (BẢN GỐC TỐI ƯU HIỆU NĂNG - KHÔNG LÀM NẶNG MÁY) ===
class AntiDebugTamperShield {
  constructor() {
    this.enabled = true;
    this.tamperDetected = false;
    this.debugAttempts = 0;
    this.startTime = performance.now();
    this.init();
  }
  init() {
    if (!this.enabled) return;
    // 1. Chống mở DevTools (F12, Ctrl+Shift+I, menu)
    this.blockDevTools();
    // 2. Chống debug bằng breakpoint / console
    this.antiBreakpoint();
    // 3. Chống tamper JS (thay đổi hàm, xóa code)
    this.antiTamper();
    // 4. Tự động khóa nếu phát hiện can thiệp
    this.startMonitoring();
  }
  // --- 1. CHỐNG MỞ DEVTOOLS ---
  blockDevTools() {
    const devtools = /./;
    devtools.toString = () => {
      this.debugAttempts++;
      this.triggerLock("devtools_open_detected");
      return "Blocked";
    };
    // FIX: Tăng từ 500ms lên 2000ms (2 giây/lần). 
    // Việc check kích thước cửa sổ không cần quá dồn dập, giúp giảm tải CPU rõ rệt.
    setInterval(() => {
      if (window.outerHeight - window.innerHeight > 200 || window.outerWidth - window.innerWidth > 200) {
        this.debugAttempts++;
        this.triggerLock("devtools_resized_detected");
      }
    }, 2000);
    // Chặn phím tắt
    document.addEventListener("keydown", (e) => {
      if (e.keyCode === 123 || // F12
        (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 67 || e.keyCode === 74)) || // Ctrl+Shift+I/C/J
        (e.ctrlKey && e.keyCode === 85) // Ctrl+U
      ) {
        e.preventDefault();
        this.debugAttempts++;
        this.triggerLock("hotkey_blocked");
      }
    }, true);
  }
  // --- 2. CHỐNG BREAKPOINT & CONSOLE DEBUG ---
  antiBreakpoint() {
    const checkDebug = () => {
      const start = Date.now();
      debugger; // Nếu đang debug → treo
      if (Date.now() - start > 100) {
        this.triggerLock("debugger_statement_hit");
      }
    };
    // FIX: Nới rộng khoảng thời gian lặp kiểm tra breakpoint ngẫu nhiên.
    // Thay vì check liên tục (5-10s), giãn cách ra giúp trình duyệt không bị mệt mà vẫn tóm được cracker.
    setTimeout(checkDebug, Math.random() * 5000 + 3000);
    setInterval(checkDebug, Math.random() * 20000 + 15000); // 15s đến 35s check một lần
    // Chặn console.log nếu dùng để debug
    const originalLog = console.log;
    console.log = (...args) => {
      if (args.some(arg => typeof arg === "string" && (arg.includes("trial") || arg.includes("deviceId")))) {
        this.triggerLock("sensitive_log_detected");
        return;
      }
      originalLog.apply(console, args);
    };
  }
  // --- 3. CHỐNG TAMPER JS (thay đổi hàm, xóa code) ---
  antiTamper() {
    const criticalFuncs = [
      initializeTrial,
      checkActivation,
      verifyTrial,
      verifyActivation,
      fetchServerTime,
      generateDeviceId
    ];
    criticalFuncs.forEach(func => {
      if (typeof func !== "function") {
        this.triggerLock("critical_function_missing");
        return;
      }
      const originalCode = func.toString();
      // FIX: Giãn tần suất quét chuỗi .toString() từ (3-5s) lên thành (20-30s).
      // Do hàm chạy lặp vô hạn cho từng hàm critical, giãn thời gian giúp triệt tiêu hiện tượng nghẽn luồng (I/O) gây nặng máy.
      setInterval(() => {
        if (func.toString() !== originalCode) {
          this.triggerLock("function_tampered");
        }
      }, 20000 + Math.random() * 10000);
    });
  }
  // --- 4. GIÁM SÁT & KHÓA VĨNH VIỄN ---
  startMonitoring() {
    // FIX: Tăng từ 5000ms lên 10000ms (10 giây/lần). Giảm bớt số chu kỳ kiểm tra của luồng chính.
    setInterval(() => {
      if (this.debugAttempts > 3 || this.tamperDetected) {
        this.triggerLock("multiple_violations");
      }
    }, 10000);
  }
  // --- KHÓA THIẾT BỊ KHI PHÁT HIỆN ---
  async triggerLock(reason) {
    if (this.tamperDetected) return;
    this.tamperDetected = true;
    // === CHỐNG KHÓA SAI KHI CÀI LẦN ĐẦU ===
    const isFirstRun = await new Promise(resolve => {
      chrome.storage.local.get(["firstRunLocked"], r => resolve(r.firstRunLocked));
    });
    if (!isFirstRun) {
      await chrome.storage.local.set({
        firstRunLocked: true
      });
      console.warn("Cảnh báo bảo mật: Phát hiện hoạt động đáng ngờ lần đầu – cho phép tiếp tục (1 lần duy nhất)");
      this.tamperDetected = false;
      return;
    }
    // === HẾT 1 LẦN THỬ – KHÓA THẬT ===
    await logSuspiciousActivity("anti_tamper_triggered", {
      reason,
      debugAttempts: this.debugAttempts
    });
    const deviceId = await generateDeviceId().catch(() => "unknown");
    const lockedDevices = await new Promise(resolve => {
      chrome.storage.sync.get(["lockedDevices"], r => resolve(r.lockedDevices || []));
    });
    if (!lockedDevices.includes(deviceId)) {
      lockedDevices.push(deviceId);
      await chrome.storage.sync.set({
        lockedDevices
      });
    }
    await Promise.all([
      chrome.storage.local.set({
        trialLocked: true
      }),
      chrome.storage.sync.set({
        permanentLock: true
      })
    ]);
    setTimeout(() => chrome.runtime.reload(), 100);
  }
}
// === KHỞI TẠO SHIELD NGAY KHI EXTENSION LOAD ===
new AntiDebugTamperShield();
// Trong generateDeviceId() – chỉ log nếu DEBUG_MODE
if (CONFIG.DEBUG_MODE) {
  console.log("Device ID:", deviceId); // Cho phép debug phát triển
}
// === CANARY CHECK + DOUBLE BACKUP INDEXEDDB (SIÊU BỀN, KHÔNG THỂ XÓA) ===
// 1. Tạo 2 bản backup + canary token
async function createSecureBackups() {
  console.time("CreateSecureBackups");
  try {
    const deviceId = await generateDeviceId();
    const serverTime = await fetchServerTime();
    const entropy = await gatherQuantumEntropy();
    const fingerprint = {
      deviceId,
      firstInstall: serverTime,
      entropySeed: entropy.seed,
      checksum: await computeFingerprintChecksum(deviceId, serverTime, entropy.seed),
      signature: await signFingerprint(deviceId, serverTime, entropy.seed),
      canary: await generateCanaryToken(deviceId, serverTime),
      backupTimestamp: serverTime
    };
    // Lưu vào 3 nơi: chính + 2 backup
    await Promise.all([
      saveToIndexedDB("PitchShifterSecure", "fingerprint", fingerprint),
      saveToIndexedDB("PitchShifterSecure_Backup1", "fingerprint", {
        ...fingerprint,
        backupId: 1
      }),
      saveToIndexedDB("PitchShifterSecure_Backup2", "fingerprint", {
        ...fingerprint,
        backupId: 2
      })
    ]);
    // Đồng bộ backup 2 lên chrome.storage.sync (không bị xóa khi clear data)
    await new Promise(resolve => {
      chrome.storage.sync.set({
        indexedDBBackup2: btoa(JSON.stringify(fingerprint))
      }, resolve);
    });
    console.timeEnd("CreateSecureBackups");
    return true;
  } catch (error) {
    handleError("Lỗi tạo backup IndexedDB:", error);
    console.timeEnd("CreateSecureBackups");
    return false;
  }
}
// 2. Tạo Canary Token (không thể giả mạo)
async function generateCanaryToken(deviceId, timestamp) {
  const data = `${deviceId}:${timestamp}:CANARY:${Math.random().toString(36)}`;
  const encoder = new TextEncoder();
  const key = await getCryptoKey(CONFIG.SECRET);
  const sig = await crypto.subtle.sign("HMAC", key, encoder.encode(data));
  return btoa(String.fromCharCode(...new Uint8Array(sig))).slice(0, 64);
}
// 3. Kiểm tra Canary + Khôi phục từ backup
async function verifyAndRestoreFingerprint() {
  console.time("VerifyAndRestoreFingerprint");
  try {
    // Bước 1: Kiểm tra DB chính
    let stored = await getFromIndexedDB("PitchShifterSecure", "fingerprint");
    let source = "main";
    if (!stored || !(await validateFingerprint(stored))) {
      // Bước 2: Thử backup 1
      stored = await getFromIndexedDB("PitchShifterSecure_Backup1", "fingerprint");
      source = "backup1";
      if (stored && await validateFingerprint(stored)) {
        await saveToIndexedDB("PitchShifterSecure", "fingerprint", stored);
      } else {
        // Bước 3: Thử backup 2 từ chrome.storage.sync
        const syncBackup = await new Promise(resolve => {
          chrome.storage.sync.get(["indexedDBBackup2"], r => {
            try {
              resolve(r.indexedDBBackup2 ? JSON.parse(atob(r.indexedDBBackup2)) : null);
            } catch {
              resolve(null);
            }
          });
        });
        if (syncBackup && await validateFingerprint(syncBackup)) {
          stored = syncBackup;
          source = "sync_backup2";
          await Promise.all([
            saveToIndexedDB("PitchShifterSecure", "fingerprint", stored),
            saveToIndexedDB("PitchShifterSecure_Backup1", "fingerprint", {
              ...stored,
              backupId: 1
            })
          ]);
        }
      }
    }
    if (!stored || !(await validateFingerprint(stored))) {
      await logSuspiciousActivity("fingerprint_lost_all_backups", {
        source
      });
      console.timeEnd("VerifyAndRestoreFingerprint");
      return {
        valid: false,
        firstTime: true,
        restored: false
      };
    }
    console.timeEnd("VerifyAndRestoreFingerprint");
    return {
      valid: true,
      firstTime: false,
      restored: source !== "main",
      source
    };
  } catch (error) {
    handleError("Lỗi khôi phục fingerprint:", error);
    console.timeEnd("VerifyAndRestoreFingerprint");
    return {
      valid: false,
      firstTime: false,
      error: true
    };
  }
}
// 4. Xác thực fingerprint + canary
async function validateFingerprint(fp) {
  if (!fp.deviceId || !fp.firstInstall || !fp.canary) return false;
  const currentDeviceId = await generateDeviceId();
  if (fp.deviceId !== currentDeviceId) return false;
  const expectedChecksum = await computeFingerprintChecksum(fp.deviceId, fp.firstInstall, fp.entropySeed);
  if (fp.checksum !== expectedChecksum) return false;
  const isValidSig = await verifyFingerprintSignature(fp.deviceId, fp.firstInstall, fp.entropySeed, fp.signature);
  if (!isValidSig) return false;
  // Kiểm tra canary (chống replay)
  const expectedCanary = await generateCanaryToken(fp.deviceId, fp.firstInstall);
  return fp.canary === expectedCanary;
}
// 5. Cập nhật backup định kỳ (mỗi 6h)
let backupInterval = null;

function startBackupSync() {
  if (backupInterval) return;
  backupInterval = setInterval(async () => {
    try {
      const fp = await getFromIndexedDB("PitchShifterSecure", "fingerprint");
      if (fp && await validateFingerprint(fp)) {
        await createSecureBackups();
      }
    } catch (e) {
      /* ignore */
    }
  }, 6 * 60 * 60 * 1000);
}
// Helper function to handle errors
function handleError(errorMessage, error, suppressNotification = false) {
  if (CONFIG.DEBUG_MODE) {
    const errorMsg = error?.message || (error ? JSON.stringify(error, null, 2) : "Unknown error");
    console.error(`[DEBUG] ${errorMessage}: ${errorMsg}`, error?.stack || "");
  }
  // Chỉ hiện thông báo cho người dùng nếu cần
  if (!suppressNotification && !CONFIG.DEBUG_MODE) {
    const userMsg = errorMessage.includes("Content script not ready") ? "Reloading page to activate extension..." : "Connection issue. Please try again.";
    showNotification(userMsg);
  }
}
// Conditional debug logging
function debugLog(...args) {
  if (CONFIG.DEBUG_MODE) {
    console.debug(...args);
  }
}
// List of supported URLs (from manifest.json)
const supportedPatterns = ["*://*.youtube.com/*", "*://*.vimeo.com/*", "*://*.soundcloud.com/*", "*://*.dailymotion.com/*", "*://*.twitch.tv/*"];
// background.js
const blockedDomains = ["facebook.com", "soundcloud.com"];

function isSupportedUrl(url) {
  if (!url) return false;
  // Nếu là Facebook hoặc SoundCloud → Chặn luôn
  if (blockedDomains.some(domain => url.includes(domain))) {
    return false;
  }
  return supportedPatterns.some(pattern => {
    const regex = new RegExp(pattern.replace(/\*/g, ".*"));
    return regex.test(url);
  });
}

function injectContentScriptIfNeeded(tabId, callback) {
  chrome.tabs.sendMessage(tabId, {
    type: "ping"
  }, (pingResponse) => {
    if (!chrome.runtime.lastError && pingResponse) {
      if (callback) callback({
        status: "success",
        message: "Content script already injected and ready"
      });
      return;
    }
    chrome.scripting.executeScript({
      target: {
        tabId: tabId
      },
      files: ['jungle.js', 'content.js']
    }, () => {
      if (chrome.runtime.lastError) {
        handleError("Error injecting content script and Jungle library:", chrome.runtime.lastError);
        if (callback) callback({
          status: "error",
          message: "Could not inject content script. Try reloading manually!"
        });
      } else {
        if (callback) callback({
          status: "success",
          message: "Content script and Jungle library injected and ready"
        });
      }
    });
  });
}
// === BIẾN CHẶN RELOAD CONFIRM LẶP (SIÊU CHẶT, CHỈ HIỆN 1 LẦN DUY NHẤT) ===
let isShowingReloadConfirm = false; // Flag local – chặn tức thì trong cùng popup
const RELOAD_GLOBAL_LOCK_KEY = "__pspro_reload_global_lock__"; // Key trong storage.local để chặn giữa các popup instance
const RELOAD_LOCK_DURATION = 15000; // 15 giây khóa toàn cục (đủ để reload xong)
const PING_RETRY_DELAY = 1500;

function sendMessageToActiveTab(message, callback, retries = 3) {
  chrome.tabs.query({
    active: true,
    currentWindow: true
  }, (tabs) => {
    const tab = tabs[0];
    if (!tab || !tab.id || !tab.url || !isSupportedUrl(tab.url)) {
      if (callback) callback({
        status: "notSupported",
        message: "This tab is not supported"
      });
      return;
    }
    const tryPingAndSend = () => {
      // Nếu đang hiển thị confirm → bỏ qua hoàn toàn
      if (isShowingReloadConfirm) {
        if (retries > 0) {
          setTimeout(() => sendMessageToActiveTab(message, callback, retries - 1), PING_RETRY_DELAY);
        } else if (callback) {
          callback({
            status: "waiting",
            message: "Extension is initializing..."
          });
        }
        return;
      }
      chrome.tabs.sendMessage(tab.id, {
        type: "ping"
      }, (pingResponse) => {
        // CASE 1: Content script đã sẵn sàng → gửi message bình thường
        if (!chrome.runtime.lastError && pingResponse) {
          chrome.tabs.sendMessage(tab.id, message, (response) => {
            if (chrome.runtime.lastError) {
              handleError("Error sending message:", chrome.runtime.lastError);
              if (callback) callback({
                status: "error",
                message: "Error communicating with tab"
              });
            } else if (!response || typeof response !== "object") {
              if (callback) callback({
                status: "error",
                message: "Invalid response"
              });
            } else {
              if (callback) callback(response);
            }
          });
          return;
        }
        // CASE 2: Content chưa sẵn sàng → kiểm tra lock toàn cục
        chrome.storage.local.get([RELOAD_GLOBAL_LOCK_KEY], (result) => {
          const lockTime = result[RELOAD_GLOBAL_LOCK_KEY] || 0;
          const now = Date.now();
          if (now - lockTime < RELOAD_LOCK_DURATION) {
            // Đã có popup khác đang xử lý → chờ
            if (retries > 0) {
              setTimeout(() => sendMessageToActiveTab(message, callback, retries - 1), PING_RETRY_DELAY);
            } else if (callback) {
              callback({
                status: "waiting",
                message: "Tab is reloading, please wait…"
              });
            }
            return;
          }
          // CASE 3: ĐƯỢC QUYỀN HIỆN CONFIRM → CHỈ 1 LẦN DUY NHẤT
          isShowingReloadConfirm = true;
          chrome.storage.local.set({
            [RELOAD_GLOBAL_LOCK_KEY]: Date.now()
          });
          showCustomConfirm("You need to reload the page for the extension to take effect. Do you want to reload now?",
            () => {
              chrome.tabs.reload(tab.id, () => {
                if (chrome.runtime.lastError) {
                  handleError("Error reloading tab:", chrome.runtime.lastError);
                  isShowingReloadConfirm = false;
                  chrome.storage.local.remove([RELOAD_GLOBAL_LOCK_KEY]);
                  if (callback) callback({
                    status: "error",
                    message: "Could not reload tab"
                  });
                  return;
                }
                setTimeout(() => {
                  injectContentScriptIfNeeded(tab.id, (injectRes) => {
                    isShowingReloadConfirm = false;
                    chrome.storage.local.remove([RELOAD_GLOBAL_LOCK_KEY]);
                    if (injectRes.status === "success") {
                      sendMessageToActiveTab(message, callback, 3);
                    } else if (callback) {
                      callback(injectRes);
                    }
                  });
                }, 1500);
              });
            },
            () => {
              isShowingReloadConfirm = false;
              chrome.storage.local.remove([RELOAD_GLOBAL_LOCK_KEY]);
              if (callback) callback({
                status: "cancelled",
                message: "User cancelled reload"
              });
            });
          // Tự động reset flag sau 15 giây (đề phòng user không bấm gì)
          setTimeout(() => {
            isShowingReloadConfirm = false;
            chrome.storage.local.remove([RELOAD_GLOBAL_LOCK_KEY]);
          }, RELOAD_LOCK_DURATION);
        });
      });
    };
    tryPingAndSend();
  });
}
// Show temporary notification
function showNotification(message) {
  const overlay = document.getElementById("value-overlay");
  if (overlay) {
    overlay.textContent = message;
    overlay.classList.add("neon");
    setTimeout(() => overlay.classList.remove("neon"), 1500);
  } else {
    console.log("Notification:", message);
  }
}
// Show custom confirmation dialog
function showCustomConfirm(message, onConfirm, onCancel) {
  const confirmModal = document.createElement("div");
  confirmModal.className = "custom-confirm";
  confirmModal.style.zIndex = "10000"; // Tăng z-index để trên showNotification
  confirmModal.innerHTML = `
        <div class="confirm-content">
            <p>${message}</p>
            <div class="confirm-buttons">
                <button id="confirm-yes">Yes</button>
                <button id="confirm-no">No</button>
            </div>
        </div>
    `;
  document.body.appendChild(confirmModal);
  document.getElementById("confirm-yes").addEventListener("click", () => {
    document.body.removeChild(confirmModal);
    onConfirm();
  });
  document.getElementById("confirm-no").addEventListener("click", () => {
    document.body.removeChild(confirmModal);
    if (onCancel) onCancel();
  });
}
// Global variables for original BPM, key, and song title
let baseBPM = null;
let currentKey = null;
let latestStatusTime = 0;
let currentSongTitle = "No songs yet";
let port;
// Cache for key verification, trial, and CryptoKey
let activationCache = {
  key: null,
  deviceId: null,
  result: null,
  timestamp: 0
};
let trialCache = {
  deviceId: null,
  result: null,
  timestamp: 0
};
let cachedCryptoKey = null;
// Debounce function to optimize events
function debounce(func, wait) {
  let timeout;
  return (...args) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}
// Static variable to avoid repeated warnings
let hasWarned = false;
// Enhanced fallback hash function
function simpleHash(str) {
  let hash = 0x5a7b3c;
  const bytes = new Uint8Array(16);
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i) ^ (i + 0x1f);
    hash = ((hash << 7) ^ (hash >> 3)) + (char << (i % 4)) | 0;
    bytes[i % 16] = (hash & 0xff) ^ (char & 0x7f);
  }
  // Dummy operations for obfuscation
  let dummy = hash;
  for (let i = 0; i < 8; i++) dummy = (dummy ^ i) << (i % 3);
  return Array.from(bytes).map(byte => byte.toString(16).padStart(2, "0")).join("").slice(0, 32);
}
// Sinh mã Device ID tĩnh, bảo mật cao kết hợp Canvas Fingerprint & Đồng bộ đám mây
// ĐÃ TỐI ƯU: ƯU TIÊN TRẢ ID VỀ TRƯỚC (0ms), ĐỒNG BỘ CHẠY SAU CHỐNG LAG APP
async function generateDeviceId() {
  return new Promise((resolve) => {
    try {
      const isDevEnvironment = (location.protocol === "file:" || location.hostname === "localhost" || location.hostname === "127.0.0.1" || /^192\.168\.\d{1,3}\.\d{1,3}$/.test(location.hostname) || location.protocol === "chrome-extension:");
      if (!isDevEnvironment && location.protocol !== "https:" && !hasWarned) {
        debugLog("Tạo Device ID ưu tiên ngữ cảnh bảo mật (HTTPS)");
        hasWarned = true;
      }
      // ====================================================================
      // BƯỚC 1: KIỂM TRA LOCAL STORAGE TRƯỚC (Tốc độ đọc ổ cứng cục bộ cực nhanh ~0ms)
      // ====================================================================
      chrome.storage.local.get(["deviceId"], (localResult) => {
        if (localResult.deviceId) {
          resolve(localResult.deviceId); // 🚀 TRẢ VỀ NGAY LẬP TỨC CHO UI CHẠY
          // Kiểm tra và đồng bộ ngầm lên đám mây (Chạy background, không bắt UI phải đợi)
          chrome.storage.sync.get(["deviceId"], (syncCheck) => {
            if (!syncCheck.deviceId) {
              chrome.storage.sync.set({
                deviceId: localResult.deviceId
              });
            }
          });
          return;
        }
        // ====================================================================
        // BƯỚC 2: NẾU LOCAL KHÔNG CÓ -> KIỂM TRA ĐÁM MÂY SYNC STORAGE
        // ====================================================================
        chrome.storage.sync.get(["deviceId"], (syncResult) => {
          if (syncResult.deviceId) {
            resolve(syncResult.deviceId); // 🚀 TRẢ VỀ NGAY LẬP TỨC CHÚNG TA ĐÃ TÌM THẤY TRÊN MÂY
            // Đồng bộ ngược về local ngầm để lần sau đọc từ Bước 1 cho nhanh
            chrome.storage.local.set({
              deviceId: syncResult.deviceId
            });
            return;
          }
          // ====================================================================
          // BƯỚC 3: CẢ HAI ĐỀU TRỐNG (CÀI APP LẦN ĐẦU) -> TIẾN HÀNH TÍNH TOÁN NẶNG
          // ====================================================================
          let ctxString = "";
          try {
            const canvas = document.createElement("canvas");
            const ctx = canvas.getContext("2d");
            if (ctx) {
              ctx.textBaseline = "top";
              ctx.font = "14px 'Arial'";
              ctx.textBaseline = "alphabetic";
              ctx.fillStyle = "#f60";
              ctx.fillRect(125, 1, 62, 20);
              ctx.fillStyle = "#069";
              ctx.fillText("PitchShifterPro_AntiTamper_🚀_" + (navigator.hardwareConcurrency || 0), 2, 15);
              ctxString = canvas.toDataURL(); // Phụ thuộc GPU + Driver phần cứng
            }
          } catch (canvasError) {
            debugLog("Canvas Fingerprint bị chặn, dùng fallback trống", canvasError);
            ctxString = "NO_CANVAS_SUPPORT";
          }
          // Thu thập thông số cấu hình sâu của máy
          const deviceInfo = [
            navigator.hardwareConcurrency || 0,
            screen.width || 0,
            screen.height || 0,
            window.devicePixelRatio || 1,
            screen.colorDepth || 24,
            navigator.language || "en-US",
            ctxString,
            navigator.userAgent.includes("Windows") ? "Win" : "Mac"
          ].join("||");
          console.info("Khởi tạo Device ID lần đầu tiên dựa trên cấu hình phần cứng đồ họa.");
          // Hàm băm mật mã học nặng PBKDF2
          const hashDeviceInfo = async (info) => {
            try {
              const encoder = new TextEncoder();
              const key = await crypto.subtle.importKey("raw", CONFIG.SECRET, {
                  name: "PBKDF2"
                }, false,
                ["deriveBits"]);
              const hash = await crypto.subtle.deriveBits({
                name: "PBKDF2",
                salt: encoder.encode(info.slice(0, 16)),
                iterations: 100000, // 🔴 Hàm chạy nặng ở đây
                hash: "SHA-512"
              }, key, 256);
              return Array.from(new Uint8Array(hash)).map(byte => byte.toString(16).padStart(2, "0")).join("").slice(0, 32);
            } catch (cryptoError) {
              debugLog("PBKDF2 thất bại, sử dụng hàm hash dự phòng:", cryptoError);
              return simpleHash(info);
            }
          };
          // Tiến hành băm và lưu trữ
          hashDeviceInfo(deviceInfo).then((newDeviceId) => {
            resolve(newDeviceId); // 🚀 Tạo xong trả về luôn cho user dùng
            // Việc lưu vào bộ nhớ ném xuống cuối cho chạy ngầm sau khi user đã nhận được ID
            chrome.storage.local.set({
              deviceId: newDeviceId
            }, () => {
              chrome.storage.sync.set({
                deviceId: newDeviceId
              });
            });
          }).catch((hashError) => {
            console.error("Lỗi khi hash Device ID:", hashError);
            const fallbackId = simpleHash(deviceInfo);
            resolve(fallbackId); // 🚀 Trả về ID dự phòng ngay
            chrome.storage.local.set({
              deviceId: fallbackId
            }, () => {
              chrome.storage.sync.set({
                deviceId: fallbackId
              });
            });
          });
        });
      });
    } catch (error) {
      console.error("Lỗi nghiêm trọng khi tạo Device ID:", error);
      // Xử lý khẩn cấp nếu toàn bộ luồng trên bị crash đột ngột
      let catchCtxString = "NO_CANVAS_SUPPORT";
      try {
        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.textBaseline = "top";
          ctx.font = "14px 'Arial'";
          ctx.textBaseline = "alphabetic";
          ctx.fillStyle = "#f60";
          ctx.fillRect(125, 1, 62, 20);
          ctx.fillStyle = "#069";
          ctx.fillText("PitchShifterPro_AntiTamper_🚀_" + (navigator.hardwareConcurrency || 0), 2, 15);
          catchCtxString = canvas.toDataURL();
        }
      } catch (ce) {}
      const deviceInfo = [
        navigator.hardwareConcurrency || 0,
        screen.width || 0,
        screen.height || 0,
        window.devicePixelRatio || 1,
        screen.colorDepth || 24,
        navigator.language || "en-US",
        catchCtxString,
        navigator.userAgent.includes("Windows") ? "Win" : "Mac"
      ].join("||");
      const fallbackId = simpleHash(deviceInfo);
      resolve(fallbackId); // Trả về ngay lập tức
      chrome.storage.local.set({
        deviceId: fallbackId
      }, () => {
        chrome.storage.sync.set({
          deviceId: fallbackId
        });
      });
    }
  });
}
// Encrypt data
function encryptData(data, secret) {
  try {
    const encoder = new TextEncoder();
    const dataBytes = encoder.encode(JSON.stringify(data));
    const hmac = new Uint8Array(32);
    let checkSum = 0;
    for (let i = 0; i < dataBytes.length; i++) {
      const byte = dataBytes[i] ^ secret[i % secret.length];
      hmac[i % 32] ^= byte;
      checkSum += byte;
    }
    // Integrity check
    if (checkSum % 0x7 !== 0x3) throw new Error("Integrity check failed");
    // Dummy operations
    let dummy = checkSum;
    for (let i = 0; i < 4; i++) dummy = (dummy ^ i) >> (i % 2);
    return btoa(String.fromCharCode(...hmac));
  } catch (error) {
    handleError("Error encrypting data:", error);
    return "";
  }
}
// Check key format
function isValidKeyFormat(activationKey) {
  try {
    const decodedKey = atob(activationKey);
    const parts = decodedKey.split(":");
    if (parts.length !== 3) return false;
    const [signature, type, expiry] = parts;
    if (!signature || !type || !expiry) return false;
    if (!["yearly", "permanent", "custom"].includes(type)) return false;
    if ((type === "yearly" || type === "custom") && isNaN(parseInt(expiry))) return false;
    // Dummy check for obfuscation
    let dummy = 0;
    for (let i = 0; i < signature.length; i++) dummy += signature.charCodeAt(i) ^ i;
    return true;
  } catch (error) {
    return false;
  }
}
// Initialize CryptoKey
async function getCryptoKey(secret) {
  if (cachedCryptoKey) {
    console.log("Debug: Using cached CryptoKey");
    return cachedCryptoKey;
  }
  console.time("ImportCryptoKey");
  try {
    cachedCryptoKey = await crypto.subtle.importKey("raw", secret, {
        name: "HMAC",
        hash: "SHA-512"
      }, false,
      ["sign"]);
    console.log("Debug: Created new CryptoKey");
    // Dummy operations
    let dummy = 0;
    for (let i = 0; i < 8; i++) dummy += (i ^ secret[i % secret.length]) << (i % 3);
  } catch (error) {
    handleError("Error importing CryptoKey:", error);
    throw error;
  } finally {
    console.timeEnd("ImportCryptoKey");
  }
  return cachedCryptoKey;
}
// Log suspicious activity
async function logSuspiciousActivity(event, details) {
  console.time("LogSuspiciousActivity");
  try {
    const deviceId = await generateDeviceId();
    const logEntry = {
      event,
      details,
      timestamp: Date.now(),
      deviceId
    };
    // Sử dụng bộ nhớ đệm tạm thời để giảm độ trễ
    let logs = trialCache.suspiciousLogs || [];
    logs.push(logEntry);
    trialCache.suspiciousLogs = logs;
    // Kiểm tra và khởi tạo lockedDevices nếu chưa tồn tại
    let lockedDevices = await new Promise((resolve) => {
      chrome.storage.sync.get(["lockedDevices"], (result) => resolve(result.lockedDevices || []));
    });
    // Chỉ khóa vĩnh viễn nếu vượt ngưỡng logs (>3) và thiết bị chưa bị khóa
    if (logs.length > 3 && !lockedDevices.includes(deviceId)) {
      lockedDevices.push(deviceId);
      trialCache.trialLocked = true;
      trialCache.permanentLock = true;
      // Đồng bộ hóa với storage sau khi khóa
      await Promise.all([
        new Promise((resolve) => {
          chrome.storage.local.set({
            trialLocked: true,
            suspiciousLogs: logs
          }, () => {
            if (chrome.runtime.lastError) {
              console.warn("Lỗi lưu vào local storage:", chrome.runtime.lastError);
            }
            resolve();
          });
        }),
        new Promise((resolve) => {
          chrome.storage.sync.set({
            permanentLock: true,
            suspiciousLogs: logs,
            lockedDevices: lockedDevices
          }, () => {
            if (chrome.runtime.lastError) {
              console.warn("Lỗi đồng bộ sang sync storage:", chrome.runtime.lastError);
            }
            resolve();
          });
        })
      ]);
      console.warn("Thiết bị bị khóa vĩnh viễn do hoạt động đáng ngờ!");
      console.timeEnd("LogSuspiciousActivity");
      return;
    }
    // Lưu log vào storage mà không làm chậm quá trình
    await Promise.all([
      new Promise((resolve) => {
        chrome.storage.local.set({
          suspiciousLogs: logs
        }, () => {
          if (chrome.runtime.lastError) {
            console.warn("Lỗi lưu vào local storage:", chrome.runtime.lastError);
          }
          resolve();
        });
      }),
      new Promise((resolve) => {
        chrome.storage.sync.set({
          suspiciousLogs: logs,
          lockedDevices: lockedDevices
        }, () => {
          if (chrome.runtime.lastError) {
            console.warn("Lỗi đồng bộ sang sync storage:", chrome.runtime.lastError);
          }
          resolve();
        });
      })
    ]);
    console.timeEnd("LogSuspiciousActivity");
  } catch (error) {
    debugLog("Lỗi ghi log hoạt động đáng ngờ:", error);
    console.timeEnd("LogSuspiciousActivity");
  }
}
// Thay thế console.debug trong fetchServerTime
async function fetchServerTime() {
  console.time("FetchServerTime");
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 450);
    const fetchWithTimeout = async (url, options = {}) => {
      try {
        const response = await fetch(url, {
          ...options,
          signal: controller.signal
        });
        const dateHeader = response.headers.get('Date');
        if (dateHeader) {
          const serverTime = new Date(dateHeader).getTime();
          if (!isNaN(serverTime)) return serverTime;
        }
        return null;
      } catch (error) {
        if (error.name === 'AbortError') return null;
        debugLog(`Error fetching from ${url}:`, error);
        return null;
      }
    };
    const sources = [
      fetchWithTimeout('https://www.cloudflare.com/cdn-cgi/trace', {
        method: 'GET'
      }),
      fetchWithTimeout('https://www.youtube.com', {
        method: 'HEAD'
      }),
      fetchWithTimeout('https://time.google.com', {
        method: 'HEAD'
      })
    ];
    const serverTime = await Promise.race(sources.filter(p => p !== null).map(async (promise, index) => {
      const result = await promise;
      if (result && !isNaN(result)) {
        clearTimeout(timeout);
        return result;
      }
      if (index === sources.length - 1) {
        throw new Error("All sources failed");
      }
      return null;
    }));
    if (serverTime) {
      console.timeEnd("FetchServerTime");
      return serverTime;
    }
    const deviceId = await generateDeviceId();
    await logSuspiciousActivity("server_time_fetch_failed", {
      deviceId,
      sources
    });
    debugLog("No valid server time from any source, falling back to system time");
    console.timeEnd("FetchServerTime");
    return Date.now();
  } catch (error) {
    const deviceId = await generateDeviceId();
    await logSuspiciousActivity("server_time_fetch_error", {
      deviceId,
      error: error.message
    });
    debugLog("Error fetching server time, falling back to system time:", error);
    console.timeEnd("FetchServerTime");
    return Date.now();
  }
}
// Update last access time
async function updateLastAccessTime() {
  const currentTime = Date.now();
  await new Promise((resolve) => {
    chrome.storage.local.set({
      lastAccessTime: currentTime
    }, () => {
      chrome.storage.sync.set({
        lastAccessTime: currentTime
      }, () => {
        if (chrome.runtime.lastError) {
          console.warn("Error syncing lastAccessTime to sync storage:", chrome.runtime.lastError);
        }
        resolve();
      });
    });
  });
}
// Verify activation key (optimized with Web Crypto API and cache)
async function verifyActivation(activationKey, deviceId) {
  console.time("VerifyActivation");
  try {
    // Kiểm tra thời gian hệ thống so với thời gian server
    let serverTime;
    try {
      serverTime = await fetchServerTime();
    } catch (error) {
      console.timeEnd("VerifyActivation");
      return {
        valid: false,
        message: "Unable to retrieve server time! Please check your network connection."
      };
    }
    const systemTime = Date.now();
    const maxAllowedDrift = 300 * 1000; // 5 phút: chuẩn bảo mật phổ biến (Kerberos/OAuth), vẫn cho phép drift tự nhiên nhỏ
    if (Math.abs(systemTime - serverTime) > maxAllowedDrift) {
      await logSuspiciousActivity("system_time_drift_detected_at_activation", {
        systemTime,
        serverTime,
        deviceId
      });
      console.timeEnd("VerifyActivation");
      return {
        valid: false,
        message: "System time is incorrect! Please adjust your system time to match the current time."
      };
    }
    // Check cache
    if (activationCache.key === activationKey && activationCache.deviceId === deviceId && Date.now() - activationCache.timestamp < CONFIG.CACHE_TIMEOUT) {
      console.log("Debug: Using cached verification result");
      console.timeEnd("VerifyActivation");
      return activationCache.result;
    }
    // Early format check
    if (!isValidKeyFormat(activationKey)) {
      console.timeEnd("VerifyActivation");
      return {
        valid: false,
        message: "Invalid key format!"
      };
    }
    const decodedKey = atob(activationKey);
    const [signature, type, expiry] = decodedKey.split(":");
    const data = {
      deviceId,
      type,
      expiry: parseInt(expiry)
    };
    const dataStr = JSON.stringify(data);
    // Generate HMAC-SHA512 signature with Web Crypto API
    const secretKey = await getCryptoKey(CONFIG.SECRET);
    const encoder = new TextEncoder();
    const signatureBuffer = await crypto.subtle.sign("HMAC", secretKey, encoder.encode(dataStr));
    const expectedSignature = btoa(String.fromCharCode(...new Uint8Array(signatureBuffer)));
    if (signature !== expectedSignature) {
      console.timeEnd("VerifyActivation");
      return {
        valid: false,
        message: "Invalid activation key!"
      };
    }
    if (type !== "yearly" && type !== "permanent" && type !== "custom") {
      console.timeEnd("VerifyActivation");
      return {
        valid: false,
        message: "Invalid key type!"
      };
    }
    const expiryDate = parseInt(expiry, 10);
    if ((type === "yearly" || type === "custom") && serverTime > expiryDate) {
      console.timeEnd("VerifyActivation");
      return {
        valid: false,
        message: "The key has expired!"
      };
    }
    // Store in cache
    activationCache = {
      key: activationKey,
      deviceId: deviceId,
      result: {
        valid: true,
        type,
        expiry: type === "permanent" ? null : expiryDate
      },
      timestamp: serverTime
    };
    console.timeEnd("VerifyActivation");
    return activationCache.result;
  } catch (error) {
    handleError("Error verifying the key:", error);
    console.timeEnd("VerifyActivation");
    return {
      valid: false,
      message: "Error verifying the key! Please try again."
    };
  }
}
async function verifyTrial(deviceId, trialData) {
  console.time("VerifyTrial");
  try {
    // Kiểm tra và khởi tạo lockedDevices nếu chưa tồn tại
    let lockedDevices = await new Promise((resolve) => {
      chrome.storage.sync.get(["lockedDevices"], (result) => resolve(result.lockedDevices || []));
    });
    if (!Array.isArray(lockedDevices)) {
      lockedDevices = [];
      await new Promise((resolve) => {
        chrome.storage.sync.set({
          lockedDevices: lockedDevices
        }, resolve);
      });
    }
    // Kiểm tra nếu thiết bị đã bị khóa vĩnh viễn
    if (lockedDevices.includes(deviceId)) {
      console.timeEnd("VerifyTrial");
      return {
        valid: false,
        message: "This device has been permanently locked due to previous suspicious activity!"
      };
    }
    // Kiểm tra permanentLock
    const permanentLock = await new Promise((resolve) => {
      chrome.storage.sync.get(["permanentLock"], (result) => resolve(result.permanentLock || false));
    });
    if (permanentLock) {
      if (!lockedDevices.includes(deviceId)) {
        lockedDevices.push(deviceId);
        await new Promise((resolve) => {
          chrome.storage.sync.set({
            lockedDevices: lockedDevices
          }, resolve);
        });
      }
      console.timeEnd("VerifyTrial");
      return {
        valid: false,
        message: "The trial has been permanently locked due to suspicious activity!"
      };
    }
    // Lấy thời gian server
    let serverTime;
    try {
      serverTime = await fetchServerTime();
    } catch (error) {
      if (!lockedDevices.includes(deviceId)) {
        lockedDevices.push(deviceId);
        await new Promise((resolve) => {
          chrome.storage.sync.set({
            lockedDevices: lockedDevices
          }, resolve);
        });
      }
      await new Promise((resolve) => {
        chrome.storage.local.set({
          trialLocked: true
        }, () => {
          chrome.storage.sync.set({
            permanentLock: true
          }, resolve);
        });
      });
      console.timeEnd("VerifyTrial");
      return {
        valid: false,
        message: "Unable to verify trial due to failure in retrieving server time! The device has been locked."
      };
    }
    // Kiểm tra thời gian hệ thống
    const systemTime = Date.now();
    const maxAllowedDrift = 300 * 1000; // 5 phút: chuẩn bảo mật phổ biến (Kerberos/OAuth), vẫn cho phép drift tự nhiên nhỏ
    if (Math.abs(systemTime - serverTime) > maxAllowedDrift) {
      await logSuspiciousActivity("system_time_drift_detected", {
        systemTime,
        serverTime,
        deviceId
      });
      if (!lockedDevices.includes(deviceId)) {
        lockedDevices.push(deviceId);
        await new Promise((resolve) => {
          chrome.storage.sync.set({
            lockedDevices: lockedDevices
          }, resolve);
        });
      }
      await new Promise((resolve) => {
        chrome.storage.local.set({
          trialLocked: true
        }, () => {
          chrome.storage.sync.set({
            permanentLock: true
          }, resolve);
        });
      });
      console.timeEnd("VerifyTrial");
      return {
        valid: false,
        message: "System time is incorrect! Please adjust your system time to match the current time."
      };
    }
    // Kiểm tra cache
    if (trialCache.deviceId === deviceId && Date.now() - trialCache.timestamp < CONFIG.CACHE_TIMEOUT && trialCache.result?.valid && Math.abs(serverTime - trialCache.timestamp) < maxAllowedDrift) {
      console.log("Debug: Using cached trial verification result");
      console.timeEnd("VerifyTrial");
      return trialCache.result;
    }
    // Kiểm tra dữ liệu thử nghiệm
    let isDataChanged = false;
    if (!trialData || !trialData.startTime || !trialData.signature || !trialData.lockSignature) {
      const syncData = await new Promise((resolve) => {
        chrome.storage.sync.get(["trialBackup"], (result) => resolve(result.trialBackup || null));
      });
      if (syncData && syncData.startTime && syncData.signature && syncData.lockSignature) {
        trialData = syncData;
        await new Promise((resolve) => {
          chrome.storage.local.set({
            trial: trialData
          }, resolve);
        });
      } else {
        isDataChanged = true;
        await logSuspiciousActivity("missing_trial_data", {
          deviceId
        });
        console.timeEnd("VerifyTrial");
        return {
          valid: false,
          message: "Trial data not found! Please initialize a new trial."
        };
      }
    }
    // Kiểm tra installTimestamp
    const installTimestamp = await new Promise((resolve) => {
      chrome.storage.sync.get(["installTimestamp"], (result) => resolve(result.installTimestamp || 0));
    });
    if (installTimestamp && serverTime > installTimestamp + CONFIG.TRIAL_DURATION) {
      if (!lockedDevices.includes(deviceId)) {
        lockedDevices.push(deviceId);
        await new Promise((resolve) => {
          chrome.storage.sync.set({
            lockedDevices: lockedDevices
          }, resolve);
        });
      }
      await new Promise((resolve) => {
        chrome.storage.local.set({
          trialLocked: true
        }, () => {
          chrome.storage.sync.set({
            permanentLock: true
          }, resolve);
        });
      });
      console.timeEnd("VerifyTrial");
      return {
        valid: false,
        message: "The trial has expired based on the installation timestamp! The device has been locked."
      };
    }
    // Kiểm tra trialLocked
    const locked = await new Promise((resolve) => {
      chrome.storage.local.get(["trialLocked"], (result) => resolve(result.trialLocked || false));
    });
    if (locked) {
      if (!lockedDevices.includes(deviceId)) {
        lockedDevices.push(deviceId);
        await new Promise((resolve) => {
          chrome.storage.sync.set({
            lockedDevices: lockedDevices
          }, resolve);
        });
      }
      console.timeEnd("VerifyTrial");
      return {
        valid: false,
        message: "The trial has been locked due to suspicious activity! The device has been locked."
      };
    }
    // Xác minh chữ ký HMAC-SHA512
    const data = {
      deviceId,
      startTime: trialData.startTime
    };
    const dataStr = JSON.stringify(data);
    const secretKey = await getCryptoKey(CONFIG.SECRET);
    const encoder = new TextEncoder();
    const signatureBuffer = await crypto.subtle.sign("HMAC", secretKey, encoder.encode(dataStr));
    const expectedSignature = btoa(String.fromCharCode(...new Uint8Array(signatureBuffer)));
    // Xác minh lockSignature
    const lockData = {
      deviceId,
      startTime: trialData.startTime,
      signature: trialData.signature
    };
    const lockDataStr = JSON.stringify(lockData);
    const lockSignatureBuffer = await crypto.subtle.sign("HMAC", secretKey, encoder.encode(lockDataStr));
    const expectedLockSignature = btoa(String.fromCharCode(...new Uint8Array(lockSignatureBuffer)));
    if (trialData.signature !== expectedSignature || trialData.lockSignature !== expectedLockSignature) {
      await logSuspiciousActivity("invalid_trial_signature", {
        deviceId,
        signature: trialData.signature
      });
      if (!lockedDevices.includes(deviceId)) {
        lockedDevices.push(deviceId);
        await new Promise((resolve) => {
          chrome.storage.sync.set({
            lockedDevices: lockedDevices
          }, resolve);
        });
      }
      await new Promise((resolve) => {
        chrome.storage.local.set({
          trialLocked: true
        }, () => {
          chrome.storage.sync.set({
            permanentLock: true
          }, resolve);
        });
      });
      console.timeEnd("VerifyTrial");
      return {
        valid: false,
        message: "Invalid trial signature! The device has been locked."
      };
    }
    const startTime = parseInt(trialData.startTime, 10);
    if (isNaN(startTime) || serverTime < startTime) {
      await logSuspiciousActivity("invalid_trial_start_time", {
        deviceId,
        startTime,
        serverTime
      });
      if (!lockedDevices.includes(deviceId)) {
        lockedDevices.push(deviceId);
        await new Promise((resolve) => {
          chrome.storage.sync.set({
            lockedDevices: lockedDevices
          }, resolve);
        });
      }
      await new Promise((resolve) => {
        chrome.storage.local.set({
          trialLocked: true
        }, () => {
          chrome.storage.sync.set({
            permanentLock: true
          }, resolve);
        });
      });
      console.timeEnd("VerifyTrial");
      return {
        valid: false,
        message: "Invalid trial start time! The device has been locked."
      };
    }
    // Kiểm tra thời gian hết hạn
    if (serverTime > startTime + CONFIG.TRIAL_DURATION) {
      if (!lockedDevices.includes(deviceId)) {
        lockedDevices.push(deviceId);
        await new Promise((resolve) => {
          chrome.storage.sync.set({
            lockedDevices: lockedDevices
          }, resolve);
        });
      }
      await new Promise((resolve) => {
        chrome.storage.local.set({
          trialLocked: true
        }, () => {
          chrome.storage.sync.set({
            permanentLock: true
          }, resolve);
        });
      });
      console.timeEnd("VerifyTrial");
      return {
        valid: false,
        message: "The trial has expired! The device has been locked."
      };
    }
    // Kiểm tra thao túng thời gian hệ thống
    const lastAccessTime = await new Promise((resolve) => {
      chrome.storage.local.get(["lastAccessTime"], (result) => resolve(result.lastAccessTime || 0));
    });
    const syncLastAccessTime = await new Promise((resolve) => {
      chrome.storage.sync.get(["lastAccessTime"], (result) => resolve(result.lastAccessTime || 0));
    });
    const lastServerTime = await new Promise((resolve) => {
      chrome.storage.local.get(["lastServerTime"], (result) => resolve(result.lastServerTime || 0));
    });
    if (
      (lastAccessTime && Math.abs(systemTime - lastAccessTime) > maxAllowedDrift) || (syncLastAccessTime && Math.abs(systemTime - syncLastAccessTime) > maxAllowedDrift) || (lastServerTime && Math.abs(systemTime - lastServerTime) > maxAllowedDrift)) {
      await logSuspiciousActivity("system_time_drift_detected", {
        systemTime,
        lastAccessTime,
        syncLastAccessTime,
        lastServerTime,
        installTimestamp
      });
      if (!lockedDevices.includes(deviceId)) {
        lockedDevices.push(deviceId);
        await new Promise((resolve) => {
          chrome.storage.sync.set({
            lockedDevices: lockedDevices
          }, resolve);
        });
      }
      await new Promise((resolve) => {
        chrome.storage.local.set({
          trialLocked: true
        }, () => {
          chrome.storage.sync.set({
            permanentLock: true
          }, resolve);
        });
      });
      console.timeEnd("VerifyTrial");
      return {
        valid: false,
        message: "System time is incorrect! Please adjust your system time to match the current time."
      };
    }
    // Cập nhật thời gian truy cập cuối
    await updateLastAccessTime(serverTime);
    // Lưu vào cache
    trialCache = {
      deviceId: deviceId,
      result: {
        valid: true,
        startTime,
        expiry: startTime + CONFIG.TRIAL_DURATION
      },
      timestamp: serverTime
    };
    console.timeEnd("VerifyTrial");
    return trialCache.result;
  } catch (error) {
    handleError("Error verifying the trial:", error);
    console.timeEnd("VerifyTrial");
    return {
      valid: false,
      message: "Error verifying the trial! Please try again."
    };
  }
}
// === HIDDEN FINGERPRINT FILE + QUANTUM ENTROPY + INDEXEDDB (OFFLINE SIÊU CẤP) ===
// === THAY THẾ createHiddenFingerprintFile() ===
async function createHiddenFingerprintFile() {
  const success = await createSecureBackups();
  if (success) {
    startBackupSync();
  }
  return success;
}
// === THAY THẾ HOÀN TOÀN verifyHiddenFingerprint() ===
async function verifyHiddenFingerprint() {
  const result = await verifyAndRestoreFingerprint();
  // Nếu bị khôi phục từ backup → có nghĩa là đã cố xóa file chính
  if (result.restored) {
    await logSuspiciousActivity("fingerprint_restored_suspicious", {
      from: result.source,
      reason: "Main fingerprint missing → restored from backup"
    });
    console.warn(`CẢNH BÁO: Phát hiện hành vi xóa fingerprint → Khôi phục từ ${result.source}`);
  }
  // NẾU KHÔNG CÓ FINGERPRINT CHÍNH + KHÔNG PHẢI LẦN ĐẦU → GIAN LẬN 100%
  if (!result.valid && !result.firstTime) {
    const deviceId = await generateDeviceId();
    await logSuspiciousActivity("reinstall_attempt_blocked", {
      deviceId
    });
    // KHÓA VĨNH VIỄN THIẾT BỊ
    const lockedDevices = await new Promise(r => chrome.storage.sync.get(["lockedDevices"], res => r(res.lockedDevices || [])));
    if (!lockedDevices.includes(deviceId)) {
      lockedDevices.push(deviceId);
      await chrome.storage.sync.set({
        lockedDevices
      });
    }
    await Promise.all([
      chrome.storage.local.set({
        trialLocked: true
      }),
      chrome.storage.sync.set({
        permanentLock: true
      })
    ]);
    showNotification("Phát hiện gian lận! Thiết bị đã bị khóa vĩnh viễn.");
    // Reload ngay lập tức → người dùng thấy chết luôn
    setTimeout(() => chrome.runtime.reload(), 1500);
    return {
      valid: false,
      blocked: true,
      reason: "reinstall_attempt"
    };
  }
  // Nếu hợp lệ → bắt đầu backup định kỳ
  if (result.valid && !result.firstTime) {
    startBackupSync();
  }
  return result;
}
// 3. Thu thập Entropy lượng tử từ trình duyệt (không cần server)
async function gatherQuantumEntropy() {
  const sources = [];
  const samples = 128;
  for (let i = 0; i < samples; i++) {
    const start = performance.now();
    crypto.getRandomValues(new Uint8Array(1));
    const end = performance.now();
    sources.push((end - start) * 1000);
  }
  const canvas = document.createElement("canvas");
  canvas.width = 64;
  canvas.height = 64;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#f60";
  ctx.fillRect(0, 0, 64, 64);
  ctx.font = "13px Arial";
  ctx.fillText("🔐", 10, 30);
  const canvasData = canvas.toDataURL();
  const canvasHash = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(canvasData));
  sources.push(...new Uint8Array(canvasHash));
  let audioEntropy = 0;
  try {
    const audioCtx = new(window.OfflineAudioContext || window.webkitOfflineAudioContext)(1, 5000, 44100);
    const oscillator = audioCtx.createOscillator();
    oscillator.type = "triangle";
    oscillator.frequency.value = 10000;
    const compressor = audioCtx.createDynamicsCompressor();
    oscillator.connect(compressor);
    compressor.connect(audioCtx.destination);
    oscillator.start(0);
    const buffer = await audioCtx.startRendering();
    const channel = buffer.getChannelData(0);
    for (let i = 0; i < 100; i++) audioEntropy += channel[i] || 0;
  } catch (e) {
    /* ignore */
  }
  sources.push(audioEntropy);
  const mathNoise = Math.atan2(performance.now(), Math.random() * 1e9) * 1e6;
  sources.push(mathNoise);
  let seed = 0;
  for (const val of sources) seed = (seed ^ (val * 31)) >>> 0;
  const entropyArray = new Uint32Array(samples);
  for (let i = 0; i < samples; i++) {
    seed ^= seed << 13;
    seed ^= seed >> 17;
    seed ^= seed << 5;
    entropyArray[i] = seed;
  }
  return {
    seed: Array.from(entropyArray).join(","),
    hash: await crypto.subtle.digest("SHA-512", new TextEncoder().encode(Array.from(entropyArray).join(",")))
  };
}
// 4. Tính checksum cho fingerprint
async function computeFingerprintChecksum(deviceId, firstInstall, entropySeed) {
  const data = `${deviceId}:${firstInstall}:${entropySeed}`;
  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey("raw", CONFIG.SECRET, {
    name: "HMAC",
    hash: "SHA-512"
  }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, encoder.encode(data));
  return btoa(String.fromCharCode(...new Uint8Array(sig))).slice(0, 64);
}
// 5. Ký và xác minh fingerprint
async function signFingerprint(deviceId, firstInstall, entropySeed) {
  const data = `${deviceId}:${firstInstall}:${entropySeed}`;
  const encoder = new TextEncoder();
  const key = await getCryptoKey(CONFIG.SECRET);
  const sig = await crypto.subtle.sign("HMAC", key, encoder.encode(data));
  return btoa(String.fromCharCode(...new Uint8Array(sig)));
}
async function verifyFingerprintSignature(deviceId, firstInstall, entropySeed, signature) {
  const data = `${deviceId}:${firstInstall}:${entropySeed}`;
  const encoder = new TextEncoder();
  const key = await getCryptoKey(CONFIG.SECRET);
  const sigBuffer = await crypto.subtle.sign("HMAC", key, encoder.encode(data));
  const expectedSig = btoa(String.fromCharCode(...new Uint8Array(sigBuffer)));
  return signature === expectedSig;
}
// 6. IndexedDB Helper (ẩn, bền vững, không bị xóa khi uninstall)
function openIndexedDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("PitchShifterSecure", 1);
    request.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains("fingerprint")) {
        db.createObjectStore("fingerprint", {
          keyPath: "id"
        });
      }
    };
    request.onsuccess = (e) => resolve(e.target.result);
    request.onerror = (e) => reject(e.target.error);
  });
}
async function saveToIndexedDB(dbName, storeName, data) {
  const db = await openIndexedDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readwrite");
    const store = tx.objectStore(storeName);
    store.put({
      id: "main",
      ...data
    });
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
async function getFromIndexedDB(dbName, storeName) {
  const db = await openIndexedDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readonly");
    const store = tx.objectStore(storeName);
    const request = store.get("main");
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error);
  });
}
async function initializeTrial(deviceId) {
  console.time("InitializeTrial");
  try {
    // === BƯỚC 1: KIỂM TRA FILE ẨN (ANTI-REINSTALL) ===
    const fpCheck = await verifyHiddenFingerprint();
    if (!fpCheck.valid && !fpCheck.firstTime) {
      await logSuspiciousActivity("reinstall_attempt_detected", {
        deviceId,
        fpCheck
      });
      console.timeEnd("InitializeTrial");
      return {
        valid: false,
        message: "This device has already used the trial! Purchase a key to continue."
      };
    }
    // === BƯỚC 2: TẠO FILE ẨN NẾU LẦN ĐẦU ===
    if (fpCheck.firstTime) {
      const created = await createHiddenFingerprintFile();
      if (!created) {
        console.timeEnd("InitializeTrial");
        return {
          valid: false,
          message: "Failed to initialize security system!"
        };
      }
    }
    // === TIẾP TỤC NHƯ GỐC (giữ nguyên toàn bộ logic) ===
    let lockedDevices = await new Promise((resolve) => {
      chrome.storage.sync.get(["lockedDevices"], (result) => resolve(result.lockedDevices || []));
    });
    if (!Array.isArray(lockedDevices)) {
      lockedDevices = [];
      await new Promise((resolve) => {
        chrome.storage.sync.set({
          lockedDevices
        }, resolve);
      });
    }
    if (lockedDevices.includes(deviceId)) {
      await new Promise((resolve) => {
        chrome.storage.local.set({
          trialLocked: true
        }, () => {
          chrome.storage.sync.set({
            permanentLock: true
          }, resolve);
        });
      });
      console.timeEnd("InitializeTrial");
      return {
        valid: false,
        message: "This device has been permanently locked due to previous suspicious activity!"
      };
    }
    let serverTime;
    try {
      serverTime = await fetchServerTime();
    } catch (error) {
      if (!lockedDevices.includes(deviceId)) {
        lockedDevices.push(deviceId);
        await new Promise((resolve) => {
          chrome.storage.sync.set({
            lockedDevices
          }, resolve);
        });
      }
      await new Promise((resolve) => {
        chrome.storage.local.set({
          trialLocked: true
        }, () => {
          chrome.storage.sync.set({
            permanentLock: true
          }, resolve);
        });
      });
      console.timeEnd("InitializeTrial");
      return {
        valid: false,
        message: "Unable to initialize trial due to failure in retrieving server time! The device has been locked."
      };
    }
    const systemTime = Date.now();
    const maxAllowedDrift = 24 * 60 * 60 * 1000;
    if (Math.abs(systemTime - serverTime) > maxAllowedDrift) {
      await logSuspiciousActivity("system_time_drift_detected_at_trial_init", {
        systemTime,
        serverTime,
        deviceId
      });
      if (!lockedDevices.includes(deviceId)) {
        lockedDevices.push(deviceId);
        await new Promise((resolve) => {
          chrome.storage.sync.set({
            lockedDevices
          }, resolve);
        });
      }
      await new Promise((resolve) => {
        chrome.storage.local.set({
          trialLocked: true
        }, () => {
          chrome.storage.sync.set({
            permanentLock: true
          }, resolve);
        });
      });
      console.timeEnd("InitializeTrial");
      return {
        valid: false,
        message: "System time is incorrect! Please adjust your system time to match the current time."
      };
    }
    let trialData = await new Promise((resolve) => {
      chrome.storage.local.get(["trial"], (result) => resolve(result.trial || null));
    });
    const syncData = await new Promise((resolve) => {
      chrome.storage.sync.get(["trialBackup"], (result) => resolve(result.trialBackup || null));
    });
    if (syncData && syncData.startTime && syncData.signature && syncData.lockSignature) {
      trialData = syncData;
      await new Promise((resolve) => {
        chrome.storage.local.set({
          trial: trialData
        }, resolve);
      });
    }
    if (trialData) {
      const verification = await verifyTrial(deviceId, trialData);
      if (verification.valid) {
        console.timeEnd("InitializeTrial");
        return verification;
      } else {
        console.timeEnd("InitializeTrial");
        return {
          valid: false,
          message: verification.message
        };
      }
    }
    const installTimestamp = await new Promise((resolve) => {
      chrome.storage.sync.get(["installTimestamp"], (result) => resolve(result.installTimestamp || 0));
    });
    if (installTimestamp && serverTime > installTimestamp + CONFIG.TRIAL_DURATION) {
      if (!lockedDevices.includes(deviceId)) {
        lockedDevices.push(deviceId);
        await new Promise((resolve) => {
          chrome.storage.sync.set({
            lockedDevices
          }, resolve);
        });
      }
      await new Promise((resolve) => {
        chrome.storage.local.set({
          trialLocked: true
        }, () => {
          chrome.storage.sync.set({
            permanentLock: true
          }, resolve);
        });
      });
      console.timeEnd("InitializeTrial");
      return {
        valid: false,
        message: "The trial has expired based on the installation timestamp! The device has been locked."
      };
    }
    // === TẠO TRIAL MỚI (CHỈ LẦN ĐẦU) ===
    const startTime = serverTime;
    const data = {
      deviceId,
      startTime
    };
    const dataStr = JSON.stringify(data);
    const secretKey = await getCryptoKey(CONFIG.SECRET);
    const encoder = new TextEncoder();
    const signatureBuffer = await crypto.subtle.sign("HMAC", secretKey, encoder.encode(dataStr));
    const signature = btoa(String.fromCharCode(...new Uint8Array(signatureBuffer)));
    const lockData = {
      deviceId,
      startTime,
      signature
    };
    const lockDataStr = JSON.stringify(lockData);
    const lockSignatureBuffer = await crypto.subtle.sign("HMAC", secretKey, encoder.encode(lockDataStr));
    const lockSignature = btoa(String.fromCharCode(...new Uint8Array(lockSignatureBuffer)));
    const newTrialData = {
      startTime,
      signature,
      lockSignature
    };
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({
        trial: newTrialData
      }, () => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve();
      });
    });
    await new Promise((resolve, reject) => {
      chrome.storage.sync.set({
        trialBackup: newTrialData,
        installTimestamp: startTime,
        lockedDevices
      }, () => {
        if (chrome.runtime.lastError) console.warn("Error syncing trial to sync storage:", chrome.runtime.lastError);
        resolve();
      });
    });
    await updateLastAccessTime(serverTime);
    console.timeEnd("InitializeTrial");
    return {
      valid: true,
      startTime,
      expiry: startTime + CONFIG.TRIAL_DURATION
    };
  } catch (error) {
    handleError("Error initializing the trial:", error);
    console.timeEnd("InitializeTrial");
    return {
      valid: false,
      message: "Error initializing the trial! Please try again."
    };
  }
}
async function checkActivation() {
  console.time("CheckActivation");
  return new Promise((resolve) => {
    // === KIỂM TRA FILE ẨN TRƯỚC KHI CHO PHÉP BẤT KỲ TRẠNG THÁI NÀO ===
    verifyHiddenFingerprint().then(fpCheck => {
      if (!fpCheck.valid && !fpCheck.firstTime) {
        console.timeEnd("CheckActivation");
        return resolve({
          activated: false,
          message: "This device has already used the trial! Purchase a key to continue."
        });
      }
      // === TIẾP TỤC NHƯ GỐC (giữ nguyên 100% logic) ===
      chrome.storage.local.get(["isActivated", "activation", "deviceId", "trial"], async (result) => {
        const {
          isActivated,
          activation,
          deviceId,
          trial
        } = result;
        const syncActivation = await new Promise((resolve) => {
          chrome.storage.sync.get(["activationBackup"], (result) => resolve(result.activationBackup || null));
        });
        if (syncActivation && syncActivation.activationKey && syncActivation.deviceId) {
          await new Promise((resolve) => {
            chrome.storage.local.set({
              activation: syncActivation,
              isActivated: true
            }, resolve);
          });
          if (!activation || activation.activationKey !== syncActivation.activationKey) {
            result.activation = syncActivation;
            result.isActivated = true;
          }
        }
        if (isActivated && activation && deviceId) {
          const verification = await verifyActivation(activation.activationKey, deviceId);
          if (!verification.valid) {
            chrome.storage.local.remove(["activation", "isActivated"]);
            chrome.storage.sync.remove(["activationBackup"]);
            console.timeEnd("CheckActivation");
            return resolve({
              activated: false,
              message: verification.message
            });
          }
          const daysLeft = verification.expiry ? Math.ceil((verification.expiry - Date.now()) / (1000 * 60 * 60 * 24)) : null;
          await new Promise((resolve) => {
            chrome.storage.sync.set({
              activationBackup: activation
            }, resolve);
          });
          console.timeEnd("CheckActivation");
          return resolve({
            activated: true,
            type: verification.type,
            expiry: verification.expiry,
            daysLeft
          });
        }
        if (activation && deviceId) {
          const verification = await verifyActivation(activation.activationKey, deviceId);
          if (!verification.valid) {
            chrome.storage.local.remove(["activation", "isActivated"]);
            chrome.storage.sync.remove(["activationBackup"]);
            console.timeEnd("CheckActivation");
            return resolve({
              activated: false,
              message: verification.message
            });
          }
          chrome.storage.local.set({
            isActivated: true
          });
          await new Promise((resolve) => {
            chrome.storage.sync.set({
              activationBackup: activation
            }, resolve);
          });
          const daysLeft = verification.expiry ? Math.ceil((verification.expiry - Date.now()) / (1000 * 60 * 60 * 24)) : null;
          console.timeEnd("CheckActivation");
          return resolve({
            activated: true,
            type: verification.type,
            expiry: verification.expiry,
            daysLeft
          });
        }
        if (deviceId) {
          const trialVerification = await verifyTrial(deviceId, trial);
          if (trialVerification.valid) {
            const daysLeft = Math.ceil((trialVerification.expiry - Date.now()) / (1000 * 60 * 60 * 24));
            console.timeEnd("CheckActivation");
            return resolve({
              activated: true,
              type: "trial",
              expiry: trialVerification.expiry,
              daysLeft
            });
          } else {
            console.timeEnd("CheckActivation");
            return resolve({
              activated: false,
              message: trialVerification.message
            });
          }
        }
        console.timeEnd("CheckActivation");
        return resolve({
          activated: false
        });
      });
    }).catch(error => {
      handleError("Lỗi kiểm tra file ẩn trong checkActivation:", error);
      console.timeEnd("CheckActivation");
      return resolve({
        activated: false,
        message: "Security check failed!"
      });
    });
  });
}
// Save activation key to storage
async function saveActivation(deviceId, activationKey, type, expiry) {
  console.time("SaveActivation");
  try {
    const activationData = {
      deviceId,
      activationKey,
      type,
      expiry: expiry || null
    };
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({
        activation: activationData,
        isActivated: true
      }, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          chrome.storage.sync.set({
            activationBackup: activationData
          }, () => {
            if (chrome.runtime.lastError) {
              console.warn("Error syncing activation to sync storage:", chrome.runtime.lastError);
            }
            resolve(true);
          });
        }
      });
    });
    console.timeEnd("SaveActivation");
    return true;
  } catch (error) {
    handleError("Error saving activation key:", error);
    console.timeEnd("SaveActivation");
    return false;
  }
}
// Lock/unlock interface controls
function toggleControls(enabled) {
  const elements = ["enabled", "pitch", "playback-rate", "boost", "pan", "pitch-shift-type", "pitch-reset", "playback-rate-reset", "boost-reset", "pan-reset", "fav-icon", "fav-list-icon", "hold-btn", "refresh-btn", "preset-warm", "preset-bright", "preset-bass-heavy", "preset-vocal", "preset-pro-natural", "preset-karaoke-dynamic", "preset-rock-metal", "preset-smart-studio"];
  elements.forEach(id => {
    const element = document.getElementById(id);
    if (element) {
      element.disabled = !enabled;
      element.style.opacity = enabled ? "1" : "0.5";
      element.style.cursor = enabled ? "pointer" : "not-allowed";
    }
  });
}
// Get thumbnail URL for different platforms
function getThumbnailUrl(url) {
  // Kiểm tra tính hợp lệ của url
  const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
  if (typeof url !== 'string' || url.trim() === '') {
    if (isDebug) {
      console.warn('URL không hợp lệ trong getThumbnailUrl:', {
        url,
        caller: arguments.callee.caller?.name || 'unknown',
        timestamp: Date.now()
      });
    }
    return "icon48.png"; // Fallback nếu url không hợp lệ
  }
  // YouTube
  const youtubeMatch = url.match(/(?:youtube(?:-nocookie)?\.com\/(?:[^/\n\s]+\/\S+|(?:v|e(?:mbed)?|shorts)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
  if (youtubeMatch) {
    return `https://img.youtube.com/vi/${youtubeMatch[1]}/default.jpg`;
  }
  // Vimeo
  const vimeoMatch = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
  if (vimeoMatch) {
    return `https://vimeo.com/api/v2/video/${vimeoMatch[1]}.json`;
  }
  // SoundCloud (placeholder, as SoundCloud API may require additional handling)
  const soundcloudMatch = url.match(/soundcloud\.com\/[^\/]+\/[^\/]+/);
  if (soundcloudMatch) {
    return "icon48.png"; // Replace with actual SoundCloud thumbnail logic if available
  }
  // Fallback
  if (isDebug) {
    console.warn('Không tìm thấy thumbnail phù hợp cho URL:', {
      url,
      caller: arguments.callee.caller?.name || 'unknown',
      timestamp: Date.now()
    });
  }
  return "icon48.png";
}
// Fuzzy search for favorites with enhanced intelligence and performance
let searchCache = new Map();

function fuzzySearch(text, query, limit = 100) {
  const cacheKey = `${text}||${query}`;
  if (searchCache.has(cacheKey)) {
    return searchCache.get(cacheKey);
  }
  const normalizeText = (str) => {
    return str.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  };
  const textNormalized = normalizeText(text || "Unknown");
  const queryNormalized = normalizeText(query || "");
  if (!queryNormalized) return {
    score: 0,
    matches: []
  };
  let score = 0;
  let matches = [];
  let queryIndex = 0;
  let lastMatchIndex = -1;
  for (let i = 0; i < textNormalized.length && queryIndex < queryNormalized.length; i++) {
    if (textNormalized[i] === queryNormalized[queryIndex]) {
      score += 10;
      if (i === lastMatchIndex + 1) score += 5;
      if (lastMatchIndex !== -1) score -= (i - lastMatchIndex - 1) * 0.5;
      matches.push(i);
      lastMatchIndex = i;
      queryIndex++;
    } else {
      score -= 0.2;
    }
  }
  if (queryIndex < queryNormalized.length) return {
    score: -1,
    matches: []
  };
  if (matches[0] === 0) score += 15;
  if (matches.length === textNormalized.length) score += 20;
  score = Math.max(0, Math.min(score, 100));
  const result = {
    score,
    matches
  };
  searchCache.set(cacheKey, result);
  if (searchCache.size > 1000) searchCache.clear(); // Giới hạn cache
  return result;
}
// Periodic system time check (every 6 hours)
let periodicCheckInterval = null;

function startPeriodicTimeCheck() {
  if (periodicCheckInterval) {
    console.debug("Periodic time check already running");
    return;
  }
  periodicCheckInterval = setInterval(async () => {
    try {
      const activationStatus = await checkActivation();
      if (!activationStatus.activated) {
        console.debug("Skipping time check: Extension not activated");
        return;
      }
      const serverTime = await fetchServerTime();
      const systemTime = Date.now();
      const maxAllowedDrift = 300 * 1000; // 5 phút: chuẩn bảo mật phổ biến (Kerberos/OAuth), vẫn cho phép drift tự nhiên nhỏ
      // LƯU LẠI THỜI GIAN SERVER LẦN TRƯỚC ĐỂ SO SÁNH
      const lastServerTime = await new Promise(r => chrome.storage.local.get(["lastServerTime"], res => r(res.lastServerTime || 0)));
      let suspicious = false;
      let reason = "";
      // CASE 1: Lệch quá xa (cả tiến lẫn ngược)
      if (Math.abs(systemTime - serverTime) > maxAllowedDrift) {
        suspicious = true;
        reason = "time_drift_too_large";
      }
      // CASE 2: TUA TIẾN (tăng giờ lên tương lai quá xa)
      else if (lastServerTime > 0 && serverTime < lastServerTime - 60 * 60 * 1000) { // server giảm > 1 tiếng so với lần trước
        suspicious = true;
        reason = "server_time_went_backward"; // người dùng tua tiến rồi tua ngược lại
      }
      // CASE 3: TUA NGƯỢC (giảm giờ về quá khứ)
      else if (lastServerTime > 0 && serverTime > lastServerTime + 30 * 24 * 60 * 60 * 1000) { // tăng > 30 ngày so với lần trước
        suspicious = true;
        reason = "server_time_jumped_forward"; // tua tiến quá xa
      }
      if (suspicious) {
        const deviceId = await generateDeviceId();
        await logSuspiciousActivity("time_tampering_critical", {
          systemTime,
          serverTime,
          lastServerTime,
          drift: Math.abs(systemTime - serverTime),
          reason,
          deviceId
        });
        // KHÓA CHẾT LUÔN – KHÔNG THA THỨ
        const lockedDevices = await new Promise(r => chrome.storage.sync.get(["lockedDevices"], res => r(res.lockedDevices || [])));
        if (!lockedDevices.includes(deviceId)) {
          lockedDevices.push(deviceId);
          await chrome.storage.sync.set({
            lockedDevices
          });
        }
        await Promise.all([
          chrome.storage.local.set({
            trialLocked: true
          }),
          chrome.storage.sync.set({
            permanentLock: true
          })
        ]);
        showNotification("Phát hiện thao túng thời gian nghiêm trọng! Thiết bị đã bị khóa vĩnh viễn.");
        setTimeout(() => chrome.runtime.reload(), 1500);
        // DỪNG LUÔN VIỆC KIỂM TRA NỮA
        if (periodicCheckInterval) {
          clearInterval(periodicCheckInterval);
          periodicCheckInterval = null;
        }
        return;
      }
      // CẬP NHẬT lastServerTime CHO LẦN SAU
      await chrome.storage.local.set({
        lastServerTime: serverTime
      });
    } catch (error) {
      console.debug("Periodic time check failed:", error);
    }
  }, 6 * 60 * 60 * 1000); // 6 tiếng/lần
  // Dừng khi popup đóng
  port?.onDisconnect.addListener(() => {
    if (periodicCheckInterval) {
      clearInterval(periodicCheckInterval);
      periodicCheckInterval = null;
    }
  });
}
// Main initialization function
function init() {
  let transpose = true;
  let favorites = [];
  let currentUrl = null;
  let currentTabId = null;
  let currentSettings = {
    pitch: 0,
    playbackRate: 1,
    boost: 0.7,
    pan: 0,
    transpose: true,
    soundProfile: "proNatural"
  };
  let isHeld = false;
  let isActivated = false;
  // Get DOM elements
  const elements = {
    enabled: document.getElementById("enabled"),
    pitch: document.getElementById("pitch"),
    pitchValue: document.getElementById("pitch-value"),
    pitchShiftTypeSelect: document.getElementById("pitch-shift-type"),
    pitchReset: document.getElementById("pitch-reset"),
    playbackRate: document.getElementById("playback-rate"),
    playbackRateValue: document.getElementById("playback-rate-value"),
    playbackRateReset: document.getElementById("playback-rate-reset"),
    boost: document.getElementById("boost"),
    boostValue: document.getElementById("boost-value"),
    boostReset: document.getElementById("boost-reset"),
    pan: document.getElementById("pan"),
    panValue: document.getElementById("pan-value"),
    panReset: document.getElementById("pan-reset"),
    favIcon: document.getElementById("fav-icon"),
    favListIcon: document.getElementById("fav-list-icon"),
    songTitle: document.getElementById("song-title"),
    bpmValue: document.getElementById("bpm-value"),
    favoritesModal: document.getElementById("favorites-modal"),
    modalClose: document.getElementById("modal-close"),
    favoritesTableBody: document.getElementById("favorites-table-body"),
    exportBtn: document.getElementById("export-btn"),
    importBtn: document.getElementById("import-btn"),
    importFile: document.getElementById("import-file"),
    searchFavorites: document.getElementById("search-favorites"),
    clearAllFavorites: document.getElementById("clear-all-favorites"),
    themeToggle: document.getElementById("theme-toggle"),
    refreshBtn: document.getElementById("refresh-btn"),
    holdBtn: document.getElementById("hold-btn"),
    presetButtons: document.querySelectorAll(".preset-btn"),
    buyBtn: document.getElementById("buy-btn"),
    licenseStatus: document.getElementById("license-status"),
    activationModal: document.getElementById("activation-modal"),
    activationModalClose: document.getElementById("activation-modal-close"),
    deviceIdInput: document.getElementById("device-id"),
    copyDeviceIdBtn: document.getElementById("copy-device-id"),
    activationKeyInput: document.getElementById("activation-key"),
    activateBtn: document.getElementById("activate-btn"),
    activationError: document.getElementById("activation-error"),
    successModal: document.getElementById("success-modal"),
    successModalClose: document.getElementById("success-modal-close"),
    successModalOk: document.getElementById("success-modal-ok")
  };
  // Check DOM elements and log details
  for (const [key, value] of Object.entries(elements)) {
    if (!value) {
      console.warn(`DOM element ${key} not found in HTML`);
    }
  }
  startPeriodicTimeCheck();
  // Apply settings to content script
  const applySettings = debounce((settings) => {
    if (elements.enabled?.checked && currentTabId && !isHeld && isActivated) {
      chrome.tabs.sendMessage(currentTabId, settings, (response) => {
        if (chrome.runtime.lastError || !response || response.status === "error") {
          showNotification(response?.message || "Error applying settings");
          console.log("Settings applied:", settings, "Response:", response);
        }
      });
    }
  }, 200);
  // Update UI values and save to currentSettings
  function setPitchValue(value) {
    if (elements.pitch && elements.pitchValue) {
      elements.pitch.value = value;
      elements.pitchValue.textContent = value;
      currentSettings.pitch = value;
      if (baseBPM) {
        const adjustedBPM = adjustBPMWithPitch(baseBPM, value, transpose);
        updateBPMDisplay(adjustedBPM, null, currentKey);
      }
    }
  }

  function setPlaybackRate(value) {
    if (elements.playbackRate && elements.playbackRateValue) {
      elements.playbackRate.value = value;
      elements.playbackRateValue.textContent = value;
      currentSettings.playbackRate = value;
    }
  }

  function setBoostValue(value) {
    if (elements.boost && elements.boostValue) {
      elements.boost.value = value;
      elements.boostValue.textContent = value;
      currentSettings.boost = value;
    }
  }

  function setPanValue(value) {
    if (elements.pan && elements.panValue) {
      elements.pan.value = value;
      elements.panValue.textContent = value;
      currentSettings.pan = value;
    }
  }

  function setPitchShiftTypeSmooth() {
    if (elements.pitch && elements.pitchShiftTypeSelect) {
      elements.pitch.max = 12;
      elements.pitch.min = -12;
      elements.pitch.step = 0.01;
      elements.pitchShiftTypeSelect.value = "smooth";
      transpose = false;
      currentSettings.transpose = false;
      if (baseBPM) {
        const adjustedBPM = adjustBPMWithPitch(baseBPM, parseFloat(elements.pitch.value), transpose);
        updateBPMDisplay(adjustedBPM, null, currentKey);
      }
    }
  }

  function setPitchShiftTypeSemiTone() {
    if (elements.pitch && elements.pitchShiftTypeSelect) {
      elements.pitch.max = 12;
      elements.pitch.min = -12;
      elements.pitch.step = 0.5;
      elements.pitchShiftTypeSelect.value = "semi-tone";
      transpose = true;
      currentSettings.transpose = true;
      if (baseBPM) {
        const adjustedBPM = adjustBPMWithPitch(baseBPM, parseFloat(elements.pitch.value), transpose);
        updateBPMDisplay(adjustedBPM, null, currentKey);
      }
    }
  }
  // Update preset UI
  function updatePresetUI(selectedPreset) {
    // Chuẩn hóa selectedPreset: chuyển kebab-case thành camelCase nếu cần
    let normalizedPreset = selectedPreset;
    if (selectedPreset.includes('-')) {
      normalizedPreset = selectedPreset.replace(/-([a-z])/g, (match, letter) => letter.toUpperCase());
      console.log(`updatePresetUI: Normalized preset from ${selectedPreset} to ${normalizedPreset}`);
    }
    elements.presetButtons.forEach(btn => {
      const presetId = btn.id.replace("preset-", "");
      // Chuyển presetId thành camelCase để so sánh
      const preset = presetId.split('-').map((part, index) => index === 0 ? part : part.charAt(0).toUpperCase() + part.slice(1)).join('');
      // So sánh với cả dạng camelCase và kebab-case
      const isActive = preset === normalizedPreset || presetId === selectedPreset;
      btn.classList.toggle("active", isActive);
    });
  }

  function resetToDefault() {
    setPitchValue(0);
    setPlaybackRate(1);
    setBoostValue(0.7);
    setPanValue(0);
    transpose = true;
    baseBPM = null;
    currentKey = null;
    currentSettings = {
      pitch: 0,
      playbackRate: 1,
      boost: 0.7,
      pan: 0,
      transpose: true,
      soundProfile: "proNatural"
    };
    if (elements.pitchShiftTypeSelect) elements.pitchShiftTypeSelect.value = "semi-tone";
    updatePresetUI("proNatural");
    updateBPMDisplay(null);
    if (elements.enabled?.checked && isActivated) {
      applySettings(currentSettings);
    }
  }
  // Adjust BPM based on pitch
  function adjustBPMWithPitch(bpm, pitch, transpose) {
    if (!bpm) return null;
    const pitchFactor = transpose ? Math.pow(2, pitch / 12) : (1 + pitch);
    return Math.round(bpm * pitchFactor);
  }
  // Update BPM and Key display
  function updateBPMDisplay(bpm, confidence = null, key = null, status = null) {
    if (!elements.bpmValue) {
      console.warn("bpmValue element not found");
      return;
    }
    if (status) {
      elements.bpmValue.textContent = status;
    } else if (bpm !== null) {
      const confidenceText = confidence ? ` (${Math.round(confidence * 100)}%)` : "";
      const keyText = key && key !== "Unknown" ? ` - Key: ${key}` : "";
      elements.bpmValue.textContent = `BPM: ${bpm}${confidenceText}${keyText}`;
      elements.bpmValue.classList.add("blink");
      requestAnimationFrame(() => {
        setTimeout(() => elements.bpmValue.classList.remove("blink"), 2000);
      });
      if (confidence) {
        baseBPM = bpm;
        currentKey = key;
      }
    } else {
      elements.bpmValue.textContent = "BPM: ...";
      baseBPM = null;
      currentKey = null;
    }
  }
  // Update song title with smart animation
  function updateSongTitle(passedTitle) {
    if (!elements.songTitle) return;
    if (passedTitle && passedTitle !== "No songs yet") {
      currentSongTitle = passedTitle;
    }
    elements.songTitle.textContent = currentSongTitle;
    const containerWidth = elements.songTitle.parentElement?.offsetWidth || 0;
    const textWidth = elements.songTitle.scrollWidth || 0;
    elements.songTitle.style.animation = textWidth > containerWidth ? "scrollText 10s linear infinite" : "none";
  }

  function updateLicenseStatus(activationStatus) {
    if (!elements.licenseStatus || !elements.buyBtn) {
      console.warn("Missing licenseStatus or buyBtn elements");
      return;
    }
    try {
      // --- NÂNG CẤP: TÍNH NĂNG XEM ID KHI CLICK ---
      // Lấy giá trị mới nhất từ input (đảm bảo không bao giờ bị N/A)
      const currentDeviceId = elements.deviceIdInput?.value || "N/A";
      elements.licenseStatus.dataset.userId = currentDeviceId;
      elements.licenseStatus.style.cursor = "pointer";
      elements.licenseStatus.title = currentLang === 'vi' ? "Click để xem/copy ID thiết bị" : "Click to view/copy Device ID";
      // Gán sự kiện click để toggle giữa [Ngày hết hạn] <-> [Device ID]
      if (!elements.licenseStatus.dataset.hasListener) {
        elements.licenseStatus.dataset.hasListener = "true";
        elements.licenseStatus.onclick = function() {
          if (this.dataset.showing === 'id') {
            // Trở về hiển thị ngày/trạng thái cũ
            this.textContent = this.dataset.originalText;
            this.dataset.showing = 'date';
          } else {
            // Hiển thị ID và tự động copy vào clipboard
            this.dataset.originalText = this.textContent;
            const idToShow = elements.deviceIdInput?.value || "N/A";
            this.textContent = (currentLang === 'vi' ? "ID: " : "User ID: ") + idToShow;
            this.dataset.showing = 'id';
            // Tự động copy cho tiện
            navigator.clipboard.writeText(idToShow).then(() => {
              showNotification(currentLang === 'vi' ? "Đã copy ID!" : "Device ID copied!");
            });
          }
        };
      }
      // --- LOGIC GỐC CỦA BẠN (GIỮ NGUYÊN) ---
      if (activationStatus.activated && (activationStatus.daysLeft > 0 || activationStatus.type === "permanent")) {
        elements.buyBtn.style.display = "none";
        elements.licenseStatus.style.display = "inline";
        if (activationStatus.type === "permanent") {
          const text = currentLang === 'vi' ? "Key vĩnh viễn" : "Lifetime Key";
          elements.licenseStatus.textContent = text;
          elements.licenseStatus.dataset.originalText = text;
          elements.licenseStatus.dataset.showing = 'date';
          elements.licenseStatus.classList.remove("warning");
        } else {
          const daysLeft = Number(activationStatus.daysLeft);
          if (isNaN(daysLeft)) {
            console.error("Invalid daysLeft value:", activationStatus.daysLeft);
            elements.buyBtn.style.display = "inline-block";
            elements.licenseStatus.style.display = "none";
            toggleControls(false);
            showNotification(currentLang === 'vi' ? "Dữ liệu kích hoạt không hợp lệ!" : "Invalid activation data!");
            return;
          }
          // ĐỊNH DẠNG NGÀY THEO NGÔN NGỮ
          const endDate = new Date(Date.now() + daysLeft * 86400000);
          const formattedDate = endDate.toLocaleDateString(currentLang === 'vi' ? 'vi-VN' : 'en-US', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
          });
          // DỊCH LABEL
          const baseKey = activationStatus.type === "trial" ? "Trial End Date:" : "Subscription End Date:";
          const labelText = translations[currentLang][baseKey] || baseKey;
          const displayString = `${labelText} ${formattedDate}`;
          elements.licenseStatus.textContent = displayString;
          elements.licenseStatus.dataset.originalText = displayString;
          elements.licenseStatus.dataset.showing = 'date';
          // CẢNH BÁO SẮP HẾT HẠN
          if (daysLeft <= 7) {
            elements.licenseStatus.classList.add("warning");
            elements.licenseStatus.title = currentLang === 'vi' ? `Sắp hết hạn! Vui lòng ${activationStatus.type === "trial" ? "mua key" : "gia hạn"} để tiếp tục sử dụng.` : `Your ${activationStatus.type === "trial" ? "trial" : "subscription"} will expire on ${formattedDate}. ${activationStatus.type === "trial" ? "Purchase a key to continue!" : "Renew now!"}`;
          } else {
            elements.licenseStatus.classList.remove("warning");
          }
        }
      } else {
        elements.buyBtn.style.display = "inline-block";
        elements.licenseStatus.style.display = "none";
        toggleControls(false);
        // DỊCH THÔNG BÁO HẾT HẠN / KHÓA THIẾT BỊ
        let msg = activationStatus.message || "";
        if (!msg || msg.includes("expired") || msg.includes("trial") || msg.includes("locked")) {
          if (msg.includes("This device has already used the trial")) {
            msg = translations[currentLang]["This device has already used the trial! Purchase a key to continue."];
          } else if (msg.includes("permanently locked")) {
            msg = translations[currentLang]["The device has been permanently locked due to suspicious activity!"];
          } else {
            msg = translations[currentLang]["Trial or subscription has expired! Please purchase a key."];
          }
        }
        showNotification(msg || (currentLang === 'vi' ? "Đã hết hạn sử dụng! Vui lòng mua key." : "Trial or subscription has expired! Please purchase a key."));
        console.log("Buy button displayed due to expired or invalid activation");
      }
      // CẬP NHẬT LẠI GIAO DIỆN SAU KHI THAY ĐỔI TEXT
      requestAnimationFrame(() => translateUI());
    } catch (error) {
      console.error("Error updating license status:", error);
      elements.buyBtn.style.display = "inline-block";
      elements.licenseStatus.style.display = "none";
      toggleControls(false);
      showNotification(currentLang === 'vi' ? "Lỗi trạng thái license! Vui lòng mua key." : "Error in license status! Please purchase a key.");
    }
  }
  // Handle messages from content.js
  function handleContentMessage(message) {
    if (message.type === "videoChanged") {
      currentUrl = message.videoSrc;
      const favItem = favorites.find(f => f.link === currentUrl);
      if (elements.favIcon) elements.favIcon.classList.toggle("active", !!favItem);
      updateSongTitle(message.title);
      if (favItem) {
        setPitchValue(favItem.pitch);
        setPlaybackRate(favItem.playbackRate);
        setBoostValue(favItem.boost);
        setPanValue(favItem.pan);
        transpose = favItem.transpose !== undefined ? favItem.transpose : true;
        if (transpose) setPitchShiftTypeSemiTone();
        else setPitchShiftTypeSmooth();
        updatePresetUI(favItem.soundProfile || "proNatural");
        updateBPMDisplay(favItem.bpm || message.bpm);
        applySettings({
          pitch: favItem.pitch,
          playbackRate: favItem.playbackRate,
          boost: favItem.boost,
          pan: favItem.pan,
          transpose,
          soundProfile: favItem.soundProfile || "proNatural"
        });
      } else if (message.holdState) {
        setPitchValue(message.pitch);
        setPlaybackRate(message.playbackRate);
        setBoostValue(message.boost);
        setPanValue(message.pan);
        transpose = message.transpose !== undefined ? message.transpose : true;
        if (transpose) setPitchShiftTypeSemiTone();
        else setPitchShiftTypeSmooth();
        updatePresetUI(message.soundProfile || "proNatural");
        updateBPMDisplay(message.bpm);
      } else {
        resetToDefault();
        updateBPMDisplay(message.bpm);
      }
    } else if (message.type === "bpmUpdate") {
      updateBPMDisplay(message.bpm, message.confidence, message.key);
    } else if (message.type === "bpmStatus") {
      const currentTime = Date.now();
      if (currentTime >= latestStatusTime) {
        latestStatusTime = currentTime;
        updateBPMDisplay(null, null, null, message.message);
      }
    }
  }
  // Event for clicking BPM to calculate BPM and Key
  elements.bpmValue?.addEventListener("click", () => {
    showNotification("Initializing BPM analysis...");
    let retries = 0;
    const maxRetries = 3;
    const retryDelay = 2000;
    const tryCalculateBPM = () => {
      sendMessageToActiveTab({
        type: "calculateBPM"
      }, (response) => {
        if (!response || response.status === "notSupported") {
          showNotification("This tab does not support BPM calculation");
          updateBPMDisplay(null);
        } else if (response.status === "success") {
          updateBPMDisplay(response.bpm, response.confidence, response.key);
          showNotification(`BPM and key analysis successful (${Math.round(response.confidence * 100)}%)`);
        } else if (response.error === "No active video or analyser not ready" && retries < maxRetries) {
          retries++;
          console.log(`Retrying BPM calculation (${retries}/${maxRetries})...`);
          showNotification(`Retrying BPM analysis (${retries}/${maxRetries})...`);
          setTimeout(tryCalculateBPM, retryDelay);
        } else if (response.error === "Advertisement detected" || response.error === "Skipping intro or outro") {
          showNotification("Please wait until the advertisement or intro/outro ends and try again!");
          updateBPMDisplay(null);
        } else {
          showNotification(response?.message || "Unable to analyze BPM and key!");
          updateBPMDisplay(null);
        }
      });
    };
    tryCalculateBPM();
  });
  // Filter and display favorites list with index number before thumbnail
  function filterFavorites(searchTerm = "") {
    let filtered = favorites;
    const favoritesCount = document.getElementById("favorites-count");
    if (searchTerm) {
      filtered = favorites.map(item => ({
        item,
        searchResult: fuzzySearch(item.title || "Unknown", searchTerm)
      })).filter(({
        searchResult
      }) => searchResult.score > 0).sort((a, b) => b.searchResult.score - a.searchResult.score).slice(0, 100).map(({
        item
      }) => item);
    }
    if (favoritesCount) {
      favoritesCount.textContent = `Found ${filtered.length} song${filtered.length !== 1 ? "s" : ""}`;
    } else {
      console.log(`Found ${filtered.length} song${filtered.length !== 1 ? "s" : ""}`);
    }
    if (elements.favoritesTableBody) {
      elements.favoritesTableBody.innerHTML = "";
      filtered.forEach((item, index) => {
        const originalIndex = favorites.indexOf(item);
        const thumbnail = getThumbnailUrl(item.link);
        const songTitle = item.title || "Unknown";
        const row = document.createElement("tr");
        row.innerHTML = `
                <td><span class="index-number">${String(originalIndex + 1).padStart(2, "0")}</span></td>
                <td></td>
                <td>${item.pitch}</td>
                <td>${item.boost}</td>
                <td>${item.pan}</td>
                <td>${item.bpm || "..."}</td>
                <td>${profileDisplayNames[item.soundProfile] || item.soundProfile || 'Natural'}</td>
                <td><a href="${item.link}" target="_blank" class="open-link-btn" title="${songTitle}">Open</a></td>
                <td><button class="delete-fav-btn" title="Delete ${songTitle}">X</button></td>
            `;
        const img = document.createElement("img");
        img.src = thumbnail;
        img.alt = `Thumbnail for ${songTitle}`;
        img.className = "thumbnail";
        img.title = songTitle;
        img.style.cursor = "pointer";
        img.addEventListener("click", () => window.open(item.link, "_blank"));
        row.cells[1].appendChild(img);
        row.addEventListener("click", (e) => {
          if (e.target.tagName !== "BUTTON" && e.target.tagName !== "A" && e.target.tagName !== "IMG" && e.target.tagName !== "SPAN" && isActivated) {
            setPitchValue(item.pitch);
            setPlaybackRate(item.playbackRate);
            setBoostValue(item.boost);
            setPanValue(item.pan);
            transpose = item.transpose !== undefined ? item.transpose : true;
            if (transpose) setPitchShiftTypeSemiTone();
            else setPitchShiftTypeSmooth();
            updatePresetUI(item.soundProfile || "proNatural");
            applySettings({
              pitch: item.pitch,
              playbackRate: item.playbackRate,
              boost: item.boost,
              pan: item.pan,
              transpose,
              soundProfile: item.soundProfile || "proNatural"
            });
          }
        });
        // CHỈ SỬA 2 DÒNG NÀY – DÙNG CLASS CỦA MÀY ĐÃ CÓ CSS → HIỆN ĐẸP NGAY!
        const openLink = row.querySelector("td:nth-child(8) a");
        if (openLink) openLink.className = "open-link-btn";
        const deleteBtn = row.querySelector(".delete-fav-btn");
        if (deleteBtn) {
          deleteBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            favorites.splice(originalIndex, 1);
            chrome.storage.local.set({
              favorites
            }, () => filterFavorites(elements.searchFavorites?.value || ""));
            if (elements.favIcon?.classList.contains("active") && item.link === currentUrl) {
              elements.favIcon.classList.remove("active");
              resetToDefault();
            }
          });
        }
        elements.favoritesTableBody.appendChild(row);
      });
    }
  }

  function updateFavoritesTable() {
    filterFavorites(elements.searchFavorites?.value || "");
  }
  // Update state based on video URL
  function updateStateBasedOnUrl(newUrl, values) {
    currentUrl = newUrl;
    const favItem = favorites.find(f => f.link === currentUrl);
    if (favItem) {
      if (elements.favIcon) elements.favIcon.classList.add("active");
      setPitchValue(favItem.pitch);
      setPlaybackRate(favItem.playbackRate);
      setBoostValue(favItem.boost);
      setPanValue(favItem.pan);
      transpose = favItem.transpose !== undefined ? favItem.transpose : true;
      if (transpose) setPitchShiftTypeSemiTone();
      else setPitchShiftTypeSmooth();
      updatePresetUI(favItem.soundProfile || "proNatural");
      updateBPMDisplay(favItem.bpm);
      applySettings({
        pitch: favItem.pitch,
        playbackRate: favItem.playbackRate,
        boost: favItem.boost,
        pan: favItem.pan,
        transpose,
        soundProfile: favItem.soundProfile || "proNatural"
      });
    } else if (values && values.holdState) {
      setPitchValue(values.pitch || 0);
      setPlaybackRate(values.playbackRate || 1);
      setBoostValue(values.boost || 0.7);
      setPanValue(values.pan || 0);
      transpose = values.transpose !== undefined ? values.transpose : true;
      if (transpose) setPitchShiftTypeSemiTone();
      else setPitchShiftTypeSmooth();
      updatePresetUI(values.soundProfile || "proNatural");
      updateBPMDisplay(values.bpm);
      if (elements.favIcon) elements.favIcon.classList.remove("active");
    } else if (values && values.videoSrc === currentUrl) {
      setPitchValue(values.pitch || 0);
      setPlaybackRate(values.playbackRate || 1);
      setBoostValue(values.boost || 0.7);
      setPanValue(values.pan || 0);
      transpose = values.transpose !== undefined ? values.transpose : true;
      if (transpose) setPitchShiftTypeSemiTone();
      else setPitchShiftTypeSmooth();
      updatePresetUI(values.soundProfile || "proNatural");
      updateBPMDisplay(values.bpm);
      if (elements.favIcon) elements.favIcon.classList.remove("active");
    } else {
      resetToDefault();
      if (elements.favIcon) elements.favIcon.classList.remove("active");
    }
  }
  // Sync state when opening popup or switching tabs
  function syncState() {
    chrome.tabs.query({
      active: true,
      currentWindow: true
    }, (tabs) => {
      const tab = tabs[0];
      if (!tab || !tab.id || !tab.url) {
        toggleControls(false);
        updateSongTitle("No active tab");
        updateBPMDisplay(null);
        resetToDefault();
        return;
      }
      currentTabId = tab.id;
      // === 1. Nếu URL KHÔNG hỗ trợ → tắt hết, KHÔNG ping, KHÔNG confirm ===
      if (!isSupportedUrl(tab.url)) {
        updateSongTitle("Tab not supported");
        updateBPMDisplay(null);
        if (elements.enabled) {
          elements.enabled.checked = false;
          elements.enabled.disabled = true;
        }
        toggleControls(false);
        resetToDefault();
        return;
      }
      // === 2. URL hỗ trợ → ping để kiểm tra content script ===
      chrome.tabs.sendMessage(tab.id, {
        type: "ping"
      }, (pingResponse) => {
        // Content script chưa sẵn sàng → dùng hàm sendMessageToActiveTab để hiện confirm (giữ nguyên logic chống spam của mày)
        if (chrome.runtime.lastError || !pingResponse || pingResponse.status !== "ready") {
          // Dùng hàm gốc của mày để xử lý confirm reload (chỉ hiện 1 lần)
          sendMessageToActiveTab({
            type: "get"
          }, (values) => {
            // Sau khi reload/inject xong → xử lý kết quả
            if (!values || values.status !== "success") {
              updateSongTitle("No video detected");
              updateBPMDisplay(null);
              // Vẫn cho phép bật extension dù chưa có video
              if (elements.enabled) {
                elements.enabled.disabled = false;
                elements.enabled.checked = false;
              }
              resetToDefault();
            } else {
              // Có video → cập nhật bình thường
              currentUrl = values.videoSrc || null;
              updateSongTitle(values.title || "Unknown");
              updateBPMDisplay(values.bpm);
              updateStateBasedOnUrl(currentUrl, values);
              if (elements.enabled) {
                elements.enabled.checked = values.enabled;
                elements.enabled.disabled = false;
              }
              isHeld = values.holdState || false;
              if (elements.holdBtn) {
                elements.holdBtn.textContent = isHeld ? "🔐" : "🔓";
                elements.holdBtn.classList.toggle("active", isHeld);
              }
              updatePresetUI(values.soundProfile || "proNatural");
            }
          });
          return;
        }
        // === 3. Content script đã sẵn sàng → lấy trạng thái trực tiếp ===
        sendMessageToActiveTab({
          type: "get"
        }, (values) => {
          if (!values || values.status !== "success") {
            updateSongTitle("No video detected");
            updateBPMDisplay(null);
            if (elements.enabled) {
              elements.enabled.disabled = false;
              elements.enabled.checked = false;
            }
            resetToDefault();
          } else {
            currentUrl = values.videoSrc || null;
            updateSongTitle(values.title || "Unknown");
            updateBPMDisplay(values.bpm);
            updateStateBasedOnUrl(currentUrl, values);
            if (elements.enabled) {
              elements.enabled.checked = values.enabled;
              elements.enabled.disabled = false;
            }
            isHeld = values.holdState || false;
            if (elements.holdBtn) {
              elements.holdBtn.textContent = isHeld ? "🔐" : "🔓";
              elements.holdBtn.classList.toggle("active", isHeld);
            }
            updatePresetUI(values.soundProfile || "proNatural");
          }
        });
      });
    });
  }
  // Initialize activation status
  // Initialize activation status (ĐÃ TỐI ƯU UI BLINK & AN TOÀN)
  // Tạo 1 biến toàn cục ở phạm vi này để lưu cache Device ID, chống lag khi bấm nút Buy
  let cachedDeviceId = "";
  // Initialize activation status (ĐÃ TỐI ƯU KHÔNG LỒNG CALLBACK - SIÊU MƯỢT)
  async function initializeActivation(cachedIsActivated) {
    // === [FIX GIAO DIỆN CHỚP TẮT] Render tức thì từ dữ liệu đã truyền vào ===
    if (cachedIsActivated && typeof elements !== 'undefined' && elements.buyBtn && elements.licenseStatus) {
      elements.buyBtn.style.display = "none";
      elements.licenseStatus.style.display = "inline";
      elements.licenseStatus.textContent = currentLang === 'vi' ? "Đang xác thực..." : "Verifying...";
      toggleControls(true);
    }
    // === Bắt đầu chạy logic nặng ===
    const deviceId = await generateDeviceId();
    cachedDeviceId = deviceId; // Lưu lại vào cache để nút Buy dùng ngay lập tức
    // --- CHÈN VÀO ĐÂY ---
    if (elements.deviceIdInput) elements.deviceIdInput.value = deviceId;
    let activationStatus = await checkActivation();
    console.log("Activation Status:", activationStatus);
    // Nếu chưa kích hoạt, thử init trial
    if (!activationStatus.activated) {
      const trialStatus = await initializeTrial(deviceId);
      if (trialStatus.valid) {
        activationStatus = {
          activated: true,
          type: "trial",
          expiry: trialStatus.expiry,
          daysLeft: Math.ceil((trialStatus.expiry - Date.now()) / (1000 * 60 * 60 * 24))
        };
        showNotification(`Started 30-day trial! ${activationStatus.daysLeft} days left`);
      } else {
        showNotification(trialStatus.message);
      }
    }
    isActivated = activationStatus.activated;
    // Cứu rỗi giao diện nếu verify thất bại hoàn toàn
    if (!isActivated && typeof elements !== 'undefined' && elements.buyBtn && elements.licenseStatus) {
      elements.buyBtn.style.display = "inline-block";
      elements.licenseStatus.style.display = "none";
    }
    toggleControls(isActivated);
    updateLicenseStatus(activationStatus);
    if (isActivated && activationStatus.daysLeft && activationStatus.daysLeft <= 7) {
      showNotification(`${activationStatus.type === "trial" ? "Trial" : "Key"} will expire in ${activationStatus.daysLeft} days!`);
    }
    if (!isActivated && typeof elements !== 'undefined' && elements.enabled) {
      elements.enabled.checked = false;
      elements.enabled.disabled = true;
    }
  }
  // Event for Buy button (ĐÃ SỬA: BẤM CÁI HIỆN POPUP NGAY, KHÔNG LAG)
  elements.buyBtn?.addEventListener("click", async () => {
    // Lấy nhanh từ cache, nếu chưa kịp có cache (hiếm) thì mới tính toán lại
    const deviceId = cachedDeviceId || await generateDeviceId();
    if (elements.deviceIdInput && elements.activationModal) {
      elements.deviceIdInput.value = deviceId;
      elements.activationModal.classList.add("active");
      elements.activationModal.style.display = "block";
      elements.activationModal.setAttribute("aria-hidden", "false");
      elements.activationKeyInput?.focus();
    }
  });
  // Event for Copy Device ID button
  elements.copyDeviceIdBtn?.addEventListener("click", () => {
    if (elements.deviceIdInput) {
      navigator.clipboard.writeText(elements.deviceIdInput.value).then(() => {
        showNotification("Device ID copied");
      }).catch((error) => {
        handleError("Error copying Device ID:", error);
        showNotification("Error copying Device ID!");
      });
    }
  });
  // Event for Activate button
  elements.activateBtn?.addEventListener("click", async () => {
    console.time("ActivationProcess");
    const activationKey = elements.activationKeyInput?.value.trim();
    if (!activationKey) {
      elements.activationError.textContent = "Please enter an activation key!";
      console.timeEnd("ActivationProcess");
      return;
    }
    const deviceId = elements.deviceIdInput?.value;
    if (!isValidKeyFormat(activationKey)) {
      elements.activationError.textContent = "Invalid key format!";
      console.timeEnd("ActivationProcess");
      return;
    }
    const verification = await verifyActivation(activationKey, deviceId);
    if (!verification.valid) {
      elements.activationError.textContent = verification.message;
      console.timeEnd("ActivationProcess");
      return;
    }
    const saved = await saveActivation(deviceId, activationKey, verification.type, verification.expiry);
    if (!saved) {
      elements.activationError.textContent = "Error saving activation key!";
      console.timeEnd("ActivationProcess");
      return;
    }
    elements.activationModal.classList.add("closing");
    setTimeout(() => {
      elements.activationModal.classList.remove("active", "closing");
      elements.activationModal.style.display = "none";
      elements.activationModal.setAttribute("aria-hidden", "true");
      elements.activationKeyInput.value = "";
      elements.activationError.textContent = "";
      elements.successModal.classList.add("active");
      elements.successModal.style.display = "block";
      elements.successModal.setAttribute("aria-hidden", "false");
      elements.successModalOk?.focus();
    }, 300);
    isActivated = true;
    toggleControls(true);
    updateLicenseStatus({
      activated: true,
      type: verification.type,
      daysLeft: verification.expiry ? Math.ceil((verification.expiry - Date.now()) / (1000 * 60 * 60 * 24)) : null
    });
    showNotification("Activation successful!");
    console.timeEnd("ActivationProcess");
  });
  // Event for closing Activation Modal
  elements.activationModalClose?.addEventListener("click", () => {
    elements.activationModal.classList.add("closing");
    setTimeout(() => {
      elements.activationModal.classList.remove("active", "closing");
      elements.activationModal.style.display = "none";
      elements.activationModal.setAttribute("aria-hidden", "true");
      elements.activationKeyInput.value = "";
      elements.activationError.textContent = "";
    }, 300);
  });
  // Events for OK and closing Success Modal
  elements.successModalOk?.addEventListener("click", () => {
    elements.successModal.classList.add("closing");
    setTimeout(() => {
      elements.successModal.classList.remove("active", "closing");
      elements.successModal.style.display = "none";
      elements.successModal.setAttribute("aria-hidden", "true");
      chrome.runtime.sendMessage({
        action: "refreshExtension"
      }, (response) => {
        if (chrome.runtime.lastError) {
          handleError("Error sending refreshExtension:", chrome.runtime.lastError);
          showNotification("Error refreshing extension!");
          return;
        }
        if (!response || (response.status !== "success" && response.status !== "state refreshed")) {
          handleError("Failed to refresh extension:", response?.message || "No response");
          showNotification(response?.message || "Error refreshing extension!");
          return;
        }
        showNotification("Extension refreshed successfully");
        syncState();
      });
    }, 300);
  });
  elements.successModalClose?.addEventListener("click", () => {
    elements.successModal.classList.add("closing");
    setTimeout(() => {
      elements.successModal.classList.remove("active", "closing");
      elements.successModal.style.display = "none";
      elements.successModal.setAttribute("aria-hidden", "true");
      chrome.runtime.sendMessage({
        action: "refreshExtension"
      }, (response) => {
        if (chrome.runtime.lastError) {
          handleError("Error sending refreshExtension:", chrome.runtime.lastError);
          showNotification("Error refreshing extension!");
          return;
        }
        if (!response || (response.status !== "success" && response.status !== "state refreshed")) {
          handleError("Failed to refresh extension:", response?.message || "No response");
          showNotification(response?.message || "Error refreshing extension!");
          return;
        }
        showNotification("Extension refreshed successfully");
        syncState();
      });
    }, 300);
  });
  // Initialize state from storage and content script (ĐÃ TỐI ƯU GỘP CHUNG QUÉT STORAGE)
  chrome.storage.local.get(["favorites", "enabled", "theme", "isActivated"], async (result) => {
    if (chrome.runtime.lastError) {
      handleError("Error retrieving data from storage:", chrome.runtime.lastError);
      resetToDefault();
      return;
    }
    favorites = result.favorites || [];
    updateFavoritesTable();
    const savedTheme = result.theme || "dark";
    document.body.setAttribute("data-theme", savedTheme);
    if (elements.themeToggle) elements.themeToggle.textContent = savedTheme === "dark" ? "☀️" : "🌙";
    // KHÓA SWITCH LUÔN TỪ ĐẦU NẾU TRONG STORAGE CHƯA ĐƯỢC ACTIVE -> CHỐNG CHỚP TẮT SWITCH
    const savedEnabled = result.enabled !== undefined ? result.enabled : false;
    if (elements.enabled) {
      if (!result.isActivated) {
        elements.enabled.checked = false;
        elements.enabled.disabled = true;
      } else {
        elements.enabled.checked = savedEnabled;
      }
    }
    // Truyền thẳng kết quả "isActivated" từ cache vào hàm khởi tạo
    await initializeActivation(result.isActivated);
    syncState();
  });
  // Event for enabling/disabling extension
  elements.enabled?.addEventListener("change", () => {
    if (!isActivated) {
      elements.enabled.checked = false;
      showNotification("Please activate the application first!");
      return;
    }
    const isEnabled = elements.enabled.checked;
    sendMessageToActiveTab({
      enabled: isEnabled
    }, (response) => {
      if (!response || response.status === "notSupported") {
        elements.enabled.checked = false;
        elements.enabled.disabled = true;
        chrome.storage.local.set({
          enabled: false
        });
        showNotification("This tab does not support the extension");
      } else if (response.status === "success") {
        chrome.storage.local.set({
          enabled: isEnabled
        });
        showNotification(isEnabled ? "Pitch Shifter enabled" : "Pitch Shifter disabled");
        if (!isEnabled) {
          resetToDefault();
        } else if (isActivated) {
          applySettings(currentSettings);
        }
      } else {
        elements.enabled.checked = !isEnabled;
        showNotification("Error changing state: " + (response.message || "Unknown"));
      }
    });
  });
  // Slider change events with effects
  function addSliderListener(slider, valueElement, key, resetValue) {
    slider?.addEventListener("input", () => {
      if (!isActivated) return;
      const value = parseFloat(slider.value);
      if (valueElement) valueElement.textContent = value;
      currentSettings[key] = value;
      applySettings({
        [key]: value
      });
      slider.classList.add("active");
      valueElement.classList.add("active-value");
      setTimeout(() => {
        slider.classList.remove("active");
        valueElement.classList.remove("active-value");
      }, 1000);
    });
    slider?.parentElement.querySelector(".reset-btn")?.addEventListener("click", () => {
      if (!isActivated) return;
      if (slider && valueElement) {
        slider.value = resetValue;
        valueElement.textContent = resetValue;
        currentSettings[key] = resetValue;
        applySettings({
          [key]: resetValue,
          boost: currentSettings.boost,
          soundProfile: currentSettings.soundProfile
        });
      }
    });
  }
  addSliderListener(elements.pitch, elements.pitchValue, "pitch", 0);
  addSliderListener(elements.playbackRate, elements.playbackRateValue, "playbackRate", 1);
  addSliderListener(elements.boost, elements.boostValue, "boost", 0.7);
  addSliderListener(elements.pan, elements.panValue, "pan", 0);
  elements.pitchShiftTypeSelect?.addEventListener("change", () => {
    if (!isActivated) return;
    const selectedOption = elements.pitchShiftTypeSelect.value;
    if (selectedOption === "smooth") setPitchShiftTypeSmooth();
    else setPitchShiftTypeSemiTone();
    const value = parseFloat(elements.pitch.value);
    setPitchValue(value);
    applySettings({
      transpose,
      pitch: value
    });
  });
  // Event for Hold button
  elements.holdBtn?.addEventListener("click", () => {
    if (!isActivated) return;
    isHeld = !isHeld;
    elements.holdBtn.textContent = isHeld ? "🔐" : "🔒";
    elements.holdBtn.classList.toggle("active", isHeld);
    sendMessageToActiveTab({
      type: "hold",
      holdState: isHeld
    }, (response) => {
      if (response?.status === "success") {
        showNotification(isHeld ? "Settings held" : "Settings released");
        updateSongTitle(currentSongTitle);
      } else {
        showNotification("Error changing hold state!");
        isHeld = !isHeld;
        elements.holdBtn.textContent = isHeld ? "🔐" : "🔒";
        elements.holdBtn.classList.toggle("active", isHeld);
        updateSongTitle(currentSongTitle);
      }
    });
  });
  // Events for Preset buttons with improved synchronization
  elements.presetButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      if (!isActivated) {
        showNotification("Please activate the application first!");
        return;
      }
      if (isHeld) {
        showNotification("Settings are held, cannot change preset");
        return;
      }
      const presetId = btn.id.replace("preset-", "");
      const preset = presetId.split('-').map((part, index) => index === 0 ? part : part.charAt(0).toUpperCase() + part.slice(1)).join('');
      sendMessageToActiveTab({
        type: "applyPreset",
        preset
      }, (response) => {
        if (response?.status === "success") {
          updatePresetUI(preset); // Sử dụng preset (camelCase) thay vì presetId
          currentSettings.soundProfile = preset;
          showNotification(`Applied preset: ${profileDisplayNames[preset] || preset}`);
        } else {
          showNotification("Error applying preset: " + (response?.message || "Unknown"));
          console.log("Preset response:", response);
        }
      });
    });
  });
  // Add/remove favorites
  elements.favIcon?.addEventListener("click", () => {
    if (!isActivated) {
      showNotification("Please activate the application first!");
      return;
    }
    const isActive = elements.favIcon.classList.toggle("active");
    if (isActive) {
      sendMessageToActiveTab({
        type: "get"
      }, (values) => {
        if (!values || values.status !== "success") {
          showNotification("Error: Could not retrieve current settings!");
          elements.favIcon.classList.remove("active");
          return;
        }
        // CHỈ SỬA DÒNG NÀY – LẤY TRỰC TIẾP TỪ NÚT ACTIVE TRÊN UI → ĐÚNG 100%
        const activeProfileBtn = document.querySelector(".preset-btn.active");
        const savedProfile = activeProfileBtn ? activeProfileBtn.id.replace("preset-", "") : (values.soundProfile || currentSettings.soundProfile);
        const favorite = {
          title: elements.songTitle?.textContent || "Unknown",
          pitch: values.pitch || currentSettings.pitch,
          playbackRate: values.playbackRate || currentSettings.playbackRate,
          boost: values.boost || currentSettings.boost,
          pan: values.pan || currentSettings.pan,
          bpm: baseBPM || values.bpm || null,
          link: values.videoSrc,
          transpose: values.transpose !== undefined ? values.transpose : transpose,
          soundProfile: savedProfile // ← CHỈ SỬA DÒNG NÀY THÔI, CÒN LẠI GIỮ NGUYÊN
        };
        chrome.storage.local.get(["favorites"], (result) => {
          favorites = result.favorites || [];
          const existingIndex = favorites.findIndex(f => f.link === favorite.link);
          if (existingIndex !== -1) {
            favorites[existingIndex] = favorite;
            showNotification("Updated favorite settings");
          } else {
            favorites.push(favorite);
            showNotification("Added to favorites");
          }
          chrome.storage.local.set({
            favorites
          }, () => updateFavoritesTable());
        });
      });
    } else {
      favorites = favorites.filter(f => f.link !== currentUrl);
      chrome.storage.local.set({
        favorites
      }, () => {
        updateFavoritesTable();
        resetToDefault();
        showNotification("Removed from favorites");
      });
    }
  });
  // Open/close favorites modal
  elements.favListIcon?.addEventListener("click", () => {
    if (!isActivated) {
      showNotification("Please activate the application first!");
      return;
    }
    if (elements.favoritesModal) {
      elements.favoritesModal.style.display = "block";
      elements.favoritesModal.setAttribute("aria-hidden", "false");
      elements.searchFavorites?.focus();
    }
  });
  elements.modalClose?.addEventListener("click", () => {
    if (elements.favoritesModal) {
      elements.favoritesModal.style.display = "none";
      elements.favoritesModal.setAttribute("aria-hidden", "true");
    }
  });
  elements.searchFavorites?.addEventListener("input", debounce((e) => {
    filterFavorites(e.target.value);
  }, 300));
  elements.clearAllFavorites?.addEventListener("click", () => {
    if (!isActivated) {
      showNotification("Please activate the application first!");
      return;
    }
    showCustomConfirm("Are you sure you want to clear all favorites?", () => {
      favorites = [];
      chrome.storage.local.set({
        favorites
      }, () => {
        updateFavoritesTable();
        if (elements.favIcon) elements.favIcon.classList.remove("active");
        resetToDefault();
        showNotification("Cleared all favorites");
      });
    });
  });
  // Export favorites
  elements.exportBtn?.addEventListener("click", () => {
    if (!isActivated) {
      showNotification("Please activate the application first!");
      return;
    }
    chrome.storage.local.get(["favorites"], (result) => {
      if (chrome.runtime.lastError) {
        handleError("Error exporting favorites:", chrome.runtime.lastError);
        showNotification("Error exporting list!");
        return;
      }
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(favorites));
      chrome.downloads.download({
        url: dataStr,
        filename: "favorites.json",
        conflictAction: "uniquify"
      });
      showNotification("Exported favorites list");
    });
  });
  // Import favorites
  elements.importBtn?.addEventListener("click", () => {
    if (!isActivated) {
      showNotification("Please activate the application first!");
      return;
    }
    elements.importFile?.click();
  });
  elements.importFile?.addEventListener("change", (event) => {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const importedFavorites = JSON.parse(e.target.result);
        importedFavorites.forEach(item => {
          const existingIndex = favorites.findIndex(f => f.link === item.link);
          if (existingIndex !== -1) favorites[existingIndex] = item;
          else favorites.push(item);
        });
        chrome.storage.local.set({
          favorites
        }, () => {
          updateFavoritesTable();
          updateStateBasedOnUrl(currentUrl);
          showNotification("Imported favorites list");
        });
      } catch (error) {
        handleError("Error importing favorites:", error);
        showNotification("Error: Invalid file!");
      }
    };
    reader.readAsText(file);
    elements.importFile.value = "";
  });
  // Theme toggle
  elements.themeToggle?.addEventListener("click", () => {
    const currentTheme = document.body.getAttribute("data-theme");
    const newTheme = currentTheme === "dark" ? "light" : "dark";
    document.body.setAttribute("data-theme", newTheme);
    elements.themeToggle.textContent = newTheme === "dark" ? "☀️" : "🌙";
    chrome.storage.local.set({
      theme: newTheme
    });
    showNotification(`Switched to ${newTheme} theme`);
  });
  // Refresh button to reset settings to default
  elements.refreshBtn?.addEventListener("click", () => {
    if (!isActivated) {
      showNotification("Please activate the application first!");
      return;
    }
    resetToDefault();
    sendMessageToActiveTab({
      type: "refreshState"
    }, () => {
      showNotification(elements.enabled?.checked ? "Refreshed state" : "Reset settings (not applied because extension is off)");
    });
  });
  // === DOWNLOAD COVER BUTTON – GỌN NHẸ, HOÀN HẢO, HỖ TRỢ DỊCH ===
  const downloadCoverBtn = document.getElementById("download-cover-btn");
  if (downloadCoverBtn) {
    downloadCoverBtn.addEventListener("click", () => {
      // Lấy từ điển ngôn ngữ hiện tại
      const t = translations[currentLang];
      if (!isActivated) {
        showNotification(t["Please activate the app before creating cover!"]);
        return;
      }
      sendMessageToActiveTab({
        type: "downloadCover"
      }, (response) => {
        if (response?.status === "success") {
          console.log("%c" + t["Download Cover started successfully – cosmic bass incoming!"], "color:gold;font-weight:bold;font-size:18px");
        } else if (response?.status === "error") {
          showNotification(response.message || t["Error creating cover! Check console for details"]);
        } else {
          showNotification(t["Creating cover... Magical toast + progress will appear on YouTube soon!"]);
        }
      });
    });
  }
  // Dynamic listeners for tab and message
  let onActivatedListener, onMessageListener;
  chrome.tabs.onActivated.addListener(onActivatedListener = () => syncState());
  chrome.runtime.onMessage.addListener(onMessageListener = handleContentMessage);
  // Sync when tab is updated (reload, URL change)
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (tabId === currentTabId && changeInfo.status === "complete") {
      syncState();
    }
  });
}
document.addEventListener("DOMContentLoaded", () => {
  // Khởi tạo kết nối với background nếu chưa có
  if (!port) {
    port = chrome.runtime.connect({
      name: "popup"
    });
    port.onDisconnect.addListener(() => {
      debugLog("Popup ngắt kết nối, lý do:", chrome.runtime.lastError?.message || "Không xác định");
      port = null;
    });
    try {
      init();
    } catch (error) {
      handleError("Lỗi khởi tạo extension:", error);
      showNotification("Lỗi khởi tạo extension!");
    }
  } else {
    debugLog("Popup đã kết nối trước đó, bỏ qua khởi tạo mới");
  }
  // 2. Gọi hàm kiểm tra update sau khi đã init xong
  showUpdateNotification();
  // Xử lý modal tác giả
  const authorIcon = document.getElementById('author-icon');
  const authorModal = document.getElementById('author-modal');
  const closeModal = document.getElementById('author-modal-close');
  const okButton = document.getElementById('author-modal-ok');

  function showModal() {
    if (authorModal) {
      authorModal.style.display = 'block';
      authorModal.removeAttribute('inert');
      authorModal.setAttribute('aria-hidden', 'false');
      if (okButton) okButton.focus();
    }
  }

  function hideModal() {
    if (authorModal) {
      if (okButton && okButton === document.activeElement && authorIcon) {
        authorIcon.setAttribute('tabindex', '0');
        authorIcon.focus();
      }
      authorModal.style.display = 'none';
      authorModal.setAttribute('inert', '');
      authorModal.setAttribute('aria-hidden', 'true');
    }
  }
  if (authorIcon) authorIcon.addEventListener('click', showModal);
  if (closeModal) closeModal.addEventListener('click', hideModal);
  if (okButton) okButton.addEventListener('click', hideModal);
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && authorModal && authorModal.style.display === 'block') {
      hideModal();
    }
  });
});
// Hàm hỗ trợ so sánh phiên bản (Giữ nguyên vì đã chuẩn)
function isVersionGreater(v1, v2) {
  const arr1 = v1.split('.').map(Number);
  const arr2 = v2.split('.').map(Number);
  for (let i = 0; i < Math.max(arr1.length, arr2.length); i++) {
    const num1 = arr1[i] || 0;
    const num2 = arr2[i] || 0;
    if (num1 > num2) return true;
    if (num1 < num2) return false;
  }
  return false;
}
async function showUpdateNotification() {
  const res = await chrome.storage.local.get(["updateInfo", "dismissedVersion"]);
  const info = res.updateInfo;
  if (!info) return;
  const currentVersion = chrome.runtime.getManifest().version;
  // Kiểm tra phiên bản chuẩn xác
  if (!isVersionGreater(info.latest_version, currentVersion) || res.dismissedVersion === info.latest_version) return;
  const modal = document.getElementById("update-modal");
  if (!modal) return;
  // Gán tiêu đề an toàn
  const titleEl = document.getElementById("update-title");
  if (titleEl) titleEl.textContent = info.announcement.title || "Cập nhật mới";
  // Gán nội dung an toàn
  const msgEl = document.getElementById("update-msg");
  if (msgEl) {
    let content = info.announcement.message || "";
    if (info.announcement.changelog && Array.isArray(info.announcement.changelog)) {
      const logText = info.announcement.changelog.map(item => "\n• " + item).join("");
      content += logText;
    }
    msgEl.textContent = content;
  }
  // 🎯 VÁ LỖI NỘI HÀM CHÈN SỰ KIỆN: Kiểm tra ID Video YouTube an toàn
  if (info.announcement.youtube_link) {
    const match = info.announcement.youtube_link.match(/(?:youtu\.be\/|youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=))([^"&?/\s]{11})/);
    const videoId = match ? match[1] : null;
    const container = document.getElementById("update-video-container");
    if (container && videoId) {
      // Thay vì dùng innerHTML tạo chuỗi thô bạo, tạo Element thuần để bảo mật tuyệt đối CSP
      container.textContent = ""; // Xóa sạch dữ liệu cũ tránh rác RAM
      const linkAnchor = document.createElement("a");
      linkAnchor.href = info.announcement.youtube_link;
      linkAnchor.target = "_blank";
      linkAnchor.style.textDecoration = "none";
      const wrapperDiv = document.createElement("div");
      wrapperDiv.style.position = "relative";
      wrapperDiv.style.cursor = "pointer";
      wrapperDiv.style.marginTop = "10px";
      const imgEl = document.createElement("img");
      imgEl.src = `https://img.youtube.com/vi/${videoId}/0.jpg`;
      imgEl.style.width = "100%";
      imgEl.style.borderRadius = "8px";
      imgEl.style.display = "block";
      const playBtn = document.createElement("div");
      playBtn.textContent = "▶";
      playBtn.style.cssText = "position:absolute; top:35%; left:40%; font-size:40px; color:white; text-shadow:0 0 5px #000;";
      wrapperDiv.appendChild(imgEl);
      wrapperDiv.appendChild(playBtn);
      linkAnchor.appendChild(wrapperDiv);
      container.appendChild(linkAnchor);
    }
  }
  // Hiện modal
  modal.classList.add("is-visible");
  // 🎯 VÁ LỖI RÒ RỈ RAM: Dùng EventListener kèm cờ { once: true } hoặc gỡ bỏ sự kiện cũ cũ
  const btnDownload = document.getElementById("btn-download");
  if (btnDownload) {
    // Xóa hàm cũ hoàn toàn để giải phóng bộ nhớ cũ
    btnDownload.onclick = null;
    btnDownload.onclick = () => {
      window.open(info.download_url, "_blank");
      chrome.storage.local.set({
        "dismissedVersion": info.latest_version
      });
      modal.classList.remove("is-visible");
    };
  }
  const btnClose = document.getElementById("btn-close-update");
  if (btnClose) {
    btnClose.onclick = null; // Chốt chặn chống phình RAM khi lặp sự kiện
    btnClose.onclick = () => {
      const checkbox = document.getElementById("dont-show-again");
      if (checkbox && checkbox.checked) {
        chrome.storage.local.set({
          "dismissedVersion": info.latest_version
        });
      }
      modal.classList.remove("is-visible");
    };
  }
}