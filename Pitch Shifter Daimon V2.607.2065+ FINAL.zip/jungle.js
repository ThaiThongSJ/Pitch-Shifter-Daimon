// jungle.js - Advanced Audio Processing Module with Smart Integration
(function() {
  if (window.__jungle_audio_module_marker__) {
    console.log("[Jungle Audio Module] Already loaded, skipping");
    return;
  }
  window.__jungle_audio_module_marker__ = true;
  'use strict';
  /**
   * HÀM XỬ LÝ LỖI TỐI ƯU: Không tạo rác khi chạy bình thường
   */
  function handleError(errorMessage, error, context = {}, severity = 'low', options = {}) {
    const isBrowser = typeof window !== 'undefined';
    const isDebug = isBrowser && (window.location.hostname === 'localhost' || window.location.search?.includes('debug=true'));
    // Xuất console nhanh theo mức độ nghiêm trọng
    if (severity === 'high') {
      console.error(`[CRITICAL ERROR]: ${errorMessage}`, error || "");
    } else if (isDebug) {
      console.warn(`[AUDIO WARNING]: ${errorMessage}`);
    }
    // 1. TRÍCH XUẤT NGỮ CẢNH (ĐỒNG BỘ TUYỆT ĐỐI THEO proNatural)
    const spectralProfile = context.spectralProfile || {
      profile: 'proNatural' // 🪐 VÁ LỖI LOGIC: Đổi hẳn từ smartStudio sang proNatural cho nhất quán hệ thống
    };
    const songStructure = context.songStructure || {
      section: 'unknown'
    };
    const errorType = context.function === 'getCPULoad' ? 'performance' : context.requestedSize ? 'audio' : 'memory';
    // 2. THU THẬP DỮ LIỆU HIỆU NĂNG AN TOÀN (Rút ngắn thời gian truy cập Window)
    let cpuLoadVal = 'unknown';
    let memUsedStr = 'N/A';
    if (options.memoryManager && typeof options.memoryManager.get === 'function') {
      const history = options.memoryManager.get('cpuLoadHistory');
      if (Array.isArray(history) && history.length > 0) {
        cpuLoadVal = history[history.length - 1].load || 'unknown';
      }
    }
    if (isBrowser && window.performance?.memory) {
      const mem = window.performance.memory;
      if (Number.isFinite(mem.usedJSHeapSize) && mem.jsHeapSizeLimit > 0) {
        memUsedStr = (mem.usedJSHeapSize / 1048576).toFixed(2) + ' MB';
      }
    }
    // 3. CẤU TRÚC LỖI NGUYÊN BẢN (Tuyệt đối không làm hỏng liên kết ứng dụng)
    const errorDetails = {
      message: `${errorMessage}: ${error?.message || "Unknown error"}`,
      stack: error?.stack || "",
      context: {
        ...context,
        spectralProfile: spectralProfile.profile,
        songStructure: songStructure.section,
        performance: {
          cpuLoad: cpuLoadVal,
          memoryUsed: memUsedStr
        }
      },
      errorType,
      severity,
      timestamp: Date.now()
    };
    // 4. LƯU TRỮ LỊCH SỬ (Dùng Shift nhanh, giới hạn RAM thông minh)
    if (options.memoryManager && typeof options.memoryManager.get === 'function' && typeof options.memoryManager.set === 'function') {
      try {
        const deviceMemory = (typeof navigator !== 'undefined' ? navigator.deviceMemory : null) || 4;
        const maxErrors = deviceMemory < 4 ? 20 : 40;
        let errorHistory = options.memoryManager.get('errorHistory') || [];
        if (!Array.isArray(errorHistory)) errorHistory = [];
        errorHistory.push(errorDetails);
        if (errorHistory.length > maxErrors) {
          errorHistory.shift();
        }
        options.memoryManager.set('errorHistory', errorHistory, 'high');
      } catch (storeError) {
        // Im lặng bảo vệ luồng âm thanh
      }
    }
    // 5. BÁO CÁO SERVER TRONG SUỐT (Chỉ gửi lỗi high khi online)
    if (options.reportToServer && severity === 'high' && isBrowser && navigator.onLine) {
      try {
        fetch(options.reportToServer, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(errorDetails),
          keepalive: true
        }).catch(() => {});
      } catch (fetchError) {}
    }
    if (isDebug) console.debug('Error Details Quantum:', errorDetails);
  }
  /**
   * TỐI ƯU CỰC ĐẠI: Fast-path cho dữ liệu âm thanh.
   * Dùng cho các giá trị chạy hàng triệu lần/giây (Buffer, Frequency data)
   */
  function ensureFinite(value, defaultValue = 0, options = {}) {
    // Fast path: Định dạng số chuẩn xác thì thoát sớm cực nhanh (Tốc độ tối đa)
    if (typeof value === 'number' && Number.isFinite(value)) {
      return value;
    }
    // Slow path: Chỉ xử lý khi gặp giá trị lỗi (NaN, Infinity)
    const isBrowser = typeof window !== 'undefined';
    const isDebug = isBrowser && (window.location.hostname === 'localhost' || window.location.search.includes('debug=true'));
    if (isDebug) {
      const errorMessage = options.errorMessage || `Invalid value: ${value}, using default: ${defaultValue}`;
      console.warn(`[Jungle Safety]: ${errorMessage}`);
    }
    return defaultValue;
  }
  /**
   * Jungle Core - CPU Load Monitor v18.2 FINAL (Refined by Gemini)
   * Chức năng: Đo đạc và dự báo tải hệ thống để điều phối thuật toán Audio.
   * Cam kết: Giữ nguyên trọng số Profile, tối ưu RAM/CPU, Fix Crash.
   */
  Jungle.prototype.getCPULoad = function() {
    // 1. AN TOÀN HỆ THỐNG & VALIDATION (GIỮ NGUYÊN CHÍNH XÁC)
    const AudioContextClass = (typeof window !== 'undefined') ? (window.AudioContext || window.webkitAudioContext) : null;
    if (!this.context || (AudioContextClass && !(this.context instanceof AudioContextClass))) {
      if (typeof handleError === 'function') {
        handleError('Invalid AudioContext', new Error('AudioContext is invalid'), {
          function: 'getCPULoad'
        }, 'high', {
          memoryManager: this.memoryManager
        });
      }
      return this.qualityMode === 'low' ? 0.3 : 0.7;
    }
    const perf = (typeof window !== 'undefined' && window.performance) ? window.performance : null;
    const isDebug = (typeof window !== 'undefined' && window.location) ? (window.location.hostname === 'localhost' || window.location.search.includes('debug=true')) : false;
    if (isDebug && perf) perf.mark('cpu-load-start');
    // 2. THÔNG SỐ MÔI TRƯỜNG 
    const sampleRate = this.context.sampleRate || 48000;
    const audioLatency = this.context.baseLatency || this.context.outputLatency || 0;
    let latencyFactor = Math.min(audioLatency * 35, 0.2);
    const workerLoad = this.worker && Number.isFinite(this.nextProcessingInterval) ? Math.min(this.nextProcessingInterval / 2000, 0.12) : 0;
    const nav = (typeof navigator !== 'undefined') ? navigator : {};
    const isIOS = nav.userAgent ? /iPad|iPhone|iPod/.test(nav.userAgent) : false;
    const hardwareConcurrency = nav.hardwareConcurrency || (isIOS ? 2 : 4);
    const deviceLoad = Math.min(1 / (hardwareConcurrency * 1.8), 0.08);
    let memoryFactor = 0;
    if (perf && perf.memory && Number.isFinite(perf.memory.usedJSHeapSize) && perf.memory.jsHeapSizeLimit > 0) {
      memoryFactor = Math.min(perf.memory.usedJSHeapSize / perf.memory.jsHeapSizeLimit, 0.08);
    }
    let gpuLoad = 0;
    if (this.webGPUDevice && this.devicePerf === 'high' && this.fftSize && this.webGPUDevice.limits?.maxComputeWorkgroupStorageSize) {
      gpuLoad = Math.min(0.15, this.webGPUDevice.limits.maxComputeWorkgroupStorageSize / (this.fftSize * 3));
    }
    // 3. LOGIC XỬ LÝ ÂM HỌC VÀ PROFILE Chuẩn proNatural (ĐỒNG BỘ 100%)
    const spectralProfile = this.spectralProfile || {
      profile: 'proNatural', // 🪐 ĐỒNG BỘ 1: Chuyển profile gốc mặc định sang proNatural
      bass: 0.5,
      vocalPresence: 0.5,
      transientEnergy: 0.5
    };
    const pProfile = spectralProfile.profile;
    const songStructure = (this.memoryManager && typeof this.memoryManager.get === 'function') ? this.memoryManager.get('lastStructure') || {
      section: 'unknown'
    } : {
      section: 'unknown'
    };
    const psychoacousticWeight = (typeof this.calculatePsychoacousticWeight === 'function') ? this.calculatePsychoacousticWeight(spectralProfile, songStructure) || 1.0 : 1.0;
    // ÁP DỤNG 8 PROFILE CHÍNH XÁC THEO TRỤC CẤU HÌNH MỚI
    if (pProfile === 'bassHeavy' || spectralProfile.bass > 0.78) {
      latencyFactor = Math.min(latencyFactor * 1.025 * psychoacousticWeight * 1.03, 0.2);
    } else if (pProfile === 'vocal' || spectralProfile.vocalPresence > 0.72) {
      latencyFactor = Math.min(latencyFactor * 0.885 * psychoacousticWeight * 1.08, 0.2);
    } else if (pProfile === 'rockMetal' || spectralProfile.transientEnergy > 0.72) {
      latencyFactor = Math.min(latencyFactor * 1.015 * psychoacousticWeight * 1.02, 0.2);
    } else if (pProfile === 'warm') {
      latencyFactor = Math.min(latencyFactor * 0.96 * psychoacousticWeight * 1.04, 0.2);
    } else if (pProfile === 'bright') {
      latencyFactor = Math.min(latencyFactor * 0.98 * psychoacousticWeight * 1.03, 0.2);
    } else if (pProfile === 'proNatural' || pProfile === 'karaokeDynamic' || pProfile === 'smartStudio') {
      // 🪐 ĐỒNG BỘ 2: Gom smartStudio cũ chạy chung hệ số tối ưu cao của proNatural để tự động di cư cấu hình an toàn
      latencyFactor = Math.min(latencyFactor * 0.91 * psychoacousticWeight * 1.07, 0.2);
    }
    // 4. TÍNH DURATION (GIỮ NGUYÊN LUỒNG ĐO ĐẠC)
    let duration = 0;
    if (isDebug && perf) {
      perf.mark('cpu-load-end');
      try {
        perf.measure('cpu-load', 'cpu-load-start', 'cpu-load-end');
        const measures = perf.getEntriesByName('cpu-load');
        if (measures.length > 0) duration = measures[measures.length - 1].duration;
        perf.clearMarks('cpu-load-start');
        perf.clearMarks('cpu-load-end');
        perf.clearMeasures('cpu-load');
      } catch (e) {}
    }
    let load = Math.min((duration / 10) * (sampleRate / 48000) * psychoacousticWeight + latencyFactor + workerLoad + deviceLoad + memoryFactor + gpuLoad, 1);
    // 5. QUẢN LÝ LỊCH SỬ TẢI
    let averageLoad = load;
    if (this.memoryManager && typeof this.memoryManager.get === 'function' && typeof this.memoryManager.set === 'function') {
      try {
        let loadHistory = this.memoryManager.get('cpuLoadHistory') || [];
        if (!Array.isArray(loadHistory)) loadHistory = [];
        const lastItem = loadHistory.length > 0 ? loadHistory[loadHistory.length - 1] : null;
        const lastLoad = lastItem ? parseFloat(lastItem.load || lastItem) : 0;
        if (loadHistory.length === 0 || Math.abs(load - lastLoad) > 0.025) {
          loadHistory.push({
            load: load.toFixed(3),
            timestamp: Date.now(),
            spectralProfile: pProfile,
            songSection: songStructure.section
          });
          if (loadHistory.length > 25) loadHistory.shift();
          this.memoryManager.set('cpuLoadHistory', loadHistory, 'high');
        }
        if (loadHistory.length > 0) {
          let sum = 0;
          for (let i = 0; i < loadHistory.length; i++) {
            sum += parseFloat(loadHistory[i].load || loadHistory[i]);
          }
          averageLoad = sum / loadHistory.length;
        }
      } catch (error) {
        if (typeof handleError === 'function') {
          handleError('Error managing CPU load history', error, {
            load,
            sampleRate,
            spectralProfile,
            songStructure
          }, 'medium', {
            memoryManager: this.memoryManager
          });
        }
      }
    }
    // 6. DEBUG LOG NGUYÊN BẢN
    if (isDebug) {
      console.debug('CPU Load v18.2 QuantumSmart Optimized:', {
        averageLoad: Number(averageLoad).toFixed(3),
        instantLoad: load.toFixed(3),
        duration: duration.toFixed(2),
        latencyFactor: latencyFactor.toFixed(4),
        psychoacousticWeight: psychoacousticWeight.toFixed(3),
        profile: pProfile,
        songSection: songStructure.section,
        workerLoad,
        deviceLoad,
        memoryFactor,
        gpuLoad
      });
    }
    return Number.isFinite(averageLoad) ? Math.max(0, Math.min(1, averageLoad)) : (this.qualityMode === 'low' ? 0.3 : 0.7);
  };
  // ===================================================================================================
  // === SYSTEM COMPONENT 1: SIÊU HÀM ĐIỀU CHỈNH ĐỘ DÀI CỬA SỔ HÀN GẮN HẠT (PUREFADE MẠNH MẼ v16.0 PRO) ===
  // ===================================================================================================
  function adjustFadeLength(fadeLength, sampleRate, spectralProfile, pitchShift, isVocal, cpuLoad, isLowPowerDevice, options = {}) {
    const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
    // 1. Kiểm tra dữ liệu đầu vào nghiêm ngặt - Xương sống bảo vệ luồng âm thanh
    if (!Number.isFinite(fadeLength) || fadeLength <= 0 || !Number.isFinite(sampleRate) || sampleRate <= 0) {
      if (typeof handleError === 'function') {
        handleError('Dữ liệu fadeLength hoặc sampleRate không hợp lệ', new Error('Invalid input metrics'), {
          fadeLength,
          sampleRate
        }, 'low', options);
      }
      return 64; // Thiết lập điểm neo khôi phục an toàn tối thiểu
    }
    // 2. Chuẩn hóa giá trị Pitch Shift - Khóa chặt sai số dải biên tần
    const fastFinite = (val, def) => (typeof val === 'number' && Number.isFinite(val)) ? val : def;
    const absPitchShift = (typeof ensureFinite === 'function') ? ensureFinite(Math.abs(pitchShift || 0), 0, {
      errorMessage: 'Invalid pitchShift'
    }) : fastFinite(Math.abs(pitchShift), 0);
    // 3. Thuật toán tính toán minFadeLength tĩnh - Đồng bộ hóa ma trận 8 Profile phù thủy
    const calculateMinFadeLength = (absPitchShift, cpuLoad, isLowPowerDevice, instrumentType) => {
      let base = (instrumentType === 'vocal' || isVocal) ? 1152 : (instrumentType === 'drum') ? 1024 : (instrumentType === 'guitar' || instrumentType === 'piano') ? 896 : 896;
      if (absPitchShift > 0.7) base *= 1.28;
      else if (absPitchShift > 0.3) base *= 1.14;
      if (cpuLoad > 0.95 || (isLowPowerDevice && cpuLoad > 0.9)) {
        base = Math.max(576, base * 0.68); // Bộ giảm chấn chống vỡ tiếng, bảo vệ năng lực CPU
      }
      // Ma trận 8 Profile phản hồi thính giác lõi phần cứng (Đảm bảo an toàn context)
      const activeProfile = this?.profile || options?.profile || 'proNatural';
      if (activeProfile === 'bassHeavy') base *= 1.12;
      if (activeProfile === 'rockMetal') base *= 1.08;
      if (activeProfile === 'vocal' || activeProfile === 'karaokeDynamic') base *= 1.18;
      if (activeProfile === 'smartStudio') base *= 1.15;
      if (activeProfile === 'warm') base *= 1.06;
      if (activeProfile === 'bright') base *= 1.04;
      if (activeProfile === 'proNatural') base *= 1.10;
      return Math.round(base);
    };
    // 4. Chuẩn hóa trắc phổ sinh học - 7 yếu tố nền tảng
    const spectralDefaults = {
      spectralComplexity: 0.5,
      transientEnergy: 0.5,
      vocalPresence: 0.5,
      bass: 0.5,
      midHigh: 0.5,
      air: 0.5,
      spectralEntropy: 0.5
    };
    const validatedSpectralProfile = Object.keys(spectralDefaults).reduce((acc, key) => {
      const val = spectralProfile?.[key];
      acc[key] = (typeof ensureFinite === 'function') ? ensureFinite(val, spectralDefaults[key]) : fastFinite(val, spectralDefaults[key]);
      acc[key] = Math.max(0, Math.min(1, acc[key]));
      return acc;
    }, {
      ...spectralDefaults
    });
    // 5. Công cụ nhận diện nhạc cụ thời gian thực độc lập
    const detectInstrument = (sp) => {
      if (sp.transientEnergy > 0.92 && sp.bass > 0.87) return 'drum';
      if (sp.midHigh > 0.87 && sp.transientEnergy > 0.78) return 'guitar';
      if (sp.midHigh > 0.82 && sp.spectralComplexity > 0.78) return 'piano';
      return 'vocal';
    };
    const instrumentType = detectInstrument(validatedSpectralProfile);
    const minFadeLength = calculateMinFadeLength(absPitchShift, cpuLoad, isLowPowerDevice, instrumentType);
    // 6. Ma trận trọng số chất lượng âm học - Bảo toàn trường phổ
    const qualityFactor = options.qualityMode === 'low' ? 0.88 : 1.18;
    const {
      transientBoost = 1.32 * qualityFactor,
        vocalBoost = 1.38 * qualityFactor,
        bassBoost = 1.30 * qualityFactor,
        midHighBoost = 1.18 * qualityFactor,
        airReduction = 0.76 / qualityFactor,
        highCpuReduction = 0.92 / qualityFactor,
        memoryManager = null
    } = options;
    // 7. Đo lường Entropy và hệ số suy giảm dải Air chống xé tiếng xì
    const entropyFactor = Math.min(1.0, 0.975 + (1 - validatedSpectralProfile.spectralEntropy) * 0.025);
    const spectralSubtractionFactor = validatedSpectralProfile.air > 0.82 || validatedSpectralProfile.bass > 0.82 ? 0.78 : 0.86;
    // 8. Thuật toán AI-Driven FadeBoost - Phối hợp chuỗi nhân đa tầng
    const currentProfile = this?.profile || options.profile || 'proNatural';
    const fadeBoost = (instrumentType === 'drum' ? 1.36 : instrumentType === 'guitar' ? 1.28 : instrumentType === 'piano' ? 1.24 : validatedSpectralProfile.vocalPresence > 0.92 ? 1.38 : 1.0) * (validatedSpectralProfile.transientEnergy > 0.92 ? 1.36 : 1.0) * (absPitchShift > 1.3 ? 1.42 : absPitchShift > 0.8 ? 1.22 : 1.0) * (currentProfile === 'vocal' || currentProfile === 'karaokeDynamic' ? 1.32 : 1.0) * (currentProfile === 'rockMetal' || validatedSpectralProfile.bass > 0.92 ? 1.28 : 1.0) * (currentProfile === 'bassHeavy' ? 1.22 : 1.0) * (currentProfile === 'smartStudio' ? 1.18 : 1.0) * (currentProfile === 'warm' ? 1.08 : 1.0) * (currentProfile === 'bright' ? 1.06 : 1.0);
    // 9. Tính toán độ dài cửa sổ tích hợp chuỗi nhân ma thuật
    let adjustedLength = fadeLength;
    if (validatedSpectralProfile.transientEnergy > 0.78 || validatedSpectralProfile.vocalPresence > 0.78) {
      adjustedLength *= isVocal ? vocalBoost * fadeBoost * 1.02 : transientBoost * fadeBoost * 1.01;
    }
    if (validatedSpectralProfile.bass > 0.78) adjustedLength *= bassBoost * fadeBoost * 1.04;
    if (validatedSpectralProfile.midHigh > 0.78) adjustedLength *= midHighBoost * fadeBoost * (validatedSpectralProfile.air > 0.78 ? 0.88 : 1.0);
    if (validatedSpectralProfile.spectralEntropy > 0.78) adjustedLength *= 1.24 * qualityFactor * entropyFactor;
    if (validatedSpectralProfile.air > 0.78 && validatedSpectralProfile.transientEnergy < 0.58) {
      adjustedLength *= airReduction * spectralSubtractionFactor;
    }
    if (cpuLoad > 0.9 || (cpuLoad > 0.85 && isLowPowerDevice)) {
      adjustedLength *= highCpuReduction * (validatedSpectralProfile.vocalPresence > 0.78 ? 1.14 : 1.0);
    }
    // 10. Bộ giới hạn vật lý tối đa (Clamp) - Khống chế thời gian trễ không vượt quá 280ms
    adjustedLength = Math.max(minFadeLength, Math.round(fastFinite(adjustedLength, fadeLength)));
    const maxFadeLength = Math.round(sampleRate * 0.28);
    adjustedLength = Math.min(maxFadeLength, adjustedLength);
    // 11. MẠCH LƯU TRỮ LỊCH SỬ CHỐNG PHÌNH RAM (ZERO ALLOCATION STRATEGY)
    if (memoryManager && typeof memoryManager.get === 'function' && typeof memoryManager.set === 'function') {
      try {
        let history = memoryManager.get('fadeLengthHistory') || [];
        if (!Array.isArray(history)) history = [];
        history.push({
          length: adjustedLength,
          timestamp: Date.now(),
          instrumentType,
          profile: currentProfile,
          pitchShift: absPitchShift.toFixed(2)
        });
        const maxHistory = isLowPowerDevice ? 15 : 20;
        if (history.length > maxHistory) {
          history = history.slice(-maxHistory);
        }
        memoryManager.set('fadeLengthHistory', history, 'normal');
      } catch (e) {
        if (typeof handleError === 'function') {
          handleError('Thất bại khi lưu trữ lịch sử cấu hình ô đệm fade', e, {
            adjustedLength
          }, 'low', {
            memoryManager
          });
        }
      }
    }
    if (isDebug) {
      console.debug('PureFadeMaster v16.0 PRO Optimized', {
        adjustedLength,
        minFadeLength,
        fadeBoost: +fadeBoost.toFixed(3),
        profile: currentProfile,
        instrumentType,
        pitchShift: absPitchShift
      });
    }
    return adjustedLength;
  }
  // ===================================================================================================
  // === SYSTEM COMPONENT 2: MẠCH TRÍCH XUẤT CỬA SỔ ĐỆM ĐỒNG BỘ ĐỐI XỨNG PHẦN CỨNG (getFadeBuffer) ===
  // ===================================================================================================
  function getFadeBuffer(context, activeTime, fadeTime, options = {}, memoryManager) {
    if (!(context instanceof(window.AudioContext || window.webkitAudioContext))) {
      if (typeof handleError === 'function') {
        handleError('Hệ thống AudioContext không hợp lệ hoặc đã bị treo giải phóng', new Error('Context Type Mismatch'), {}, 'high', {
          memoryManager
        });
      }
      return null;
    }
    const fastFinite = (val, def) => (typeof val === 'number' && Number.isFinite(val)) ? val : def;
    activeTime = (typeof ensureFinite === 'function') ? ensureFinite(activeTime, 0.25) : fastFinite(activeTime, 0.25);
    fadeTime = (typeof ensureFinite === 'function') ? ensureFinite(fadeTime, 0.15) : fastFinite(fadeTime, 0.15);
    if (!memoryManager || typeof memoryManager.getBuffer !== 'function') {
      if (typeof handleError === 'function') {
        handleError('Bộ quản lý bộ nhớ memoryManager bắt buộc phải được khởi tạo', new Error('Missing memoryManager core'), {}, 'high', {
          memoryManager
        });
      }
      return null;
    }
    const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
    const {
      pitchShift = 0,
        isVocal = false,
        qualityMode = 'high',
        channels = 2,
        spectralProfile = {},
        profile = 'proNatural'
    } = options;
    const cpuLoad = (typeof this?.getCPULoad === 'function') ? this.getCPULoad() : 0.5;
    const avgCpuLoad = cpuLoad;
    const spectralDefaults = {
      spectralComplexity: 0.5,
      transientEnergy: 0.5,
      vocalPresence: 0.5,
      bass: 0.5,
      midHigh: 0.5,
      air: 0.5,
      spectralEntropy: 0.5
    };
    const validatedSpectralProfile = Object.keys(spectralDefaults).reduce((acc, key) => {
      const val = spectralProfile?.[key];
      acc[key] = Number.isFinite(val) ? Math.max(0, Math.min(1, val)) : spectralDefaults[key];
      return acc;
    }, {
      ...spectralDefaults
    });
    const detectInstrument = (sp) => {
      const scoreDrum = sp.transientEnergy * 0.6 + sp.bass * 0.4;
      const scoreGuitar = sp.midHigh * 0.5 + sp.transientEnergy * 0.3 + sp.spectralComplexity * 0.2;
      const scorePiano = sp.midHigh * 0.4 + sp.spectralComplexity * 0.4 + sp.transientEnergy * 0.2;
      const scoreVocal = sp.vocalPresence * 0.7 + sp.midHigh * 0.3;
      const scores = {
        drum: scoreDrum,
        guitar: scoreGuitar,
        piano: scorePiano,
        vocal: scoreVocal
      };
      return Object.keys(scores).reduce((a, b) => scores[a] > scores[b] ? a : b, 'vocal');
    };
    const instrumentType = detectInstrument(validatedSpectralProfile);
    // SỬA LỖI ĐỐI XỨNG CACHE KEY: Khóa chặt nhãn cấu hình hình học đường quan
    const curveType = (instrumentType === 'drum' || instrumentType === 'vocal') ? 'cosine' : 'exponential';
    const spectralKey = `${validatedSpectralProfile.spectralComplexity}_${validatedSpectralProfile.vocalPresence}_${validatedSpectralProfile.transientEnergy}_${validatedSpectralProfile.bass}_${validatedSpectralProfile.midHigh}_${validatedSpectralProfile.air}_${validatedSpectralProfile.spectralEntropy}`;
    const key = `fade_${activeTime}_${fadeTime}_${pitchShift}_${isVocal}_${qualityMode}_${channels}_${instrumentType}_${curveType}_${spectralKey}_${profile}`;
    let buffer = memoryManager.getBuffer(key);
    const expiryTime = 60000;
    const bufferMetadata = memoryManager.get(key)?.metadata;
    const lastPitchShift = bufferMetadata?.lastPitchShift || 0;
    const pitchDelta = Math.abs(pitchShift - lastPitchShift);
    const canReuse = pitchDelta < 0.05 && (Date.now() - (bufferMetadata?.timestamp || 0)) < (expiryTime * 1.5);
    if (buffer && buffer instanceof AudioBuffer && buffer.length >= activeTime * context.sampleRate) {
      if (bufferMetadata?.timestamp && Date.now() - bufferMetadata.timestamp > expiryTime && !canReuse) {
        if (isDebug) console.debug(`[Zölzer Cache] Khóa đệm đã hết hạn thời gian thực: ${key}, tiến hành tạo lại`);
        buffer = null;
      } else {
        const isBufferValid = (() => {
          if (avgCpuLoad > 0.8) return true;
          let score = 1.0;
          if (validatedSpectralProfile.bass > 0.85 && validatedSpectralProfile.transientEnergy < 0.65) score *= 0.9;
          if (validatedSpectralProfile.midHigh > 0.8) score *= 1.05;
          if (validatedSpectralProfile.air > 0.85 && validatedSpectralProfile.spectralEntropy > 0.85) score *= 0.85;
          if (profile === 'bassHeavy' || validatedSpectralProfile.bass > 0.88) score *= 1.06;
          if (profile === 'vocal' || profile === 'karaokeDynamic' || validatedSpectralProfile.vocalPresence > 0.88) score *= 1.10;
          if (profile === 'smartStudio') score *= 1.08;
          if (profile === 'rockMetal') score *= 1.05;
          if (profile === 'warm') score *= 1.03;
          if (profile === 'bright') score *= 1.02;
          return score >= 0.9;
        })();
        if (!isBufferValid) {
          if (isDebug) console.debug(`[Zölzer Cache] Sai lệch đặc tuyến thính giác thực tế: ${key}, hủy bỏ ô đệm cũ`);
          buffer = null;
        }
      }
    } else {
      if (buffer && typeof handleError === 'function') {
        handleError('Cấu trúc ô đệm kéo dải không tương thích dung lượng hình học', new Error('AudioBuffer dimension mismatch'), {
          key,
          bufferLength: buffer?.length
        }, 'low', {
          memoryManager
        });
      }
      buffer = null;
    }
    if (!buffer && avgCpuLoad < 0.85) {
      try {
        // Đồng bộ hóa nghiêm ngặt các tham số dải biên tần truyền xuống khối lõi sinh mẫu
        buffer = createFadeBuffer.call(this, context, activeTime, fadeTime, {
          ...options,
          instrumentType,
          curveType
        }, memoryManager);
        if (!buffer || !(buffer instanceof AudioBuffer) || buffer.length <= 0) {
          throw new Error('Mạch sinh mẫu tạo ra ô đệm AudioBuffer trống rỗng hoặc hỏng pha');
        }
        memoryManager.set(key, buffer, 'high', {
          metadata: {
            timestamp: Date.now(),
            instrumentType,
            curveType,
            spectralProfile: validatedSpectralProfile,
            lastPitchShift: pitchShift,
            profile
          }
        });
        const isLowPower = navigator.hardwareConcurrency < 4;
        const maxBuffers = isLowPower ? 3 : 5;
        const allKeys = (typeof memoryManager.getAllKeys === 'function') ? memoryManager.getAllKeys() : [];
        if (allKeys.length > maxBuffers) {
          const sortedKeys = allKeys.sort((a, b) => (memoryManager.get(a)?.metadata?.timestamp || 0) - (memoryManager.get(b)?.metadata?.timestamp || 0));
          for (let i = 0; i < sortedKeys.length - maxBuffers; i++) {
            memoryManager.remove(sortedKeys[i]);
          }
          if (isDebug) console.debug(`[Zölzer Cache] Giải phóng thành công ${sortedKeys.length - maxBuffers} khối đệm cũ để dập tắt nghẹt RAM`);
        }
      } catch (error) {
        if (typeof handleError === 'function') {
          handleError('Lỗi nghiêm trọng trong chu kỳ thiết lập dải đệm thính giác', error, {
            key,
            activeTime,
            fadeTime,
            options
          }, 'high', {
            memoryManager
          });
        }
        buffer = null;
      }
    }
    if (!buffer) {
      const minFrames = 1024;
      const simpleLength = Math.max(minFrames, Math.round(activeTime * context.sampleRate * 0.8));
      buffer = context.createBuffer(channels, simpleLength, context.sampleRate);
      for (let ch = 0; ch < channels; ch++) {
        buffer.getChannelData(ch).fill(0);
      }
      if (isDebug) console.debug('[Zölzer Critical Fallback] Kích hoạt ô đệm phẳng câm lặng bảo vệ dòng truyền tín hiệu');
    }
    return buffer;
  }
  // ===================================================================================================
  // === SYSTEM COMPONENT 3: SIÊU HÀM TẠO ĐỒ THỊ CỬA SỔ HÀN HẠT (VÁ LỖI CHỒNG LẤN HÌNH HỌC KHÓA PHA) ===
  // ===================================================================================================
  function createFadeBuffer(context, activeTime, fadeTime, options = {}, memoryManager) {
    if (!(context instanceof(window.AudioContext || window.webkitAudioContext))) {
      if (typeof handleError === 'function') {
        handleError('Hệ thống AudioContext không hợp lệ ở tầng sinh mẫu đồ thị', new Error('Invalid hardware line context'), {}, 'high', {
          memoryManager
        });
      }
      throw new Error("AudioContext không khả dụng.");
    }
    const fastFinite = (val, def) => (typeof val === 'number' && Number.isFinite(val)) ? val : def;
    activeTime = (typeof ensureFinite === 'function') ? ensureFinite(activeTime, 0.2) : fastFinite(activeTime, 0.2);
    fadeTime = (typeof ensureFinite === 'function') ? ensureFinite(fadeTime, 0.1) : fastFinite(fadeTime, 0.1);
    const {
      smoothness = 1.0,
        vibrance = 0.85,
        pitchShift = 0,
        isVocal = false,
        spectralProfile = {},
        qualityMode = 'high',
        channels = 1,
        transientBoost = 1.1,
        vocalWarmth = 1.2,
        curveType = 'bezier-cosine-blend'
    } = options;
    const sampleRate = (typeof ensureFinite === 'function') ? ensureFinite(context.sampleRate, 48000) : context.sampleRate || 48000;
    const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
    try {
      if (sampleRate <= 0) throw new Error("Tần số lấy mẫu sampleRate của phần cứng sai lệch vật lý.");
      const cpuLoad = (typeof this?.getCPULoad === 'function') ? this.getCPULoad() : 0.5;
      const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
      const loadHistory = memoryManager?.get('cpuLoadHistory') || [];
      const avgCpuLoad = loadHistory.length > 0 ? loadHistory.reduce((sum, val) => sum + val, 0) / loadHistory.length : cpuLoad;
      const spectralDefaults = {
        spectralComplexity: 0.5,
        transientEnergy: 0.5,
        vocalPresence: 0.5,
        bass: 0.5,
        midHigh: 0.5,
        air: 0.5,
        spectralEntropy: 0.5
      };
      const validatedSpectralProfile = Object.keys(spectralDefaults).reduce((acc, key) => {
        const val = spectralProfile?.[key];
        acc[key] = Number.isFinite(val) ? Math.max(0, Math.min(1, val)) : spectralDefaults[key];
        return acc;
      }, {
        ...spectralDefaults
      });
      const entropyFactor = Math.min(1.0, 0.92 + (1 - validatedSpectralProfile.spectralEntropy) * 0.08);
      const aiFadeFactor = (validatedSpectralProfile.vocalPresence > 0.7 ? 1.1 : 1.0) * (validatedSpectralProfile.transientEnergy > 0.7 ? 1.15 : 1.0) * (Math.abs(pitchShift) > 0.8 ? 1.2 : 1.0) * ((this?.profile === 'vocal' || this?.profile === 'karaokeDynamic') ? 1.1 : 1.0);
      let minFadeLength = 1024;
      if (avgCpuLoad > 0.85 || (isLowPowerDevice && qualityMode === 'low')) {
        minFadeLength = 640;
      } else if (Math.abs(pitchShift) > 0.9 || validatedSpectralProfile.transientEnergy > 0.8 || validatedSpectralProfile.vocalPresence > 0.8) {
        minFadeLength = 1024;
      }
      if (this?.profile === 'bassHeavy' || this?.profile === 'rockMetal' || validatedSpectralProfile.bass > 0.8) {
        minFadeLength = Math.round(minFadeLength * 1.2);
      } else if (this?.profile === 'vocal' || this?.profile === 'smartStudio') {
        minFadeLength = Math.round(minFadeLength * 1.15);
      }
      let fadeLength = Math.max(Math.round(fadeTime * sampleRate * aiFadeFactor), minFadeLength);
      // === FIX ĐƯỜNG TRUYỀN CONTEXT TRÁNH CRASH RUNTIME ===
      if (typeof adjustFadeLength === 'function') {
        fadeLength = adjustFadeLength.call(this, fadeLength, sampleRate, validatedSpectralProfile, pitchShift, isVocal, avgCpuLoad, isLowPowerDevice, options);
      }
      if (this?.profile === 'rockMetal' || validatedSpectralProfile.bass > 0.8 || validatedSpectralProfile.spectralEntropy > 0.8) {
        fadeLength = Math.round(fadeLength * 1.2);
      } else if (this?.profile === 'vocal' || this?.profile === 'karaokeDynamic') {
        fadeLength = Math.round(fadeLength * 1.15);
      } else if (this?.profile === 'bright' || this?.profile === 'smartStudio') {
        fadeLength = Math.round(fadeLength * 1.1);
      }
      const actualFadeTime = fadeLength / sampleRate;
      const activeLength = Math.round(activeTime * sampleRate);
      // FIX LỖI SỰ SỤT ĐỔ HÌNH HỌC (WINDOWING DISTORTION CHỐNG CHỒNG LẤN CỬA SỔ CHÉO)
      fadeLength = Math.min(fadeLength, Math.floor(activeLength / 2) - 8);
      let totalLength = activeLength + Math.max(0, Math.round((activeTime - 2 * actualFadeTime) * sampleRate));
      const minTotalFrames = minFadeLength * 2 + 512;
      totalLength = Math.max(totalLength, minTotalFrames);
      let bufferTimeFactor = (qualityMode === 'high' && avgCpuLoad < 0.7 ? 1.35 : 0.85) * (Math.abs(pitchShift) > 0.9 ? 1.25 : 1.0) * (isLowPowerDevice || avgCpuLoad > 0.8 ? 0.65 : 1.0) * (validatedSpectralProfile.transientEnergy > 0.8 ? transientBoost * 1.15 : 1.0) * (validatedSpectralProfile.spectralEntropy > 0.8 ? 1.2 : 1.0) * ((this?.profile === 'vocal' || this?.profile === 'smartStudio') ? 1.15 : 1.0);
      const adjustedActiveTime = activeTime * bufferTimeFactor;
      if (fadeLength < 128) {
        console.warn(`[Zölzer DSP] Cửa sổ gối hạt quá ngắn (${fadeLength} mẫu), nguy cơ xé pha rất cao.`);
      }
      const buffer = context.createBuffer(channels, totalLength, sampleRate);
      if (!buffer) throw new Error("Thất bại hệ thống phân phối ô nhớ AudioBuffer phần cứng.");
      const calculateVibranceFactor = (vibrance, fadeLength, pitchFactor, spectralProfile) => {
        const fadeDurationFactor = fadeLength < 1000 ? 0.75 : fadeLength < 5000 ? 0.9 : 1.05;
        let factor = Math.min(Math.max(vibrance, 0), 0.8) * fadeDurationFactor * (1 - pitchFactor * 0.18) * entropyFactor;
        if (spectralProfile.air > 0.8) factor *= 0.8;
        if (spectralProfile.transientEnergy > 0.8) {
          factor *= this?.profile === 'rockMetal' ? 1.2 : this?.profile === 'bright' ? 1.15 : 1.1;
        }
        if (spectralProfile.spectralEntropy > 0.8) factor *= 0.85;
        if (this?.profile === 'rockMetal') factor *= 1.2;
        if (this?.profile === 'vocal' || this?.profile === 'karaokeDynamic') factor *= 1.15;
        if (this?.profile === 'bright' || this?.profile === 'smartStudio') factor *= 1.1;
        return factor;
      };
      // TÍCH HỢP ĐA TUYẾN ĐỒ THỊ TOÁN HỌC THỰC SỰ THEO ĐÚNG CURVETYPE ĐƯỢC CHỈ ĐỊNH KHÓA
      const getFadeFunction = () => {
        const adjustedSmoothness = Math.min(Math.max(smoothness * (sampleRate / 48000), 0.4), 1.6);
        const pitchFactor = Math.abs(pitchShift);
        const vibranceFactor = calculateVibranceFactor(vibrance, fadeLength, pitchFactor, validatedSpectralProfile);
        const warmth = (isVocal || validatedSpectralProfile.vocalPresence > 0.8) ? vocalWarmth * (this?.profile === 'vocal' ? 1.1 : 1.0) : 1.0;
        if (curveType === 'cosine') {
          return (t) => {
            const cosPart = 0.5 * (1 - Math.cos(Math.PI * t));
            return Math.min(1, cosPart * (1 + vibranceFactor * 0.25 * warmth));
          };
        } else if (curveType === 'exponential') {
          return (t) => {
            const expPart = (Math.exp(3 * t) - 1) / (Math.exp(3) - 1);
            return Math.min(1, expPart * (1 + vibranceFactor * 0.22 * warmth));
          };
        } else {
          const bezierP1 = 0.07 * adjustedSmoothness * (1 + pitchFactor * 0.03);
          const bezierP2 = 0.8 * adjustedSmoothness * (1 - pitchFactor * 0.03);
          const bezierCosineBlend = Math.max(0.4 - pitchFactor * 0.07 - validatedSpectralProfile.spectralComplexity * 0.07, 0.25);
          return (t) => {
            const t2 = t * t,
              t3 = t2 * t;
            const mt = 1 - t,
              mt2 = mt * mt;
            const bezier = 3 * bezierP1 * t * mt2 + 3 * bezierP2 * t2 * mt + t3;
            const cosPart = 0.5 * (1 - Math.cos(Math.PI * t));
            return Math.min(1, (bezier * bezierCosineBlend + cosPart * (1 - bezierCosineBlend)) * (1 + vibranceFactor * 0.25 * warmth));
          };
        }
      };
      const fadeFunction = getFadeFunction();
      for (let ch = 0; ch < channels; ch++) {
        const channelData = buffer.getChannelData(ch);
        const fadeIndex1 = fadeLength;
        const fadeIndex2 = activeLength - fadeLength;
        for (let i = 0; i < totalLength; i++) {
          if (i < fadeIndex1) {
            channelData[i] = fadeFunction(i / fadeLength);
          } else if (i >= fadeIndex2 && i < activeLength) {
            channelData[i] = fadeFunction(1 - (i - fadeIndex2) / fadeLength);
          } else if (i < activeLength) {
            channelData[i] = 1;
          } else {
            channelData[i] = 0;
          }
        }
        const boundarySmoothing = Math.min(fadeLength / 4, 48);
        for (let i = 0; i < boundarySmoothing; i++) {
          const t = 0.5 * (1 - Math.cos(Math.PI * i / boundarySmoothing));
          if (fadeIndex1 - i - 1 >= 0) {
            channelData[fadeIndex1 - i - 1] = channelData[fadeIndex1 - i - 1] * (1 - t) + t;
          }
          if (fadeIndex2 + i < activeLength) {
            channelData[fadeIndex2 + i] = channelData[fadeIndex2 + i] * (1 - t) + channelData[fadeIndex2 + i - 1] * t;
          }
        }
        if (minFadeLength === 1024) {
          if (fadeIndex1 > 0) channelData[0] *= 0.4 * (1 - Math.cos(Math.PI * 0.4));
          if (fadeIndex2 < activeLength) channelData[activeLength - 1] *= 0.4 * (1 - Math.cos(Math.PI * 0.4));
        }
      }
      if (avgCpuLoad > 0.75 && this?.outputGain?.gain) {
        const targetGain = qualityMode === 'high' ? 0.6 : 0.5;
        const adjustedGain = (validatedSpectralProfile.bass > 0.8 || validatedSpectralProfile.air > 0.8) ? targetGain * 0.85 : targetGain;
        this.outputGain.gain.linearRampToValueAtTime(adjustedGain, context.currentTime + (this.rampTime || 0.065));
      }
      if (memoryManager && typeof memoryManager.set === 'function') {
        const spectralKey = `${validatedSpectralProfile.spectralComplexity}_${validatedSpectralProfile.vocalPresence}_${validatedSpectralProfile.spectralEntropy}`;
        const key = `fade_${activeTime.toFixed(3)}_${fadeTime.toFixed(3)}_bezier_${pitchShift}_${isVocal}_${qualityMode}_${channels}_${spectralKey}`;
        if (!(buffer instanceof AudioBuffer) || buffer.length < activeLength) {
          throw new Error('Độ dài ô đệm mẫu hình học không đạt chuẩn cấu trúc dải hạt');
        }
        memoryManager.set(key, buffer, 'high', {
          metadata: {
            timestamp: Date.now(),
            expiry: Date.now() + 5500
          }
        });
        const maxCache = isLowPowerDevice ? 300 : (memoryManager.getDynamicMaxSize?.() || 500);
        memoryManager.pruneCache(maxCache);
      }
      return buffer;
    } catch (error) {
      if (typeof handleError === 'function') {
        handleError('Lỗi trong chu kỳ toán học sinh mẫu đồ thị hạt', error, {
          activeTime,
          fadeTime,
          options,
          sampleRate
        }, 'high', {
          memoryManager
        });
      }
      try {
        const fallbackBuffer = context.createBuffer(channels, 1024, sampleRate);
        for (let ch = 0; ch < channels; ch++) {
          fallbackBuffer.getChannelData(ch).fill(0);
        }
        return fallbackBuffer;
      } catch (fallbackError) {
        return null;
      }
    }
  }
  // ===================================================================================================
  // === SYSTEM COMPONENT 4: BỘ ĐIỀU PHỐI ĐỌC TRÍCH ĐỆM DỊCH TẦN THỜI GIAN THỰC (getShiftBuffers) ===
  // ===================================================================================================
  function getShiftBuffers(context, activeTime, fadeTime, options = {}, memoryManager) {
    if (!(context instanceof(window.AudioContext || window.webkitAudioContext))) {
      if (typeof handleError === 'function') {
        handleError('Hệ thống phần cứng AudioContext không phản hồi dải dịch tone', new Error('Invalid context link'), {}, 'high', {
          memoryManager
        });
      }
      return null;
    }
    const fastFinite = (val, def) => (typeof val === 'number' && Number.isFinite(val)) ? val : def;
    activeTime = (typeof ensureFinite === 'function') ? ensureFinite(activeTime, 0.2) : fastFinite(activeTime, 0.2);
    fadeTime = (typeof ensureFinite === 'function') ? ensureFinite(fadeTime, 0.1) : fastFinite(fadeTime, 0.1);
    if (!memoryManager || typeof memoryManager.get !== 'function' || typeof memoryManager.set !== 'function') {
      if (typeof handleError === 'function') {
        handleError('Trục liên kết dữ liệu tĩnh memoryManager bị hở mạch', new Error('Missing allocation map methods'), {}, 'high', {
          memoryManager
        });
      }
      return null;
    }
    const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
    const {
      pitchShift = 0,
        isVocal = false,
        qualityMode = 'high',
        channels = 1,
        spectralProfile = {}
    } = options;
    const validatedPitchShift = (typeof ensureFinite === 'function') ? ensureFinite(pitchShift, 0) : fastFinite(pitchShift, 0);
    const spectralDefaults = {
      spectralComplexity: 0.5,
      vocalPresence: 0.5,
      transientEnergy: 0.5,
      bass: 0.5,
      midHigh: 0.5,
      air: 0.5,
      spectralEntropy: 0.5
    };
    const validatedSpectralProfile = Object.keys(spectralDefaults).reduce((acc, key) => {
      const val = spectralProfile?.[key];
      acc[key] = Number.isFinite(val) ? Math.max(0, Math.min(1, val)) : spectralDefaults[key];
      return acc;
    }, {
      ...spectralDefaults
    });
    try {
      const entropyFactor = Math.min(1.0, 0.94 + (1 - validatedSpectralProfile.spectralEntropy) * 0.06);
      const spectralSubtractionFactor = validatedSpectralProfile.air > 0.8 || validatedSpectralProfile.bass > 0.8 ? 0.85 : 0.9;
      const cpuLoad = (typeof this?.getCPULoad === 'function') ? this.getCPULoad() : 0.5;
      const loadHistory = memoryManager?.get('cpuLoadHistory') || [];
      const avgCpuLoad = loadHistory.length > 0 ? loadHistory.reduce((sum, val) => sum + val, 0) / loadHistory.length : cpuLoad;
      const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
      const detectInstrument = (sp) => {
        if (sp.transientEnergy > 0.85 && sp.bass > 0.8) return 'drum';
        if (sp.midHigh > 0.8 && sp.transientEnergy > 0.7) return 'guitar';
        if (sp.midHigh > 0.75 && sp.spectralComplexity > 0.7) return 'piano';
        return 'vocal';
      };
      const instrumentType = detectInstrument(validatedSpectralProfile);
      const deepLearningBufferFactor = (
        (instrumentType === 'drum' ? 1.25 : instrumentType === 'guitar' ? 1.2 : instrumentType === 'piano' ? 1.15 : validatedSpectralProfile.vocalPresence > 0.85 ? 1.2 : 1.0) * (validatedSpectralProfile.transientEnergy > 0.85 ? 1.25 : 1.0) * (Math.abs(validatedPitchShift) > 1.0 ? 1.3 : 1.0) * ((this?.profile === 'vocal' || this?.profile === 'karaokeDynamic') ? 1.2 : 1.0) * ((this?.profile === 'rockMetal' || validatedSpectralProfile.bass > 0.85) ? 1.15 : 1.0));
      const adjustedActiveTime = activeTime * deepLearningBufferFactor;
      const adjustedFadeTime = fadeTime * deepLearningBufferFactor;
      const spectralKey = `${validatedSpectralProfile.spectralComplexity}_${validatedSpectralProfile.vocalPresence}_${validatedSpectralProfile.spectralEntropy}_${instrumentType}`;
      const baseKey = `shift_${adjustedActiveTime.toFixed(3)}_${adjustedFadeTime.toFixed(3)}_${validatedPitchShift}_${isVocal}_${qualityMode}_${channels}_${spectralKey}`;
      const keyDown = `${baseKey}_down`;
      const keyUp = `${baseKey}_up`;
      let shiftDownBuffer = memoryManager.get(keyDown)?.buffer || memoryManager.get(keyDown);
      let shiftUpBuffer = memoryManager.get(keyUp)?.buffer || memoryManager.get(keyUp);
      const expiryTime = 60000;
      const validateBuffer = (buffer, key) => {
        if (!(buffer instanceof AudioBuffer)) return null;
        if (buffer.length < Math.round(adjustedActiveTime * context.sampleRate)) return null;
        const cachedItem = memoryManager.get(key);
        const timestamp = cachedItem?.metadata?.timestamp || cachedItem?.timestamp || 0;
        if (Date.now() - timestamp > expiryTime) return null;
        if (validatedSpectralProfile.spectralEntropy > 0.85 && entropyFactor < 0.96) return null;
        if (validatedSpectralProfile.air > 0.85 && spectralSubtractionFactor < 0.9) return null;
        return buffer;
      };
      shiftDownBuffer = validateBuffer(shiftDownBuffer, keyDown);
      shiftUpBuffer = validateBuffer(shiftUpBuffer, keyUp);
      if (!shiftDownBuffer || !shiftUpBuffer) {
        const bufferOptions = {
          ...options,
          smoothness: (this?.profile === 'vocal' || this?.profile === 'karaokeDynamic') ? 1.1 : (this?.profile === 'rockMetal' || instrumentType === 'drum') ? 0.9 : (this?.profile === 'bright' || instrumentType === 'guitar') ? 1.0 : (instrumentType === 'piano') ? 1.05 : 1.0,
          vibrance: (this?.profile === 'rockMetal' || instrumentType === 'drum') ? 0.95 : (this?.profile === 'bright' || instrumentType === 'guitar') ? 0.9 : (this?.profile === 'vocal' || this?.profile === 'karaokeDynamic') ? 0.85 : (instrumentType === 'piano') ? 0.9 : 0.9,
          transientBoost: (this?.profile === 'rockMetal' || instrumentType === 'drum') ? 1.2 : (this?.profile === 'bright' || instrumentType === 'guitar') ? 1.15 : (this?.profile === 'vocal' || instrumentType === 'piano') ? 1.1 : 1.15,
          vocalWarmth: (this?.profile === 'vocal' || this?.profile === 'karaokeDynamic') ? 1.3 : 1.25
        };
        if (!shiftDownBuffer) {
          shiftDownBuffer = createDelayTimeBuffer.call(this, context, adjustedActiveTime, adjustedFadeTime, false, bufferOptions, memoryManager);
          if (shiftDownBuffer instanceof AudioBuffer) {
            memoryManager.set(keyDown, shiftDownBuffer, 'high', {
              metadata: {
                timestamp: Date.now(),
                profile: this?.profile || 'proNatural',
                instrumentType
              }
            });
          }
        }
        if (!shiftUpBuffer) {
          shiftUpBuffer = createDelayTimeBuffer.call(this, context, adjustedActiveTime, adjustedFadeTime, true, bufferOptions, memoryManager);
          if (shiftUpBuffer instanceof AudioBuffer) {
            memoryManager.set(keyUp, shiftUpBuffer, 'high', {
              metadata: {
                timestamp: Date.now(),
                profile: this?.profile || 'proNatural',
                instrumentType
              }
            });
          }
        }
        if (!shiftDownBuffer || !shiftUpBuffer) throw new Error('Mạch xả dữ liệu dải đệm dịch cao độ bị ngắt đoạn lỗi vật lý');
      }
      const maxCacheSize = isLowPowerDevice ? 300 : (memoryManager.getDynamicMaxSize?.() || 500);
      if (typeof memoryManager.pruneCache === 'function') {
        memoryManager.pruneCache(maxCacheSize);
      }
      return {
        shiftDownBuffer,
        shiftUpBuffer
      };
    } catch (error) {
      if (typeof handleError === 'function') {
        handleError('Mạch đồng bộ dải dịch âm tần xảy ra sự cố dung lượng hình học', error, {
          activeTime,
          fadeTime,
          profile: this?.profile,
          instrumentType
        }, 'high', {
          memoryManager
        });
      }
      return null;
    }
  }
  // ===================================================================================================
  // === SYSTEM COMPONENT 5: SIÊU THUẬT TOÁN BẢO TỒN CẤU TRÚC VÒM HỌNG BIOLOGICAL FORMANT MATRIX (V8.5) ===
  // ===================================================================================================
  function preserveFormant(pitchMult, baseFreq, vocalPresence, spectralProfile = {}, glider = null) {
    const absMult = Math.abs(pitchMult);
    const spectralDefaults = {
      spectralComplexity: 0.5,
      transientEnergy: 0.5,
      bass: 0.5,
      midHigh: 0.5,
      air: 0.5
    };
    const validatedSpectralProfile = {
      spectralComplexity: Number.isFinite(spectralProfile?.spectralComplexity) ? Math.max(0, Math.min(1, spectralProfile.spectralComplexity)) : spectralDefaults.spectralComplexity,
      transientEnergy: Number.isFinite(spectralProfile?.transientEnergy) ? Math.max(0, Math.min(1, spectralProfile.transientEnergy)) : spectralDefaults.transientEnergy,
      bass: Number.isFinite(spectralProfile?.bass) ? Math.max(0, Math.min(1, spectralProfile.bass)) : spectralDefaults.bass,
      midHigh: Number.isFinite(spectralProfile?.midHigh) ? Math.max(0, Math.min(1, spectralProfile.midHigh)) : spectralDefaults.midHigh,
      air: Number.isFinite(spectralProfile?.air) ? Math.max(0, Math.min(1, spectralProfile.air)) : spectralDefaults.air
    };
    const cpuLoad = this?.getCPULoad ? this.getCPULoad() : 0.5;
    const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
    const cpuLoadAdjust = cpuLoad > 0.8 || isLowPowerDevice ? 0.75 : 1.0;
    const entropyFactor = Math.min(1.0, 0.9 + (1 - validatedSpectralProfile.spectralComplexity) * 0.1);
    const noiseSuppressionFactor = Math.min(1.0, 0.9 + (1 - validatedSpectralProfile.spectralComplexity) * 0.1);
    const activeGlider = glider || this?.lastGlider || {
      formantVariability: 1.0,
      grainJitter: 0.04,
      spectroAdapt: 1.0,
      vocalWarmthOptimizer: 1.0,
      bassResonanceControl: 1.0,
      dynamicFormantBlend: 1.0,
      quantumPhaseEntanglement: 1.0,
      harmonicSuperposition: 1.0,
      aiChromaEnhancer: 1.0,
      transientSculptor: 1.0,
      multiBandWeights: {
        low: 1.0,
        mid: 1.0,
        high: 1.0
      }
    };
    const formantVariability = activeGlider.formantVariability || 1.0;
    const grainJitterFactor = 1.0 + (activeGlider.grainJitter || 0.04) * 0.8;
    const spectroAdapt = activeGlider.spectroAdapt || 1.0;
    const complexityAdjust = validatedSpectralProfile.spectralComplexity > 0.7 ? 0.65 : 0.85;
    let shiftFactor = (pitchMult < 0 ? 1 + absMult * 0.18 : 1 + absMult * 0.28) * complexityAdjust * cpuLoadAdjust * noiseSuppressionFactor;
    shiftFactor *= (1 + formantVariability * (absMult / 12) * 0.6 * spectroAdapt);
    shiftFactor *= activeGlider.dynamicFormantBlend * activeGlider.quantumPhaseEntanglement;
    const isFemaleVocal = baseFreq > 400;
    const isMaleVocal = baseFreq < 240;
    const pitchBoost = absMult > 0.8 ? 1 + (absMult - 0.8) * 0.55 : absMult > 0.4 ? 1 + (absMult - 0.4) * 0.35 : 1.0;
    let vocalFactor = Math.min(vocalPresence > 0.7 ? (isFemaleVocal ? 1.45 * pitchBoost : isMaleVocal ? 1.4 * pitchBoost : 1.35 * pitchBoost) : (validatedSpectralProfile.midHigh > 0.7 ? 1.25 : 1.0), 1.55);
    vocalFactor *= grainJitterFactor;
    vocalFactor *= activeGlider.vocalWarmthOptimizer * activeGlider.harmonicSuperposition;
    let freqAdjust = Math.min(
      (isFemaleVocal && pitchMult < 0) ? 1.08 * pitchBoost : (pitchMult < 0 ? 1.03 * pitchBoost : (pitchMult > 0 && absMult > 0.8 ? 0.78 : 0.83)), 1.18);
    freqAdjust *= (1 - formantVariability * (pitchMult > 0 ? 0.7 : 0.3) * (absMult / 12));
    const bassAdjust = validatedSpectralProfile.bass > 0.7 ? (pitchMult < -0.8 ? 1.18 : 1.25) * activeGlider.multiBandWeights.low : 1.0;
    let freq = baseFreq / shiftFactor * vocalFactor * freqAdjust * bassAdjust;
    const minFreq = 85;
    const maxFreq = 4600;
    freq = Math.max(minFreq, Math.min(maxFreq, freq));
    freq *= spectroAdapt;
    if (baseFreq < 220 && pitchMult < -12) {
      freq *= 0.96;
      vocalFactor *= 1.18 * activeGlider.bassResonanceControl;
    }
    const activeProfile = this?.profile || 'proNatural';
    const transientBoost = validatedSpectralProfile.transientEnergy > 0.7 ? (activeProfile === 'rockMetal' ? 1.3 : activeProfile === 'vocal' ? 1.25 : activeProfile === 'karaokeDynamic' ? 1.35 : 1.2) : 1.0;
    const midHighBoost = validatedSpectralProfile.midHigh > 0.7 ? (activeProfile === 'bright' || activeProfile === 'smartStudio' ? 1.3 : 1.25) : 1.0;
    const airReduction = validatedSpectralProfile.air > 0.7 ? 0.7 : 0.85;
    let gain = Math.min(
      (3.8 - absMult * 0.85) * transientBoost * midHighBoost * airReduction * cpuLoadAdjust * noiseSuppressionFactor * entropyFactor, 3.8);
    gain *= (1 + formantVariability * 0.4);
    gain *= activeGlider.aiChromaEnhancer * activeGlider.bassResonanceControl;
    const qFactor = vocalPresence > 0.7 ? (absMult > 0.8 ? 0.08 : 0.12) : (absMult > 0.8 ? 0.1 : 0.18);
    const airQReduction = validatedSpectralProfile.air > 0.7 ? 0.7 : 0.85;
    let q = Math.max(1.0, (1.6 + absMult * qFactor) * airQReduction * cpuLoadAdjust * entropyFactor);
    q /= grainJitterFactor;
    return {
      freq,
      gain,
      q
    };
  }
  // ===================================================================================================
  // === SYSTEM COMPONENT 6: SIÊU HÀM TẠO SÓNG ĐIỀU KHIỂN DẢI TRỄ (VÁ TRIỆT ĐỂ CLIFF-DROP MICRO-CLICKS) ===
  // ===================================================================================================
  function createDelayTimeBuffer(context, activeTime, fadeTime, shiftUp, options = {}, memoryManager) {
    if (!(context instanceof(window.AudioContext || window.webkitAudioContext))) {
      if (typeof handleError === 'function') {
        handleError('Hệ thống phần cứng AudioContext không phản hồi dải sinh sóng trễ', new Error('Hardware IO failure'), {}, 'high', {
          memoryManager
        });
      }
      throw new Error("AudioContext không hợp lệ.");
    }
    const DEFAULT_BUFFER_TIME = 0.4;
    const DEFAULT_FADE_TIME = 0.06;
    activeTime = (typeof ensureFinite === 'function') ? ensureFinite(activeTime, DEFAULT_BUFFER_TIME) : (Number.isFinite(activeTime) ? activeTime : DEFAULT_BUFFER_TIME);
    fadeTime = (typeof ensureFinite === 'function') ? ensureFinite(fadeTime, DEFAULT_FADE_TIME) : (Number.isFinite(fadeTime) ? fadeTime : DEFAULT_FADE_TIME);
    if (activeTime <= 0 || fadeTime <= 0) {
      throw new Error("Tham số thời gian hình học cửa sổ gối hạt bắt buộc phải là số thực dương.");
    }
    if (!memoryManager || typeof memoryManager.set !== 'function') {
      throw new Error("Thiếu ma trận liên kết sơ đồ ô nhớ memoryManager tĩnh.");
    }
    const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
    const {
      pitchShift = 0, isVocal = false, spectralProfile = {}, qualityMode = 'high',
        channels = 1, smoothness = 0.95, vibrance = 0.9, transientBoost = 1.15, vocalWarmth = 1.25
    } = options;
    const validatedPitchShift = (typeof ensureFinite === 'function') ? ensureFinite(pitchShift, 0) : (Number.isFinite(pitchShift) ? pitchShift : 0);
    const validatedChannels = Math.max(1, Math.min(Math.round(Number.isFinite(channels) ? channels : 1), 8));
    const spectralDefaults = {
      spectralComplexity: 0.5,
      vocalPresence: 0.5,
      transientEnergy: 0.5,
      bass: 0.5,
      midHigh: 0.5,
      air: 0.5,
      spectralEntropy: 0.5
    };
    const validatedSpectralProfile = Object.keys(spectralDefaults).reduce((acc, key) => {
      const val = spectralProfile?.[key];
      acc[key] = Number.isFinite(val) ? Math.max(0, Math.min(1, val)) : spectralDefaults[key];
      return acc;
    }, {
      ...spectralDefaults
    });
    try {
      const sampleRate = context.sampleRate || 48000;
      const cpuLoad = (typeof this?.getCPULoad === 'function') ? this.getCPULoad() : 0.5;
      const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
      const entropyFactor = Math.min(1.0, 0.96 + (1 - validatedSpectralProfile.spectralEntropy) * 0.04);
      const spectralSubtractionFactor = validatedSpectralProfile.air > 0.8 || validatedSpectralProfile.bass > 0.8 ? 0.8 : 0.85;
      const detectInstrument = (sp) => {
        if (sp.transientEnergy > 0.9 && sp.bass > 0.85) return 'drum';
        if (sp.midHigh > 0.85 && sp.transientEnergy > 0.75) return 'guitar';
        if (sp.midHigh > 0.8 && sp.spectralComplexity > 0.75) return 'piano';
        return 'vocal';
      };
      const instrumentType = detectInstrument(validatedSpectralProfile);
      const activeProfile = this?.profile || options.profile || 'proNatural';
      const deepLearningBufferFactor = (
        (instrumentType === 'drum' ? 1.3 : instrumentType === 'guitar' ? 1.25 : instrumentType === 'piano' ? 1.2 : validatedSpectralProfile.vocalPresence > 0.9 ? 1.25 : 1.0) * (validatedSpectralProfile.transientEnergy > 0.9 ? 1.3 : 1.0) * (Math.abs(validatedPitchShift) > 1.2 ? 1.35 : 1.0) * ((activeProfile === 'vocal' || activeProfile === 'karaokeDynamic') ? 1.25 : 1.0) * ((activeProfile === 'rockMetal' || validatedSpectralProfile.bass > 0.9) ? 1.2 : 1.0));
      const adjustedActiveTime = activeTime * deepLearningBufferFactor;
      const adjustedFadeTime = fadeTime * deepLearningBufferFactor;
      const minFadeLength = (isVocal || instrumentType === 'vocal') ? 1024 : (instrumentType === 'drum' || Math.abs(validatedPitchShift) > 0.5 ? 896 : 768);
      let fadeLength = Math.max(Math.round(adjustedFadeTime * sampleRate), minFadeLength);
      // === FIX ĐƯỜNG TRUYỀN CONTEXT TRÁNH CRASH RUNTIME ===
      if (typeof adjustFadeLength === 'function') {
        fadeLength = adjustFadeLength.call(this, fadeLength, sampleRate, validatedSpectralProfile, validatedPitchShift, isVocal, cpuLoad, isLowPowerDevice, options);
      }
      const activeLength = Math.round(adjustedActiveTime * sampleRate);
      const maxTotalLength = sampleRate * 5;
      const totalLength = Math.min(activeLength + Math.max(0, Math.round((adjustedActiveTime - 2 * adjustedFadeTime) * sampleRate)), maxTotalLength);
      const buffer = context.createBuffer(validatedChannels, totalLength, sampleRate);
      if (!buffer) throw new Error("Hệ thống khởi tạo ô đệm AudioBuffer phần cứng thất bại.");
      const smoothing = Math.min(fadeLength / 5, 30) * (instrumentType === 'drum' ? 1.15 : instrumentType === 'guitar' ? 1.1 : instrumentType === 'piano' ? 1.05 : (activeProfile === 'vocal' || activeProfile === 'karaokeDynamic') ? 1.2 : 1.0);
      const finalGain = (instrumentType === 'vocal' ? vocalWarmth * ((activeProfile === 'vocal') ? 1.05 : 1.0) : instrumentType === 'drum' ? transientBoost : instrumentType === 'guitar' ? transientBoost * 0.9 : 1.0);
      for (let ch = 0; ch < validatedChannels; ch++) {
        const channelData = buffer.getChannelData(ch);
        for (let i = 0; i < activeLength; i++) {
          let delayValue = shiftUp ? (activeLength - i) / activeLength : i / activeLength;
          delayValue *= entropyFactor;
          if (i < smoothing) {
            const t = 0.5 * (1 - Math.cos(Math.PI * i / smoothing));
            delayValue = delayValue * t + (shiftUp ? 1 : 0) * (1 - t);
          } else if (i >= activeLength - smoothing) {
            const t = 0.5 * (1 - Math.cos(Math.PI * (activeLength - i) / smoothing));
            delayValue = delayValue * t + (shiftUp ? 0 : 1) * (1 - t);
          }
          channelData[i] = delayValue * finalGain;
        }
        // VÁ LỖI TÍCH TÁCH CLIFF-DROP MICRO-CLICKS TẦN SỐ CAO:
        const tailSmoothingSamples = 48;
        const tailStartIndex = activeLength - tailSmoothingSamples;
        if (tailStartIndex > 0) {
          for (let i = 0; i < tailSmoothingSamples; i++) {
            const targetIndex = tailStartIndex + i;
            if (targetIndex < activeLength) {
              const t = 0.5 * (1 + Math.cos(Math.PI * i / tailSmoothingSamples));
              channelData[targetIndex] *= t;
            }
          }
        }
        if (totalLength > activeLength) {
          channelData.fill(0, activeLength, totalLength);
        }
      }
      if (!(buffer instanceof AudioBuffer) || buffer.length < activeLength || buffer.numberOfChannels !== validatedChannels) {
        throw new Error('Dữ liệu ô sóng đệm trễ sinh ra sai cấu trúc ma trận âm học');
      }
      const spectralKey = `${validatedSpectralProfile.spectralComplexity}_${validatedSpectralProfile.vocalPresence}_${validatedSpectralProfile.spectralEntropy}_${instrumentType}`;
      const key = `delay_${adjustedActiveTime.toFixed(3)}_${adjustedFadeTime.toFixed(3)}_${validatedPitchShift}_${shiftUp}_${qualityMode}_${validatedChannels}_${spectralKey}`;
      memoryManager.set(key, buffer, 'high', {
        metadata: {
          timestamp: Date.now(),
          profile: activeProfile,
          instrumentType
        }
      });
      const maxCacheSize = isLowPowerDevice ? 300 : (memoryManager.getDynamicMaxSize?.() || 700);
      if (typeof memoryManager.pruneCache === 'function') {
        memoryManager.pruneCache(maxCacheSize);
      }
      return buffer;
    } catch (error) {
      if (typeof handleError === 'function') {
        handleError('Gặp sự cố lỗi khi tính toán mạch sinh sóng trễ hạt', error, {
          activeTime,
          fadeTime,
          shiftUp,
          options,
          sampleRate: context?.sampleRate
        }, 'high', {
          memoryManager
        });
      }
      return null;
    }
  }
  // ==========================================
  // HỆ THỐNG HẰNG SỐ TOÀN CỤC ĐỒNG BỘ CHUNG (ĐÃ TỐI ƯU STUDIO)
  // ==========================================
  const DEFAULT_DELAY_TIME = 0.080;
  const DEFAULT_FADE_TIME = 0.100;
  const DEFAULT_BUFFER_TIME = 0.200;
  const DEFAULT_RAMP_TIME = 0.075;
  const MAX_DELAY_TIME = 5;
  // --- Cắt tầng & Bộ lọc làm sạch ---
  const DEFAULT_LOW_PASS_FREQ = 18000; // Giữ lại dải siêu cao thoáng đãng (Air)
  const DEFAULT_HIGH_PASS_FREQ = 30; // Cắt sạch rác âm thanh dưới 30Hz
  const DEFAULT_NOTCH_FREQ = 1000; // Tần số mặc định an toàn cho Notch (Bypass khi nghe nhạc)
  const DEFAULT_FILTER_Q = 0.707; // Hoàn hảo! Đường cong phẳng tự nhiên nhất
  const DEFAULT_NOTCH_Q = 10.0; // Siết chặt dải cắt khi cần xử lý hú chói
  // --- Định hình Formant Giọng hát (Không đổi) ---
  const DEFAULT_FORMANT_F1_FREQ = 550;
  const DEFAULT_FORMANT_F2_FREQ = 2000;
  const DEFAULT_FORMANT_F3_FREQ = 3200;
  const DEFAULT_FORMANT_Q = 1.8;
  const DEFAULT_FORMANT_Q_MIN = 0.8;
  const DEFAULT_FORMANT_Q_MAX = 3.0;
  const DEFAULT_FORMANT_GAIN = 4.5;
  // --- Phân rã dải tần EQ (Sửa High-Mid để tránh trùng lặp) ---
  const DEFAULT_SUBMID_FREQ = 500; // Dải quyết định độ ấm/đục của loa trung
  const DEFAULT_SUBTREBLE_FREQ = 11000; // Độ sắc nét của nhạc cụ dải cao
  const DEFAULT_MIDBASS_FREQ = 200; // Độ dày, đầy đặn của giọng nam và nhạc cụ bass
  const DEFAULT_HIGHMID_FREQ = 2800; // CHỈNH SỬA: Tách khỏi 2kHz để âm thanh TRONG TRẺO, không chói
  const DEFAULT_AIR_FREQ = 13000; // Dải sáng, bay bổng, tạo "màu sắc tươi"
  // --- Dynamics Compressor (Gói gọn, làm chắc tiếng) ---
  const DEFAULT_COMPRESSOR_THRESHOLD = -18;
  const DEFAULT_COMPRESSOR_RATIO = 2.0; // Tuyệt vời! Giữ dynamic mượt mà cho nhạc
  const DEFAULT_COMPRESSOR_ATTACK = 0.015; // Rất tốt! Giữ lực trống (Transient) nảy và chắc
  const DEFAULT_COMPRESSOR_RELEASE = 0.250; // CHỈNH SỬA: Lên 250ms để âm thanh quyện, không bị giật cục
  // --- Các hiệu ứng không gian & Hài âm ---
  const DEFAULT_HARMONIC_EXCITER_GAIN = 0.4;
  const DEFAULT_TRANSIENT_BOOST = 0.5;
  const DEFAULT_STEREO_WIDTH = 0.07;
  const DEFAULT_REVERB_WET_GAIN = 0.35;
  const DEFAULT_REVERB_DECAY = 1.5;
  const DEFAULT_FFT_SIZE = 4096;
  const DEFAULT_MIN_FADE_LENGTH = 768;
  class MemoryManager {
    constructor() {
      this.buffers = new Map();
      this.priorities = new Map();
      this.accessTimestamps = new Map();
      this.expiryTime = {
        high: 180000,
        normal: 90000,
        low: 20000
      };
      this.maxTotalSize = 200 * 1024 * 1024;
      this._priorityWeight = {
        high: 3.5,
        normal: 1.8,
        low: 1.0
      };
      // FIX: Dùng chung một context để tránh rò rỉ tài nguyên hệ thống
      this._sharedCtx = null;
    }
    compressBuffer(buffer) {
      if (!(buffer instanceof AudioBuffer)) return null;
      const data = new Float32Array(buffer.length * buffer.numberOfChannels);
      for (let ch = 0; ch < buffer.numberOfChannels; ch++) {
        data.set(buffer.getChannelData(ch), ch * buffer.length);
      }
      return new Uint8Array(data.buffer);
    }
    decompressBuffer(compressed, length, channels, sampleRate) {
      if (!(compressed instanceof Uint8Array)) return null;
      // FIX: Khởi tạo lười (lazy-init) AudioContext dùng chung
      if (!this._sharedCtx) {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        this._sharedCtx = new AudioCtx();
      }
      const float32 = new Float32Array(compressed.buffer, compressed.byteOffset, length * channels);
      const buffer = this._sharedCtx.createBuffer(channels, length, sampleRate);
      for (let ch = 0; ch < channels; ch++) {
        buffer.getChannelData(ch).set(float32.subarray(ch * length, (ch + 1) * length));
      }
      return buffer;
    }
    getBufferSize(buffer) {
      if (buffer instanceof AudioBuffer) {
        return buffer.length * buffer.numberOfChannels * 4;
      } else if (buffer instanceof Uint8Array) {
        return buffer.byteLength;
      }
      return 0;
    }
    get(key) {
      if (!this.buffers.has(key)) return undefined;
      const item = this.buffers.get(key);
      const priority = this.priorities.get(key) || 'normal';
      const timestamp = item.metadata?.timestamp || this.accessTimestamps.get(key) || 0;
      // FIX: Kiểm tra hết hạn chính xác
      if (timestamp && (Date.now() - timestamp > this.expiryTime[priority])) {
        this._remove(key);
        return undefined;
      }
      this.accessTimestamps.set(key, Date.now());
      if (item.buffer instanceof Uint8Array && item.metadata?.originalLength) {
        return this.decompressBuffer(item.buffer, item.metadata.originalLength, item.metadata.channels, item.metadata.sampleRate);
      }
      return item.buffer;
    }
    getBuffer(key) {
      return this.get(key);
    }
    set(key, buffer, priority = 'normal', metadata = {}) {
      if (!buffer) return;
      const validPriorities = ['low', 'normal', 'high'];
      const effectivePriority = validPriorities.includes(priority) ? priority : 'normal';
      let storedBuffer = buffer;
      let finalMetadata = {
        ...metadata,
        timestamp: Date.now()
      };
      if (buffer instanceof AudioBuffer) {
        storedBuffer = this.compressBuffer(buffer);
        if (!storedBuffer) return;
        finalMetadata = {
          ...finalMetadata,
          originalLength: buffer.length,
          channels: buffer.numberOfChannels,
          sampleRate: buffer.sampleRate
        };
      }
      this.buffers.set(key, {
        buffer: storedBuffer,
        metadata: finalMetadata
      });
      this.priorities.set(key, effectivePriority);
      this.accessTimestamps.set(key, Date.now());
      this.pruneCache(this.getDynamicMaxSize());
    }
    allocateBuffer(key, buffer, priority = 'normal', metadata = {}) {
      this.set(key, buffer, priority, metadata);
    }
    pruneCache(maxSize) {
      const now = Date.now();
      let totalSize = 0;
      // 1. Xóa hết hạn và tính tổng dung lượng trong 1 vòng lặp để tiết kiệm CPU
      for (const [key, item] of this.buffers.entries()) {
        const priority = this.priorities.get(key) || 'normal';
        const timestamp = item.metadata?.timestamp || this.accessTimestamps.get(key) || 0;
        // FIX: Sửa lỗi phép tính thời gian (- - thành -)
        if (timestamp && (now - timestamp > this.expiryTime[priority])) {
          this._remove(key);
        } else {
          totalSize += this.getBufferSize(item.buffer);
        }
      }
      // 2. Prune thông minh (Chỉ thực hiện khi thực sự vượt ngưỡng)
      if (this.buffers.size > maxSize || totalSize > this.maxTotalSize) {
        // FIX: Di chuyển việc tạo mảng ứng viên ra ngoài vòng while
        const candidates = Array.from(this.buffers.keys()).map(k => ({
          key: k,
          priority: this._priorityWeight[this.priorities.get(k) || 'normal'],
          time: this.accessTimestamps.get(k) || 0,
          size: this.getBufferSize(this.buffers.get(k).buffer)
        }));
        // Sắp xếp: Ưu tiên xóa Priority thấp nhất, sau đó đến cái cũ nhất (LRU)
        candidates.sort((a, b) => a.priority - b.priority || a.time - b.time);
        for (const cand of candidates) {
          if (this.buffers.size <= maxSize && totalSize <= this.maxTotalSize) break;
          this._remove(cand.key);
          totalSize -= cand.size;
        }
      }
    }
    _remove(key) {
      this.buffers.delete(key);
      this.priorities.delete(key);
      this.accessTimestamps.delete(key);
    }
    getCacheStats() {
      let totalSize = 0,
        high = 0,
        normal = 0,
        low = 0;
      for (const [key, item] of this.buffers.entries()) {
        totalSize += this.getBufferSize(item.buffer);
        const p = this.priorities.get(key) || 'normal';
        if (p === 'high') high++;
        else if (p === 'normal') normal++;
        else low++;
      }
      return {
        bufferCount: this.buffers.size,
        totalSizeBytes: totalSize,
        highPriorityCount: high,
        normalPriorityCount: normal,
        lowPriorityCount: low,
        maxTotalSize: this.maxTotalSize,
        maxBufferCount: this.getDynamicMaxSize()
      };
    }
    getDynamicMaxSize() {
      const memory = navigator.deviceMemory || 4; // Mặc định 4GB nếu không lấy được
      const cores = navigator.hardwareConcurrency || 4;
      const dynamicCount = 80 + memory * 15 + cores * 10;
      this.maxTotalSize = Math.max(200 * 1024 * 1024, memory * 60 * 1024 * 1024);
      return Math.floor(dynamicCount);
    }
    clear() {
      this.buffers.clear();
      this.priorities.clear();
      this.accessTimestamps.clear();
      // FIX: Không cần xóa _sharedCtx để có thể tái sử dụng
    }
  }
  /**
   * Jungle Constructor - Phiên bản Phục hồi 100% logic gốc
   * Đảm bảo tính toàn vẹn (Integrity) tuyệt đối, giữ nguyên mọi state và cache logic.
   */
  function Jungle(context, options = {}) {
    const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
    const fastFinite = (val, def) => (typeof val === 'number' && Number.isFinite(val)) ? val : def;
    try {
      // 1. Khởi tạo contextId
      this.contextId = options.contextId || Date.now().toString(36);
      // 2. Kiểm tra cache khởi tạo (ĐÃ KHÔI PHỤC)
      const cacheKey = this.generateCacheSignature?.(this.contextId, {
        spectralProfile: options.spectralProfile,
        currentGenre: options.currentGenre,
        qualityMode: options.qualityMode
      }) || this.contextId;
      if (this.memoryManager?.get(cacheKey)?.timestamp > Date.now() - 60000) {
        const cachedConfig = this.memoryManager.get(cacheKey);
        if (isDebug) console.debug('Reusing cached Jungle config', {
          cacheKey,
          cachedConfig
        });
        Object.assign(this, cachedConfig.instance);
        return;
      }
      // 3. Dọn Debounce
      this._pitchLogDebounce = null;
      // 4. Khởi tạo AudioContext (Logic gốc)
      if (!context || !(context instanceof AudioContext) || context.state === 'closed') {
        if (isDebug) console.warn('Invalid or closed AudioContext provided, creating new AudioContext');
        try {
          context = new AudioContext();
          this.ownsContext = true;
          if (isDebug) console.debug('Created new AudioContext', {
            contextId: this.contextId,
            sampleRate: context.sampleRate
          });
        } catch (error) {
          console.error('Không thể tạo AudioContext mới', error);
          throw new Error('Không thể khởi tạo AudioContext. Vui lòng kiểm tra trình duyệt hỗ trợ Web Audio API.');
        }
      } else {
        this.ownsContext = false;
      }
      this.context = context;
      // 5. Auto-resume
      if (this.context.state === 'suspended') {
        const resume = () => {
          this.context.resume();
          document.removeEventListener('click', resume);
          document.removeEventListener('touchstart', resume);
        };
        document.addEventListener('click', resume);
        document.addEventListener('touchstart', resume);
      }
      // 6. Cảnh báo sampleRate
      if (isDebug && this.context.sampleRate < 48000) {
        console.warn(`SampleRate thấp (${this.context.sampleRate}Hz) có thể gây ra lỗi.`);
      }
      this.isStarted = false;
      // 7. Dự đoán qualityMode
      const deviceMemory = navigator.deviceMemory || 4;
      const cpuLoad = this.getCPULoad ? fastFinite(this.getCPULoad(), 0.5) : 0.5;
      const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
      this.qualityMode = options.qualityMode || (deviceMemory < 4 || cpuLoad > 0.8 || isLowPowerDevice ? 'low' : 'high');
      // 8. Fix Lag Cache
      this.lastPhaseCacheUpdate = 0;
      this.lastRoomCacheUpdate = 0;
      // 9. Khởi tạo tham số (ĐẦY ĐỦ LOGIC GỐC)
      this.delayTime = fastFinite(options.delayTime, DEFAULT_DELAY_TIME);
      this.fadeTime = fastFinite(options.fadeTime, DEFAULT_FADE_TIME);
      this.bufferTime = fastFinite(options.bufferTime, DEFAULT_BUFFER_TIME);
      this.rampTime = fastFinite(options.rampTime, DEFAULT_RAMP_TIME);
      this.lowPassFreq = fastFinite(options.lowPassFreq, DEFAULT_LOW_PASS_FREQ);
      this.highPassFreq = fastFinite(options.highPassFreq, DEFAULT_HIGH_PASS_FREQ);
      this.notchFreq = fastFinite(options.notchFreq, DEFAULT_NOTCH_FREQ);
      this.filterQ = fastFinite(options.filterQ, DEFAULT_FILTER_Q);
      this.notchQ = fastFinite(options.notchQ, DEFAULT_NOTCH_Q);
      this.formantF1Freq = fastFinite(options.formantF1Freq, DEFAULT_FORMANT_F1_FREQ);
      this.formantF2Freq = fastFinite(options.formantF2Freq, DEFAULT_FORMANT_F2_FREQ);
      this.formantQ = fastFinite(options.formantQ, DEFAULT_FORMANT_Q);
      this.subMidFreq = fastFinite(options.subMidFreq, DEFAULT_SUBMID_FREQ);
      this.subTrebleFreq = fastFinite(options.subTrebleFreq, DEFAULT_SUBTREBLE_FREQ);
      this.midBassFreq = fastFinite(options.midBassFreq, 200);
      this.highMidFreq = fastFinite(options.highMidFreq, 2000);
      this.airFreq = fastFinite(options.airFreq, 10000);
      // 10. Metadata & State (KHÔI PHỤC ĐẦY ĐỦ)
      this.spectralProfile = options.spectralProfile || {
        subBass: 0.5,
        bass: 0.5,
        subMid: 0.5,
        midLow: 0.5,
        midHigh: 0.5,
        high: 0.5,
        subTreble: 0.5,
        air: 0.5,
        vocalPresence: 0.5,
        transientEnergy: 0.5,
        instruments: {},
        chroma: Array(12).fill(0.5)
      };
      this.tempoMemory = options.tempoMemory || {
        current: 120,
        previous: 120
      };
      this.currentGenre = options.currentGenre || "Unknown";
      this.currentKey = options.currentKey || {
        key: "Unknown",
        confidence: 0,
        isMajor: true
      };
      this.currentProfile = options.currentProfile || "proNatural";
      this.nextProcessingInterval = fastFinite(options.nextProcessingInterval, 1000);
      this.currentPitchMult = fastFinite(options.currentPitchMult, 0);
      this.noiseLevel = options.noiseLevel || {
        level: 0,
        midFreq: 0.5
      };
      this.qualityPrediction = options.qualityPrediction || {
        score: 0,
        recommendations: []
      };
      this.isVocal = options.isVocal || false;
      this.wienerGain = fastFinite(options.wienerGain, 1);
      this.polyphonicPitches = options.polyphonicPitches || [];
      this.transientBoost = fastFinite(options.transientBoost, 0);
      this.MASTER_VOL = 0.6;
      // 11. Tối ưu bufferTime (Logic gốc)
      const pitchMultFactor = 1 + Math.abs(this.currentPitchMult) * 0.5;
      this.bufferTime = Math.max(this.bufferTime, this.fadeTime * 2.5 * pitchMultFactor);
      if (this.qualityMode === 'high') this.bufferTime *= 1.2;
      if (this.bufferTime < this.fadeTime * 2.5) {
        if (isDebug) console.warn("bufferTime được điều chỉnh", {
          bufferTime: this.bufferTime
        });
        this.bufferTime = this.fadeTime * 2.5;
      }
      if (this.delayTime > MAX_DELAY_TIME) {
        this.delayTime = MAX_DELAY_TIME;
      }
      // 12. MemoryManager
      this.memoryManager = options.memoryManager || new MemoryManager();
      const maxCacheSize = this.calculateMaxCacheSize?.() || 100;
      this.memoryManager.setDynamicMaxSize?.(maxCacheSize);
      this.memoryManager.pruneCache(maxCacheSize);
      // 13. Analyser
      try {
        this._analyser = options.analyser || this.context.createAnalyser();
        const analyserConfig = options.analyserConfig || {};
        this._analyser.fftSize = fastFinite(analyserConfig.fftSize, this.qualityMode === 'low' ? 512 : 1024);
        this._analyser.smoothingTimeConstant = fastFinite(analyserConfig.smoothingTimeConstant, 0.85);
      } catch (error) {
        throw new Error('Không thể khởi tạo AnalyserNode.');
      }
      // 14. Tạo buffers (ĐẦY ĐỦ OPTION)
      try {
        const bufferOptions = {
          contextId: this.contextId,
          smoothness: 1.3,
          vibrance: 0.5,
          pitchShift: this.currentPitchMult,
          isVocal: this.isVocal,
          spectralProfile: this.spectralProfile,
          currentGenre: this.currentGenre,
          noiseLevel: this.noiseLevel,
          wienerGain: this.wienerGain,
          polyphonicPitches: this.polyphonicPitches,
          qualityMode: this.qualityMode,
          edgeFade: 0.05
        };
        const buffers = getShiftBuffers(this.context, this.bufferTime, this.fadeTime, bufferOptions, this.memoryManager);
        this.shiftDownBuffer = buffers.shiftDownBuffer;
        this.shiftUpBuffer = buffers.shiftUpBuffer;
        this.fadeBuffer = getFadeBuffer(this.context, this.bufferTime, this.fadeTime, bufferOptions, this.memoryManager);
        if (!this.shiftDownBuffer || !this.shiftUpBuffer || !this.fadeBuffer) {
          throw new Error("Không thể tạo buffer hợp lệ");
        }
      } catch (error) {
        if (this.ownsContext) this.context.close();
        throw error;
      }
      // 15. Khởi tạo Graph (Hàm đã được nâng cấp an toàn)
      this.initializeNodes();
      this.initializeSpatialAudio(options.spatialAudioConfig || {
        panningModel: 'equalpower'
      });
      // 15.5 TÍCH HỢP AJU UI BRIDGE TẠI ĐÂY (Khi mọi node đã sẵn sàng)
      this.setupAjuUIBridge();
      // 16. Lưu cache instance
      if (this.memoryManager) {
        this.memoryManager.set(cacheKey, {
          instance: this,
          timestamp: Date.now(),
          expiry: Date.now() + 60000
        }, 'high');
      }
    } catch (error) {
      console.error('Lỗi trong hàm khởi tạo Jungle', error, {
        contextId: this.contextId
      });
      if (this.ownsContext && this.context) {
        this.context.close().catch(err => console.warn('Không thể đóng AudioContext', err));
      }
      throw error;
    }
  }
  /**
   * Jungle.prototype.initializeNodes - Trùm Cuối v20.5 (Bản chuẩn mực)
   * Đặc tính: Bảo toàn hoàn hảo logic gốc (dynamic parameter) + Memory Purge + Anti-Pop Ramp
   */
  Jungle.prototype.initializeNodes = function() {
    try {
      // Validate AudioContext
      if (!(this.context instanceof(window.AudioContext || window.webkitAudioContext))) {
        throw new Error('Invalid AudioContext: context is not an instance of AudioContext.');
      }
      // Check if already initialized
      if (this.input) {
        console.debug('Nodes already initialized, skipping reinitialization');
        return;
      }
      const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
      const performanceFactor = isLowPowerDevice ? 0.8 : 1.0;
      const currentTime = this.context.currentTime;
      // Convert Float32Array to AudioBuffer (Logic gốc)
      const createAudioBuffer = (float32Array, context, sampleRate, options = {}) => {
        const {
          channels = 1, normalize = false, validateData = true
        } = options;
        if (!float32Array || float32Array.length === 0) return null;
        if (validateData) {
          const step = float32Array.length > 50000 ? Math.floor(float32Array.length / 500) : 1;
          for (let i = 0; i < float32Array.length; i += step) {
            if (!Number.isFinite(float32Array[i])) throw new Error('NaN/Infinity detected');
          }
        }
        let data = float32Array;
        if (normalize) {
          let maxAbs = 0;
          for (let i = 0; i < data.length; i++) {
            if (Math.abs(data[i]) > maxAbs) maxAbs = Math.abs(data[i]);
          }
          if (maxAbs > 1.0) {
            const normalizedData = new Float32Array(data.length);
            for (let i = 0; i < data.length; i++) normalizedData[i] = data[i] / maxAbs;
            data = normalizedData;
          }
        }
        const buffer = context.createBuffer(channels, data.length / channels, sampleRate);
        buffer.getChannelData(0).set(data);
        return buffer;
      };
      // Initialize buffers & Deep Memory Purge
      const sr = this.context.sampleRate;
      if (this.shiftDownData instanceof Float32Array) {
        this.shiftDownBuffer = createAudioBuffer(this.shiftDownData, this.context, sr, {
          channels: 1
        });
        this.shiftDownData = null;
      }
      if (this.shiftUpData instanceof Float32Array) {
        this.shiftUpBuffer = createAudioBuffer(this.shiftUpData, this.context, sr, {
          channels: 1
        });
        this.shiftUpData = null;
      }
      if (this.fadeData instanceof Float32Array) {
        this.fadeBuffer = createAudioBuffer(this.fadeData, this.context, sr, {
          channels: 1
        });
        this.fadeData = null;
      }
      if (!this.shiftDownBuffer || !this.shiftUpBuffer || !this.fadeBuffer) {
        throw new Error('Missing required buffers: shiftDownBuffer, shiftUpBuffer, or fadeBuffer is undefined.');
      }
      // Validate spectralProfile
      const spectralProfile = this.spectralProfile || {};
      const defaultSpectralValue = 0.5;
      const spectralDefaults = {
        subBass: defaultSpectralValue,
        bass: defaultSpectralValue,
        subMid: defaultSpectralValue,
        midHigh: defaultSpectralValue,
        subTreble: defaultSpectralValue,
        air: defaultSpectralValue,
        vocalPresence: defaultSpectralValue
      };
      Object.keys(spectralDefaults).forEach(key => {
        spectralProfile[key] = Number.isFinite(spectralProfile[key]) ? Math.max(0, Math.min(1, spectralProfile[key])) : spectralDefaults[key];
      });
      // Initialize gain and panner nodes
      this.input = this.context.createGain();
      this.output = this.context.createGain();
      this.boostGain = this.context.createGain();
      this.panner = this.context.createStereoPanner();
      const vocalBoost = this.isVocal ? 1.2 + spectralProfile.vocalPresence * 0.3 : 1.0;
      const genreFactorMap = {
        'EDM': 1.2,
        'DrumAndBass': 1.2,
        'HipHop': 1.1,
        'Pop': 1.0,
        'Bolero': 0.9,
        'Classical': 0.8,
        'Jazz': 0.8,
        'RockMetal': 1.0,
        'Karaoke': 0.9
      };
      const genreFactor = genreFactorMap[this.currentGenre] || 1.0;
      // === FILTERS ĐÃ ĐƯỢC TỐI ƯU VÀ SẮP XẾP LẠI THEO CHUẨN STUDIO ===
      // 1. Chốt chặn siêu trầm (Chống ù rung nền)
      this.rumbleHighPass = this.context.createBiquadFilter();
      this.rumbleHighPass.type = 'highpass';
      this.rumbleHighPass.frequency.value = 20; // Ngưỡng an toàn tuyệt đối loại bỏ tạp âm hạ âm
      this.rumbleHighPass.Q.value = 0.5; // Độ dốc Butterworth phẳng, mượt mà tự nhiên
      // 2. Bộ lọc cắt tần số thấp tùy chỉnh (Dành riêng cho micro/karaoke hoặc nhạc lỗi)
      this.highPassFilter = this.context.createBiquadFilter();
      this.highPassFilter.type = 'highpass';
      this.highPassFilter.frequency.value = this.highPassFreq || DEFAULT_HIGH_PASS_FREQ; // 30Hz
      this.highPassFilter.Q.value = this.filterQ || DEFAULT_FILTER_Q;
      // 3. Notch Filter chống hú/chói (Đặt ở đầu chuỗi để làm sạch trước khi EQ)
      this.notchFilter = this.context.createBiquadFilter();
      this.notchFilter.type = 'notch';
      this.notchFilter.frequency.value = this.notchFreq || DEFAULT_NOTCH_FREQ;
      this.notchFilter.Q.value = this.notchQ || DEFAULT_NOTCH_Q;
      // 4. Các Filter dải Trầm & Trung (Low & Mid EQ) tạo sự ấm áp, chắc tiếng
      this.lowShelfGain = this.context.createBiquadFilter();
      this.lowShelfGain.type = 'lowshelf';
      this.lowShelfGain.frequency.value = 150;
      this.lowShelfGain.gain.value = 4.5 * spectralProfile.subBass * genreFactor * performanceFactor;
      this.subBassFilter = this.context.createBiquadFilter();
      this.subBassFilter.type = 'peaking';
      this.subBassFilter.frequency.value = 40;
      this.subBassFilter.Q.value = 1.2;
      this.subBassFilter.gain.value = 3 * spectralProfile.subBass * genreFactor * performanceFactor;
      this.midBassFilter = this.context.createBiquadFilter();
      this.midBassFilter.type = 'peaking';
      this.midBassFilter.frequency.value = this.midBassFreq || DEFAULT_MIDBASS_FREQ; // 200Hz
      this.midBassFilter.Q.value = 1.0;
      this.midBassFilter.gain.value = 2 * spectralProfile.bass * genreFactor * performanceFactor;
      this.subMidFilter = this.context.createBiquadFilter();
      this.subMidFilter.type = 'peaking';
      this.subMidFilter.frequency.value = this.subMidFreq || DEFAULT_SUBMID_FREQ; // 500Hz
      this.subMidFilter.Q.value = 0.8;
      this.subMidFilter.gain.value = 2 * spectralProfile.subMid * genreFactor * performanceFactor;
      this.midShelfGain = this.context.createBiquadFilter();
      this.midShelfGain.type = 'peaking';
      this.midShelfGain.frequency.value = 2000;
      this.midShelfGain.Q.value = 0.5;
      this.midShelfGain.gain.value = 4 * spectralProfile.midHigh * genreFactor * performanceFactor;
      this.highMidFilter = this.context.createBiquadFilter();
      this.highMidFilter.type = 'peaking';
      this.highMidFilter.frequency.value = this.highMidFreq || DEFAULT_HIGHMID_FREQ; // 2000Hz
      this.highMidFilter.Q.value = 0.8;
      this.highMidFilter.gain.value = 2 * spectralProfile.midHigh * genreFactor * performanceFactor;
      // 5. Định hình Formant Giọng hát (Hỗ trợ khi nâng hạ tone sâu)
      this.formantFilter1 = this.context.createBiquadFilter();
      this.formantFilter1.type = 'peaking';
      this.formantFilter1.frequency.value = this.formantF1Freq || DEFAULT_FORMANT_F1_FREQ;
      this.formantFilter1.Q.value = this.formantQ || DEFAULT_FORMANT_Q;
      this.formantFilter1.gain.value = DEFAULT_FORMANT_GAIN * vocalBoost * genreFactor * performanceFactor;
      this.formantFilter2 = this.context.createBiquadFilter();
      this.formantFilter2.type = 'peaking';
      this.formantFilter2.frequency.value = this.formantF2Freq || DEFAULT_FORMANT_F2_FREQ;
      this.formantFilter2.Q.value = this.formantQ || DEFAULT_FORMANT_Q;
      this.formantFilter2.gain.value = DEFAULT_FORMANT_GAIN * vocalBoost * genreFactor * performanceFactor;
      // 6. Các Filter Cao tần (High EQ) tạo độ tươi sáng, trong trẻo tự nhiên
      this.highShelfGain = this.context.createBiquadFilter();
      this.highShelfGain.type = 'highshelf';
      this.highShelfGain.frequency.value = 5000;
      this.highShelfGain.gain.value = 4.5 * spectralProfile.subTreble * genreFactor * performanceFactor;
      this.subTrebleFilter = this.context.createBiquadFilter();
      this.subTrebleFilter.type = 'peaking';
      this.subTrebleFilter.frequency.value = this.subTrebleFreq || DEFAULT_SUBTREBLE_FREQ; // 11000Hz
      this.subTrebleFilter.Q.value = 0.8;
      this.subTrebleFilter.gain.value = 2 * spectralProfile.subTreble * genreFactor * performanceFactor;
      this.airFilter = this.context.createBiquadFilter();
      this.airFilter.type = 'highshelf';
      this.airFilter.frequency.value = this.airFreq || DEFAULT_AIR_FREQ; // 13000Hz
      this.airFilter.gain.value = 2 * spectralProfile.air * genreFactor * performanceFactor;
      // 7. Chốt chặn dải siêu cao (Chống nhiễu cao tần, giữ treble mượt, sạch, không xé tiếng)
      this.lowPassFilter = this.context.createBiquadFilter();
      this.lowPassFilter.type = 'lowpass';
      this.lowPassFilter.frequency.value = this.lowPassFreq || DEFAULT_LOW_PASS_FREQ; // 18000Hz
      this.lowPassFilter.Q.value = this.filterQ || DEFAULT_FILTER_Q;
      // === MODULATION & PITCH SHIFTING NODES (GIỮ NGUYÊN LOGIC GỐC) ===
      this.mod1 = this.context.createBufferSource();
      this.mod2 = this.context.createBufferSource();
      this.mod3 = this.context.createBufferSource();
      this.mod4 = this.context.createBufferSource();
      this.mod1.buffer = this.shiftDownBuffer;
      this.mod2.buffer = this.shiftDownBuffer;
      this.mod3.buffer = this.shiftUpBuffer;
      this.mod4.buffer = this.shiftUpBuffer;
      this.mod1.loop = this.mod2.loop = this.mod3.loop = this.mod4.loop = true;
      this.mod1Gain = this.context.createGain();
      this.mod2Gain = this.context.createGain();
      this.mod3Gain = this.context.createGain();
      this.mod3Gain.gain.value = 0;
      this.mod4Gain = this.context.createGain();
      this.mod4Gain.gain.value = 0;
      this.mod1.connect(this.mod1Gain);
      this.mod2.connect(this.mod2Gain);
      this.mod3.connect(this.mod3Gain);
      this.mod4.connect(this.mod4Gain);
      this.modGain1 = this.context.createGain();
      this.modGain2 = this.context.createGain();
      this.delay1 = this.context.createDelay(MAX_DELAY_TIME);
      this.delay2 = this.context.createDelay(MAX_DELAY_TIME);
      this.mod1Gain.connect(this.modGain1);
      this.mod2Gain.connect(this.modGain2);
      this.mod3Gain.connect(this.modGain1);
      this.mod4Gain.connect(this.modGain2);
      this.modGain1.connect(this.delay1.delayTime);
      this.modGain2.connect(this.delay2.delayTime);
      this.fade1 = this.context.createBufferSource();
      this.fade2 = this.context.createBufferSource();
      this.fade1.buffer = this.fade2.buffer = this.fadeBuffer;
      this.fade1.loop = this.fade2.loop = true;
      this.mix1 = this.context.createGain();
      this.mix2 = this.context.createGain();
      this.mix1.gain.value = this.mix2.gain.value = 0;
      this.fade1.connect(this.mix1.gain);
      this.fade2.connect(this.mix2.gain);
      // === MASTER & COMPRESSOR ===
      this.outputGain = this.context.createGain();
      this.outputGain.gain.value = this.MASTER_VOL;
      this.compressor = this.context.createDynamicsCompressor();
      this.compressor.threshold.value = DEFAULT_COMPRESSOR_THRESHOLD;
      this.compressor.knee.value = 30;
      this.compressor.ratio.value = DEFAULT_COMPRESSOR_RATIO;
      this.compressor.attack.value = DEFAULT_COMPRESSOR_ATTACK;
      this.compressor.release.value = DEFAULT_COMPRESSOR_RELEASE;
      // =================================================================
      // === CONNECT NODES - SẮP XẾP CHUỖI AUDIO CHAIN CHUẨN STUDIO ===
      // =================================================================
      // Bước 1: Tiền xử lý, lọc nhiễu nền và tiếng hú (Clean Up)
      this.input.connect(this.rumbleHighPass);
      this.rumbleHighPass.connect(this.highPassFilter);
      this.highPassFilter.connect(this.notchFilter);
      // Bước 2: Chuỗi EQ dải Trầm và Trung (Tạo móng Bass chắc nịch, dải Mid ấm áp)
      this.notchFilter.connect(this.lowShelfGain);
      this.lowShelfGain.connect(this.subBassFilter);
      this.subBassFilter.connect(this.midBassFilter);
      this.midBassFilter.connect(this.subMidFilter);
      this.subMidFilter.connect(this.midShelfGain);
      this.midShelfGain.connect(this.highMidFilter);
      // Bước 3: Định hình Formant tối ưu trước khi nạp vào khối đổi giọng
      this.highMidFilter.connect(this.formantFilter1);
      this.formantFilter1.connect(this.formantFilter2);
      // Bước 4: Khối Pitch Shifter xử lý cao độ nâng hạ tone sâu
      this.formantFilter2.connect(this.delay1);
      this.formantFilter2.connect(this.delay2);
      this.delay1.connect(this.mix1);
      this.delay2.connect(this.mix2);
      this.mix1.connect(this.boostGain);
      this.mix2.connect(this.boostGain);
      // Bước 5: Mở rộng không gian âm thanh (Spatial Stereo Imaging)
      this.boostGain.connect(this.panner);
      // Bước 6: Chuỗi EQ dải Cao (Tạo màu sắc tươi, trong trẻo, bay bổng)
      this.panner.connect(this.highShelfGain);
      this.highShelfGain.connect(this.subTrebleFilter);
      this.subTrebleFilter.connect(this.airFilter);
      this.airFilter.connect(this.lowPassFilter); // Điểm chốt chặn tần số cao cuối cùng
      // Bước 7: Hậu xử lý Dynamics (Gói âm thanh quyện lại, tăng lực chắc chắn và xuất Master)
      this.lowPassFilter.connect(this.compressor);
      this.compressor.connect(this.outputGain);
      this.outputGain.connect(this.output);
      // Validate kết quả khởi tạo các node quan trọng
      if (!this.boostGain || !this.highShelfGain || !this.subTrebleFilter) {
        throw new Error('Required nodes for spatial audio integration are missing');
      }
      // Initialize parameters
      if (typeof this.setDelay === 'function') this.setDelay(this.delayTime || DEFAULT_DELAY_TIME);
      if (typeof this.setBoost === 'function') this.setBoost(0.7);
      if (typeof this.setPan === 'function') this.setPan(0);
      if (typeof this.setPitchOffset === 'function') this.setPitchOffset(0, false);
      // Anti-Pop Ramp để mượt mà khi bắt đầu stream audio
      if (this.output && this.output.gain) {
        this.output.gain.setValueAtTime(0, currentTime);
        this.output.gain.linearRampToValueAtTime(this.MASTER_VOL, currentTime + DEFAULT_RAMP_TIME);
      }
      console.debug('Audio nodes initialized successfully - Rumble Highpass + Optimized Chain Ready!');
    } catch (error) {
      console.error('Error initializing audio nodes:', error);
      throw error;
    }
  };
  // === ACOUSTIC TRANSPARENCY ENHANCEMENT ===
  // NÂNG CẤP CHÍNH XÁC: Bảo vệ tham số mặc định chống crash triệt để khi bộ phổ chưa load xong
  Jungle.prototype.calculateAcousticTransparencyGain = function(validatedSpectral = this.spectralProfile || {}) {
    try {
      // 1. AN TOÀN HÓA DỮ LIỆU ĐẦU VÀO (Defensive Programming)
      const safe = (val) => (typeof val === 'number' && Number.isFinite(val)) ? val : 0.5;
      const midHigh = safe(validatedSpectral.midHigh ?? validatedSpectral.high ?? 0.5);
      const high = safe(validatedSpectral.high ?? validatedSpectral.subTreble ?? 0.5);
      const subMid = safe(validatedSpectral.subMid ?? 0.5);
      const midLow = safe(validatedSpectral.midLow ?? validatedSpectral.bass ?? subMid);
      // Trọng số: Clarity cần sáng, Mud cần được nén
      const clarityScore = (midHigh * 0.4 + high * 0.6);
      const mudScore = (subMid * 0.7 + midLow * 0.3); // Tăng trọng số tần số đục
      const profile = this.profile || 'proNatural';
      const absPitch = Math.abs(this.currentPitchMult || 0);
      const vocalPresence = safe(validatedSpectral.vocalPresence ?? 0.5);
      const transientDensity = safe(validatedSpectral.transientDensity ?? 0.5);
      // 2. COEFFICIENT ĐỘNG (Dựa trên thể loại và cường độ)
      // Dùng object map thay vì if-else chồng chéo cho tốc độ xử lý nhanh hơn
      const profileMap = {
        'warm': 0.18,
        'bassHeavy': 0.18,
        'bright': 0.35,
        'smartStudio': 0.32,
        'proNatural': 0.32,
        'vocal': 0.28,
        'karaokeDynamic': 0.30,
        'rockMetal': 0.26
      };
      let coeff = profileMap[profile] || 0.25;
      // Pitch-shift compensation: Khi đổi tông (pitch), âm thanh dễ bị "bệt", cần tăng transparency
      if (absPitch > 0.3) coeff *= (1 - absPitch * 0.15);
      // 3. THUẬT TOÁN "TIGHTNESS" (Độ chắc)
      // Nhân thêm độ dày của transient. Nhạc có transient cao (EDM, Rock) cần trong trẻo hơn
      // VocalPresence neo lại độ trong để không bị "lỏng" tiếng
      coeff *= (1 + (vocalPresence * 0.25) + (transientDensity * 0.15));
      // 4. KẾT QUẢ PHI TUYẾN (Non-linear Mapping)
      // MudScore càng cao thì transparency càng phải được kiềm chế (không được đẩy gain vô tội vạ)
      const netGain = (clarityScore - (mudScore * 1.2)); // Phạt mudScore mạnh hơn
      let dynamicTransparency = 1.0 + (netGain * coeff);
      // Giới hạn an toàn (Soft-clipping)
      // Không để transparency vượt quá 1.3 để tránh méo tiếng kỹ thuật số
      return Math.max(0.85, Math.min(1.30, dynamicTransparency));
    } catch (error) {
      console.warn('Acoustic Transparency calculation fallback to 1.0', error);
      return 1.0;
    }
  };
  Jungle.prototype.applyDynamicPeakGuardian = function() {
    try {
      const currentTime = this.context.currentTime;
      // NÂNG CẤP THÔNG MINH: Tích hợp bộ đo tải để bảo vệ luồng render AV1/VP9 khi máy tải nặng
      const cpuLoad = (typeof this.getCPULoad === 'function') ? this.getCPULoad() : 0.5;
      const fft = this.getFFTAnalysis?.() || {};
      const spectral = {
        transientDensity: fft.transientDensity ?? 0.5,
        spectralFlux: fft.spectralFlux ?? 0.5,
        vocalEnergy: fft.vocalEnergy ?? 0.5,
        airEnergy: fft.airEnergy ?? 0.5,
        subTrebleEnergy: fft.subTrebleEnergy ?? 0.5,
        spectralCoherence: fft.spectralCoherence ?? 0.5,
        bassEnergy: fft.bassEnergy ?? 0.5
      };
      const rms = this.rms || 0.1;
      const absPitch = Math.abs(this.currentPitchMult || 0);
      // 🪐 ĐỒNG BỘ 2: Giữ nguyên cấu hình dự phòng
      const profile = this.profile || 'proNatural';
      const transparencyGain = this.calculateAcousticTransparencyGain();
      // =========================================================================
      // KHÔNG GIAN TOÁN HỌC PHỔ ÂM THANH NGUYÊN BẢN CỦA BẠN (GIỮ NGUYÊN CHÍNH XÁC 100%)
      // =========================================================================
      let peakRisk = 0;
      peakRisk += rms > 0.24 ? (rms - 0.24) * 14 : 0;
      peakRisk += spectral.transientDensity > 0.82 ? (spectral.transientDensity - 0.82) * 6 : 0;
      peakRisk += spectral.spectralFlux > 0.75 ? (spectral.spectralFlux - 0.75) * 5 : 0;
      peakRisk += (spectral.airEnergy + spectral.subTrebleEnergy) / 2 > 0.85 ? 1.2 : 0;
      peakRisk += absPitch > 0.6 ? absPitch * 1.2 : 0;
      peakRisk *= (1 - spectral.spectralCoherence * 0.6);
      // Bảo vệ bass bum bum: nếu bassEnergy cao → giảm risk mạnh
      if (spectral.bassEnergy > 0.7) peakRisk *= 0.7;
      peakRisk *= (spectral.vocalEnergy > 0.7 || transparencyGain < 0.9) ? 0.55 : 1.0;
      // Áp dụng độ mạnh Guardian theo Profile
      let guardianStrength = 1.0;
      if (profile === 'bright' || profile === 'smartStudio' || profile === 'proNatural') guardianStrength = 1.15;
      if (profile === 'vocal' || profile === 'karaokeDynamic') guardianStrength = 1.05;
      if (profile === 'rockMetal') guardianStrength = 1.1;
      if (profile === 'bassHeavy' || profile === 'warm') guardianStrength = 0.65;
      peakRisk *= guardianStrength;
      // CÔNG NGHỆ TỰ ĐỘNG HÓA: Nếu CPU đang quá nóng, hạ ngưỡng can thiệp
      const triggerThreshold = cpuLoad > 0.85 ? 0.35 : 0.45;
      if (peakRisk > triggerThreshold && this.outputGain?.gain && this.compressor?.threshold) {
        // Điều chỉnh tỷ lệ nén linh hoạt theo rủi ro đỉnh
        let gainReduction = Math.min(0.12, peakRisk * 0.25);
        if (cpuLoad > 0.85) gainReduction = Math.min(0.15, gainReduction * 1.15);
        // NÂNG CẤP ĐỘ MỊN: 
        // Giữ lại Ramp 0.5s của bạn, nhưng dùng exponentialRamp để chuyển đổi Gain tự nhiên, 
        // âm thanh sẽ không bị "giật" khi gainReduction can thiệp đột ngột.
        const currentOutputGain = this.outputGain.gain.value ?? 1.0;
        const targetGain = currentOutputGain * (1 - gainReduction);
        this.outputGain.gain.cancelScheduledValues(currentTime);
        this.outputGain.gain.setValueAtTime(currentOutputGain, currentTime);
        // Nâng cấp: Chuyển sang exponentialRamp (độ mịn cao nhất cho tai người)
        this.outputGain.gain.exponentialRampToValueAtTime(Math.max(0.001, targetGain), currentTime + 0.5);
        // FIX LỖI SỐ 0: Sử dụng toán tử ?? tránh giật ngưỡng nén
        const currentThresh = this.compressor.threshold.value ?? -20;
        const threshAdjust = Math.min(3, peakRisk * 5);
        const targetThresh = currentThresh + threshAdjust;
        this.compressor.threshold.cancelScheduledValues(currentTime);
        this.compressor.threshold.setValueAtTime(currentThresh, currentTime);
        // Nâng cấp: Chuyển sang exponentialRamp để Threshold thay đổi mượt hơn
        this.compressor.threshold.exponentialRampToValueAtTime(Math.min(-0.1, targetThresh), currentTime + 0.5);
        // LOG DEBUG CỦA BẠN (Đã khôi phục hoàn toàn, không thiếu 1 dòng)
        if (window.location.search.includes('debug=true')) {
          console.debug('Dynamic Peak Guardian PRO activated – ultra gentle protection', {
            peakRisk: peakRisk.toFixed(2),
            gainReduction: gainReduction.toFixed(3),
            targetGain: targetGain.toFixed(3),
            threshAdjust: threshAdjust.toFixed(2),
            bassEnergy: spectral.bassEnergy.toFixed(2),
            profile,
            cpuLoad: cpuLoad.toFixed(2)
          });
        }
      }
    } catch (error) {
      console.warn('Peak Guardian fallback - no action', error);
    }
  };
  Jungle.prototype.initializeSpatialAudio = function() {
    const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
    try {
      // Validate AudioContext
      if (!(this.context instanceof AudioContext)) {
        throw new Error('Invalid AudioContext: context is not an instance of AudioContext.');
      }
      // Check device capability
      const isLowPowerDevice = navigator.hardwareConcurrency && navigator.hardwareConcurrency < 2;
      const cpuLoad = this.getCPULoad ? ensureFinite(this.getCPULoad(), 0.5) : 0.5;
      // Initialize spatial audio properties
      this.spatialAudioEnabled = isLowPowerDevice ? false : (localStorage.getItem('spatialAudioPreference') === 'true');
      this.reverbEnabled = false;
      this.audioFormat = 'stereo';
      this.pannerNode = null;
      this.foaDecoder = null;
      this.binauralBypass = false;
      this.userSpatialAudioPreference = this.spatialAudioEnabled;
      this.reverbBuffer = null;
      // Cache spatial audio config
      const cacheKey = this.generateCacheSignature?.('spatialAudioConfig', {
        spectralProfile: this.spectralProfile,
        songStructure: this.memoryManager?.get('lastStructure'),
        audioFormat: this.audioFormat
      }) || `spatialAudio_${this.contextId}`;
      if (this.memoryManager?.get(cacheKey)?.timestamp > Date.now() - 30000) {
        const cachedConfig = this.memoryManager.get(cacheKey);
        Object.assign(this, cachedConfig);
        if (isDebug) console.debug('Reused cached spatial audio config', {
          cacheKey,
          cachedConfig
        });
        return;
      }
      // Tinh hoa: fastFinite gọn
      const fastFinite = (val, def) => Number.isFinite(val) ? val : def;
      /**
       * Toggles spatial audio on/off and dispatches event for UI.
       */
      this.toggleSpatialAudio = function(enable) {
        this.userSpatialAudioPreference = !!enable;
        this.spatialAudioEnabled = !isLowPowerDevice && this.userSpatialAudioPreference && cpuLoad < 0.9;
        this.configureSignalChain(this.audioFormat);
        try {
          localStorage.setItem('spatialAudioPreference', this.spatialAudioEnabled);
        } catch (e) {}
        if (isDebug) console.debug('Spatial audio preference set:', {
          spatialAudioEnabled: this.spatialAudioEnabled,
          cpuLoad,
          isLowPowerDevice
        });
        this.dispatchEvent?.(new CustomEvent('spatialAudioChanged', {
          detail: {
            enabled: this.spatialAudioEnabled
          }
        }));
      };
      this.setSpatialAudio = function(enable) {
        this.toggleSpatialAudio(enable);
      };
      this.setReverb = function(enable) {
        this.reverbEnabled = !!enable;
        this.configureSignalChain(this.audioFormat);
        try {
          localStorage.setItem('reverbPreference', this.reverbEnabled);
        } catch (e) {}
        if (isDebug) console.debug('Reverb preference set:', {
          reverbEnabled: this.reverbEnabled,
          cpuLoad
        });
        this.dispatchEvent?.(new CustomEvent('reverbChanged', {
          detail: {
            enabled: this.reverbEnabled
          }
        }));
      };
      this.restorePreferences = function() {
        const spatialPref = localStorage.getItem('spatialAudioPreference');
        const reverbPref = localStorage.getItem('reverbPreference');
        if (spatialPref !== null) this.setSpatialAudio(spatialPref === 'true');
        if (reverbPref !== null) this.setReverb(reverbPref === 'true');
        if (isDebug) console.debug('Restored preferences:', {
          spatialAudio: this.spatialAudioEnabled,
          reverb: this.reverbEnabled
        });
      };
      // Tinh hoa: throttle detect 2s tránh quét liên tục
      this.detectAudioFormat = function(input) {
        const now = Date.now();
        if (this._lastFormatCheck && now - this._lastFormatCheck < 2000) return this.audioFormat;
        this._lastFormatCheck = now;
        const cachedFormat = this.memoryManager?.getBuffer('audioFormat');
        if (cachedFormat && cachedFormat.expiry > Date.now()) {
          if (isDebug) console.debug('Using cached audio format:', cachedFormat.format);
          return cachedFormat.format;
        }
        let channels = 2;
        let metadata = {};
        let title = '';
        let description = '';
        if (input instanceof AudioBuffer) {
          channels = input.numberOfChannels || 2;
          metadata = input.metadata || {};
        } else if (input instanceof MediaElementAudioSourceNode && input.mediaElement) {
          const audioTracks = input.mediaElement.audioTracks || [];
          channels = audioTracks.length > 0 ? audioTracks[0].channelCount || 2 : 2;
          metadata = input.mediaElement.spatialAudioMetadata || {};
          title = input.mediaElement.title || input.mediaElement.src || '';
          description = input.mediaElement.dataset?.youtubeDescription || '';
        }
        let format = 'stereo';
        const lowerTitle = title.toLowerCase();
        const lowerDesc = description.toLowerCase();
        const spatialKeywords = ['8d audio', '10d audio', 'spatial audio', 'dolby atmos'];
        const feedbackList = this.memoryManager?.get('userFeedback') || [];
        const recentFeedback = feedbackList.find(f => f.timestamp > Date.now() - 60000 && f.semanticCategory);
        if (recentFeedback?.semanticCategory === 'vocal') {
          format = 'binaural';
        } else if (channels === 1) {
          format = 'mono';
        } else if (channels === 2 && (metadata.hrtf || spatialKeywords.some(kw => lowerTitle.includes(kw) || lowerDesc.includes(kw)))) {
          format = 'binaural';
        } else if (channels === 4 && metadata.format === 'ambisonics') {
          format = 'ambisonics';
        } else if (channels >= 6 && (metadata.format === 'atmos' || spatialKeywords.some(kw => lowerTitle.includes(kw) || lowerDesc.includes(kw)))) {
          format = 'atmos';
        }
        if (['binaural', 'ambisonics', 'atmos'].includes(format) && !navigator.mediaDevices?.getUserMedia) {
          console.warn('Spatial audio may require headphones for optimal experience.');
        }
        this.memoryManager?.allocateBuffer('audioFormat', {
          format,
          timestamp: Date.now(),
          expiry: Date.now() + 30000,
          priority: 'high'
        });
        this.memoryManager?.pruneCache(this.calculateMaxCacheSize?.() || 100);
        if (isDebug) console.debug('Detected audio format:', {
          format,
          channels,
          metadata,
          title,
          description,
          recentFeedback
        });
        return format;
      };
      this.initializeFOADecoder = function(inputNode) {
        const splitter = this.context.createChannelSplitter(4);
        inputNode.connect(splitter);
        const wGain = this.context.createGain();
        const xGain = this.context.createGain();
        const yGain = this.context.createGain();
        const zGain = this.context.createGain();
        splitter.connect(wGain, 0);
        splitter.connect(xGain, 1);
        splitter.connect(yGain, 2);
        splitter.connect(zGain, 3);
        const merger = this.context.createChannelMerger(2);
        const leftGain = this.context.createGain();
        const rightGain = this.context.createGain();
        const vocalPresence = this.spectralProfile?.vocalPresence || 0.5;
        wGain.gain.value = 1.0 / Math.sqrt(2);
        xGain.gain.value = vocalPresence > 0.7 ? 1.2 : 1.0;
        yGain.gain.value = 1.0;
        zGain.gain.value = cpuLoad > 0.8 ? 0.3 : 0.5;
        wGain.connect(leftGain);
        xGain.connect(leftGain);
        yGain.connect(leftGain);
        zGain.connect(leftGain);
        wGain.connect(rightGain);
        xGain.connect(rightGain);
        const yInverter = this.context.createGain();
        yInverter.gain.value = -1.0;
        yGain.connect(yInverter);
        yInverter.connect(rightGain);
        zGain.connect(rightGain);
        leftGain.connect(merger, 0, 0);
        rightGain.connect(merger, 0, 1);
        if (isDebug) console.debug('FOA decoder initialized', {
          vocalPresence,
          cpuLoad
        });
        return merger;
      };
      this.configureSignalChain = function(format) {
        format = format || 'stereo';
        this.audioFormat = format;
        const isSpatialFormat = ['binaural', 'ambisonics', 'atmos'].includes(format);
        this.spatialAudioEnabled = !isLowPowerDevice && this.userSpatialAudioPreference && isSpatialFormat && cpuLoad < 0.9;
        if (!this.boostGain || !this.highShelfGain || !this.subTrebleFilter) {
          console.warn('Required nodes missing, skipping signal chain configuration');
          return;
        }
        // Tinh hoa: cleanup try-catch an toàn
        try {
          if (this.boostGain && typeof this.boostGain.disconnect === 'function') this.boostGain.disconnect();
          ['panner', 'pannerNode', 'foaDecoder', 'reverb', 'reverbGain'].forEach(nodeName => {
            if (this[nodeName] && typeof this[nodeName].disconnect === 'function') {
              try {
                this[nodeName].disconnect();
              } catch (e) {}
              this[nodeName] = null;
            }
          });
        } catch (e) {
          if (isDebug) console.warn("Cleanup error during chain reconfiguration", e);
        }
        const songStructure = this.memoryManager?.get('lastStructure') || {
          section: 'unknown'
        };
        const panAdjust = songStructure.section === 'chorus' ? 0.2 : 0;
        if (!this.spatialAudioEnabled) {
          this.panner = this.context.createStereoPanner();
          this.boostGain.connect(this.panner);
          this.panner.connect(this.highShelfGain);
          if (typeof this.setPan === 'function') this.setPan(panAdjust);
          this.binauralBypass = false;
          if (isDebug) console.debug('Configured signal chain for karaoke:', {
            format,
            panAdjust
          });
        } else if (format === 'binaural') {
          this.binauralBypass = true;
          this.panner = this.context.createStereoPanner();
          this.boostGain.connect(this.panner);
          this.panner.connect(this.highShelfGain);
          if (typeof this.setPan === 'function') this.setPan(0);
          if (isDebug) console.debug('Configured signal chain for binaural audio');
        } else if (format === 'ambisonics') {
          this.foaDecoder = this.initializeFOADecoder(this.boostGain);
          this.foaDecoder.connect(this.highShelfGain);
          if (isDebug) console.debug('Configured signal chain for Ambisonics');
        } else if (format === 'atmos') {
          this.pannerNode = this.context.createPanner();
          this.pannerNode.panningModel = 'HRTF';
          this.pannerNode.distanceModel = 'inverse';
          this.pannerNode.refDistance = 1;
          this.pannerNode.maxDistance = 10000;
          this.pannerNode.rolloffFactor = songStructure.section === 'chorus' ? 1.2 : 1;
          this.boostGain.connect(this.pannerNode);
          this.pannerNode.connect(this.highShelfGain);
          if (isDebug) console.debug('Configured signal chain for Dolby Atmos', {
            rolloffFactor: this.pannerNode.rolloffFactor
          });
        }
        // Tinh hoa: reverb chỉ khi !lowPower
        if (this.reverbEnabled && !isLowPowerDevice) {
          this.reverb = this.context.createConvolver();
          this.reverb.buffer = this.reverbBuffer || this.createImpulseResponse();
          this.reverbGain = this.context.createGain();
          this.reverbGain.gain.value = cpuLoad > 0.9 ? 0.02 : (this.spatialAudioEnabled ? 0.2 : 0.05);
          this.highShelfGain.connect(this.reverb);
          this.reverb.connect(this.reverbGain);
          this.reverbGain.connect(this.subTrebleFilter);
          if (isDebug) console.debug('Added reverb', {
            reverbGain: this.reverbGain.gain.value
          });
        } else {
          if (isDebug) console.debug('Reverb disabled to preserve raw audio');
        }
      };
      this.createImpulseResponse = function() {
        const isVeryLowPower = navigator.hardwareConcurrency === 1;
        const length = this.context.sampleRate * (isVeryLowPower ? 0.2 : (isLowPowerDevice ? 0.3 : 0.5));
        const buffer = this.context.createBuffer(2, length, this.context.sampleRate);
        for (let channel = 0; channel < 2; channel++) {
          const data = buffer.getChannelData(channel);
          for (let i = 0; i < length; i++) {
            const t = i / length;
            data[i] = (Math.random() * 2 - 1) * Math.exp(-5 * t);
          }
        }
        this.reverbBuffer = buffer;
        return buffer;
      };
      // Tinh hoa: setTargetAtTime cho position mượt
      this.setSpatialPosition = function(azimuth, elevation, distance = 1) {
        if (!this.pannerNode || !this.spatialAudioEnabled) return;
        azimuth = fastFinite(azimuth, 0);
        elevation = fastFinite(elevation, 0);
        distance = fastFinite(distance, 1);
        const songStructure = this.memoryManager?.get('lastStructure') || {
          section: 'unknown'
        };
        const distanceAdjust = songStructure.section === 'chorus' ? distance * 1.2 : distance;
        const x = distanceAdjust * Math.cos(azimuth) * Math.cos(elevation);
        const y = distanceAdjust * Math.sin(elevation);
        const z = -distanceAdjust * Math.sin(azimuth) * Math.cos(elevation);
        const time = this.context.currentTime;
        this.pannerNode.positionX.setTargetAtTime(x, time, 0.1);
        this.pannerNode.positionY.setTargetAtTime(y, time, 0.1);
        this.pannerNode.positionZ.setTargetAtTime(z, time, 0.1);
        if (isDebug) console.debug('Set spatial position:', {
          azimuth,
          elevation,
          distance: distanceAdjust,
          x,
          y,
          z,
          songStructure
        });
      };
      this.bypassMonoBuffers = function(input) {
        if (this.binauralBypass && input.numberOfChannels === 2) {
          if (this.input && typeof this.input.connect === 'function') {
            this.input.connect(this.bassHighPassFilter);
          }
          if (isDebug) console.debug('Bypassed mono buffers for binaural audio');
          return true;
        }
        return false;
      };
      const originalProcessAudio = this.processAudio;
      this.processAudio = async function(input, params = {}) {
        const format = this.detectAudioFormat(input);
        this.configureSignalChain(format);
        if (format === 'binaural' && this.spatialAudioEnabled) {
          this.bypassMonoBuffers(input);
        }
        if (format === 'atmos' && this.spatialAudioEnabled && params.azimuth !== undefined && params.elevation !== undefined) {
          this.setSpatialPosition(fastFinite(params.azimuth, 0), fastFinite(params.elevation, 0), fastFinite(params.distance, 1));
        }
        await originalProcessAudio.call(this, input, params);
      };
      const originalInitializeNodes = this.initializeNodes;
      this.initializeNodes = function() {
        originalInitializeNodes.call(this);
        this.configureSignalChain(this.audioFormat);
        if (isDebug) console.debug('Spatial audio initialized within node chain');
      };
      // Lưu cấu hình vào cache
      if (this.memoryManager) {
        this.memoryManager.set(cacheKey, {
          spatialAudioEnabled: this.spatialAudioEnabled,
          reverbEnabled: this.reverbEnabled,
          audioFormat: this.audioFormat,
          pannerNode: this.pannerNode,
          foaDecoder: this.foaDecoder,
          binauralBypass: this.binauralBypass,
          userSpatialAudioPreference: this.userSpatialAudioPreference,
          reverbBuffer: this.reverbBuffer
        }, 'high', {
          timestamp: Date.now(),
          expiry: Date.now() + 30000
        });
        this.memoryManager.pruneCache(this.calculateMaxCacheSize?.() || 100);
      }
      // Restore preferences and initialize
      this.restorePreferences();
      this.configureSignalChain(this.audioFormat);
      if (isDebug) console.debug('Spatial audio initialization complete', {
        audioFormat: this.audioFormat,
        spatialAudioEnabled: this.spatialAudioEnabled,
        reverbEnabled: this.reverbEnabled,
        spectralProfile: this.spectralProfile,
        songStructure: this.memoryManager?.get('lastStructure'),
        cacheStats: this.memoryManager?.getCacheStats?.()
      });
    } catch (error) {
      console.error('Error initializing spatial audio:', error, {
        contextValid: !!this.context,
        audioFormat: this.audioFormat,
        sampleRate: this.context?.sampleRate,
        spatialAudioEnabled: this.spatialAudioEnabled,
        reverbEnabled: this.reverbEnabled
      });
      // Tinh hoa fallback khi error
      if (this.boostGain && this.highShelfGain) {
        try {
          if (typeof this.boostGain.disconnect === 'function') this.boostGain.disconnect();
          this.boostGain.connect(this.highShelfGain);
        } catch (e) {}
      }
      throw error;
    }
  };
  Jungle.prototype.stereoMix = function(balance) {
    const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
    try {
      // TRUNG THỰC TUYỆT ĐỐI: Chuẩn hóa trị số mộc từ thanh kéo của người dùng
      balance = ensureFinite(balance, 0);
      balance = Math.max(-1, Math.min(1, balance));
      if (!this.panner) {
        console.warn('Panner node not initialized, skipping stereo mix adjustment');
        return;
      }
      // CHẾ ĐỘ HI-FI REFERENCE: Khóa cứng trần không gian ảo, trung thực nguyên bản 100%
      const spatialWidth = 1.0;
      let adjustedBalance = balance;
      const profile = this.profile || 'proNatural';
      // Xử lý stereo mix phần cứng mộc nhất có thể, ramp cực nhanh 0.01s chống trễ pha
      if (!this.spatialAudioEnabled) {
        this.panner.pan.cancelScheduledValues(this.context.currentTime);
        this.panner.pan.linearRampToValueAtTime(adjustedBalance, this.context.currentTime + 0.01);
        if (isDebug) console.debug('Hi-Fi Reference Mode Activated: No artificial widening.', {
          adjustedBalance
        });
      } else {
        if (this.audioFormat === 'binaural') {
          this.panner.pan.cancelScheduledValues(this.context.currentTime);
          this.panner.pan.linearRampToValueAtTime(0, this.context.currentTime + 0.01);
        }
      }
      // Lưu giữ cấu hình tĩnh vào bộ nhớ đệm để tầng giao diện không bị đứt liên kết đồng bộ
      if (this.memoryManager) {
        const songStructure = this.memoryManager.get('lastStructure') || {
          section: 'unknown'
        };
        const cacheKey = `stereoMix_${this.contextId}_${profile}_${songStructure.section}`;
        this.memoryManager.set(cacheKey, {
          data: {
            balance: adjustedBalance,
            spatialWidth: 1.0,
            timestamp: Date.now(),
            profile
          },
          expiry: Date.now() + 30000,
          priority: 'medium'
        }, 'medium');
      }
      // Gửi sự kiện cập nhật mộc thông báo cho content.js kéo thanh trượt giao diện
      this.dispatchEvent?.(new CustomEvent('stereoMixChanged', {
        detail: {
          balance: adjustedBalance,
          spatialWidth: 1.0
        }
      }));
    } catch (error) {
      console.error('Error setting Hi-Fi stereo mix:', error);
      if (this.panner?.pan) {
        this.panner.pan.setValueAtTime(0, this.context.currentTime);
      }
    }
  };
  /**
   * Initializes Web Worker for audio processing.
   * @throws {Error} If Web Worker is not supported or fails to initialize.
   * @note Ensures Worker has its own MemoryManager instance to avoid conflicts.
   * @note Sends initialization parameters to Worker for consistent buffer creation.
   */
  Jungle.prototype.initializeWorker = function() {
    if (this.worker) return; // Tinh hoa tránh khởi tạo chồng, bảo vệ luồng duy nhất
    try {
      if (!window.Worker) {
        throw new Error("Web Workers are not supported in this environment.");
      }
      this.worker = new Worker('audioWorker.js');
      // Đảm bảo currentGenre hợp lệ dựa trên danh sách chuẩn phòng thu
      const validGenres = ['EDM', 'Pop', 'Rock', 'Jazz', 'Classical', 'Hip-Hop', 'Drum & Bass', 'Karaoke'];
      const currentGenre = validGenres.includes(this.currentGenre) ? this.currentGenre : 'Pop';
      // Xác định fftSize dựa trên thông số cấu hình phần cứng thiết bị (Context-Aware)
      const deviceMemory = navigator.deviceMemory || 4;
      const hardwareConcurrency = navigator.hardwareConcurrency || 2;
      const fftSize = (deviceMemory < 4 || hardwareConcurrency < 4) ? 1024 : (deviceMemory >= 8 ? 4096 : 2048);
      // Helper tối ưu toán tử finite nhanh gọn
      const fastFinite = (val, def) => Number.isFinite(val) ? val : def;
      
      // =========================================================================
      // CHỐT CHẶN 1: Bảo vệ tiến trình gửi thông điệp khởi tạo gốc
      // =========================================================================
      if (this.worker) {
        this.worker.postMessage({
          type: 'init',
          params: {
            smoothness: fastFinite(this.smoothness, 1.3),
            vibrance: fastFinite(this.vibrance, 0.5),
            pitchShift: fastFinite(this.currentPitchMult, 1.0),
            isVocal: !!this.isVocal,
            spectralProfile: this.spectralProfile || {},
            currentGenre: currentGenre,
            noiseLevel: this.noiseLevel || {
              level: 0.5,
              white: 0.5,
              lowFreq: 0.5,
              midFreq: 0.5
            },
            wienerGain: fastFinite(this.wienerGain, 1.0),
            polyphonicPitches: Array.isArray(this.polyphonicPitches) ? this.polyphonicPitches : [],
            sampleRate: this.context?.sampleRate || 48000,
            fftSize: fftSize,
            maxBufferAge: 60000,
            defragmentThreshold: 0.75,
            qualityMode: this.qualityMode || 'high',
            cpuLoad: (typeof this.getCPULoad === 'function') ? this.getCPULoad() : 0.5,
            userFeedback: this.memoryManager?.get('userFeedback') || {},
            deviceInfo: {
              memory: deviceMemory,
              hardwareConcurrency: hardwareConcurrency
            },
            contextAnalysis: this.initializeContextAnalyzer ? this.initializeContextAnalyzer().analyze(this) : {},
            cpuLoadHistory: this.memoryManager?.get('cpuLoadHistory') || []
          }
        });
      }

      // Khởi tạo thực thể lắng nghe sự kiện nếu chưa tồn tại
      this.eventListeners = this.eventListeners || {};
      this.registerEvent = this.registerEvent || function(eventName, callback) {
        this.eventListeners[eventName] = this.eventListeners[eventName] || [];
        this.eventListeners[eventName].push(callback);
      };
      this.triggerEvent = this.triggerEvent || function(eventName, ...args) {
        const listeners = this.eventListeners[eventName] || [];
        for (let i = 0; i < listeners.length; i++) {
          listeners[i].apply(this, args);
        }
      };
      // =========================================================================
      // CỔNG TIẾP NHẬN THÔNG ĐIỆP REALTIME: ĐỒNG BỘ 100% CÔNG NGHỆ ZERO-COPY
      // =========================================================================
      this.worker.onmessage = (e) => {
        const {
          type,
          data
        } = e.data;
        if (!type || !data) return;
        const errorContext = {
          spectralProfile: this.spectralProfile,
          wienerGain: this.wienerGain,
          polyphonicPitches: this.polyphonicPitches,
          transientBoost: this.transientBoost,
          bufferTime: this.bufferTime,
          fadeTime: this.fadeTime,
          sampleRate: this.context?.sampleRate || 48000
        };
        switch (type) {
          case 'initDone':
            console.log('Worker initialized successfully:', data);
            this.triggerEvent('workerInitialized', data);
            break;
          case 'audioResult':
            // Kiểm tra và làm sạch dữ liệu cao độ nhận diện đa âm
            const validPitches = Array.isArray(data.polyphonicPitches) ? data.polyphonicPitches.filter(p => Number.isFinite(p.frequency) && p.confidence >= 0 && p.confidence <= 1) : this.polyphonicPitches;
            const validWienerGain = (Number.isFinite(data.wienerGain) && data.wienerGain >= 0 && data.wienerGain <= 2) ? data.wienerGain : this.wienerGain;
            const validNoiseLevel = data.noiseLevel && typeof data.noiseLevel === 'object' ? data.noiseLevel : {
              level: 0.5,
              white: 0.5,
              lowFreq: 0.5,
              midFreq: 0.5
            };
            // NÂNG CẤP CHỐT HẠ: Tiếp nhận các mảng phổ đã chuyển giao từ Transferable Objects an toàn
            this.fftData = data.fftData ?? this.fftData;
            this.shiftedData = data.shiftedData ?? this.shiftedData;
            // Đồng bộ các thuộc tính ma mị driven bởi não bộ Worker
            this.spectralProfile = data.spectralProfile ?? this.spectralProfile;
            this.tempoMemory = data.tempo ?? this.tempoMemory;
            this.currentGenre = data.genre ?? this.currentGenre;
            this.currentKey = data.key ?? this.currentKey;
            this.nextProcessingInterval = data.processingInterval ?? this.nextProcessingInterval;
            this.noiseLevel = validNoiseLevel;
            this.qualityPrediction = data.qualityPrediction ?? this.qualityPrediction;
            this.isVocal = data.isVocal !== undefined ? data.isVocal : this.isVocal;
            this.wienerGain = validWienerGain;
            this.polyphonicPitches = validPitches;
            this.transientBoost = data.autoEQ?.transientBoost ?? this.transientBoost;
            // Điều hòa tài nguyên: Chỉ cập nhật phần cứng AudioNode khi CPU cho phép (<80% tải)
            const currentCPU = (typeof this.getCPULoad === 'function') ? this.getCPULoad() : 0.5;
            if (currentCPU < 0.8) {
              if (data.spectralProfile || data.isVocal || data.genre || data.noiseLevel || data.wienerGain || data.polyphonicPitches) {
                this.updateBuffers();
              }
              if (data.autoEQ) {
                this.applyAutoEQ(data.autoEQ);
              }
            }
            this.adjustSoundProfileSmartly();
            break;
          case 'songStructure':
            if (data.songStructure && Array.isArray(data.songStructure.segments)) {
              this.memoryManager?.set('songStructure', data.songStructure, 'high');
              const checkCPU = (typeof this.getCPULoad === 'function') ? this.getCPULoad() : 0.5;
              if (checkCPU < 0.7) {
                this.adjustSoundProfileSmartly({
                  songStructure: data.songStructure
                });
              }
            }
            break;
          case 'formantParams':
            if (data.formantParams && Array.isArray(data.formantParams.filters)) {
              const ramp = this.rampTime || 0.1;
              const now = this.context.currentTime;
              data.formantParams.filters.forEach((filter, index) => {
                const filterNode = this[`formantFilter${index + 1}`];
                if (filterNode && Number.isFinite(filter.freq) && Number.isFinite(filter.gain) && Number.isFinite(filter.q)) {
                  filterNode.frequency.setTargetAtTime(filter.freq, now, ramp);
                  filterNode.gain.setTargetAtTime(filter.gain, now, ramp);
                  filterNode.Q.setTargetAtTime(filter.q, now, ramp);
                }
              });
              this.memoryManager?.set('formantParams', data.formantParams, 'normal');
            }
            break;
          case 'fftSettings':
            if (Number.isFinite(data.fftSize) && data.fftSize >= 256 && data.fftSize <= 32768) {
              this.setFFTSize(data.fftSize);
              this.memoryManager?.set('fftSize', data.fftSize, 'high');
            }
            break;
          case 'bufferFeedback':
            const feedbackCPU = (typeof this.getCPULoad === 'function') ? this.getCPULoad() : 0.5;
            if (feedbackCPU < 0.8 && data.suggestedParams) {
              const {
                bufferTime,
                fadeLength,
                activeTime
              } = data.suggestedParams;
              if (Number.isFinite(bufferTime) && Number.isFinite(fadeLength) && Number.isFinite(activeTime)) {
                this.adjustBufferParams({
                  bufferTime,
                  fadeLength,
                  activeTime
                });
                this.updateBuffers({
                  bufferTime,
                  fadeLength,
                  activeTime
                });
              }
            }
            break;
          case 'error':
            console.error('Worker Inner Error Logged:', data);
            // SỬA LỖI CHÍ MẠNG: Gọi trực tiếp hàm toàn cục thay vì qua phương thức 'this' không tồn tại
            if (typeof handleError === 'function') {
              handleError('AudioWorker encountered an error:', new Error(data), errorContext, 'high');
            }
            this.adjustSoundProfileSmartly();
            this.nextProcessingInterval = Math.min(this.nextProcessingInterval * 1.2, 5000);
            break;
          case 'overload':
            console.warn('Worker thread overloaded warning:', data);
            this.nextProcessingInterval = Math.min(this.nextProcessingInterval * 1.5, 3000);
            const overloadCPU = (typeof this.getCPULoad === 'function') ? this.getCPULoad() : 0.5;
            if (overloadCPU > 0.9 && this.worker) {
              this.worker.postMessage({
                type: 'pauseAnalysis'
              });
            }
            break;
          case 'skip':
            console.log('Worker analysis skipped optimization:', data);
            break;
          default:
            console.warn('Unknown message token received from Worker:', type);
        }
      };

      // =========================================================================
      // CHỐT CHẶN 2: Bảo vệ vòng lặp gửi tin định kỳ (Batch Update) giảm thiểu tài nguyên
      // =========================================================================
      if (this.feedbackInterval) clearInterval(this.feedbackInterval);
      const isLowMemory = navigator.deviceMemory < 4;
      this.feedbackInterval = setInterval(() => {
        // Nếu worker đã bị giải phóng hoặc hủy bỏ bởi mạch reset, đứng đợi an toàn, không bắn tin lỗi
        if (!this.worker) return; 

        const currentCPU = (typeof this.getCPULoad === 'function') ? this.getCPULoad() : 0.5;
        if (currentCPU > 0.9) return; // Không gửi tin nhắn định kỳ nếu CPU đang ngập tải render AV1
        
        this.worker.postMessage({
          type: 'batchUpdate',
          params: {
            userFeedback: this.memoryManager?.get('userFeedback') || {},
            contextAnalysis: this.initializeContextAnalyzer ? this.initializeContextAnalyzer().analyze(this) : {},
            cpuLoadHistory: this.memoryManager?.get('cpuLoadHistory') || []
          }
        });
      }, isLowMemory ? 6000 : 3000);

      // =========================================================================
      // CHỐT CHẶN 3: Bảo vệ sự kiện reset khi thay đổi bài hát
      // =========================================================================
      this.onSongChange = () => {
        if (this.worker && typeof this.worker.postMessage === 'function') {
          this.worker.postMessage({
            type: 'reset'
          });
        }
      };
      this.registerEvent('songChange', this.onSongChange);
    } catch (error) {
      if (typeof handleError === 'function') {
        handleError('Error initializing Web Worker Engine:', error, {
          workerSupport: !!window.Worker,
          sampleRate: this.context?.sampleRate || 48000
        }, 'high');
      }
    }
  };
  Jungle.prototype.resumeWorkerAnalysis = function() {
    if (this.worker) {
      this.worker.postMessage({
        type: 'resumeAnalysis'
      });
    }
  };
  Jungle.prototype.processAudio = async function(input, params = {}) {
    // 1. Kiểm tra worker trước khi gọi, không đợi lặp lại thừa thãi
    if (!this.worker) {
      await this.initializeWorker();
    }
    if (this.worker && input instanceof Float32Array) {
      // TỐI ƯU: Tạo bản copy để gửi sang worker, giữ lại buffer gốc cho Main Thread xử lý (tránh crash)
      // Việc này tốn ít CPU hơn nhiều so với việc để ứng dụng bị crash hoặc lag
      const dataForWorker = new Float32Array(input);
      this.worker.postMessage({
        type: "analyzeAudio",
        timeData: dataForWorker,
        sampleRate: params.sampleRate || this.context.sampleRate || 48000,
        bufferLength: dataForWorker.length,
        cpuLoad: this.getCPULoad ? this.getCPULoad() : 0.5,
        pitchMult: this.currentPitchMult || 1.0,
        devicePerf: params.devicePerf || (navigator.hardwareConcurrency >= 4 ? "high" : "medium"),
        audioProfile: this.currentGenre ? (this.currentGenre === "EDM" ? "bassHeavy" : this.currentGenre === "Rock" ? "rockMetal" : this.currentGenre === "Karaoke" ? "karaokeDynamic" : this.currentGenre === "Jazz" ? "warm" : "vocal") : "proNatural",
        params: {
          compressionThreshold: params.compressionThreshold,
          eqGains: params.eqGains,
          noiseGate: params.noiseGate,
          azimuth: params.azimuth,
          elevation: params.elevation,
          sourceVelocity: params.sourceVelocity,
          qualityMode: this.qualityMode || "high"
        }
      }, [dataForWorker.buffer]); // Transfer buffer của bản copy (An toàn tuyệt đối)
    } else if (!this.worker) {
      console.warn("Worker not initialized, skipping audio processing");
    }
  };
  Jungle.prototype.startAudioAnalysis = function() {
    if (!this._analyser) {
      this._analyser = this.context.createAnalyser();
      this._analyser.fftSize = navigator.hardwareConcurrency && navigator.hardwareConcurrency < 4 ? 1024 : 2048;
      this.outputGain.connect(this._analyser);
    }
    const devicePerf = navigator.hardwareConcurrency && navigator.hardwareConcurrency < 4 ? "medium" : "high";
    if (this.audioAnalysisInterval) {
      clearInterval(this.audioAnalysisInterval);
      this.audioAnalysisInterval = null;
    }
    const bufferLength = this._analyser.frequencyBinCount;
    // Buffer này giữ lại để dùng cho getFloatTimeDomainData
    const timeData = new Float32Array(bufferLength);
    const runAnalysis = () => {
      if (!this.isStarted) return;
      // Lấy dữ liệu vào buffer hiện tại
      this._analyser.getFloatTimeDomainData(timeData);
      if (this.worker) {
        try {
          // TỐI ƯU AN TOÀN: Copy buffer trước khi transfer để tránh detached buffer làm hỏng timeData cho frame sau
          const transferData = new Float32Array(timeData);
          const currentProfile = this.currentGenre ? (this.currentGenre === "EDM" ? "bassHeavy" : this.currentGenre === "Rock" ? "rockMetal" : this.currentGenre === "Karaoke" ? "karaokeDynamic" : this.currentGenre === "Jazz" ? "warm" : "vocal") : "proNatural";
          this.worker.postMessage({
            type: "analyzeAudio",
            timeData: transferData,
            sampleRate: this.context.sampleRate,
            bufferLength: bufferLength,
            cpuLoad: this.getCPULoad ? this.getCPULoad() : 0.5,
            pitchMult: this.currentPitchMult || 1,
            devicePerf: devicePerf,
            audioProfile: currentProfile
          }, [transferData.buffer]);
        } catch (error) {
          this.handleError?.("Error sending message to Worker:", error);
        }
      } else {
        // Chỉ khởi tạo worker nếu chưa có, tránh tạo worker dồn dập
        if (!this._initializingWorker) {
          this.initializeWorker();
        }
      }
      // Điều tốc thông minh
      let nextInterval = this.nextProcessingInterval || 1000;
      const cpuLoad = this.getCPULoad ? this.getCPULoad() : 0.5;
      const spectralComplexity = this.spectralProfile?.spectralFlatness || 0.5;
      // Logic điều tốc giữ nguyên nhưng đã sạch hơn
      if (devicePerf === "medium" || cpuLoad > 0.8) {
        nextInterval = Math.min(nextInterval * 2, 2000);
      } else if (spectralComplexity < 0.3) {
        nextInterval *= 1.2;
      }
      this.audioAnalysisInterval = setTimeout(runAnalysis, Math.round(nextInterval));
    };
    this.audioAnalysisInterval = setTimeout(runAnalysis, 100);
  };
  Jungle.prototype.adjustSoundProfileSmartly = function() {
    if (this.polyphonicPitches?.length > 0) {
      const avgConfidence = this.polyphonicPitches.reduce((sum, p) => sum + p.confidence, 0) / this.polyphonicPitches.length;
      this.transientBoost = avgConfidence > 0.5 ? 1.2 : 1.0;
      console.debug("Adjusted transientBoost:", this.transientBoost);
    }
    this.spectralProfile = this.spectralProfile || {
      subBass: 0.5,
      bass: 0.5,
      mid: 0.5,
      high: 0.5
    };
    this.currentGenre = this.currentGenre || "Pop";
    this.noiseLevel = this.noiseLevel || {
      level: 0,
      midFreq: 0.5
    };
    this.qualityPrediction = this.qualityPrediction || {
      recommendations: []
    };
    this.tempoMemory = this.tempoMemory || 120;
    this.currentKey = this.currentKey || "C";
    this.isVocal = this.isVocal || false;
    this.wienerGain = this.wienerGain || 1.0;
  };
  Jungle.prototype.applyAutoEQ = function(eqSettings, options = {
    isInitialStart: false
  }) {
    // Khai báo trước biến để bảo vệ khối catch không bị ReferenceError nếu có sự cố xảy ra sớm
    let songStructure = {
      section: 'unknown'
    };
    let spectralProfile = {};
    let limiterFactor = 0.95;
    let bassBoostFix = 0;
    let bassTransientBoost = 0;
    let midReduceFix = 0.95;
    let trebleReduceFix = 0.95;
    let clarityBoost = 0;
    let clarityFactor = 1.0;
    try {
      const currentTime = this.context.currentTime;
      const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
      // Validate AudioContext
      if (!this.context || !(this.context instanceof AudioContext) || this.context.state === 'closed') {
        console.warn('AutoEQ: Invalid or closed AudioContext');
        return;
      }
      // Loại bỏ hoàn toàn các biến định nghĩa trùng lặp ở đây để thừa hưởng hằng số toàn cục phía trên
      // Hàm tiện ích
      const ensureFinite = (value, defaultValue) => Number.isFinite(value) ? value : defaultValue;
      const clamp = (val, min, max) => Math.max(min, Math.min(max, val));
      // Lấy thông tin thiết bị và tối ưu hóa dựa trên cấu hình RAMP toàn cục
      const absMult = Math.abs(this.currentPitchMult || 0);
      const rampTime = ensureFinite(this.rampTime, DEFAULT_RAMP_TIME);
      const cpuLoad = this.getCPULoad ? ensureFinite(this.getCPULoad(), 0.5) : 0.5;
      const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
      const deviceAdaptFactor = Math.max(0.65, Math.min(1.0, 1.0 - (cpuLoad * 0.2) * (isLowPowerDevice ? 0.35 : 0.1)));
      // RMS và limiter
      const rms = ensureFinite(this.rms, 0.1);
      limiterFactor = (rms > 0.18 || (this.spectralProfile?.transientDensity > 0.8)) ? 0.65 : 0.95;
      // Lấy spectral profile và FFT analysis
      const fftAnalysis = this.getFFTAnalysis?.() || {};
      spectralProfile = {
        subBassEnergy: ensureFinite(fftAnalysis.subBassEnergy, 0.5),
        bassEnergy: ensureFinite(fftAnalysis.bassEnergy, 0.5),
        midEnergy: ensureFinite(fftAnalysis.midEnergy, 0.5),
        highMidEnergy: ensureFinite(fftAnalysis.highMidEnergy, 0.5),
        trebleEnergy: ensureFinite(fftAnalysis.trebleEnergy, 0.5),
        airEnergy: ensureFinite(fftAnalysis.airEnergy, 0.5),
        vocalEnergy: ensureFinite(fftAnalysis.vocalEnergy, 0.55),
        transientDensity: ensureFinite(fftAnalysis.transientDensity, 0.5),
        harmonicRatio: ensureFinite(fftAnalysis.harmonicRatio, 0.5),
        spectralComplexity: ensureFinite(fftAnalysis.spectralEntropy, 0.5),
        spectralFlux: ensureFinite(fftAnalysis.spectralFlux, 0.5)
      };
      songStructure = this.memoryManager?.get('lastStructure') || {
        section: 'unknown'
      };
      // ĐỒNG BỘ 1: Đổi cấu hình dự phòng từ smartStudio sang proNatural
      const profile = this.profile || 'proNatural';
      // Lấy userFeedback
      const feedbackList = this.memoryManager?.get('userFeedback') || [];
      const recentFeedback = feedbackList.find(f => f.timestamp > Date.now() - 60000 && f.semanticCategory);
      const isVocalFeedback = recentFeedback?.semanticCategory === 'vocal';
      // PRO: Lấy glider từ QuantumFormantOptimizerV2 pro
      const glider = this.lastGlider || {
        formantVariability: 50,
        grainJitter: 0.0,
        spectroAdapt: 1.0,
        multiBandWeights: {
          low: 1.0,
          mid: 1.0,
          high: 1.0
        }
      };
      const formantVariability = glider.formantVariability / 100;
      const grainJitterFactor = 1.0 + glider.grainJitter * 0.9;
      const spectroAdapt = ensureFinite(glider.spectroAdapt, 1.0);
      const spectralFluxPro = spectralProfile.spectralFlux * (1 + formantVariability * 0.5);
      // Tinh hoa: computeClarity 
      const computeClarity = (f) => {
        const clarityFactorMap = {
          'vocal': 1.25,
          'karaokeDynamic': 1.25,
          'proNatural': 1.2,
          'bright': 1.15
        };
        const cf = clarityFactorMap[profile] || 1.0;
        const vocalClarity = spectralProfile.vocalEnergy > 0.65 ? 1.15 : 0.95;
        let cb = Math.min(1.35, cf * vocalClarity * (1.0 + spectralFluxPro * 0.25) * spectroAdapt);
        cb *= (1 + formantVariability * 0.4);
        const bassResonanceMap = {
          'bassHeavy': 0.98,
          'vocal': 0.88,
          'warm': 0.92
        };
        const bassResonance = bassResonanceMap[profile] || 0.9;
        const bassClarity = Math.max(0.75, Math.min(1.25, 1.0 - (spectralProfile.bassEnergy * 0.25)));
        let bf = bassResonance * bassClarity * (1.0 - absMult * 0.08) * glider.multiBandWeights.low * grainJitterFactor;
        const transientSculptMap = {
          'rockMetal': 1.2,
          'bassHeavy': 1.1,
          'karaokeDynamic': 1.15
        };
        const transientSculpt = transientSculptMap[profile] || 0.95;
        let tf = Math.min(1.25, spectralProfile.transientDensity * transientSculpt * (1.0 - absMult * 0.12) * grainJitterFactor);
        if (cpuLoad > 0.8) tf *= 0.75;
        if (absMult > 0.5) tf *= 0.88;
        const spectralBalance = (spectralProfile.bassEnergy + spectralProfile.subBassEnergy) / (spectralProfile.midEnergy + spectralProfile.trebleEnergy + spectralProfile.airEnergy + 0.001);
        let spectralAdjust = spectralBalance > 1.2 ? 0.82 : spectralBalance < 0.8 ? 1.18 : 1.0;
        spectralAdjust *= spectroAdapt;
        const purityFilter = 1 / (1 + Math.pow(f / 1250, 2)) * cb;
        const maskingThreshold = Math.pow(10, -(spectralProfile.spectralComplexity || 0) / 18) * purityFilter * 1.3;
        const sectionEmotionMap = {
          'chorus': 1.25,
          'bridge': 1.18,
          'verse': 1.05
        };
        const sectionEmotion = sectionEmotionMap[songStructure.section] || 1.0;
        const timbreCurve = 0.00055 * Math.pow(f, 3) + 0.0055 * Math.pow(f, 2) + 0.055 * f + 1.0;
        let emotionalTimbre = sectionEmotion * timbreCurve * cb * (1 + formantVariability * 0.3);
        const pitchShiftImpact = absMult > 0.5 ? 0.88 : 1.0;
        return Math.max(0.7, Math.min(1.3, cb * bf * tf * spectralAdjust * maskingThreshold * emotionalTimbre * pitchShiftImpact * spectroAdapt));
      };
      const f = this.polyphonicPitches?.[0]?.frequency || 440;
      clarityFactor = computeClarity(f);
      clarityFactor *= (1 + formantVariability * 0.35);
      // Wiener và pitch adjustment
      const wienerThresholdAdjust = this.wienerGain < 0.8 ? -12 * (1 - this.wienerGain) : 0;
      const pitchAdjust = Math.min(6, absMult * 12) * deviceAdaptFactor;
      // Tự động cân bằng âm thanh với PureSonicClarityV3 pro
      if (this.currentPitchMult < 0 && absMult > 0.25) {
        bassBoostFix = 1.8 + absMult * 0.7 + (spectralProfile.bassEnergy < 0.5 ? 0.6 : 0) + (spectralProfile.midEnergy > 0.75 || spectralProfile.trebleEnergy > 0.75 ? 0.4 : 0);
        bassTransientBoost = absMult > 0.5 ? 0.4 : 0;
      }
      midReduceFix = spectralProfile.midEnergy > 0.75 ? 0.7 : 0.95;
      trebleReduceFix = spectralProfile.trebleEnergy > 0.75 ? 0.7 : 0.95;
      clarityBoost = (spectralProfile.midEnergy > 0.75 || spectralProfile.trebleEnergy > 0.75) && bassBoostFix > 2.0 ? 0.4 : 0;
      clarityBoost *= grainJitterFactor;
      // Tinh hoa: rampParam AN TOÀN (Node Integrity Guard)
      const bloomRampTime = options.isInitialStart ? 0.3 : rampTime * deviceAdaptFactor;
      const normalRampTime = rampTime * deviceAdaptFactor;
      const targetTimeBloom = currentTime + bloomRampTime;
      const targetTimeNormal = currentTime + normalRampTime;
      const rampParam = (param, value, useBloom = false) => {
        if (!param || typeof param.cancelScheduledValues !== 'function') return;
        const targetTime = useBloom ? targetTimeBloom : targetTimeNormal;
        param.cancelScheduledValues(currentTime);
        param.linearRampToValueAtTime(clamp(ensureFinite(value, 0), -40, 40), targetTime);
      };
      // Dynamic Q Adapt
      const dynamicQAdapt = (baseQ, absMult, variability) => Math.max(0.6, baseQ - absMult * 0.18 - variability * 0.15 * spectroAdapt);
      if (this.currentPitchMult < 0 && absMult > 0.25) {
        if (this.subBassFilter?.Q) rampParam(this.subBassFilter.Q, dynamicQAdapt(0.65, absMult, formantVariability));
        if (this.lowShelfFilter?.Q) rampParam(this.lowShelfFilter.Q, dynamicQAdapt(0.8, absMult, formantVariability));
      }
      // Mạch Compressor cấu hình dựa trên giá trị gốc đồng bộ từ hệ thống hằng số lớn
      if (this.compressor?.threshold && this.compressor?.ratio && this.compressor?.attack && this.compressor?.release) {
        this.compressor.threshold.cancelScheduledValues(currentTime);
        this.compressor.ratio.cancelScheduledValues(currentTime);
        this.compressor.attack.cancelScheduledValues(currentTime);
        this.compressor.release.cancelScheduledValues(currentTime);
        this.compressor.threshold.setValueAtTime(this.compressor.threshold.value, currentTime);
        this.compressor.ratio.setValueAtTime(this.compressor.ratio.value, currentTime);
        this.compressor.attack.setValueAtTime(this.compressor.attack.value, currentTime);
        this.compressor.release.setValueAtTime(this.compressor.release.value, currentTime);
        let thresholdPro = ensureFinite(eqSettings.clarityGain, 0) < 1.8 ? -20 + wienerThresholdAdjust - pitchAdjust : -16 + wienerThresholdAdjust - pitchAdjust;
        thresholdPro *= spectroAdapt;
        rampParam(this.compressor.threshold, thresholdPro);
        rampParam(this.compressor.ratio, 5.5 + absMult * 1.2 * grainJitterFactor);
        rampParam(this.compressor.attack, spectralProfile.bassEnergy < 0.5 ? 0.0018 : DEFAULT_COMPRESSOR_ATTACK);
        rampParam(this.compressor.release, spectralProfile.bassEnergy < 0.5 ? DEFAULT_COMPRESSOR_RELEASE * 1.15 : DEFAULT_COMPRESSOR_RELEASE);
      }
      // Transient boost adjustment PRO đồng bộ hằng số gốc
      let transientBoostAdjust = Math.min(ensureFinite(eqSettings.transientBoost, DEFAULT_TRANSIENT_BOOST) * 1.6, 3.2);
      if (spectralProfile.transientDensity > 0.6 || spectralProfile.spectralFlux > 0.65 || profile === 'rockMetal' || profile === 'vocal') {
        transientBoostAdjust *= 1.25;
      }
      // ĐỒNG BỘ 2: Gộp thêm proNatural vào mạch tính toán transient nhịp điệu bài hát
      if (profile === 'bright' || profile === 'smartStudio' || profile === 'proNatural') {
        transientBoostAdjust *= 1.05;
      }
      transientBoostAdjust *= clarityFactor * grainJitterFactor;
      // Harmonic boost adjustment PRO
      let harmonicBoost = spectralProfile.harmonicRatio > 0.6 && (profile === 'warm' || profile === 'jazz') ? 1.4 : 1.0;
      if (isVocalFeedback) {
        harmonicBoost *= 1.05;
      }
      harmonicBoost *= (1 + formantVariability * 0.25);
      // EQ filter settings với PureSonicClarityV3 pro
      rampParam(this.subBassFilter?.gain, Math.min((ensureFinite(eqSettings.subBassGain, 3) + (profile === 'bassHeavy' ? 1.8 : 0) + (spectralProfile.subBassEnergy > 0.7 ? 0.7 : 0) + bassBoostFix) * limiterFactor * clarityFactor * glider.multiBandWeights.low, 3.5));
      rampParam(this.lowShelfGain?.gain, Math.min((ensureFinite(eqSettings.bassGain, 4.5) + 1.8 + bassBoostFix * 0.5 + bassTransientBoost) * limiterFactor * clarityFactor * glider.multiBandWeights.low, 3.5));
      rampParam(this.subMidFilter?.gain, Math.min((ensureFinite(eqSettings.subMidGain, 0) + 2.8 + harmonicBoost + (spectralProfile.spectralComplexity > 0.7 ? 0.7 : 0) + clarityBoost) * limiterFactor * midReduceFix * clarityFactor * glider.multiBandWeights.mid, 3.5));
      rampParam(this.midBassFilter?.gain, Math.min((ensureFinite(eqSettings.midLowGain, 0) + 3.8 + (profile === 'bassHeavy' ? 1.0 : 0) + clarityBoost) * limiterFactor * midReduceFix * clarityFactor * glider.multiBandWeights.mid, 3.5));
      rampParam(this.midShelfGain?.gain, Math.min((ensureFinite(eqSettings.midHighGain, 4) + 2.2 + transientBoostAdjust + clarityBoost) * limiterFactor * midReduceFix * clarityFactor * glider.multiBandWeights.mid, 3.5));
      rampParam(this.highShelfGain?.gain, Math.min((ensureFinite(eqSettings.highGain, 4.5) + 1.2 + transientBoostAdjust + (profile === 'bright' ? 0.7 : 0) + clarityBoost) * limiterFactor * trebleReduceFix * clarityFactor * glider.multiBandWeights.high, 3.5), options.isInitialStart);
      // ĐỒNG BỘ 3 & 4: Ép thêm điều kiện proNatural vào dải siêu cao tần (SubTreble và Air)
      rampParam(this.subTrebleFilter?.gain, Math.min((ensureFinite(eqSettings.subTrebleGain, 0) + 2.8 + transientBoostAdjust + ((profile === 'smartStudio' || profile === 'proNatural') ? 0.7 : 0) + clarityBoost) * limiterFactor * trebleReduceFix * clarityFactor * glider.multiBandWeights.high, 3.5), options.isInitialStart);
      rampParam(this.airFilter?.gain, Math.min((ensureFinite(eqSettings.airGain, 0) + 2.8 + ((profile === 'smartStudio' || profile === 'proNatural') ? 1.0 : 0) + clarityBoost) * limiterFactor * trebleReduceFix * clarityFactor * glider.multiBandWeights.high, 3.5), options.isInitialStart);
      // Formant filter settings PRO đồng bộ hoàn toàn với dải tần mặc định lớn
      const formantFreqAdjust = songStructure.section === 'chorus' ? 1.1 : songStructure.section === 'bridge' ? 1.05 : songStructure.section === 'verse' ? 1.0 : 0.95;
      let formantFreqPro = formantFreqAdjust * (1 + formantVariability * (absMult > 0.8 ? 0.12 : 0.08));
      if (this.formantFilter1?.frequency && this.formantFilter1?.gain) {
        rampParam(this.formantFilter1.frequency, ensureFinite(eqSettings.formantF1Freq, DEFAULT_FORMANT_F1_FREQ) * formantFreqPro);
        rampParam(this.formantFilter1.gain, Math.min((ensureFinite(eqSettings.formantGain, DEFAULT_FORMANT_GAIN) + (profile === 'vocal' || isVocalFeedback ? 1.6 : 0)) * limiterFactor * clarityFactor * spectroAdapt, 3.5));
      }
      if (this.formantFilter2?.frequency && this.formantFilter2?.gain) {
        rampParam(this.formantFilter2.frequency, ensureFinite(eqSettings.formantF2Freq, DEFAULT_FORMANT_F2_FREQ) * formantFreqPro);
        rampParam(this.formantFilter2.gain, Math.min((ensureFinite(eqSettings.formantGain, DEFAULT_FORMANT_GAIN) + (profile === 'vocal' || isVocalFeedback ? 1.6 : 0)) * limiterFactor * clarityFactor * spectroAdapt, 3.5));
      }
      if (this.formantFilter3?.frequency && this.formantFilter3?.gain) {
        rampParam(this.formantFilter3.frequency, ensureFinite(eqSettings.formantF3Freq, DEFAULT_FORMANT_F3_FREQ) * formantFreqPro);
        rampParam(this.formantFilter3.gain, Math.min((ensureFinite(eqSettings.formantGain, DEFAULT_FORMANT_GAIN) + (profile === 'vocal' || isVocalFeedback ? 1.6 : 0)) * limiterFactor * clarityFactor * spectroAdapt, 3.5));
      }
      // Lưu EQ settings và spectralBalance PRO vào bộ nhớ đệm
      if (this.memoryManager && spectralProfile.spectralFlux > 0.03) {
        const cacheKey = `eqSettings_${this.contextId}_${profile}_${songStructure.section}`;
        const cacheData = {
          data: {
            ...eqSettings,
            timestamp: Date.now(),
            profile,
            songStructure,
            spectralProfile,
            spectralBalance: (spectralProfile.bassEnergy + spectralProfile.subBassEnergy) / (spectralProfile.midEnergy + spectralProfile.trebleEnergy + spectralProfile.airEnergy + 0.001),
            clarityFactor,
            gliderParams: {
              formantVariability: glider.formantVariability,
              grainJitter: glider.grainJitter,
              spectroAdapt: glider.spectroAdapt
            }
          },
          expiry: Date.now() + (isLowPowerDevice && cpuLoad > 0.9 ? 12000 : 20000),
          priority: 'high'
        };
        this.memoryManager.set(cacheKey, cacheData, 'high');
        if (Math.random() > 0.8) {
          this.memoryManager.pruneCache(this.memoryManager.getDynamicMaxSize?.() || 100);
        }
      }
      // Debug logging PRO
      if (isDebug) {
        console.debug('Applied Auto-EQ with PureSonicClarityV3 pro:', {
          eqSettings,
          transientBoostAdjust,
          harmonicBoost,
          wienerThresholdAdjust,
          pitchAdjust,
          spectralProfile,
          songStructure,
          profile,
          cpuLoad,
          isLowPowerDevice,
          isVocalFeedback,
          bassBoostFix,
          bassTransientBoost,
          midReduceFix,
          trebleReduceFix,
          clarityBoost,
          clarityFactor,
          limiterFactor,
          deviceAdaptFactor,
          spectralFluxPro,
          isInitialStart: options.isInitialStart
        });
      }
    } catch (error) {
      console.error('Error applying auto-EQ with PureSonicClarityV3 pro:', error, {
        eqSettings,
        wienerGain: this.wienerGain,
        transientBoost: this.transientBoost,
        profile: this.profile,
        songStructure,
        spectralProfile,
        limiterFactor,
        bassBoostFix,
        bassTransientBoost,
        midReduceFix,
        trebleReduceFix,
        clarityBoost,
        clarityFactor
      });
    }
  };
  Jungle.prototype.start = function() {
    if (this.isStarted) return Promise.resolve();
    return this.ensureAudioContext().then(() => {
      try {
        const currentTime = this.context.currentTime;
        const cpuLoad = this.getCPULoad ? ensureFinite(this.getCPULoad(), 0.5) : 0.5;
        const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
        // 🪐 ĐỒNG BỘ 1: Đổi cấu hình mặc định khởi động sang proNatural cho mộc tuyệt đối
        const profile = this.profile || 'proNatural';
        const songStructure = this.memoryManager?.get('lastStructure') || {
          section: 'unknown'
        };
        // Kiểm tra các node – tinh hoa gom nhóm + rõ index lỗi
        const nodes = [this.mod1, this.mod2, this.mod3, this.mod4, this.fade1, this.fade2];
        for (let i = 0; i < nodes.length; i++) {
          if (!nodes[i] || typeof nodes[i].start !== 'function') {
            throw new Error(`Audio node at index ${i} is not initialized or missing start()`);
          }
        }
        // Dynamic Start Timing
        const startDelay = isLowPowerDevice && cpuLoad > 0.9 ? 0.030 : 0.050;
        const bufferTime = ensureFinite(this.bufferTime, DEFAULT_BUFFER_TIME);
        const fadeTime = ensureFinite(this.fadeTime, DEFAULT_FADE_TIME);
        const structureAdjust = songStructure.section === 'chorus' ? 1.1 : songStructure.section === 'bridge' ? 1.05 : 1.0;
        const t = currentTime + startDelay * structureAdjust;
        const t2 = t + bufferTime - fadeTime;
        // Khởi động các node phần cứng
        this.mod1.start(t);
        this.mod2.start(t2);
        this.mod3.start(t);
        this.mod4.start(t2);
        this.fade1.start(t);
        this.fade2.start(t2);
        // Đặt trạng thái khởi động
        this.isStarted = true;
        // Khởi tạo worker và phân tích âm thanh
        this.initializeWorker();
        // 🪐 ĐỒNG BỘ 2: Ép proNatural nhận cấu hình FFT_SIZE chuẩn studio ngay từ vạch xuất phát
        if (profile === 'bright' || profile === 'proNatural' || profile === 'vocal') {
          this.setFFTSize(DEFAULT_FFT_SIZE);
        }
        this.startAudioAnalysis();
        // Tinh hoa: applyAutoEQ với isInitialStart → Blooming Effect thần thánh
        if (this.autoEQSettings) {
          this.applyAutoEQ(this.autoEQSettings, {
            isInitialStart: true
          });
        }
        // Reset entanglement state
        if (this.worker) {
          this.worker.postMessage({
            type: 'resetEntanglement'
          });
        }
        // Lưu trạng thái khởi động vào memoryManager
        if (this.memoryManager) {
          const cacheKey = `startState_${this.contextId}_${profile}`;
          const cacheData = {
            data: {
              isStarted: true,
              timestamp: Date.now(),
              profile,
              songStructure
            },
            expiry: Date.now() + (isLowPowerDevice ? 30000 : 60000),
            priority: 'high'
          };
          this.memoryManager.set(cacheKey, cacheData, 'high');
          // Tinh hoa random prune nhẹ main thread
          if (Math.random() > 0.8) {
            this.memoryManager.pruneCache(this.memoryManager.getDynamicMaxSize?.() || 100);
          }
        }
        // Debug logging
        const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
        if (isDebug) {
          console.debug('Jungle started with Hi-Fi Baseline:', {
            startTime: t,
            fadeTime: t2,
            bufferTime,
            cpuLoad,
            isLowPowerDevice,
            profile,
            songStructure,
            fftSize: this._analyser?.fftSize || DEFAULT_FFT_SIZE
          });
        }
      } catch (error) {
        this.isStarted = false;
        handleError('Error starting Jungle nodes:', error, {
          profile: this.profile,
          songStructure,
          cpuLoad,
          isLowPowerDevice
        }, 'high', {
          memoryManager: this.memoryManager
        });
        throw error;
      }
    });
  };
  // HẰNG SỐ TĨNH (đưa ra ngoài hàm để giảm GC)
  const STATIC_PROFILE_CONFIGS = {
    'warm': {
      bassReduction: 0.65,
      clarityBoost: 0.85,
      instrumentFocus: 1.1,
      transientSculpt: 0.85,
      melodySynthesis: 1.1
    },
    'bright': {
      bassReduction: 0.5,
      clarityBoost: 1.15,
      instrumentFocus: 1.2,
      transientSculpt: 1.1,
      melodySynthesis: 1.2
    },
    'bassHeavy': {
      bassReduction: 0.6,
      clarityBoost: 0.8,
      instrumentFocus: 1.0,
      transientSculpt: 1.1,
      melodySynthesis: 1.0
    },
    'vocal': {
      bassReduction: 0.4,
      clarityBoost: 1.25,
      instrumentFocus: 1.3,
      transientSculpt: 0.95,
      melodySynthesis: 1.3
    },
    'proNatural': {
      bassReduction: 0.5,
      clarityBoost: 1.1,
      instrumentFocus: 1.1,
      transientSculpt: 0.85,
      melodySynthesis: 1.35
    },
    'karaokeDynamic': {
      bassReduction: 0.4,
      clarityBoost: 1.25,
      instrumentFocus: 1.4,
      transientSculpt: 1.1,
      melodySynthesis: 1.35
    },
    'rockMetal': {
      bassReduction: 0.5,
      clarityBoost: 1.0,
      instrumentFocus: 1.25,
      transientSculpt: 1.2,
      melodySynthesis: 1.0
    },
    'smartStudio': {
      bassReduction: 0.45,
      clarityBoost: 1.1,
      instrumentFocus: 1.2,
      transientSculpt: 1.1,
      melodySynthesis: 1.25
    },
    'popStudio': {
      bassReduction: 0.5,
      clarityBoost: 1.3,
      instrumentFocus: 1.3,
      transientSculpt: 1.1,
      melodySynthesis: 1.25
    }
  };
  // =================================================================
  // === PHẦN 1: KIẾN TRÚC TĨNH ZERO-GC & MÔ HÌNH MẶT NẠ THÍNH GIÁC AI ===
  // =================================================================
  Jungle.prototype.applyVitamin = function(profileName, pitchMult, absPitchMult, cosmicEnhance, options) {
    try {
      // CHỐT CHẶN AN TOÀN TOÀN DIỆN: Kiểm tra AudioContext và sự sẵn sàng của kiến trúc Node tín hiệu
      if (!this.context || !this.lowShelfGain || !this.subMidFilter || !this.midShelfGain || !this.highMidFilter || !this.subTrebleFilter || !this.airFilter) {
        console.warn('AudioContext hoặc kiến trúc Node tín hiệu chưa sẵn sàng');
        return;
      }
      const currentTime = this.context.currentTime;
      const rampTime = this.rampTime || 0.1;
      const minFadeLength = 512;
      // CPU-Load Adaptability Factor tĩnh
      const cpuLoad = typeof this.getCPULoad === 'function' ? this.getCPULoad() : 0.5;
      const crossFadeTime = Math.max(minFadeLength / this.context.sampleRate, cpuLoad > 0.9 ? 0.06 : 0.08);
      // === HÀM BẢO VỆ BIÊN ĐỘ AN TOÀN TUYỆT ĐỐI CHỐNG KHÓA PHA CƠ HỌC ===
      const ensureFinite = (value, defaultValue) => Number.isFinite(value) ? value : defaultValue;
      const clamp = (val, min, max) => Math.max(min, Math.min(max, val));
      // Bộ điều phối làm mịn dải tần tích hợp Dirty Checking (Không gọi hủy lệnh vô tội vạ làm lệch pha)
      const safeRamp = (param, value, rampDuration) => {
        if (!param || typeof param.linearRampToValueAtTime !== 'function') return;
        const safeValue = clamp(ensureFinite(value, 0), -40, 40);
        if (Math.abs(param.value - safeValue) > 0.001) {
          param.cancelScheduledValues(currentTime);
          param.setValueAtTime(param.value, currentTime);
          param.linearRampToValueAtTime(safeValue, currentTime + (rampDuration || 0.1));
        }
      };
      // === TRÍCH XUẤT TRẠNG THÁI TRƯỚC DƯỚI DẠNG BIẾN SỐ NGUYÊN BẢN (ZERO ALLOCATION) ===
      const prevLowShelfGain = this.lowShelfGain?.gain?.value ?? 0;
      const prevSubMidGain = this.subMidFilter?.gain?.value ?? 0;
      const prevMidShelfGain = this.midShelfGain?.gain?.value ?? 0;
      const prevHighMidGain = this.highMidFilter?.gain?.value ?? 0;
      const prevSubTrebleGain = this.subTrebleFilter?.gain?.value ?? 0;
      // === GIẢI PHÁP ZERO-GC: TRÍCH XUẤT PHỔ THÍCH NGHI KHÔNG TẠO OBJECT RÁC ===
      const sProfile = this.spectralProfile;
      const subBassVal = (sProfile && Number.isFinite(sProfile.subBass)) ? Math.max(0, Math.min(1, sProfile.subBass)) : 0.5;
      const bassVal = (sProfile && Number.isFinite(sProfile.bass)) ? Math.max(0, Math.min(1, sProfile.bass)) : 0.5;
      const subMidVal = (sProfile && Number.isFinite(sProfile.subMid)) ? Math.max(0, Math.min(1, sProfile.subMid)) : 0.5;
      const midLowVal = (sProfile && Number.isFinite(sProfile.midLow)) ? Math.max(0, Math.min(1, sProfile.midLow)) : 0.6;
      const midHighVal = (sProfile && Number.isFinite(sProfile.midHigh)) ? Math.max(0, Math.min(1, sProfile.midHigh)) : 0.6;
      const highVal = (sProfile && Number.isFinite(sProfile.high)) ? Math.max(0, Math.min(1, sProfile.high)) : 0.5;
      const subTrebleVal = (sProfile && Number.isFinite(sProfile.subTreble)) ? Math.max(0, Math.min(1, sProfile.subTreble)) : 0.5;
      const airVal = (sProfile && Number.isFinite(sProfile.air)) ? Math.max(0, Math.min(1, sProfile.air)) : 0.5;
      const vocalPresenceVal = (sProfile && Number.isFinite(sProfile.vocalPresence)) ? Math.max(0, Math.min(1, sProfile.vocalPresence)) : 0.75;
      const transientEnergyVal = (sProfile && Number.isFinite(sProfile.transientEnergy)) ? Math.max(0, Math.min(1, sProfile.transientEnergy)) : 0.5;
      const instrumentPresenceVal = (sProfile && Number.isFinite(sProfile.instrumentPresence)) ? Math.max(0, Math.min(1, sProfile.instrumentPresence)) : 0.5;
      const harmonicRichnessVal = (sProfile && Number.isFinite(sProfile.harmonicRichness)) ? Math.max(0, Math.min(1, sProfile.harmonicRichness)) : 0.5;
      const spectralEntropyVal = (sProfile && Number.isFinite(sProfile.spectralEntropy)) ? Math.max(0, Math.min(1, sProfile.spectralEntropy)) : 0.5;
      if (!sProfile) {
        console.warn('spectralProfile chưa được định nghĩa trong applyVitamin, dùng cấu trúc tĩnh mặc định');
      }
      // Trích xuất tham số điều khiển tùy biến người dùng an toàn
      const userFeedback = (options && options.userFeedback) ? options.userFeedback : {};
      // Chuẩn hóa biến đầu vào cao cấp Chống tràn sai số tần số
      const validatedPitchMult = Number.isFinite(pitchMult) ? pitchMult : 0;
      const validatedAbsPitchMult = Number.isFinite(absPitchMult) ? Math.max(0, absPitchMult) : Math.abs(validatedPitchMult);
      const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
      const deviceAdaptFactor = Math.max(0.65, Math.min(1.0, 1.0 - (cpuLoad * 0.2) * (isLowPowerDevice ? 0.35 : 0.1)));
      // Công thức cân bằng mật độ năng lượng phổ nguyên bản
      const spectralBalance = (subBassVal + bassVal) / (midLowVal + midHighVal + subTrebleVal + airVal + 0.001);
      const profileChangeMagnitude = this.lastProfileName !== profileName ? 1.0 : Math.min(validatedAbsPitchMult * 0.5, 0.5);
      const adjustedRampTime = rampTime * (1 + profileChangeMagnitude * 0.3) * deviceAdaptFactor;
      // Đọc trực tiếp dữ liệu lưới phân tích thời gian thực không qua ánh xạ trung gian
      const fftAnalysis = this._analyser ? this.getFFTAnalysis() : null;
      const isInstrumentHeavy = (fftAnalysis && fftAnalysis.instrumentEnergy > 0.6) || instrumentPresenceVal > 0.6;
      const isVocalHeavy = this.isVocal || vocalPresenceVal > 0.65;
      const highFreqEnergy = (fftAnalysis && fftAnalysis.highFreqEnergy) ? fftAnalysis.highFreqEnergy : airVal;
      const harmonicRichness = (fftAnalysis && fftAnalysis.harmonicRichness) ? fftAnalysis.harmonicRichness : harmonicRichnessVal;
      const subBassEnergy = (fftAnalysis && fftAnalysis.subBassEnergy) ? fftAnalysis.subBassEnergy : subBassVal;
      // Mạch nhận diện thiết bị đầu ra để bù trừ đáp tuyến bảo vệ thính giác
      const isHeadphone = this.isHeadphoneModeEnabled || (navigator.mediaDevices && typeof navigator.mediaDevices.enumerateDevices === 'function' ? this.checkOutputDevice() : false);
      const headphoneTrebleReduction = isHeadphone ? 0.82 : 1.0;
      // === THAY THẾ CHUỖI MAP KHỞI TẠO BẰNG TOÁN TỬ SWITCH TRỰC TIẾP (ZERO ALLOCATION / RAM TỐI ƯU ĐỘC LẬP) ===
      let genreBoost = 1.0;
      switch (this.currentGenre) {
        case 'EDM':
        case 'Drum & Bass':
          genreBoost = 1.2;
          break;
        case 'Hip-Hop':
          genreBoost = 1.1;
          break;
        case 'Pop':
          genreBoost = 1.0;
          break;
        case 'Bolero':
          genreBoost = 0.9;
          break;
        case 'Classical/Jazz':
          genreBoost = 0.85;
          break;
        case 'Rock/Metal':
          genreBoost = 1.15;
          break;
        default:
          genreBoost = 1.0;
          break;
      }
      // Nạp dữ liệu cấu hình hệ thống Glider nguyên bản bảo toàn dải động
      const gliderFormantVariability = this.lastGlider ? (this.lastGlider.formantVariability || 50) : 50;
      const gliderGrainJitter = this.lastGlider ? (this.lastGlider.grainJitter || 0.0) : 0.0;
      const gliderSpectroAdapt = this.lastGlider ? (this.lastGlider.spectroAdapt || 1.0) : 1.0;
      const gliderWeightLow = this.lastGlider?.multiBandWeights ? (this.lastGlider.multiBandWeights.low ?? 1.0) : 1.0;
      const gliderWeightMid = this.lastGlider?.multiBandWeights ? (this.lastGlider.multiBandWeights.mid ?? 1.0) : 1.0;
      const gliderWeightHigh = this.lastGlider?.multiBandWeights ? (this.lastGlider.multiBandWeights.high ?? 1.0) : 1.0;
      const formantVariability = gliderFormantVariability / 100;
      const grainJitterFactor = 1.0 + gliderGrainJitter * 1.0;
      const spectroAdapt = gliderSpectroAdapt || 1.0;
      const spectralFluxPro = ((fftAnalysis && fftAnalysis.spectralFlux) ? fftAnalysis.spectralFlux : 0.5) * (1 + formantVariability * 0.6);
      // Tính toán ma trận tỉ lệ Formant thông minh PRO
      const vitConfigFormantScaleBase = 1.0 + validatedPitchMult * 0.008;
      const vitConfigFormantScale = Math.max(0.85, Math.min(1.15, vitConfigFormantScaleBase * (1 + formantVariability * 0.25)));
      const vitConfigHarmonicBoost = profileName === 'bassHeavy' ? 1.15 : (profileName === 'vocal' ? 1.0 : 1.1);
      const vitConfigClarityBoost = (profileName === 'vocal' || profileName === 'karaokeDynamic') ? 1.25 : 1.0;
      const vitConfigMelodySynthesisFactor = (profileName === 'proNatural' || profileName === 'karaokeDynamic') ? 1.3 : 1.1;
      const vitConfigPitchShiftFactor = validatedAbsPitchMult > 0.5 ? 0.9 : 1.0;
      const vitConfigPhaseLockFactor = this.qualityMode === 'high' ? 1.1 : 0.9;
      const vitConfigEmotionalVector = profileName === 'warm' ? 0.85 : (profileName === 'rockMetal' ? 1.1 : 1.0);
      // === KHỐI TOÁN HỌC INLINE VITAMIN-ENHANCE CHÂN THỰC (TRIỆT TIÊU TOÀN BỘ CLOSURE FUNCTION GÂY LÃNG PHÍ BỘ NHỚ) ===
      const fundamental = isVocalHeavy ? 560 : 440;
      const emotionalSection = profileName === 'warm' ? 1 : (profileName === 'rockMetal' ? 2 : 0); // 1: calm, 2: aggressive, 0: neutral
      // 1. Thuật toán phân rã chuỗi hài Melody Factor không sinh rác mảng
      const melodySynthesis = vitConfigMelodySynthesisFactor * (1 + formantVariability * 0.5);
      let melodyFactor = 0;
      const harmonicOrder = cpuLoad > 0.8 ? 3 : 8;
      for (let i = 1; i <= harmonicOrder; i++) {
        const harmonicFreq = fundamental * i * (1 + validatedPitchMult * 0.005 * spectroAdapt);
        const wavelet = Math.exp(-Math.pow(harmonicFreq / 120, 2) / 0.18) * Math.cos(6.283185307179586 * harmonicFreq);
        melodyFactor += wavelet * (1 / (i * 1.05)) * melodySynthesis * grainJitterFactor;
      }
      melodyFactor = Math.max(0.75, Math.min(1.25, melodyFactor));
      // 2. Thuật toán mô phỏng năng lượng dải trầm Quantum Bass vật lý tĩnh
      const sigma = profileName === 'bassHeavy' ? 0.4 : (profileName === 'vocal' ? 0.25 : 0.3);
      let quantumBass = 0;
      for (let i = 1; i <= harmonicOrder; i++) {
        const waveletCoeff = Math.exp(-Math.pow(fundamental / 90, 2) / (2 * sigma * sigma)) * Math.cos(6.283185307179586 * fundamental * i);
        const harmonicSeries = Math.sin(6.283185307179586 * fundamental * i * i) / (i * 1.1);
        quantumBass += waveletCoeff * harmonicSeries * vitConfigHarmonicBoost * gliderWeightLow;
      }
      quantumBass = Math.max(0.75, Math.min(1.25, quantumBass * grainJitterFactor));
      // 3. Đo đạc độ bện quyện Entanglement trung âm nguyên bản (Vòng lặp unrolled hoàn toàn - Bỏ mảng rác)
      const vocalPresenceProfileFactor = profileName === 'vocal' ? 1.1 : (profileName === 'warm' ? 0.9 : 0.85);
      const vocalFormant = (180 * vocalPresenceProfileFactor * vitConfigClarityBoost * spectroAdapt) + (2200 * vocalPresenceProfileFactor * vitConfigClarityBoost * spectroAdapt);
      let midGainTmp = midHighVal > 0.65 ? 0.6 : 0.5;
      let trebleQTmp = airVal > 0.65 ? 0.55 : 0.45;
      if (bassVal > 0.65) {
        midGainTmp *= 0.85;
        trebleQTmp *= 0.85;
      }
      let entanglement = Math.sqrt(Math.abs(vocalFormant * midGainTmp * trebleQTmp * gliderWeightMid));
      entanglement = Math.max(0.75, Math.min(1.25, entanglement * (1 + formantVariability * 0.35)));
      // 4. MÔ HÌNH MẶT NẠ THÍNH GIÁC AI (Perceptual Masking Model) - Tự động làm mịn dải Air tự nhiên, nắn dải Mid quyện chặt bài nhạc
      const purityFilter = 1 / (1 + Math.pow(fundamental / 1350, 2)) * vitConfigClarityBoost * spectroAdapt;
      const maskingThreshold = Math.pow(10, -spectralEntropyVal / 17) * purityFilter * 1.25;
      const phaseDiff = fftAnalysis ? Math.atan2(fftAnalysis.imag || 0, fftAnalysis.real || 1) : 0;
      const phaseCoherence = Math.cos(phaseDiff) * vitConfigPhaseLockFactor * 1.3 * grainJitterFactor;
      const sculptFactor = profileName === 'rockMetal' ? 1.3 : (profileName === 'bassHeavy' ? 1.1 : 0.85);
      let transientSculpt = transientEnergyVal * sculptFactor * vitConfigClarityBoost * grainJitterFactor;
      if (cpuLoad > 0.8) transientSculpt *= 0.7;
      if (transientEnergyVal > 0.65) transientSculpt *= 0.82;
      if (validatedAbsPitchMult > 0.5) transientSculpt *= 0.88;
      const toneAlignment = profileName === 'karaokeDynamic' ? 1.2 : (profileName === 'proNatural' ? 1.1 : 1.0);
      const masterFormant = vitConfigFormantScale * (1 + validatedPitchMult * 0.01) * toneAlignment * (1 - formantVariability * (validatedPitchMult > 0 ? 0.65 : 0.25));
      const emotionalVector = emotionalSection === 1 ? 0.85 : (emotionalSection === 2 ? 1.1 : 1.0);
      // Đọc năng lượng tĩnh trực tiếp trên instance, triệt tiêu việc ghi đè rác vào memoryManager liên tục
      const spectralEnergy = fftAnalysis ? Math.pow(Math.abs(fftAnalysis.energy || 0.5), 2) : 0.25;
      const prevEnergy = this._prevEnergyContextContext || spectralEnergy;
      const spectralFluxAt = Math.abs(spectralEnergy - prevEnergy) / (spectralEnergy + 0.001);
      this._prevEnergyContextContext = spectralEnergy;
      const spectralAttention = Math.exp(spectralEnergy * spectralFluxAt * 0.85) / (1 + Math.exp(spectralEnergy * spectralFluxAt * 0.85)) * spectralFluxPro;
      const timbreCurve = (0.00065 * Math.pow(fundamental, 3)) + (0.0065 * Math.pow(fundamental, 2)) + (0.065 * fundamental) + 1.1;
      const emotionTimbre = emotionalVector * timbreCurve * vitConfigMelodySynthesisFactor * (1 + formantVariability * 0.35);
      // LUẬT BẢO TOÀN ÁP SUẤT SPL PHI TUYẾN (Math.tanh Soft Limiter) bảo vệ màng loa dải treble khỏi xung nổ đỉnh
      const totalGainFactor = (melodyFactor * quantumBass * entanglement * maskingThreshold * emotionalVector * masterFormant * spectralAttention * emotionTimbre * vitConfigPitchShiftFactor * spectroAdapt) / (phaseCoherence + transientSculpt + 0.001);
      let vitaminFactor = Math.max(0.7, Math.min(1.3, totalGainFactor));
      vitaminFactor *= (1 + formantVariability * 0.4);
      // Trích xuất cấu hình Profile từ hệ thống cấu hình tĩnh phần cứng
      const profile = (typeof STATIC_PROFILE_CONFIGS !== 'undefined' && STATIC_PROFILE_CONFIGS[profileName]) || (typeof STATIC_PROFILE_CONFIGS !== 'undefined' && STATIC_PROFILE_CONFIGS['proNatural']) || {
        clarityBoost: 1.0,
        instrumentFocus: 1.0,
        bassReduction: 1.0
      };
      const normalizationFactor = 0.4 / Math.max(1, profile.clarityBoost * profile.instrumentFocus * genreBoost * deviceAdaptFactor);
      // Đồng bộ hóa chu kỳ chuyển đổi: Ghi nhớ nhãn cấu hình cuối không dùng node Gain phụ làm méo pha tuyến tính
      this.lastProfileName = profileName;
      // === KHỐI TÍNH TOÁN MA TRẬN ĐIỀU PHỐI GIA VỊ PHỔ THÍCH NGHI ĐẦY ĐỦ ===
      const subBassBoost = subBassEnergy < 0.45 ? 1.6 + validatedAbsPitchMult * 0.4 + (spectralBalance < 0.8 ? 0.3 : 0) : (subBassVal > 0.7 ? 0.7 : 0.9) * profile.bassReduction * deviceAdaptFactor * gliderWeightLow;
      const bassTransientBoost = validatedPitchMult < 0 && validatedAbsPitchMult > 0.5 ? 0.2 : 0;
      const subMidBoost = subMidVal < 0.4 ? 0.9 : (subMidVal > 0.7 ? 0.7 : 0.8) * profile.bassReduction * deviceAdaptFactor * gliderWeightMid;
      const vocalClarityGuard = vocalPresenceVal > 0.8 ? 0.7 : 1.0;
      const midReduceFix = midLowVal > 0.7 || midHighVal > 0.7 ? 0.6 : 1.0;
      const midBoost = midLowVal < 0.5 || midHighVal < 0.5 ? 0.9 : (midLowVal > 0.7 ? 0.7 : 0.8) * deviceAdaptFactor * midReduceFix * vocalClarityGuard * gliderWeightMid;
      const instrumentBoost = isInstrumentHeavy ? 0.9 : (isVocalHeavy ? 0.8 : 0.9) * profile.instrumentFocus * deviceAdaptFactor;
      const trebleReduceFix = subTrebleVal > 0.65 || airVal > 0.65 ? 0.6 : 1.0;
      const trebleBoostBase = subTrebleVal < 0.4 ? 0.8 : (subTrebleVal > 0.65 ? 0.7 : 0.8);
      const clarityBoost = (spectralBalance < 0.8 && subBassBoost > 1.5) || (midLowVal > 0.7 || subTrebleVal > 0.65) ? 0.2 : 0;
      const transientBoost = Math.min(transientEnergyVal > 0.65 ? 0.9 : 0.8 + (this.transientBoost || 0) * 0.5, 0.9) * (1.0 + harmonicRichness * 0.1) * profile.clarityBoost * deviceAdaptFactor * grainJitterFactor;
      // Bộ giảm chấn Treble phi tuyến tránh hiện tượng xé tiếng, chói gắt dải Air
      let dynamicTrebleReduction = 1.0;
      let deEsserGain = -12;
      if (highFreqEnergy > 0.65 || userFeedback.distortion < -1.0) {
        dynamicTrebleReduction = 1.0 - (highFreqEnergy - 0.65) * 0.6;
        deEsserGain = -20 - (highFreqEnergy - 0.65) * 18;
      } else if (highFreqEnergy > 0.5) {
        dynamicTrebleReduction = 1.0 - (highFreqEnergy - 0.5) * 0.4;
        deEsserGain = -12 - (highFreqEnergy - 0.5) * 10;
      }
      dynamicTrebleReduction = Math.max(0.6, dynamicTrebleReduction * headphoneTrebleReduction * vitConfigEmotionalVector * spectroAdapt);
      // Thuật toán Formant thông minh PRO triệt tiêu hoàn toàn góc tối khi hạ tone, chống chói mỏng giọng khi nâng tone
      let f1FreqBase = isVocalHeavy ? 560 : 510;
      let f2FreqBase = isVocalHeavy ? 2300 : 2020;
      let formantGain = isVocalHeavy ? 1.8 : 1.6;
      if (validatedPitchMult > 0) {
        f1FreqBase += validatedAbsPitchMult * 30;
        f2FreqBase += validatedAbsPitchMult * 120;
        formantGain = Math.max(1.4, formantGain - validatedAbsPitchMult * 0.3) * vitConfigPitchShiftFactor;
      } else if (validatedPitchMult < 0) {
        f1FreqBase = Math.max(300, f1FreqBase - validatedAbsPitchMult * 15);
        f2FreqBase = Math.max(1500, f2FreqBase - validatedAbsPitchMult * 80);
        formantGain = Math.min(2.0, formantGain + validatedAbsPitchMult * 0.2) * vitConfigPitchShiftFactor;
      }
      formantGain *= (1.0 + vocalPresenceVal * 0.15) * profile.clarityBoost * deviceAdaptFactor * vocalClarityGuard * vitConfigEmotionalVector * (1 + formantVariability * 0.3);
      formantGain = Math.min(2.0, formantGain + (userFeedback.vocalClarity || 0) * 0.1);
      // Cấu hình Compressor tối ưu PRO thích nghi theo mật độ phổ dải trầm
      const dynamicFactor = Math.min(1 + validatedAbsPitchMult * 0.15, 1.2);
      const thresholdBase = -20 * dynamicFactor * vitConfigPitchShiftFactor * spectroAdapt;
      const ratioBase = subBassVal > 0.7 ? 3.8 : (isInstrumentHeavy ? 2.8 : 3.3) * dynamicFactor * vitConfigPitchShiftFactor;
      const attackTime = subBassVal < 0.45 ? 0.0008 : (transientEnergyVal > 0.65 ? 0.0012 : 0.003);
      const releaseTime = subBassVal < 0.45 ? 0.3 : (subBassVal > 0.7 ? 0.06 : (isInstrumentHeavy ? 0.08 : 0.15));
      const notchFreq = isVocalHeavy ? 7400 : 6700;
      const notchQ = isVocalHeavy ? 4.0 : 2.9;
      const panAdjust = validatedPitchMult * 0.1 + (subBassEnergy > 0.7 ? 0.05 : 0);
      const noiseGateThreshold = (fftAnalysis && fftAnalysis.noiseLevel > 0.3) ? -45 : -50;
      // VÔ HIỆU HÓA HOÀN TOÀN VANG ẢO (REVERB / ECHO) - Bảo vệ độ khô nguyên bản, chân thực, hòa quyện cao cấp
      const reverbFactor = 0;
      // === MẠCH KÍCH HÀI DẢI TRẦM HARMONIC EXCITER TĨNH CAO CẤP ===
      let harmonicExciterGain = 0;
      if (cpuLoad < 0.9 && (subBassEnergy < 0.45 || subBassEnergy > 0.6) && this.context) {
        harmonicExciterGain = Math.min(0.7, 0.5 + (userFeedback.harmonicRichness || 0) * 0.2 + (spectralBalance < 0.8 ? 0.15 : 0)) * deviceAdaptFactor * vitConfigHarmonicBoost * gliderWeightLow;
        // Đồ thị kích hài tĩnh - Tạo một lần duy nhất dứt khoát không sinh rác
        if (!this.harmonicExciter) {
          this.harmonicExciter = this.context.createWaveShaper();
          const curve = new Float32Array(1024);
          for (let i = 0; i < 1024; i++) {
            const x = (i - 512) / 512;
            curve[i] = Math.tanh(x * 1.5);
          }
          this.harmonicExciter.curve = curve;
          this.harmonicExciterBandPass = this.context.createBiquadFilter();
          this.harmonicExciterBandPass.type = 'bandpass';
          this.harmonicExciterBandPass.frequency.setValueAtTime(45, currentTime);
          this.harmonicExciterBandPass.Q.setValueAtTime(1.0, currentTime);
          this.harmonicExciterHighPass = this.context.createBiquadFilter();
          this.harmonicExciterHighPass.type = 'highpass';
          this.harmonicExciterHighPass.frequency.setValueAtTime(80, currentTime);
          this.harmonicExciterGainNode = this.context.createGain();
          this.harmonicExciterGainNode.gain.setValueAtTime(0, currentTime);
          if (this.lowShelfGain && this.outputNode) {
            this.lowShelfGain.connect(this.harmonicExciterBandPass);
            this.harmonicExciterBandPass.connect(this.harmonicExciter);
            this.harmonicExciter.connect(this.harmonicExciterHighPass);
            this.harmonicExciterHighPass.connect(this.harmonicExciterGainNode);
            this.harmonicExciterGainNode.connect(this.outputNode);
          }
        }
        if (this.harmonicExciterGainNode?.gain) {
          const targetExciterGain = Math.min(0.7, harmonicExciterGain * normalizationFactor * vitConfigPitchShiftFactor * grainJitterFactor);
          if (Math.abs(this.harmonicExciterGainNode.gain.value - targetExciterGain) > 0.001) {
            this.harmonicExciterGainNode.gain.cancelScheduledValues(currentTime);
            this.harmonicExciterGainNode.gain.setValueAtTime(this.harmonicExciterGainNode.gain.value, currentTime);
            this.harmonicExciterGainNode.gain.linearRampToValueAtTime(targetExciterGain, currentTime + adjustedRampTime);
          }
        }
      } else if (this.harmonicExciterGainNode?.gain) {
        if (Math.abs(this.harmonicExciterGainNode.gain.value - 0) > 0.001) {
          this.harmonicExciterGainNode.gain.cancelScheduledValues(currentTime);
          this.harmonicExciterGainNode.gain.setValueAtTime(this.harmonicExciterGainNode.gain.value, currentTime);
          this.harmonicExciterGainNode.gain.linearRampToValueAtTime(0, currentTime + adjustedRampTime);
        }
      }
      // === MẠCH TÍNH TOÁN ĐỘ LỢI MỤC TIÊU VÀ RAMP TUYẾN TÍNH MẠCH XẢ PHẦN CỨNG ===
      let lowShelfTargetGain = Math.min(0.7, (prevLowShelfGain + bassTransientBoost) * subBassBoost * genreBoost * profile.bassReduction * normalizationFactor * vitaminFactor);
      safeRamp(this.lowShelfGain?.gain, lowShelfTargetGain, adjustedRampTime);
      if (validatedPitchMult < 0 && validatedAbsPitchMult > 0.25 && this.lowShelfGain?.Q) {
        safeRamp(this.lowShelfGain.Q, 0.85 - validatedAbsPitchMult * 0.2 * (1 - formantVariability * 0.3), adjustedRampTime);
      }
      if (this.lowShelfGain?.frequency && Math.abs(this.lowShelfGain.frequency.value - 50) > 5) {
        safeRamp(this.lowShelfGain.frequency, 50, adjustedRampTime);
      }
      let subMidTargetGain = Math.min(0.7, (prevSubMidGain + clarityBoost) * subMidBoost * genreBoost * profile.bassReduction * normalizationFactor * vitaminFactor);
      safeRamp(this.subMidFilter?.gain, subMidTargetGain, adjustedRampTime);
      let midShelfTargetGain = Math.min(0.7, (prevMidShelfGain + clarityBoost) * midBoost * genreBoost * instrumentBoost * normalizationFactor * midReduceFix * vocalClarityGuard * vitaminFactor);
      safeRamp(this.midShelfGain?.gain, midShelfTargetGain, adjustedRampTime);
      if (this.midShelfGain?.Q && Math.abs(this.midShelfGain.Q.value - 1.1) > 0.005) {
        safeRamp(this.midShelfGain.Q, 1.1, adjustedRampTime);
      }
      let highMidTargetGain = Math.min(0.7, (prevHighMidGain + clarityBoost) * instrumentBoost * transientBoost * normalizationFactor * midReduceFix * vocalClarityGuard * vitaminFactor);
      safeRamp(this.highMidFilter?.gain, highMidTargetGain, adjustedRampTime);
      let subTrebleTargetGain = Math.min(0.7, (prevSubTrebleGain + clarityBoost) * trebleBoostBase * transientBoost * genreBoost * normalizationFactor * trebleReduceFix * dynamicTrebleReduction * vitaminFactor);
      safeRamp(this.subTrebleFilter?.gain, subTrebleTargetGain, adjustedRampTime);
      // =================================================================
      // === PHẦN 2: ĐIỀU PHỐI FORMANT NÂNG CAO & LUẬT BẢO TOÀN ÁP SUẤT SPL ===
      // =================================================================
      // === FORMANT FILTER 1 ===
      let formantF1TargetGain = Math.min(0.7, formantGain * normalizationFactor * vitaminFactor);
      const f1FreqTarget = Math.max(200, Math.min(1200, f1FreqBase * (1 + formantVariability * 0.1)));
      const f1QTarget = Math.max(0.3, Math.min(4.0, 1.3 * vitConfigPhaseLockFactor * grainJitterFactor));
      if (this.formantFilter1?.frequency && this.formantFilter1?.gain && this.formantFilter1?.Q) {
        // Thiết lập điểm neo chống Pop/Click cơ học trên dòng thời gian tĩnh
        this.formantFilter1.frequency.cancelScheduledValues(currentTime);
        this.formantFilter1.gain.cancelScheduledValues(currentTime);
        this.formantFilter1.Q.cancelScheduledValues(currentTime);
        this.formantFilter1.frequency.setValueAtTime(this.formantFilter1.frequency.value, currentTime);
        this.formantFilter1.gain.setValueAtTime(this.formantFilter1.gain.value, currentTime);
        this.formantFilter1.Q.setValueAtTime(this.formantFilter1.Q.value, currentTime);
        // Sử dụng mạch safeRamp tích hợp Dirty Checking giảm tải CPU
        if (Math.abs(this.formantFilter1.frequency.value - f1FreqTarget) > 5) {
          safeRamp(this.formantFilter1.frequency, f1FreqTarget, adjustedRampTime);
        }
        if (Math.abs(this.formantFilter1.gain.value - formantF1TargetGain) > 0.005) {
          safeRamp(this.formantFilter1.gain, formantF1TargetGain, adjustedRampTime);
        }
        if (Math.abs(this.formantFilter1.Q.value - f1QTarget) > 0.005) {
          safeRamp(this.formantFilter1.Q, f1QTarget, adjustedRampTime);
        }
      }
      // === FORMANT FILTER 2 ===
      let formantF2TargetGain = Math.min(0.7, formantGain * 0.85 * normalizationFactor * vitaminFactor);
      const f2FreqTarget = Math.max(1000, Math.min(3500, f2FreqBase * (1 + formantVariability * 0.1)));
      const f2QTarget = Math.max(0.3, Math.min(4.0, 1.3 * vitConfigPhaseLockFactor * grainJitterFactor));
      if (this.formantFilter2?.frequency && this.formantFilter2?.gain && this.formantFilter2?.Q) {
        this.formantFilter2.frequency.cancelScheduledValues(currentTime);
        this.formantFilter2.gain.cancelScheduledValues(currentTime);
        this.formantFilter2.Q.cancelScheduledValues(currentTime);
        this.formantFilter2.frequency.setValueAtTime(this.formantFilter2.frequency.value, currentTime);
        this.formantFilter2.gain.setValueAtTime(this.formantFilter2.gain.value, currentTime);
        this.formantFilter2.Q.setValueAtTime(this.formantFilter2.Q.value, currentTime);
        if (Math.abs(this.formantFilter2.frequency.value - f2FreqTarget) > 5) {
          safeRamp(this.formantFilter2.frequency, f2FreqTarget, adjustedRampTime);
        }
        if (Math.abs(this.formantFilter2.gain.value - formantF2TargetGain) > 0.005) {
          safeRamp(this.formantFilter2.gain, formantF2TargetGain, adjustedRampTime);
        }
        if (Math.abs(this.formantFilter2.Q.value - f2QTarget) > 0.005) {
          safeRamp(this.formantFilter2.Q, f2QTarget, adjustedRampTime);
        }
      }
      // === KHỐI NÉN DỰA TRÊN DẢI ĐỘNG CỦA BỘ NÃO v20.0 ===
      if (this.compressor?.threshold && this.compressor?.ratio && this.compressor?.attack && this.compressor?.release) {
        this.compressor.threshold.cancelScheduledValues(currentTime);
        this.compressor.ratio.cancelScheduledValues(currentTime);
        this.compressor.attack.cancelScheduledValues(currentTime);
        this.compressor.release.cancelScheduledValues(currentTime);
        this.compressor.threshold.setValueAtTime(this.compressor.threshold.value, currentTime);
        this.compressor.ratio.setValueAtTime(this.compressor.ratio.value, currentTime);
        this.compressor.attack.setValueAtTime(this.compressor.attack.value, currentTime);
        this.compressor.release.setValueAtTime(this.compressor.release.value, currentTime);
        const finalRatio = Math.max(1.0, Math.min(20.0, ratioBase * grainJitterFactor));
        if (Math.abs(this.compressor.threshold.value - thresholdBase) > 0.05) {
          safeRamp(this.compressor.threshold, thresholdBase, adjustedRampTime);
        }
        if (Math.abs(this.compressor.ratio.value - finalRatio) > 0.05) {
          safeRamp(this.compressor.ratio, finalRatio, adjustedRampTime);
        }
        if (Math.abs(this.compressor.attack.value - attackTime) > 0.00005) {
          safeRamp(this.compressor.attack, attackTime, adjustedRampTime);
        }
        if (Math.abs(this.compressor.release.value - releaseTime) > 0.005) {
          safeRamp(this.compressor.release, releaseTime, adjustedRampTime);
        }
      }
      // Định hình dải cao Air trong suốt, trong trẻo tự nhiên
      let airTargetGain = Math.min(0.7, (1.5 + clarityBoost) * (1 + airVal * 0.5) * dynamicTrebleReduction * normalizationFactor * vitaminFactor * gliderWeightHigh);
      safeRamp(this.airFilter?.gain, airTargetGain, adjustedRampTime);
      // Định vị mạch Panner trung tâm, loại bỏ lệch pha không gian ảo
      if (this.panner?.pan) {
        this.panner.pan.cancelScheduledValues(currentTime);
        this.panner.pan.setValueAtTime(this.panner.pan.value, currentTime);
        if (Math.abs(this.panner.pan.value - panAdjust) > 0.005) {
          safeRamp(this.panner.pan, panAdjust, adjustedRampTime);
        }
      }
      // Mạch kiểm soát âm xì De-Esser nâng cao tránh chói gắt dải cao khi lên nốt cao
      if (this.deEsser?.gain) {
        this.deEsser.gain.cancelScheduledValues(currentTime);
        this.deEsser.gain.setValueAtTime(this.deEsser.gain.value, currentTime);
        if (Math.abs(this.deEsser.gain.value - deEsserGain) > 0.05) {
          safeRamp(this.deEsser.gain, deEsserGain, adjustedRampTime);
        }
      }
      // Bộ lọc Notch Filter tĩnh dập tiếng rít micro thời gian thực
      if (this.notchFilter?.frequency && this.notchFilter?.Q) {
        this.notchFilter.frequency.cancelScheduledValues(currentTime);
        this.notchFilter.Q.cancelScheduledValues(currentTime);
        this.notchFilter.frequency.setValueAtTime(this.notchFilter.frequency.value, currentTime);
        this.notchFilter.Q.setValueAtTime(this.notchFilter.Q.value, currentTime);
        if (Math.abs(this.notchFilter.frequency.value - notchFreq) > 5) {
          safeRamp(this.notchFilter.frequency, notchFreq, adjustedRampTime);
        }
        if (Math.abs(this.notchFilter.Q.value - (notchQ * vitConfigPhaseLockFactor)) > 0.005) {
          safeRamp(this.notchFilter.Q, notchQ * vitConfigPhaseLockFactor, adjustedRampTime);
        }
      }
      // Mạch dập nhiễu Noise Gate tĩnh làm sạch nền nhạc và giọng hát Khô - Sạch hoàn toàn
      if (this.noiseGate?.threshold) {
        this.noiseGate.threshold.cancelScheduledValues(currentTime);
        this.noiseGate.threshold.setValueAtTime(this.noiseGate.threshold.value, currentTime);
        if (Math.abs(this.noiseGate.threshold.value - noiseGateThreshold) > 0.05) {
          safeRamp(this.noiseGate.threshold, noiseGateThreshold, adjustedRampTime);
        }
      }
      // === ĐỒNG BỘ MẠCH ĐIỀU PHỐI ĐỘ LỢI PHẢN HỒI NGƯỜI DÙNG TÍCH HỢP UI BRIDGE ===
      if (userFeedback) {
        if (userFeedback.warmth > 0) {
          lowShelfTargetGain = Math.min(0.7, lowShelfTargetGain + userFeedback.warmth * 0.2 * vitConfigEmotionalVector);
          safeRamp(this.lowShelfGain?.gain, lowShelfTargetGain, adjustedRampTime);
          subMidTargetGain = Math.min(0.7, subMidTargetGain + userFeedback.warmth * 0.15 * vitConfigEmotionalVector);
          safeRamp(this.subMidFilter?.gain, subMidTargetGain, adjustedRampTime);
        }
        if (userFeedback.clarity > 0) {
          midShelfTargetGain = Math.min(0.7, midShelfTargetGain + userFeedback.clarity * 0.15 * vitConfigEmotionalVector);
          safeRamp(this.midShelfGain?.gain, midShelfTargetGain, adjustedRampTime);
          highMidTargetGain = Math.min(0.7, highMidTargetGain + userFeedback.clarity * 0.1 * vitConfigEmotionalVector);
          safeRamp(this.highMidFilter?.gain, highMidTargetGain, adjustedRampTime);
        }
        if (userFeedback.distortion < -1.0) {
          subTrebleTargetGain = Math.min(0.7, subTrebleTargetGain * 0.55 * vitConfigEmotionalVector);
          safeRamp(this.subTrebleFilter?.gain, subTrebleTargetGain, adjustedRampTime);
          airTargetGain = Math.min(0.7, airTargetGain * 0.55 * vitConfigEmotionalVector);
          safeRamp(this.airFilter?.gain, airTargetGain, adjustedRampTime);
          safeRamp(this.deEsser?.gain, Math.max(-24, deEsserGain - 4), adjustedRampTime);
        }
        if (userFeedback.bass > 0) {
          lowShelfTargetGain = Math.min(0.7, lowShelfTargetGain + userFeedback.bass * 0.2 * vitConfigHarmonicBoost);
          safeRamp(this.lowShelfGain?.gain, lowShelfTargetGain, adjustedRampTime);
          if (this.lowShelfGain?.frequency && Math.abs(this.lowShelfGain.frequency.value - 45) > 5) {
            safeRamp(this.lowShelfGain.frequency, 45, adjustedRampTime);
          }
          if (this.lowShelfGain?.Q && Math.abs(this.lowShelfGain.Q.value - 0.85) > 0.005) {
            safeRamp(this.lowShelfGain.Q, 0.85, adjustedRampTime);
          }
        }
        if (userFeedback.depth > 0) {
          lowShelfTargetGain = Math.min(0.7, lowShelfTargetGain + userFeedback.depth * 0.3 * vitConfigHarmonicBoost);
          safeRamp(this.lowShelfGain?.gain, lowShelfTargetGain, adjustedRampTime);
          if (this.lowShelfGain?.frequency && Math.abs(this.lowShelfGain.frequency.value - 40) > 5) {
            safeRamp(this.lowShelfGain.frequency, 40, adjustedRampTime);
          }
          if (this.lowShelfGain?.Q && Math.abs(this.lowShelfGain.Q.value - 0.85) > 0.005) {
            safeRamp(this.lowShelfGain.Q, 0.85, adjustedRampTime);
          }
        }
        if (userFeedback.harmonicRichness > 0 && harmonicExciterGain > 0) {
          if (this.harmonicExciterGainNode?.gain) {
            const userExciterTarget = Math.min(0.7, harmonicExciterGain + userFeedback.harmonicRichness * 0.15 * vitConfigHarmonicBoost) * normalizationFactor;
            safeRamp(this.harmonicExciterGainNode.gain, userExciterTarget, adjustedRampTime);
          }
          if (this.subMidFilter?.gain) {
            subMidTargetGain = Math.min(0.7, subMidTargetGain * 0.8 * subMidBoost * genreBoost * profile.bassReduction * normalizationFactor * vitaminFactor);
            safeRamp(this.subMidFilter.gain, subMidTargetGain, adjustedRampTime);
          }
        }
      }
      // === LUẬT BẢO TOÀN ÁP SUẤT SPL PRO (NON-LINEAR SOFT CLIPPING LIMITER - Math.tanh) ===
      const totalGain = Math.max(lowShelfTargetGain, subMidTargetGain, midShelfTargetGain, highMidTargetGain, subTrebleTargetGain, airTargetGain, formantF1TargetGain, formantF2TargetGain, harmonicExciterGain * normalizationFactor);
      if (totalGain > 0.7) {
        const excessGain = totalGain - 0.7;
        const safeTotalGain = 0.7 + (Math.tanh(excessGain / 0.4) * 0.25);
        const gainReductionFactor = (safeTotalGain / totalGain) * vitConfigPitchShiftFactor * spectroAdapt;
        lowShelfTargetGain *= gainReductionFactor;
        subMidTargetGain *= gainReductionFactor;
        midShelfTargetGain *= gainReductionFactor;
        highMidTargetGain *= gainReductionFactor;
        subTrebleTargetGain *= gainReductionFactor;
        airTargetGain *= gainReductionFactor;
        formantF1TargetGain *= gainReductionFactor;
        formantF2TargetGain *= gainReductionFactor;
        harmonicExciterGain *= gainReductionFactor;
      }
      // === THỰC THI MẠCH XẢ KHÓA CUỐI TUYẾN TÍNH ĐỒNG BỘ PHẦN CỨNG ===
      if (this.lowShelfGain?.gain) safeRamp(this.lowShelfGain.gain, lowShelfTargetGain, adjustedRampTime);
      if (this.subMidFilter?.gain) safeRamp(this.subMidFilter.gain, subMidTargetGain, adjustedRampTime);
      if (this.midShelfGain?.gain) safeRamp(this.midShelfGain.gain, midShelfTargetGain, adjustedRampTime);
      if (this.highMidFilter?.gain) safeRamp(this.highMidFilter.gain, highMidTargetGain, adjustedRampTime);
      if (this.subTrebleFilter?.gain) safeRamp(this.subTrebleFilter.gain, subTrebleTargetGain, adjustedRampTime);
      if (this.formantFilter1?.gain) safeRamp(this.formantFilter1.gain, formantF1TargetGain, adjustedRampTime);
      if (this.formantFilter2?.gain) safeRamp(this.formantFilter2.gain, formantF2TargetGain, adjustedRampTime);
      if (this.airFilter?.gain) safeRamp(this.airFilter.gain, airTargetGain, adjustedRampTime);
      if (this.harmonicExciterGainNode?.gain) {
        safeRamp(this.harmonicExciterGainNode.gain, Math.min(0.7, harmonicExciterGain * normalizationFactor * vitConfigPitchShiftFactor), adjustedRampTime);
      }
      // === HỆ THỐNG CACHE ĐÓNG BĂNG TĨNH CHỐNG LEAK BỘ NHỚ RAM TRONG LUỒNG THỜI GIAN THỰC (ZERO-GC) ===
      if (this.memoryManager) {
        const cacheKey = 'vitaminSettings';
        if (this.memoryManager.buffers.has(cacheKey)) {
          this.memoryManager.buffers.delete(cacheKey);
        }
        this.memoryManager.buffers.set(cacheKey, Object.freeze({
          profile: profileName,
          subBassBoost,
          bassTransientBoost,
          subMidBoost,
          midBoost,
          instrumentBoost,
          trebleBoost: trebleBoostBase,
          transientBoost,
          formantGain,
          deEsserGain,
          notchFreq,
          notchQ,
          airGainBase: airTargetGain,
          dynamicTrebleReduction,
          highFreqEnergy,
          genreBoost,
          isHeadphone,
          isInstrumentHeavy,
          reverb: 0,
          bassReduction: profile.bassReduction,
          clarityBoost,
          midReduceFix,
          trebleReduceFix,
          vocalClarityGuard,
          spectralBalance,
          userFeedback,
          minFadeLength,
          crossFadeTime,
          subBassEnergy,
          harmonicExciterGain,
          totalGain,
          timestamp: Date.now(),
          expiry: Date.now() + 12000,
          priority: 'high'
        }));
        this.memoryManager.pruneCache(typeof this.calculateMaxCacheSize === 'function' ? this.calculateMaxCacheSize() : 80);
      }
      const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
      if (isDebug) {
        console.debug('Vitamin Engine Finalized with Perceptual Masking Model & SPL Law.');
      }
    } catch (error) {
      console.error('Lỗi khẩn cấp mạch xả Vitamin PRO:', error);
      const fallbackTime = this.context ? this.context.currentTime : 0;
      const fallbackRampTime = 0.1;
      if (this.outputGain?.gain) {
        this.outputGain.gain.cancelScheduledValues(fallbackTime);
        this.outputGain.gain.setValueAtTime(this.outputGain.gain.value || 0.6, fallbackTime);
        this.outputGain.gain.linearRampToValueAtTime(0.6, fallbackTime + fallbackRampTime);
      }
      if (this.harmonicExciterGainNode?.gain) {
        this.harmonicExciterGainNode.gain.cancelScheduledValues(fallbackTime);
        this.harmonicExciterGainNode.gain.setValueAtTime(this.harmonicExciterGainNode.gain.value, fallbackTime);
        this.harmonicExciterGainNode.gain.linearRampToValueAtTime(0, fallbackTime + fallbackRampTime);
      }
    }
  };
  // Dời ra ngoài hàm (Scope toàn cục trong Worker) để reuse bộ nhớ
  const _fftEnergies = new Float32Array(6);
  const _emptyAnalysis = {
    subBassEnergy: 0.5,
    bassEnergy: 0.5,
    midEnergy: 0.5,
    highMidEnergy: 0.5,
    trebleEnergy: 0.5,
    airEnergy: 0.5,
    instrumentEnergy: 0.5,
    vocalEnergy: 0.5,
    highFreqEnergy: 0.5,
    noiseLevel: 0.5,
    spectralFlux: 0.5,
    spectralEntropy: 0.5,
    spectralCoherence: 0.5,
    transientDensity: 0.5,
    harmonicRichness: 0.5
  };
  Jungle.prototype.getFFTAnalysis = function() {
    if (!this._analyser) return _emptyAnalysis;
    const bufferLength = this._analyser.frequencyBinCount;
    if (!this._fftDataArray || this._fftDataArray.length !== bufferLength) {
      this._fftDataArray = new Float32Array(bufferLength);
      this._prevFftDataArray = new Float32Array(bufferLength);
    }
    this._analyser.getFloatFrequencyData(this._fftDataArray);
    const sampleRate = this.context.sampleRate;
    const binSize = sampleRate / (2 * bufferLength);
    const sampleStep = (navigator.hardwareConcurrency && navigator.hardwareConcurrency < 4) ? 4 : 1;
    const effectiveBufferLength = Math.floor(bufferLength / sampleStep);
    // Tính toán năng lượng (Zero-allocation)
    let subBass = 0,
      bass = 0,
      mid = 0,
      highMid = 0,
      treble = 0,
      air = 0;
    let inst = 0,
      voc = 0,
      highFreq = 0,
      noise = 0,
      sEnergy = 0,
      sFlux = 0,
      transient = 0;
    for (let i = 0; i < bufferLength; i += sampleStep) {
      const val = this._fftDataArray[i];
      const energy = val > -100 ? Math.pow(10, val / 20) : 0;
      const freq = i * binSize;
      if (freq < 30) noise += energy;
      else if (freq < 80) subBass += energy;
      else if (freq < 200) bass += energy;
      else if (freq < 1000) mid += energy;
      else if (freq < 4000) highMid += energy;
      else if (freq < 6000) treble += energy;
      else air += energy;
      if (freq >= 200 && freq <= 4000) inst += energy;
      if (freq >= 300 && freq <= 3000) voc += energy;
      if (freq >= 6000) highFreq += energy;
      sEnergy += energy;
      const delta = Math.abs(energy - this._prevFftDataArray[i]);
      sFlux += delta;
      if (delta > 0.1 && freq >= 200 && freq <= 6000) transient++;
    }
    const norm = 10 / effectiveBufferLength;
    const result = {
      subBassEnergy: Math.min(1, subBass * norm),
      bassEnergy: Math.min(1, bass * norm),
      midEnergy: Math.min(1, mid * norm),
      highMidEnergy: Math.min(1, highMid * norm),
      trebleEnergy: Math.min(1, treble * norm),
      airEnergy: Math.min(1, air * norm),
      instrumentEnergy: Math.min(1, inst * norm),
      vocalEnergy: Math.min(1, voc * norm),
      highFreqEnergy: Math.min(1, highFreq * norm),
      noiseLevel: Math.min(1, noise * norm),
      spectralFlux: Math.min(1, sFlux * norm)
    };
    // Entropy calculation (Sử dụng array tĩnh _fftEnergies)
    _fftEnergies[0] = result.subBassEnergy;
    _fftEnergies[1] = result.bassEnergy;
    _fftEnergies[2] = result.midEnergy;
    _fftEnergies[3] = result.highMidEnergy;
    _fftEnergies[4] = result.trebleEnergy;
    _fftEnergies[5] = result.airEnergy;
    const totalE = _fftEnergies.reduce((a, b) => a + b, 0) || 1;
    let entropy = 0;
    for (let i = 0; i < 6; i++) {
      const p = _fftEnergies[i] / totalE;
      if (p > 0) entropy -= p * Math.log2(p);
    }
    result.spectralEntropy = entropy / 2.58; // log2(6) ≈ 2.58
    result.spectralCoherence = Math.min(1, 1 - result.spectralEntropy * 0.5);
    result.transientDensity = Math.min(1, transient / effectiveBufferLength * 100);
    result.harmonicRichness = Math.min(1, (result.midEnergy + result.highMidEnergy) * 0.6 + result.vocalEnergy * 0.4);
    // Cập nhật state
    this._prevFftDataArray.set(this._fftDataArray);
    return result;
  };
  Jungle.prototype.checkOutputDevice = async function() {
    // Debounce cũ của bạn vẫn rất tốt
    if (this._lastDeviceCheck !== undefined && (Date.now() - (this._lastDeviceCheckTime || 0) < 5000)) {
      return this._lastDeviceCheck;
    }
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) return false;
      const devices = await navigator.mediaDevices.enumerateDevices();
      // Kiểm tra xem có label nào bị trống không
      const hasLabels = devices.some(d => d.label !== '');
      const isHeadphone = devices.some(device => device.kind === 'audiooutput' && (device.label.toLowerCase().includes('headphone') || device.label.toLowerCase().includes('tai nghe')));
      // NẾU label trống, nghĩa là trình duyệt chặn, chúng ta KHÔNG NÊN cache kết quả false vội
      // Đánh dấu để lần sau nó thử lại khi quyền đã cấp
      if (!hasLabels && !isHeadphone) {
        // Có thể log debug ở đây để biết là do permission chứ không phải do thiếu thiết bị
        return false;
      }
      this._lastDeviceCheck = isHeadphone;
      this._lastDeviceCheckTime = Date.now();
      return isHeadphone;
    } catch (e) {
      return false;
    }
  };
  Jungle.prototype.setDelay = function(delayTime) {
    try {
      if (typeof delayTime !== 'number' || isNaN(delayTime)) {
        throw new Error('delayTime must be a valid number.');
      }
      delayTime = Math.max(0, Math.min(MAX_DELAY_TIME, delayTime));
      const cpuLoad = this.getCPULoad ? ensureFinite(this.getCPULoad(), 0.5) : 0.5;
      const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
      // 🪐 ĐỒNG BỘ 1: Đổi cấu hình dự phòng mặc định sang proNatural
      const profile = this.profile || 'proNatural';
      const songStructure = this.memoryManager?.get('lastStructure') || {
        section: 'unknown'
      };
      const spectralProfile = this.spectralProfile || {
        subBass: 0.5,
        bass: 0.5,
        subMid: 0.5,
        midLow: 0.5,
        midHigh: 0.5,
        high: 0.5,
        subTreble: 0.5,
        air: 0.5,
        vocalPresence: 0.5,
        transientEnergy: 0.5,
        instruments: {},
        chroma: null,
        spectralComplexity: 0.5,
        harmonicRatio: 0.5
      };
      const feedbackList = this.memoryManager?.get('userFeedback') || [];
      const isVocalFeedback = feedbackList.some(f => f.timestamp > Date.now() - 60000 && f.semanticCategory === 'vocal');
      if (!this.modGain1?.gain || !this.modGain2?.gain || !(this.context instanceof AudioContext)) {
        throw new Error('modGain1, modGain2, or AudioContext is not initialized.');
      }
      // ĐƯỜNG TRUYỀN TÍN HIỆU MỘC
      let adjustedDelayTime = delayTime;
      let rampTime = ensureFinite(this.rampTime, DEFAULT_RAMP_TIME);
      // 🪐 ĐỒNG BỘ 2: Chỉ áp dụng thuật toán phóng đại không gian cho các profile cũ, cô lập proNatural hoàn toàn mộc
      if (profile === 'smartStudio' || profile === 'bright') {
        adjustedDelayTime *= 1.1;
        rampTime *= 1.3;
      } else if (profile === 'vocal' || isVocalFeedback) {
        adjustedDelayTime *= 1.05;
        rampTime *= 1.2;
      }
      // 🪐 ĐỒNG BỘ 3: proNatural nói KHÔNG với việc tự ý đổi độ trễ theo Chorus (Triệt tiêu hiện tượng méo tiếng phase)
      if (profile !== 'proNatural' && songStructure.section === 'chorus') {
        adjustedDelayTime *= 1.15;
        rampTime *= 1.1;
      }
      if (isLowPowerDevice && cpuLoad > 0.9) {
        rampTime *= 0.7;
      }
      adjustedDelayTime = Math.max(0, Math.min(MAX_DELAY_TIME, adjustedDelayTime));
      // Stable Transition - Anchor Point + Ramp
      const currentTime = this.context.currentTime;
      const safeTime = currentTime + 0.01;
      // 🪐 ĐỒNG BỘ 4: Khóa cứng hệ số giao thoa mạch về 0.5 chuẩn kỹ thuật cho proNatural để âm thanh ra mộc nhất
      const delayFactor = (profile === 'smartStudio') ? 0.6 : 0.5;
      const finalGainValue = delayFactor * adjustedDelayTime;
      const g1 = this.modGain1.gain;
      const g2 = this.modGain2.gain;
      g1.cancelScheduledValues(safeTime);
      g1.setValueAtTime(g1.value, safeTime);
      g1.linearRampToValueAtTime(finalGainValue, safeTime + rampTime);
      g2.cancelScheduledValues(safeTime);
      g2.setValueAtTime(g2.value, safeTime);
      g2.linearRampToValueAtTime(finalGainValue, safeTime + rampTime);
      // Quản lý bộ nhớ đệm trạng thái tĩnh
      if (this.memoryManager) {
        const cacheKey = `delayState_${this.contextId}_${profile}`;
        this.memoryManager.set(cacheKey, {
          data: {
            delayTime: adjustedDelayTime,
            rampTime,
            delayFactor,
            profile,
            songStructure,
            isVocalFeedback
          },
          expiry: Date.now() + (isLowPowerDevice ? 30000 : 60000),
          priority: 'high'
        }, 'high');
        if (Math.random() > 0.8) {
          this.memoryManager.pruneCache(this.memoryManager.getDynamicMaxSize?.() || 100);
        }
      }
      const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
      if (isDebug) {
        console.debug('Hi-Fi Delay set successfully (No artificial chorus effect):', {
          delayTime: adjustedDelayTime,
          rampTime,
          profile
        });
      }
    } catch (error) {
      handleError('Error setting delay:', error, {
        delayTime,
        profile: this.profile,
        cpuLoad: this.getCPULoad?.() || 0.5,
        isLowPowerDevice: navigator.hardwareConcurrency < 4,
        contextState: this.context?.state
      }, 'high', {
        memoryManager: this.memoryManager
      });
    }
  };
  // === BAN CHẤP HÀNH MA TRẬN ĐỐI TƯỢNG TĨNH NGOÀI CLASS (CƠ CHẾ ZERO-GC TUYỆT ĐỐI) ===
  const _f1Preserved = {
    freq: 0,
    gain: 0,
    q: 0
  };
  const _f2Preserved = {
    freq: 0,
    gain: 0,
    q: 0
  };
  const updatePreserve = (targetObj, semitones, baseFreq, presence, sp, formantScale, entanglementFactor, emotionalVector, phaseLockFactor) => {
    if (typeof preserveFormant === 'function') {
      const res = preserveFormant(semitones, baseFreq, presence, sp);
      targetObj.freq = res.freq;
      targetObj.gain = res.gain;
      targetObj.q = res.q;
    } else {
      targetObj.freq = baseFreq * Math.pow(2, semitones / 12) * formantScale * entanglementFactor;
      targetObj.gain = Math.min(0.5 + (0.045 * Math.abs(semitones)) * emotionalVector, 0.78);
      targetObj.q = Math.max(1.0 - (0.007 * Math.abs(semitones)) * phaseLockFactor, 0.72);
    }
  };
  // ===================================================================================================
  // === SIÊU HÀM ĐIỀU PHỐI DỊCH TONE CHUYỂN VỊ THỜI GIAN THỰC ZÖLZER AT2030 ULTIMATE PRO v16.8 ===
  // ===================================================================================================
  Jungle.prototype.setPitchOffset = function(mult, transpose = false) {
    try {
      // 1. KIỂM TRA AUDIO CONTEXT PHẦN CỨNG - XƯƠNG SỐNG AN TOÀN TRUYỀN DẪN
      if (!this.context || !(this.context instanceof AudioContext) || this.context.state === 'closed') {
        throw new Error('Hệ thống AudioContext không hợp lệ hoặc đã bị đóng vĩnh viễn');
      }
      // 2. MẠCH CHỐNG RÒ RỈ EVENT LISTENER KHI CONTEXT BỊ TREO (ANTI-LEAK RESUMER)
      if (this.context.state === 'suspended') {
        if (!this._isResuming) {
          this._isResuming = true;
          const resumeHandler = () => {
            this.context.resume().then(() => {
              this._isResuming = false;
              console.debug('[Zölzer AT2030] Kích hoạt luồng AudioContext thành công qua tương tác người dùng.');
            }).catch(err => {
              this._isResuming = false;
              if (typeof handleError === 'function') {
                handleError('Thất bại khi đánh thức AudioContext', err, {}, 'high', {
                  memoryManager: this.memoryManager
                });
              }
              this.notifyUIError?.('Vui lòng chạm vào màn hình để mở khóa luồng âm thanh');
            });
          };
          ['click', 'touchstart'].forEach(evt => document.addEventListener(evt, resumeHandler, {
            once: true
          }));
        }
      }
      const currentTime = this.context.currentTime;
      const safeTime = currentTime + 0.01;
      const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
      // 3. BỘ ĐIỀU PHỐI ĐỘ LỢI VỚI LỆNH ĐẶT TRƯỚC AN TOÀN (SAFE PARAMETER SCHEDULER)
      const safeParam = (param, val, time, method = 'linear') => {
        if (!param || !Number.isFinite(val)) return;
        try {
          param.cancelScheduledValues(safeTime);
          param.setValueAtTime(param.value ?? 0.001, safeTime); // Tránh 0 cho exponential
          if (method === 'exponential') {
            // Dùng cho Freq để chuyển động mượt theo tai người
            param.exponentialRampToValueAtTime(Math.max(val, 0.001), time);
          } else if (method === 'linear') {
            param.linearRampToValueAtTime(val, time);
          } else {
            param.setValueAtTime(val, time);
          }
        } catch (e) {
          param.setValueAtTime(val, safeTime);
        }
      };
      // Khóa chết trạng thái chống nổ âm thanh cục bộ
      [this.outputGain, this.mod1Gain, this.mod2Gain, this.mod3Gain, this.mod4Gain].forEach(node => {
        if (node && node.gain) {
          safeParam(node.gain, node.gain.value ?? 0, safeTime, 'set');
        }
      });
      // 4. CHUẨN HÓA ĐẦU VÀO
      const validateNum = (val, def) => (typeof val === 'number' && Number.isFinite(val)) ? val : def;
      const pitchMultInput = validateNum(mult, 0);
      let adjustedPitchMult = pitchMultInput / 12;
      if (transpose) {
        adjustedPitchMult = Math.max(-24, Math.min(24, pitchMultInput)) / 12;
      } else {
        adjustedPitchMult = Math.max(-12, Math.min(12, pitchMultInput)) / 12;
      }
      const absPitchMult = Math.abs(adjustedPitchMult);
      this.currentPitchMult = adjustedPitchMult;
      const semitones = adjustedPitchMult * 12;
      // Phân tích ma trận trắc phổ
      const sp = this.spectralProfile || {};
      const spectralComplexity = validateNum(sp.spectralComplexity, 0.5);
      const transientEnergy = validateNum(sp.transientEnergy, 0.5);
      const vocalPresence = validateNum(sp.vocalPresence, this.currentProfile === 'vocal' ? 0.8 : 0.5);
      const bass = validateNum(sp.bass, this.currentProfile === 'bassHeavy' ? 0.7 : 0.5);
      const air = validateNum(sp.air, 0.5);
      const isFemaleVocal = (this.formantF1Freq ?? 300) > 400 || (this.formantF2Freq ?? 1600) > 1800;
      // 5. CẤU HÌNH HỆ SỐ PHÙ THỦY AT2030 CORE
      const cpuLoad = this.cpuLoad ?? (typeof this.getCPULoad === 'function' ? this.getCPULoad() : 0.5);
      const isLowPower = !!this.isLowPowerDevice;
      const isVocalMode = this.isVocal || this.currentProfile === 'vocal' || this.currentProfile === 'karaokeDynamic';
      const atEnabled = isVocalMode || absPitchMult > 0;
      let formantScaleRaw = isFemaleVocal ? 1.08 + semitones * 0.013 : 1.0 + semitones * 0.018;
      const formantScale = Math.max(0.82, Math.min(1.28, formantScaleRaw));
      let devAdaptRaw = 1.0 - cpuLoad * (isLowPower ? 0.42 : 0.16);
      const deviceAdaptFactor = Math.max(0.76, Math.min(1.0, devAdaptRaw));
      const harmonicBoost = this.currentProfile === 'bassHeavy' ? 1.25 : this.currentProfile === 'vocal' ? 1.12 : 1.0;
      const transientSculpt = (this.currentProfile === 'rockMetal' || this.currentProfile === 'bassHeavy') ? 1.55 : 1.25;
      const phaseLockFactor = this.currentProfile === 'vocal' ? 1.0 : (this.qualityMode === 'high' ? 0.96 : 0.87);
      const emotionalVector = this.currentProfile === 'warm' ? 0.94 : (this.currentProfile === 'rockMetal' ? 1.18 : 1.0);
      const rampTime = validateNum(this.rampTime, 0.15);
      const adjustedRampTime = Math.max(0.09, rampTime * (1 + absPitchMult * 0.09));
      const crossFadeTime = Math.max(0.05, this.fadeTime ?? 0.06);
      const rampEnd = safeTime + adjustedRampTime;
      const crossFadeEnd = safeTime + adjustedRampTime + crossFadeTime;
      const previousState = {
        outputGain: this.outputGain?.gain.value ?? 1.0,
        lowPassFreq: this.lowPassFilter?.frequency.value ?? 16000,
        highPassFreq: this.highPassFilter?.frequency.value ?? 80,
        notchFreq: this.notchFilter?.frequency.value ?? 1000,
        subMidGain: this.subMidFilter?.gain.value ?? 0,
        highShelfGain: this.highShelfFilter?.gain.value ?? 0,
        lowShelfGain: this.lowShelfFilter?.gain.value ?? 0,
        formantF1Freq: this.formantFilter1?.frequency.value ?? 300,
        formantF2Freq: this.formantFilter2?.frequency.value ?? 1600
      };
      // === MẠCH RESET TRẠNG THÁI TUYỆT ĐỐI ===
      if (adjustedPitchMult === 0) {
        if (this.outputGain) safeParam(this.outputGain.gain, 1.0 * deviceAdaptFactor, crossFadeEnd);
        if (this.lowPassFilter) {
          safeParam(this.lowPassFilter.frequency, 16000, crossFadeEnd);
          safeParam(this.lowPassFilter.Q, 0.5, crossFadeEnd);
        }
        if (this.highPassFilter) {
          safeParam(this.highPassFilter.frequency, 80, crossFadeEnd);
          safeParam(this.highPassFilter.Q, 0.5, crossFadeEnd);
        }
        if (this.notchFilter) {
          safeParam(this.notchFilter.frequency, 1000, crossFadeEnd);
          safeParam(this.notchFilter.Q, 1, crossFadeEnd);
        }
        if (this.subMidFilter) safeParam(this.subMidFilter.gain, 0, crossFadeEnd);
        if (this.highShelfFilter) safeParam(this.highShelfFilter.gain, 0, crossFadeEnd);
        if (this.lowShelfFilter) safeParam(this.lowShelfFilter.gain, 0, crossFadeEnd);
        if (this.formantFilter1 && this.formantFilter2) {
          safeParam(this.formantFilter1.frequency, 300, crossFadeEnd);
          safeParam(this.formantFilter2.frequency, 1600, crossFadeEnd);
          safeParam(this.formantFilter1.gain, 0, crossFadeEnd);
          safeParam(this.formantFilter2.gain, 0, crossFadeEnd);
          safeParam(this.formantFilter1.Q, 1, crossFadeEnd);
          safeParam(this.formantFilter2.Q, 1, crossFadeEnd);
        }
        [this.mod1Gain, this.mod2Gain, this.mod3Gain, this.mod4Gain].forEach(g => {
          if (g?.gain) safeParam(g.gain, 0, rampEnd);
        });
        if (typeof this.setDelay === 'function') this.setDelay(0, adjustedRampTime + crossFadeTime);
        if (isDebug) console.debug('[Zölzer AT2030] Toàn bộ hệ thống lọc thích nghi được khôi phục về dải phẳng mượt nguyên bản.');
        return;
      }
      // 6. THIẾT LẬP KÍCH THƯỚC Ô ĐỆM (Tối ưu phản hồi live)
      const bufferTime = absPitchMult > 0 ? Math.max(0.15, this.bufferTime ?? 0.15, (this.fadeTime ?? 0.06) * 58 * (atEnabled ? 1.08 : 1.0)) : this.bufferTime ?? 0.08;
      if (bufferTime !== this.bufferTime) {
        this.bufferTime = bufferTime;
      }
      const bufferOptions = {
        smoothness: this.currentProfile === 'vocal' ? 2.1 : 1.9,
        vibrance: this.currentProfile === 'bright' ? 1.65 : 1.5,
        pitchShift: semitones,
        isVocal: isVocalMode,
        spectralProfile: sp,
        qualityMode: this.qualityMode || 'ultra-high',
        formantScale,
        harmonicBoost,
        transientSculpt,
        phaseLockFactor,
        emotionalVector,
        deviceAdaptFactor,
        grainSize: absPitchMult > 1 ? 0.068 : 0.078,
        hopSize: absPitchMult > 1 ? 0.068 / 2.7 : 0.078 / 2.8,
        grainDensity: absPitchMult > 1 ? 2.4 : 2.1
      };
      // 7. CẬP NHẬT MA TRẬN DẢI ĐỆM
      if (!this.shiftDownBuffer || !this.shiftUpBuffer || !this.fadeBuffer) {
        if (typeof getShiftBuffers === 'function' && typeof getFadeBuffer === 'function') {
          try {
            const buffers = getShiftBuffers.call(this, this.context, bufferTime, this.fadeTime ?? 0.08, bufferOptions, this.memoryManager);
            this.shiftDownBuffer = buffers.shiftDownBuffer;
            this.shiftUpBuffer = buffers.shiftUpBuffer;
            this.fadeBuffer = getFadeBuffer.call(this, this.context, bufferTime, this.fadeTime ?? 0.08, bufferOptions, this.memoryManager);
            if (isDebug) console.debug('[Zölzer AT2030] Nạp thành công dải đệm sóng hạt độc lập sạch lỗi pha.');
          } catch (bufferError) {
            if (typeof handleError === 'function') {
              handleError('AT2030 bộ nhớ đệm cập nhật thất bại vật lý', bufferError, {
                bufferOptions
              }, 'high', {
                memoryManager: this.memoryManager
              });
            }
          }
        }
      }
      // 8. ĐIỀU PHỐI BIÊN ĐỘ MODULATION GAIN
      const gainValue = adjustedPitchMult > 0 ? 1 : 0;
      const normalizationFactor = 1 / (1 + absPitchMult * 0.05) * deviceAdaptFactor;
      if (this.mod1Gain && this.mod2Gain && this.mod3Gain && this.mod4Gain) {
        const downGain = (1 - gainValue) * normalizationFactor * emotionalVector;
        const upGain = gainValue * normalizationFactor * emotionalVector;
        safeParam(this.mod1Gain.gain, downGain, rampEnd);
        safeParam(this.mod2Gain.gain, downGain, rampEnd);
        safeParam(this.mod3Gain.gain, upGain, rampEnd);
        safeParam(this.mod4Gain.gain, upGain, rampEnd);
      }
      const delayTime = (this.delayTime ?? 0.06) * absPitchMult * deviceAdaptFactor;
      if (typeof this.setDelay === 'function') this.setDelay(delayTime, adjustedRampTime);
      // 9. KHÓA PHA SINH HỌC + FORMANT (TỐI ƯU HÓA)
      let adjustedVocalPresence = vocalPresence;
      if (semitones < 0) {
        adjustedVocalPresence = Math.min(vocalPresence + (0.07 * Math.abs(semitones)), 1.25);
      }
      const entanglementFactor = bass > 0.65 ? 0.94 : 1.0;
      // Tính toán formant
      updatePreserve(_f1Preserved, semitones, this.formantF1Freq ?? 300, adjustedVocalPresence, sp, formantScale, entanglementFactor, emotionalVector, phaseLockFactor);
      updatePreserve(_f2Preserved, semitones, this.formantF2Freq ?? 1600, adjustedVocalPresence, sp, formantScale, entanglementFactor, emotionalVector, phaseLockFactor);
      if (atEnabled && semitones !== 0) {
        // Thay Hard Clamping bằng Soft Saturation để giọng nghe tự nhiên hơn khi pitch cực đoan
        const f1Limit = isFemaleVocal ? 640 : 540;
        const f2Limit = isFemaleVocal ? 2950 : 2650;
        // Tăng cường độ mềm mại bằng cách dùng lerp nhẹ
        _f1Preserved.freq = _f1Preserved.freq > f1Limit ? (f1Limit + (_f1Preserved.freq - f1Limit) * 0.15) : _f1Preserved.freq;
        _f2Preserved.freq = _f2Preserved.freq > f2Limit ? (f2Limit + (_f2Preserved.freq - f2Limit) * 0.15) : _f2Preserved.freq;
      }
      if (this.formantFilter1 && this.formantFilter2) {
        // Thay thế 0.96 cứng bằng một hệ số dựa trên phaseLockFactor để kiểm soát gain ổn định hơn
        const gainSafety = 0.95 + (phaseLockFactor * 0.04);
        safeParam(this.formantFilter1.frequency, _f1Preserved.freq, rampEnd);
        safeParam(this.formantFilter1.gain, _f1Preserved.gain * gainSafety, rampEnd);
        safeParam(this.formantFilter1.Q, _f1Preserved.q, rampEnd);
        safeParam(this.formantFilter2.frequency, _f2Preserved.freq, rampEnd);
        safeParam(this.formantFilter2.gain, _f2Preserved.gain * gainSafety, rampEnd);
        safeParam(this.formantFilter2.Q, _f2Preserved.q, rampEnd);
      }
      // 10. MẠCH LỌC THÍCH NGHI STUDIO (BẢN TỐI ƯU HÓA)
      let lowPassFreq = validateNum(this.lowPassFreq, 16000);
      let highPassFreq = validateNum(this.highPassFreq, 80);
      // NÂNG CẤP: Notch tracking theo Pitch (để luôn chặn được tần số chói khi nâng/hạ tone)
      let notchFreq = validateNum(this.notchFreq, 1000) * (1 + adjustedPitchMult * 0.12);
      notchFreq = Math.max(600, Math.min(notchFreq, 2500)); // Giới hạn dải Notch an toàn
      const filterQ = 1.0 + absPitchMult * 0.015 * phaseLockFactor;
      let notchQ = 1.2;
      if (spectralComplexity > 0.65 || this.currentProfile === 'smartStudio') {
        lowPassFreq = Math.min(lowPassFreq * 0.95 * deviceAdaptFactor, 18000);
        notchQ = 1.3 * phaseLockFactor;
      }
      if (this.currentProfile === 'vocal' || this.currentProfile === 'karaokeDynamic') {
        // NÂNG CẤP: Đảm bảo HighPass không bao giờ bị tụt xuống dưới ngưỡng an toàn (ví dụ 100Hz)
        highPassFreq = Math.max(highPassFreq * 1.15 * emotionalVector, 130);
      }
      const maxFreqChange = Math.abs(adjustedPitchMult) > 0.5 ? 600 : 350;
      // Logic xử lý thay đổi tần số (Giữ nguyên cấu trúc thông minh của bạn)
      if (adjustedPitchMult > 0) {
        const newLow = lowPassFreq * (1 - absPitchMult * 0.05) * deviceAdaptFactor;
        lowPassFreq = Math.abs(newLow - lowPassFreq) > maxFreqChange ? lowPassFreq + (newLow > lowPassFreq ? maxFreqChange : -maxFreqChange) : newLow;
        const newHigh = highPassFreq * (1 + absPitchMult * 0.002) * emotionalVector;
        highPassFreq = Math.max(highPassFreq, Math.abs(newHigh - highPassFreq) > maxFreqChange ? highPassFreq + (newHigh > highPassFreq ? maxFreqChange : -maxFreqChange) : newHigh);
      } else if (adjustedPitchMult < 0) {
        const newLow = Math.min(lowPassFreq * (1 + absPitchMult * 0.06) * deviceAdaptFactor, 20000);
        lowPassFreq = Math.abs(newLow - lowPassFreq) > maxFreqChange ? lowPassFreq + (newLow > lowPassFreq ? maxFreqChange : -maxFreqChange) : newLow;
        // NÂNG CẤP: Khi hạ tone, luôn chặn HighPass không cho quá thấp để tránh ù
        const newHigh = Math.min(highPassFreq * (1 - absPitchMult * 0.008) * emotionalVector, 180);
        highPassFreq = Math.abs(newHigh - highPassFreq) > maxFreqChange ? highPassFreq + (newHigh > highPassFreq ? maxFreqChange : -maxFreqChange) : newHigh;
      }
      if (this.lowPassFilter && this.highPassFilter && this.notchFilter) {
        safeParam(this.lowPassFilter.Q, filterQ, rampEnd);
        safeParam(this.highPassFilter.Q, filterQ, rampEnd);
        safeParam(this.lowPassFilter.frequency, lowPassFreq, rampEnd);
        safeParam(this.highPassFilter.frequency, highPassFreq, rampEnd);
        safeParam(this.notchFilter.frequency, notchFreq, rampEnd);
        safeParam(this.notchFilter.Q, notchQ, rampEnd);
      }
      // 11. BẢO VỆ MÀNG LOA + BASS LAN TỎA (BUM-BUM) & BÙ BODY (UP-TONE) - OPTIMIZED
      if (this.lowShelfFilter) {
        const isPitchDown = semitones < 0;
        const isPitchUp = semitones > 0;
        // --- TRƯỜNG HỢP: HẠ TONE (Cần ấm, lan tỏa nhưng phải kiểm soát Mud) ---
        if (isPitchDown) {
          // 78Hz là điểm vàng cho Sub-bass, giữ nguyên nhưng siết nhẹ nếu hạ quá sâu
          const lowShelfFreq = (78 - Math.min(10, Math.abs(semitones) * 0.5)) * deviceAdaptFactor;
          // Giảm bớt gain nếu tone hạ quá sâu (dưới -10) để bass không bị "phá" mid
          const depthFactor = semitones < -10 ? 0.8 : 1.0;
          let lowShelfGain = Math.min(0.48 + (Math.abs(semitones) * 0.032) * harmonicBoost * (bass > 0.6 ? 1.15 : 1.0), 0.82) * depthFactor;
          // Q rộng vừa phải để bass lan tỏa, nhưng không quá rộng để tránh lấn vào Mid
          let lowShelfQ = Math.min(0.85, 0.65 + Math.max(0, (Math.abs(semitones) - 4) * 0.035));
          if (semitones < -6) {
            const reduction = Math.min(0.62, 1.0 - (Math.abs(semitones) - 6) * 0.028);
            lowShelfGain *= reduction;
          }
          safeParam(this.lowShelfFilter.frequency, lowShelfFreq, safeTime, 'set');
          safeParam(this.lowShelfFilter.gain, lowShelfGain, rampEnd);
          if (this.lowShelfFilter.Q) safeParam(this.lowShelfFilter.Q, lowShelfQ, rampEnd);
        }
        // --- TRƯỜNG HỢP: NÂNG TONE (Cần body, chắc gọn - Tránh bị mỏng) ---
        else if (isPitchUp) {
          // Hạ tần số xuống 85Hz thay vì 95Hz để bù "Body" thay vì bù "Boxy/Ù"
          const lowShelfFreq = 85 * deviceAdaptFactor;
          // Gain tính toán kỹ hơn theo semitones để tạo độ dày tự nhiên
          let lowShelfGain = Math.min(0.20 + (semitones * 0.022), 0.50);
          // Q cố định 0.65 - hơi rộng hơn 0.6 một chút để âm thanh có độ dày (thickness) 
          // thay vì quá cứng (dry)
          let lowShelfQ = 0.65;
          safeParam(this.lowShelfFilter.frequency, lowShelfFreq, safeTime, 'set');
          safeParam(this.lowShelfFilter.gain, lowShelfGain, rampEnd);
          if (this.lowShelfFilter.Q) safeParam(this.lowShelfFilter.Q, lowShelfQ, rampEnd);
        }
        // --- TRƯỜNG HỢP: VỀ 0 (Reset phẳng) ---
        else {
          // Đảm bảo trả về trạng thái trung tính 0dB một cách êm ái
          safeParam(this.lowShelfFilter.gain, 0, rampEnd);
          safeParam(this.lowShelfFilter.frequency, 80, safeTime, 'set');
        }
      }
      // 12. BÙ GAIN + LOOKAHEAD LIMITER (Chống nổ, không cần IF)
      let outputGainBoost = 1.0 * emotionalVector;
      if (adjustedPitchMult < 0) {
        outputGainBoost = Math.max(0.92, 1.0 - Math.abs(semitones) * 0.012);
      } else if (adjustedPitchMult > 0) {
        outputGainBoost = Math.min(1.38, 1.0 + absPitchMult * 0.12 * emotionalVector);
      }
      // Luôn chạy Limiter để bắt đỉnh transient
      if (this.mainCompressor) {
        const targetThreshold = -12 - (outputGainBoost - 1.0) * 10;
        safeParam(this.mainCompressor.threshold, targetThreshold, rampEnd);
        safeParam(this.mainCompressor.ratio, 4.0, rampEnd);
        safeParam(this.mainCompressor.attack, 0.003, rampEnd);
        safeParam(this.mainCompressor.release, 0.05, rampEnd);
      }
      if (this.outputGain) safeParam(this.outputGain.gain, outputGainBoost, rampEnd);
      // 13. GIA VỊ BÙ PHỔ + ADAPTIVE DE-ESSER + TRANSIENT EXCITER + HARMONIC
      // Tăng độ nảy (Transient Exciter)
      if (this.transientExciter && transientEnergy < 0.8) {
        const transientBoost = 1.0 + (1.0 - transientEnergy) * 0.2;
        safeParam(this.transientExciter.gain, transientBoost, rampEnd);
      }
      // Adaptive De-Esser & Clarity
      let highShelfTargetGain = 0;
      let highShelfFreq = 9000;
      if (adjustedPitchMult > 0) {
        const deEsserReduction = Math.min(0.68, 0.22 + absPitchMult * 0.32 * spectralComplexity);
        highShelfTargetGain = -deEsserReduction * (isFemaleVocal ? 1.12 : 1.0);
        highShelfFreq = 8400;
      } else if (air < 0.38) {
        highShelfTargetGain = 0.78 * transientSculpt;
        highShelfFreq = 9800;
      }
      if (this.highShelfFilter) {
        safeParam(this.highShelfFilter.frequency, highShelfFreq, safeTime, 'set');
        safeParam(this.highShelfFilter.gain, highShelfTargetGain, rampEnd);
      }
      // Override gain khi transient thấp để tránh bị xì (giữ logic gốc)
      if (transientEnergy < 0.65 && this.highShelfFilter) {
        safeParam(this.highShelfFilter.gain, Math.max(highShelfTargetGain, 0.8 * transientSculpt * entanglementFactor), rampEnd);
      }
      // Cân bằng bù mid
      if (this.subMidFilter) {
        // Logic 1: Bass boost
        if (bass < 0.4) {
          safeParam(this.subMidFilter.gain, 0.3 * harmonicBoost * entanglementFactor, rampEnd);
        }
        // Logic 2: Warmth boost khi hạ tone (ghi đè nếu cần)
        if (adjustedPitchMult < 0) {
          const warmthBoost = Math.min(0.52 + (Math.abs(semitones) * 0.04) * emotionalVector * entanglementFactor, 1.0);
          safeParam(this.subMidFilter.gain, warmthBoost, rampEnd);
        }
      }
      // Harmonic Injection (Tối ưu Saturation Tracking)
      if (typeof this.applyHarmonicEnhancement === 'function') {
        const baseSat = 0.15;
        const pitchSat = Math.max(0, 0.2 - absPitchMult * 0.02);
        const intensity = (0.13 * absPitchMult * harmonicBoost * (spectralComplexity + 0.4)) * (baseSat + pitchSat);
        this.applyHarmonicEnhancement({
          intensity: intensity,
          frequencyRange: adjustedPitchMult > 0 ? [2000, 8000] : [100, 5000]
        });
      }
      // Vitamin (Giữ lại tính năng proNatural)
      if (typeof this.applyVitamin === 'function' && this.currentProfile === 'proNatural') {
        this.applyVitamin('proNatural', adjustedPitchMult, absPitchMult);
      }
      // 14. REFRESH PROFILE
      if (typeof this.setSoundProfile === 'function' && this.currentProfile) {
        if (this._profileRefreshTimeout) clearTimeout(this._profileRefreshTimeout);
        this._profileRefreshTimeout = setTimeout(() => {
          try {
            this.setSoundProfile(this.currentProfile);
            if (isDebug) console.debug('[Zölzer AT2030] Refresh thành công cấu hình âm thanh tối ưu dải động.');
          } catch (e) {
            console.warn('Yêu cầu refresh Sound Profile bị huỷ nhẹ', e);
          }
          this._profileRefreshTimeout = null;
        }, adjustedRampTime * 1000 + 40);
      }
      // 15. MEMORY MANAGER
      if (this.memoryManager) {
        if (!this._pitchLogDebounce) {
          this._pitchLogDebounce = setTimeout(() => {
            this.memoryManager.allocateBuffer('pitchConfig', {
              pitchMult: adjustedPitchMult,
              absPitchMult,
              qualityMode: this.qualityMode,
              bufferTime,
              lowPassFreq,
              highPassFreq,
              vocalClarityBoost: 0, // đã chuyển sang highShelf
              at2030Config: {
                formantScale,
                harmonicBoost,
                transientSculpt,
                phaseLockFactor,
                emotionalVector,
                deviceAdaptFactor
              },
              timestamp: Date.now(),
              expiry: Date.now() + 60000,
              priority: 'ultra-high'
            }, 'high');
            if (typeof this.calculateMaxCacheSize === 'function') {
              this.memoryManager.pruneCache(this.calculateMaxCacheSize());
            }
            this._pitchLogDebounce = null;
          }, 500);
        }
      }
      if (typeof this.notifyUIUpdate === 'function') {
        this.notifyUIUpdate({
          pitchMult: adjustedPitchMult,
          absPitchMult,
          qualityMode: this.qualityMode,
          bufferTime,
          lowPassFreq,
          highPassFreq,
          vocalClarityBoost: 0,
          timestamp: Date.now()
        });
      }
    } catch (error) {
      if (typeof handleError === 'function') {
        handleError('Lỗi nghiêm trọng mạch thiết lập dải dịch cao độ Zölzer', error, {
          mult,
          transpose,
          contextState: this.context?.state
        }, 'high', {
          memoryManager: this.memoryManager
        });
      }
      this.notifyUIError?.('Thất bại khi xử lý thay đổi cao độ âm thanh');
      if (previousState && this.outputGain?.gain) {
        safeParam(this.outputGain.gain, previousState.outputGain || 1.0, this.context.currentTime + 0.1);
      }
    }
  };
  // === ĐẶT NGOÀI CLASS / ĐẦU FILE ===
  const DEFAULT_SPECTRAL = {
    subBass: 0.5,
    bass: 0.5,
    subMid: 0.5,
    midLow: 0.5,
    midHigh: 0.5,
    high: 0.5,
    subTreble: 0.5,
    air: 0.5,
    vocalPresence: 0.5,
    transientEnergy: 0.5,
    instruments: {},
    chroma: null,
    spectralComplexity: 0.5,
    harmonicRatio: 0.5
  };
  Jungle.prototype.setBoost = function(boost, band = "all") {
    try {
      // Kiểm tra giá trị boost
      if (typeof boost !== 'number' || isNaN(boost)) {
        throw new Error('Boost must be a valid number.');
      }
      boost = Math.max(0.7, Math.min(8.0, boost));
      // Lấy thông tin thiết bị và cấu hình
      const cpuLoad = this.getCPULoad ? ensureFinite(this.getCPULoad(), 0.5) : 0.5;
      const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
      // 🪐 ĐỒNG BỘ 1: Đổi cấu hình dự phòng mặc định sang proNatural cho mộc tuyệt đối
      const profile = this.profile || 'proNatural';
      const songStructure = this.memoryManager?.get('lastStructure') || {
        section: 'unknown'
      };
      // Zero-GC: Dùng object mặc định tĩnh
      const spectralProfile = this.spectralProfile || DEFAULT_SPECTRAL;
      const feedbackList = this.memoryManager?.get('userFeedback') || [];
      const isVocalFeedback = feedbackList.find(f => f.timestamp > Date.now() - 60000 && f.semanticCategory === 'vocal');
      const rms = this.rms || 0.1;
      const limiterFactor = rms > 0.15 || spectralProfile.transientEnergy > 0.8 ? 0.85 : 1.0;
      // Kiểm tra AudioContext
      if (!(this.context instanceof AudioContext)) {
        throw new Error('AudioContext is not initialized.');
      }
      const currentTime = this.context.currentTime;
      // Dynamic Boost Adjustment
      let rampTime = ensureFinite(this.rampTime, DEFAULT_RAMP_TIME);
      // 🪐 ĐỒNG BỘ 2: Chỉ làm chậm rampTime đối với profile cũ, proNatural giữ nguyên tốc độ gốc để âm thanh phản hồi sắc nét
      if (profile === 'bright' || profile === 'smartStudio' || profile === 'vocal') {
        rampTime *= 1.4;
      } else if (isLowPowerDevice && cpuLoad > 0.9) {
        rampTime *= 0.7;
      }
      let adjustedBoost = boost;
      // 🪐 ĐỒNG BỘ 3: Cô lập hoàn toàn proNatural, không tự ý kích 10% âm lượng ở đoạn Chorus làm hỏng Dynamic Range nguyên bản
      if (profile !== 'proNatural' && songStructure.section === 'chorus') {
        adjustedBoost *= 1.1;
        adjustedBoost = Math.max(0.7, Math.min(8.0, adjustedBoost));
      }
      if (isVocalFeedback && band === 'vocal') {
        adjustedBoost *= 1.1;
        adjustedBoost = Math.max(0.7, Math.min(8.0, adjustedBoost));
      }
      // Helper applyRamp (DRY + chống pop/click)
      const applyRamp = (param, value) => {
        if (param && param instanceof AudioParam) {
          param.cancelScheduledValues(currentTime);
          param.linearRampToValueAtTime(value, currentTime + rampTime);
        }
      };
      // Apply boost theo band
      if (band === 'all' || band === 'total') {
        if (!this.boostGain?.gain) throw new Error('boostGain is not initialized');
        applyRamp(this.boostGain.gain, adjustedBoost * limiterFactor);
      } else if (band === 'bass') {
        if (!this.lowShelfGain?.gain || !this.subBassFilter?.gain) throw new Error('lowShelfGain or subBassFilter is not initialized');
        const bassBoost = adjustedBoost * (profile === 'bassHeavy' ? 1.8 : 1.6) * limiterFactor;
        applyRamp(this.lowShelfGain.gain, bassBoost);
        applyRamp(this.subBassFilter.gain, adjustedBoost * 1.3 * limiterFactor);
      } else if (band === 'subMid') {
        if (!this.subMidFilter?.gain) throw new Error('subMidFilter is not initialized');
        const subMidBoost = adjustedBoost * (spectralProfile.spectralComplexity > 0.7 ? 1.4 : 1.2) * limiterFactor;
        applyRamp(this.subMidFilter.gain, subMidBoost);
      } else if (band === 'mid') {
        if (!this.midShelfGain?.gain) throw new Error('midShelfGain is not initialized');
        applyRamp(this.midShelfGain.gain, adjustedBoost * 1.3 * limiterFactor);
      } else if (band === 'highMid') {
        if (!this.highMidFilter?.gain) throw new Error('highMidFilter is not initialized');
        const highMidBoost = adjustedBoost * (profile === 'bright' ? 1.4 : 1.2) * limiterFactor;
        applyRamp(this.highMidFilter.gain, highMidBoost);
      } else if (band === 'treble') {
        if (!this.highShelfGain?.gain || !this.subTrebleFilter?.gain) throw new Error('highShelfGain or subTrebleFilter is not initialized');
        const trebleBoost = adjustedBoost * (profile === 'bright' ? 1.6 : 1.4) * limiterFactor;
        applyRamp(this.highShelfGain.gain, trebleBoost);
        applyRamp(this.subTrebleFilter.gain, adjustedBoost * 1.3 * limiterFactor);
      } else if (band === 'air') {
        if (!this.airFilter?.gain) throw new Error('airFilter is not initialized');
        // 🪐 ĐỒNG BỘ 4: Khóa cứng hệ số dải không khí về 1.0 phẳng cho proNatural, triệt tiêu hiện tượng chói gắt dải cao
        const airBoost = adjustedBoost * ((profile === 'smartStudio') ? 1.2 : 1.0) * limiterFactor;
        applyRamp(this.airFilter.gain, airBoost);
      } else if (band === 'vocal') {
        if (!this.formantFilter1?.gain || !this.formantFilter2?.gain || !this.formantFilter3?.gain) {
          throw new Error('formantFilter1, formantFilter2, or formantFilter3 is not initialized');
        }
        const vocalBoost = adjustedBoost * (isVocalFeedback || profile === 'vocal' ? 1.2 : 1.0) * limiterFactor;
        applyRamp(this.formantFilter1.gain, vocalBoost);
        applyRamp(this.formantFilter2.gain, vocalBoost);
        applyRamp(this.formantFilter3.gain, vocalBoost);
      } else {
        throw new Error(`Invalid band: ${band}`);
      }
      // Lưu trạng thái vào memoryManager
      if (this.memoryManager) {
        const cacheKey = `boostState_${this.contextId}_${profile}_${band}`;
        this.memoryManager.set(cacheKey, {
          data: {
            boost: adjustedBoost,
            band,
            rampTime,
            timestamp: Date.now(),
            profile,
            songStructure,
            spectralProfile,
            isVocalFeedback,
            limiterFactor
          },
          expiry: Date.now() + (isLowPowerDevice ? 30000 : 60000),
          priority: 'high'
        }, 'high');
        this.memoryManager.pruneCache(this.memoryManager.getDynamicMaxSize?.() || 50);
      }
      const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
      if (isDebug) {
        console.debug(`Hi-Fi Boost set to ${adjustedBoost.toFixed(3)} for band: ${band} (Profile: ${profile})`);
      }
    } catch (error) {
      handleError('Error setting boost:', error, {
        boost,
        band,
        profile: this.profile,
        cpuLoad: this.getCPULoad?.() || 0.5,
        isLowPowerDevice: navigator.hardwareConcurrency < 4,
        contextState: this.context?.state,
        isVocalFeedback,
        limiterFactor: limiterFactor || 1.0
      }, 'high', {
        memoryManager: this.memoryManager
      });
    }
  };
  Jungle.prototype.setPan = function(pan) {
    try {
      // Kiểm tra giá trị pan
      if (typeof pan !== 'number' || isNaN(pan)) {
        throw new Error('Pan must be a valid number.');
      }
      pan = Math.max(-1, Math.min(1, pan));
      // Lấy thông tin thiết bị và cấu hình
      const cpuLoad = this.getCPULoad ? ensureFinite(this.getCPULoad(), 0.5) : 0.5;
      const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
      // 🪐 ĐỒNG BỘ 1: Đổi cấu hình dự phòng mặc định sang proNatural
      const profile = this.profile || 'proNatural';
      const songStructure = this.memoryManager?.get('lastStructure') || {
        section: 'unknown'
      };
      const spectralProfile = this.spectralProfile || {
        subBass: 0.5,
        bass: 0.5,
        subMid: 0.5,
        midLow: 0.5,
        midHigh: 0.5,
        high: 0.5,
        subTreble: 0.5,
        air: 0.5,
        vocalPresence: 0.5,
        transientEnergy: 0.5,
        instruments: {},
        chroma: null,
        spectralComplexity: 0.5,
        harmonicRatio: 0.5
      };
      // Kiểm tra panner node và AudioContext
      if (!this.panner || !(this.context instanceof AudioContext)) {
        throw new Error('Panner node or AudioContext is not initialized.');
      }
      // Dynamic Pan Adjustment
      let rampTime = ensureFinite(this.rampTime, DEFAULT_RAMP_TIME);
      // 🪐 ĐỒNG BỘ 2: Chỉ làm chậm rampTime đối với profile cũ, proNatural giữ tốc độ gốc để định vị âm hình siêu tốc
      if (profile === 'bright' || profile === 'smartStudio') {
        rampTime *= 1.2;
      } else if (isLowPowerDevice && cpuLoad > 0.9) {
        rampTime *= 0.8;
      }
      // 🪐 ĐỒNG BỘ 3: Cô lập proNatural hoàn toàn, nói KHÔNG với việc tự ý nhân 1.1 lần làm lệch vị trí nhạc cụ ở Chorus
      if (profile !== 'proNatural' && songStructure.section === 'chorus') {
        pan *= 1.1;
        pan = Math.max(-1, Math.min(1, pan));
      }
      // Stable Pan Transition – tinh hoa cancelScheduledValues + fallback mộc
      const currentTime = this.context.currentTime;
      if (this.panner.pan) {
        this.panner.pan.cancelScheduledValues(currentTime);
        this.panner.pan.linearRampToValueAtTime(pan, currentTime + rampTime);
      } else if (typeof this.panner.setPosition === 'function') {
        this.panner.setPosition(pan, 0, 1 - Math.abs(pan));
      }
      // Lưu trạng thái pan vào memoryManager dưới nhãn cấu hình mới
      if (this.memoryManager) {
        const cacheKey = `panState_${this.contextId}_${profile}`;
        this.memoryManager.set(cacheKey, {
          data: {
            pan,
            rampTime,
            timestamp: Date.now(),
            profile,
            songStructure,
            spectralProfile
          },
          expiry: Date.now() + (isLowPowerDevice ? 30000 : 60000),
          priority: 'high'
        }, 'high');
        this.memoryManager.pruneCache(this.memoryManager.getDynamicMaxSize?.() || 50);
      }
      const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
      if (isDebug) {
        console.debug('Hi-Fi Pan set successfully (No artificial distortion):', {
          pan,
          rampTime,
          profile
        });
      }
    } catch (error) {
      handleError('Error setting pan:', error, {
        pan,
        profile: this.profile,
        cpuLoad: this.getCPULoad?.() || 0.5,
        isLowPowerDevice: navigator.hardwareConcurrency < 4,
        contextState: this.context?.state
      }, 'high', {
        memoryManager: this.memoryManager
      });
    }
  };
  // === ĐẶT CHỈ MỘT LẦN Ở ĐẦU FILE ===
  const DEFAULT_SPECTRAL_PROFILE = {
    subBass: 0.5,
    bass: 0.5,
    subMid: 0.5,
    midLow: 0.5,
    midHigh: 0.5,
    high: 0.5,
    subTreble: 0.5,
    air: 0.5,
    vocalPresence: 0.5,
    transientEnergy: 0.5,
    instruments: {},
    chroma: null,
    spectralComplexity: 0.5,
    harmonicRatio: 0.5
  };
  Jungle.prototype.ensureAudioContext = function() {
    return new Promise((resolve, reject) => {
      try {
        // Lấy thông tin thiết bị và cấu hình
        const cpuLoad = this.getCPULoad ? ensureFinite(this.getCPULoad(), 0.5) : 0.5;
        const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
        // 🪐 ĐỒNG BỘ 1: Đổi cấu hình dự phòng khởi tạo sang proNatural
        const profile = this.profile || 'proNatural';
        const songStructure = this.memoryManager?.get('lastStructure') || {
          section: 'unknown'
        };
        // Zero-GC: Sử dụng object mặc định tĩnh (chỉ khai báo 1 lần)
        const spectralProfile = this.spectralProfile || DEFAULT_SPECTRAL_PROFILE;
        // Real-time Neural Network Integration
        const detectInstrument = (sp) => {
          const scoreDrum = sp.transientEnergy * 0.6 + sp.bass * 0.4;
          const scoreGuitar = sp.midHigh * 0.5 + sp.transientEnergy * 0.3 + sp.spectralComplexity * 0.2;
          const scorePiano = sp.midHigh * 0.4 + sp.spectralComplexity * 0.4 + sp.transientEnergy * 0.2;
          const scoreVocal = sp.vocalPresence * 0.7 + sp.midHigh * 0.3;
          const scores = {
            drum: scoreDrum,
            guitar: scoreGuitar,
            piano: scorePiano,
            vocal: scoreVocal
          };
          return Object.keys(scores).reduce((a, b) => scores[a] > scores[b] ? a : b, 'vocal');
        };
        const validateSpectralProfile = (sp) => {
          let validityScore = 1.0;
          if (sp.bass > 0.85 && sp.transientEnergy < 0.65) validityScore *= 0.9;
          if (sp.midHigh > 0.8) validityScore *= 1.05;
          if (sp.air > 0.85 && sp.spectralComplexity > 0.85) validityScore *= 0.85;
          return validityScore >= 0.9;
        };
        const instrumentType = detectInstrument(spectralProfile);
        const curveType = (instrumentType === 'drum' || instrumentType === 'vocal') ? 'cosine' : 'exponential';
        const isSpectralValid = validateSpectralProfile(spectralProfile);
        // Tinh hoa: AudioCtxClass fallback an toàn
        const AudioCtxClass = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtxClass) {
          const error = new Error('Web Audio API is not supported in this environment.');
          handleError('Error ensuring AudioContext:', error, {
            profile,
            cpuLoad,
            isLowPowerDevice,
            instrumentType
          }, 'high', {
            memoryManager: this.memoryManager
          });
          reject(error);
          return;
        }
        // Kiểm tra và khởi tạo lại AudioContext nếu cần
        if (!(this.context instanceof AudioContext) || this.context.state === 'closed') {
          if (this.ownsContext) {
            // Tinh hoa: close context cũ trước tạo mới
            if (this.context) {
              this.context.close().catch(e => console.warn('Error closing old AudioContext:', e));
            }
            this.context = new AudioCtxClass();
            this.ownsContext = true;
            // Tinh hoa: baseLatency tăng khi CPU cao hạ nhiệt
            if (isLowPowerDevice && cpuLoad > 0.9) {
              try {
                this.context.baseLatency = Math.min(this.context.baseLatency * 1.4, 0.12);
              } catch (e) {}
            }
            // Tái tạo buffer
            const bufferOptions = {
              // 🪐 ĐỒNG BỘ 2: Chỉ profile cũ mới kích ảo độ mượt, proNatural khóa cứng chuẩn mộc 1.4
              smoothness: (profile === 'vocal' || profile === 'bright') ? 1.6 : 1.4,
              // 🪐 ĐỒNG BỘ 3: Chỉ smartStudio cũ mới nịnh tai thêm Vibrance, proNatural khóa cứng chuẩn mộc 0.55
              vibrance: (profile === 'smartStudio') ? 0.65 : 0.55,
              pitchShift: this.currentPitchMult || 0,
              isVocal: this.isVocal || profile === 'vocal',
              spectralProfile,
              currentGenre: this.currentGenre || 'Unknown',
              noiseLevel: this.noiseLevel || {
                level: 0,
                midFreq: 0.5,
                white: 0.5
              },
              wienerGain: this.wienerGain || 1,
              polyphonicPitches: this.polyphonicPitches || [],
              qualityMode: this.qualityMode || 'high',
              profile,
              songStructure,
              instrumentType,
              curveType
            };
            const bTime = this.bufferTime || 0.3;
            const fTime = this.fadeTime || 0.15;
            const buffers = getShiftBuffers(this.context, bTime, fTime, bufferOptions, this.memoryManager);
            this.shiftDownBuffer = buffers.shiftDownBuffer;
            this.shiftUpBuffer = buffers.shiftUpBuffer;
            this.fadeBuffer = getFadeBuffer(this.context, bTime, fTime, bufferOptions, this.memoryManager);
            if (!this.shiftDownBuffer || !this.shiftUpBuffer || !this.fadeBuffer || !isSpectralValid) {
              throw new Error('Failed to create valid buffers or spectral profile invalid');
            }
            if (this.fadeBuffer.length < bTime * this.context.sampleRate) {
              throw new Error('fadeBuffer length insufficient');
            }
            this.initializeNodes();
            // Lưu trạng thái buffer vào memoryManager
            if (this.memoryManager) {
              const cacheKey = `bufferState_${this.contextId}_${profile}_${instrumentType}_${curveType}`;
              this.memoryManager.set(cacheKey, {
                data: {
                  shiftDownLength: this.shiftDownBuffer.length,
                  shiftUpLength: this.shiftUpBuffer.length,
                  fadeBufferLength: this.fadeBuffer.length,
                  bufferTime: bTime,
                  fadeTime: fTime,
                  timestamp: Date.now(),
                  profile,
                  songStructure,
                  instrumentType,
                  curveType
                },
                expiry: Date.now() + (isLowPowerDevice ? 60000 : 120000),
                priority: 'high'
              });
              this.memoryManager.pruneCache(50);
            }
            resolve(true);
          } else {
            const error = new Error('Invalid or closed AudioContext and no ownership to reinitialize.');
            handleError('Error ensuring AudioContext:', error, {
              profile,
              cpuLoad,
              isLowPowerDevice,
              instrumentType
            }, 'high', {
              memoryManager: this.memoryManager
            });
            reject(error);
          }
          return;
        }
        // Xử lý trạng thái AudioContext
        switch (this.context.state) {
          case 'suspended':
            const resumeOnUserGesture = () => {
              this.context.resume().then(() => resolve(true)).catch(error => {
                // Điềm tĩnh xử lý lỗi, không kích hoạt thông báo UI Error bừa bãi khi user chưa click
                console.debug('AudioCtx resume delayed until next real click.');
                reject(error);
              });
            };
            // TINH HOA FIX: Đổi từ hasBeenActive thành isActive để chặn đứng lệnh gọi ép buộc
            const isTransientActive = (navigator.userActivation?.isActive || document.userActivation?.isActive);
            if (isTransientActive) {
              resumeOnUserGesture();
            } else {
              const userGestureHandler = () => {
                resumeOnUserGesture();
                ['click', 'touchstart', 'keydown'].forEach(e => document.removeEventListener(e, userGestureHandler));
              };
              ['click', 'touchstart', 'keydown'].forEach(e => document.addEventListener(e, userGestureHandler));
            }
            break;
          case 'running':
            if (this._analyser && this._analyser.fftSize !== DEFAULT_FFT_SIZE) {
              this._analyser.fftSize = DEFAULT_FFT_SIZE;
            }
            resolve(true);
            break;
          default:
            resolve(true);
            break;
        }
        // Debug logging
        const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
        if (isDebug) {
          console.debug('AudioContext ensured (Hi-Fi Mode)', {
            state: this.context.state,
            sampleRate: this.context.sampleRate,
            bufferTime: this.bufferTime || 0.3,
            fadeTime: this.fadeTime || 0.15,
            cpuLoad,
            isLowPowerDevice,
            profile,
            songStructure,
            instrumentType,
            curveType,
            cacheStats: this.memoryManager?.getCacheStats?.()
          });
        }
      } catch (error) {
        handleError('Error ensuring AudioContext:', error, {
          ownsContext: this.ownsContext,
          contextState: this.context?.state,
          profile,
          cpuLoad,
          isLowPowerDevice,
          instrumentType
        }, 'high', {
          memoryManager: this.memoryManager
        });
        reject(error);
      }
    });
  };
  Jungle.prototype.disconnect = function() {
    try {
      // 1. Dọn dẹp các thành phần logic và worker
      const profile = this.profile || 'proNatural';
      const cpuLoad = this.getCPULoad ? ensureFinite(this.getCPULoad(), 0.5) : 0.5;
      const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
      const songStructure = this.memoryManager?.get('lastStructure') || {
        section: 'unknown'
      };
      // Anti-pop ramp
      if (this.outputGain?.gain) {
        const now = this.context.currentTime;
        this.outputGain.gain.cancelScheduledValues(now);
        this.outputGain.gain.setValueAtTime(this.outputGain.gain.value, now);
        this.outputGain.gain.linearRampToValueAtTime(0, now + 0.01);
      }
      // Stop audio sources
      if (this.isStarted) {
        [this.mod1, this.mod2, this.mod3, this.mod4, this.fade1, this.fade2].forEach(node => {
          if (node?.stop) try {
            node.stop();
          } catch (e) {}
        });
        this.isStarted = false;
      }
      if (this._pitchLogDebounce) clearTimeout(this._pitchLogDebounce);
      if (this.audioAnalysisInterval) clearInterval(this.audioAnalysisInterval);
      // Terminate worker
      if (this.worker) {
        try {
          this.worker.postMessage({
            command: 'cleanup',
            profile
          });
          this.worker.terminate();
        } catch (e) {}
        this.worker = null;
      }
      // 2. Disconnect Audio Nodes (Sử dụng Set để loại bỏ trùng lặp tự động)
      const audioNodes = new Set([
        this.input, this.rumbleHighPass, this.bassHighPassFilter, this.highPassFilter,
        this.lowShelfGain, this.subBassFilter, this.subMidFilter, this.midBassFilter,
        this.midShelfGain, this.highMidFilter, this.formantFilter1, this.formantFilter2,
        this.formantFilter3, this.delay1, this.delay2, this.mix1, this.mix2,
        this.boostGain, this.panner, this.highShelfGain, this.subTrebleFilter,
        this.airFilter, this.trebleLowPass, this.lowPassFilter, this.notchFilter,
        this.compressor, this.outputGain, this.output, this.pannerNode,
        this.foaDecoder, this.reverb, this.reverbGain
      ]);
      audioNodes.forEach(node => {
        if (node && typeof node.disconnect === 'function') {
          try {
            if (node.gain) node.gain.cancelScheduledValues(this.context.currentTime);
            if (node.frequency) node.frequency.cancelScheduledValues(this.context.currentTime);
            node.disconnect();
          } catch (e) {
            console.debug('Node disconnect issue:', e);
          }
        }
      });
      // 3. Xử lý kết nối bổ sung
      const modConnections = [{
        g: this.mod1Gain,
        t: this.modGain1
      }, {
        g: this.mod2Gain,
        t: this.modGain2
      }, {
        g: this.mod3Gain,
        t: this.modGain1
      }, {
        g: this.mod4Gain,
        t: this.modGain2
      }];
      modConnections.forEach(({
        g,
        t
      }) => g?.disconnect(t));
      this.modGain1?.disconnect(this.delay1?.delayTime);
      this.modGain2?.disconnect(this.delay2?.delayTime);
      this.fade1?.disconnect(this.mix1?.gain);
      this.fade2?.disconnect(this.mix2?.gain);
      this._analyser?.disconnect();
      // 4. Nullify references (Garbage Collection)
      const nodeRefs = ['mod1', 'mod2', 'mod3', 'mod4', 'fade1', 'fade2', 'mod1Gain', 'mod2Gain', 'mod3Gain', 'mod4Gain', 'modGain1', 'modGain2', 'mix1', 'mix2', 'delay1', 'delay2', 'input', 'output', 'boostGain', 'panner', 'bassHighPassFilter', 'highPassFilter', 'lowShelfGain', 'subBassFilter', 'subMidFilter', 'midBassFilter', 'midShelfGain', 'highMidFilter', 'formantFilter1', 'formantFilter2', 'formantFilter3', 'highShelfGain', 'subTrebleFilter', 'airFilter', 'trebleLowPass', 'lowPassFilter', 'notchFilter', 'outputGain', 'compressor', 'worker', 'memoryManager', 'pannerNode', 'foaDecoder', 'reverb', 'reverbGain', 'reverbBuffer', 'rumbleHighPass'];
      nodeRefs.forEach(ref => this[ref] = null);
      // --- CHÈN VÀO ĐÂY ---
      // Làm sạch triệt để trạng thái EQ cộng dồn và các thông số phụ trợ
      this.spectralProfile = {
        subBass: 0.5,
        bass: 0.5,
        subMid: 0.5,
        midLow: 0.5,
        midHigh: 0.5,
        high: 0.5,
        subTreble: 0.5,
        air: 0.5,
        vocalPresence: 0.5,
        transientEnergy: 0.5,
        instruments: {},
        chroma: null,
        spectralComplexity: 0.5,
        harmonicRatio: 0.5
      };
      this.userFeedbackAdjust = {
        bass: 0,
        mid: 0,
        treble: 0,
        air: 0,
        vocalClarity: 0,
        warmth: 0
      };
      if (this.outputGain && this.outputGain.gain) {
        this.outputGain.gain.cancelScheduledValues(this.context.currentTime);
        this.outputGain.gain.setValueAtTime(1.0, this.context.currentTime);
      }
      // ---------------------
      // Clear buffers và quản lý memoryManager
      this.shiftDownBuffer = null;
      // Clear buffers và quản lý memoryManager
      this.shiftDownBuffer = null;
      this.shiftUpBuffer = null;
      this.fadeBuffer = null;
      if (this.memoryManager) {
        this.memoryManager.buffers.clear();
        const cacheKey = `disconnectState_${this.contextId}_${profile}`;
        this.memoryManager.set(cacheKey, {
          data: {
            isStarted: false,
            timestamp: Date.now(),
            profile,
            songStructure,
            cpuLoad
          },
          expiry: Date.now() + (isLowPowerDevice ? 30000 : 60000),
          priority: 'high'
        }, 'high');
        this.memoryManager.pruneCache(this.memoryManager.getDynamicMaxSize?.() || 100);
      }
      // Khôi phục tham số mặc định mộc
      this.delayTime = DEFAULT_DELAY_TIME;
      this.fadeTime = DEFAULT_FADE_TIME;
      this.bufferTime = DEFAULT_BUFFER_TIME;
      this.rampTime = DEFAULT_RAMP_TIME;
      this.lowPassFreq = DEFAULT_LOW_PASS_FREQ;
      this.highPassFreq = DEFAULT_HIGH_PASS_FREQ;
      this.notchFreq = DEFAULT_NOTCH_FREQ;
      this.filterQ = DEFAULT_FILTER_Q;
      this.notchQ = DEFAULT_NOTCH_Q;
      this.formantF1Freq = DEFAULT_FORMANT_F1_FREQ;
      this.formantF2Freq = DEFAULT_FORMANT_F2_FREQ;
      this.formantF3Freq = DEFAULT_FORMANT_F3_FREQ;
      this.formantQ = DEFAULT_FORMANT_Q;
      this.subMidFreq = DEFAULT_SUBMID_FREQ;
      this.subTrebleFreq = DEFAULT_SUBTREBLE_FREQ;
      this.midBassFreq = DEFAULT_MIDBASS_FREQ;
      this.highMidFreq = DEFAULT_HIGHMID_FREQ;
      this.airFreq = DEFAULT_AIR_FREQ;
      this.spectralProfile = {
        subBass: 0.5,
        bass: 0.5,
        subMid: 0.5,
        midLow: 0.5,
        midHigh: 0.5,
        high: 0.5,
        subTreble: 0.5,
        air: 0.5,
        vocalPresence: 0.5,
        transientEnergy: 0.5,
        instruments: {},
        chroma: null,
        spectralComplexity: 0.5,
        harmonicRatio: 0.5
      };
      this.tempoMemory = null;
      this.currentGenre = 'Unknown';
      this.currentKey = {
        key: 'Unknown',
        confidence: 0,
        isMajor: true
      };
      this.currentProfile = profile;
      this.nextProcessingInterval = 800;
      this.currentPitchMult = 0;
      this.noiseLevel = {
        level: 0,
        midFreq: 0.5,
        white: 0.5
      };
      this.qualityPrediction = {
        score: 0,
        recommendations: []
      };
      this.isVocal = profile === 'vocal';
      this.wienerGain = 1;
      this.polyphonicPitches = [];
      this.transientBoost = DEFAULT_TRANSIENT_BOOST;
      // Đóng AudioContext nếu sở hữu – tinh hoa async + gỡ tham chiếu ngay
      if (this.ownsContext && this.context) {
        const ctxToClose = this.context;
        this.context = null;
        ctxToClose.close().then(() => console.debug('AudioContext closed successfully under Hi-Fi profile:', {
          profile
        })).catch(error => {
          handleError('Error closing AudioContext:', error, {
            profile
          }, 'high');
        });
      }
      // Debug logging
      const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
      if (isDebug) {
        console.debug('Jungle disconnected successfully without memory leaks!', {
          cpuLoad,
          isLowPowerDevice,
          profile,
          songStructure,
          isStarted: this.isStarted,
          ownsContext: this.ownsContext
        });
      }
    } catch (error) {
      handleError('Error during Jungle disconnect:', error, {
        isStarted: this.isStarted,
        ownsContext: this.ownsContext,
        profile: this.profile || 'proNatural',
        cpuLoad: this.getCPULoad?.() || 0.5,
        isLowPowerDevice: navigator.hardwareConcurrency ? navigator.hardwareConcurrency < 4 : false
      }, 'high', {
        memoryManager: this.memoryManager
      });
      throw error;
    }
  };
  Jungle.prototype.reset = function() {
    try {
      // Tinh hoa: dọn gesture handler cũ tránh leak
      if (this._userGestureHandler) {
        document.removeEventListener('click', this._userGestureHandler);
        document.removeEventListener('touchstart', this._userGestureHandler);
        this._userGestureHandler = null;
      }
      // Disconnect và dọn dẹp trạng thái hiện tại
      this.disconnect();
      this.isStarted = false;
      // Lấy thông tin thiết bị và cấu hình
      const cpuLoad = this.getCPULoad ? ensureFinite(this.getCPULoad(), 0.5) : 0.5;
      const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
      // 🪐 ĐỒNG BỘ 1: Đổi cấu hình dự phòng mặc định sang proNatural
      const profile = this.profile || 'proNatural';
      const songStructure = this.memoryManager?.get('lastStructure') || {
        section: 'unknown'
      };
      // Tinh hoa: self-healing AudioContext khi ownsContext
      if (this.ownsContext) {
        if (this.context) {
          this.context.close().catch(e => console.warn('Error closing AudioContext:', e));
        }
        this.context = new(window.AudioContext || window.webkitAudioContext)();
        if (this.context.state === 'suspended') {
          this._userGestureHandler = () => {
            this.context.resume().then(() => console.debug('AudioContext resumed after reset'));
            document.removeEventListener('click', this._userGestureHandler);
            document.removeEventListener('touchstart', this._userGestureHandler);
            this._userGestureHandler = null;
          };
          document.addEventListener('click', this._userGestureHandler);
          document.addEventListener('touchstart', this._userGestureHandler);
        }
      } else if (!(this.context instanceof AudioContext)) {
        throw new Error('Invalid AudioContext after reset');
      }
      // Tinh hoa: getDef gọn thay DEFAULT constants
      // === ĐỒNG BỘ HOÀN TOÀN THEO HẰNG SỐ STUDIO MỚI ===
      const getDef = (val, def) => (typeof val !== 'undefined' ? val : def);
      this.delayTime = getDef(window.DEFAULT_DELAY_TIME, 0.080);
      this.fadeTime = getDef(window.DEFAULT_FADE_TIME, 0.100);
      this.bufferTime = getDef(window.DEFAULT_BUFFER_TIME, 0.200);
      this.rampTime = getDef(window.DEFAULT_RAMP_TIME, 0.075);
      this.lowPassFreq = getDef(window.DEFAULT_LOW_PASS_FREQ, 18000);
      this.highPassFreq = getDef(window.DEFAULT_HIGH_PASS_FREQ, 30); // Đồng bộ: 30Hz cắt móng trầm sạch sẽ
      this.notchFreq = getDef(window.DEFAULT_NOTCH_FREQ, 1000); // Đồng bộ: 1000Hz vùng an toàn khi nghe nhạc
      this.filterQ = getDef(window.DEFAULT_FILTER_Q, 0.707); // Đồng bộ: 0.707 phẳng pha tuyến tính
      this.notchQ = getDef(window.DEFAULT_NOTCH_Q, 10.0); // Đồng bộ: Q lớn để siết nhiễu hẹp
      this.formantF1Freq = getDef(window.DEFAULT_FORMANT_F1_FREQ, 550);
      this.formantF2Freq = getDef(window.DEFAULT_FORMANT_F2_FREQ, 2000);
      this.formantF3Freq = getDef(window.DEFAULT_FORMANT_F3_FREQ, 3200);
      this.formantQ = getDef(window.DEFAULT_FORMANT_Q, 1.8);
      this.subMidFreq = getDef(window.DEFAULT_SUBMID_FREQ, 500);
      this.subTrebleFreq = getDef(window.DEFAULT_SUBTREBLE_FREQ, 11000);
      this.midBassFreq = getDef(window.DEFAULT_MIDBASS_FREQ, 200);
      this.highMidFreq = getDef(window.DEFAULT_HIGHMID_FREQ, 2800); // Đồng bộ: 2800Hz tách bạch dải trung cao trong trẻo
      this.airFreq = getDef(window.DEFAULT_AIR_FREQ, 13000);
      this.qualityMode = 'high';
      this.currentPitchMult = 0;
      this.isVocal = profile === 'vocal';
      this.wienerGain = 1;
      this.polyphonicPitches = [];
      this.transientBoost = getDef(window.DEFAULT_TRANSIENT_BOOST, 0.5);
      this.nextProcessingInterval = 800;
      this.currentGenre = 'Unknown';
      this.currentKey = {
        key: 'Unknown',
        confidence: 0,
        isMajor: true
      };
      this.currentProfile = profile;
      this.noiseLevel = {
        level: 0,
        midFreq: 0.5,
        white: 0.5
      };
      this.qualityPrediction = {
        score: 0,
        recommendations: []
      };
      this.spectralProfile = {
        subBass: 0.5,
        bass: 0.5,
        subMid: 0.5,
        midLow: 0.5,
        midHigh: 0.5,
        high: 0.5,
        subTreble: 0.5,
        air: 0.5,
        vocalPresence: 0.5,
        transientEnergy: 0.5,
        instruments: {},
        chroma: null,
        spectralComplexity: 0.5,
        harmonicRatio: 0.5
      };
      this.tempoMemory = null;
      // Tinh hoa: clear cache cũ nếu memoryManager có
      if (this.memoryManager) {
        if (typeof this.memoryManager.clear === 'function') {
          this.memoryManager.clear();
        }
      } else {
        this.memoryManager = new MemoryManager();
      }
      // Smart Reset Algorithm: Tính toán bufferTime
      const pitchMultFactor = 1 + Math.abs(this.currentPitchMult) * 0.6;
      let bufferTime = Math.max(this.bufferTime, this.fadeTime * 2.7 * pitchMultFactor);
      // 🪐 ĐỒNG BỘ 2: Chỉ áp dụng nhân tỉ lệ bộ đệm cho cấu hình cũ, proNatural giữ nguyên kích thước gốc để tiếng nhạc đập nảy, dứt khoát
      if (profile === 'bright' || profile === 'smartStudio' || profile === 'vocal') {
        bufferTime *= 1.3;
      } else if (isLowPowerDevice && cpuLoad > 0.9) {
        bufferTime *= 0.9;
      }
      if (bufferTime < this.fadeTime * 2.7) {
        bufferTime = this.fadeTime * 2.7;
      }
      // Tinh hoa: hard-limit với MAX_DELAY_TIME
      if (this.delayTime > MAX_DELAY_TIME) {
        this.delayTime = MAX_DELAY_TIME;
      }
      this.bufferTime = bufferTime;
      // Tạo lại các buffer – tinh hoa fallback trùng khớp cấu hình xuất phát ban đầu
      try {
        const bufferOptions = {
          // 🪐 ĐỒNG BỘ 3: Đồng nhất thông số hình học sóng với hàm ensureAudioContext, triệt tiêu hiện tượng lệch màu sau khi Reset
          smoothness: (profile === 'vocal' || profile === 'bright') ? 1.6 : 1.4,
          vibrance: (profile === 'smartStudio') ? 0.65 : 0.55,
          pitchShift: this.currentPitchMult,
          isVocal: this.isVocal,
          spectralProfile: this.spectralProfile,
          currentGenre: this.currentGenre,
          noiseLevel: this.noiseLevel,
          wienerGain: this.wienerGain,
          polyphonicPitches: this.polyphonicPitches,
          qualityMode: this.qualityMode,
          profile,
          songStructure
        };
        const buffers = getShiftBuffers(this.context, this.bufferTime, this.fadeTime, bufferOptions, this.memoryManager);
        this.shiftDownBuffer = buffers.shiftDownBuffer;
        this.shiftUpBuffer = buffers.shiftUpBuffer;
        this.fadeBuffer = getFadeBuffer(this.context, this.bufferTime, this.fadeTime, bufferOptions, this.memoryManager);
        if (!this.shiftDownBuffer || !this.shiftUpBuffer || !this.fadeBuffer) {
          throw new Error('Failed to create valid buffers after reset');
        }
        if (this.fadeBuffer.length < this.bufferTime * this.context.sampleRate) {
          throw new Error('fadeBuffer length insufficient after reset');
        }
        // Lưu trạng thái buffer vào memoryManager
        const cacheKey = `bufferState_${this.contextId}_${profile}`;
        this.memoryManager.set(cacheKey, {
          data: {
            shiftDownLength: this.shiftDownBuffer.length,
            shiftUpLength: this.shiftUpBuffer.length,
            fadeBufferLength: this.fadeBuffer.length,
            bufferTime: this.bufferTime,
            fadeTime: this.fadeTime,
            timestamp: Date.now()
          },
          expiry: Date.now() + (isLowPowerDevice ? 30000 : 60000),
          priority: 'high'
        }, 'high');
      } catch (error) {
        handleError('Error creating buffers after reset', error, {
          profile
        }, 'high', {
          memoryManager: this.memoryManager
        });
      }
      // Khởi tạo lại các node phần cứng mộc
      try {
        this.initializeNodes();
      } catch (error) {
        handleError('Error initializing nodes after reset', error, {
          profile
        }, 'high', {
          memoryManager: this.memoryManager
        });
        if (this.ownsContext) this.context.close();
        throw error;
      }
      // Khởi tạo lại worker nếu cần
      if (this.worker) {
        this.initializeWorker();
      }
      // Lưu trạng thái reset tĩnh vào memoryManager
      const resetCacheKey = `resetState_${this.contextId}_${profile}`;
      this.memoryManager.set(resetCacheKey, {
        data: {
          isStarted: false,
          qualityMode: this.qualityMode,
          bufferTime: this.bufferTime,
          profile,
          songStructure,
          timestamp: Date.now()
        },
        expiry: Date.now() + 60000,
        priority: 'high'
      }, 'high');
      this.memoryManager.pruneCache(this.memoryManager.getDynamicMaxSize?.() || 100);
      // Debug logging
      const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
      if (isDebug) {
        console.debug('Jungle reset successfully under Hi-Fi profile', {
          sampleRate: this.context.sampleRate,
          bufferTime: this.bufferTime,
          fadeTime: this.fadeTime,
          profile
        });
      }
    } catch (error) {
      handleError('Error during Jungle reset:', error, {
        ownsContext: this.ownsContext,
        contextState: this.context?.state,
        qualityMode: this.qualityMode,
        profile: this.profile,
        cpuLoad,
        isLowPowerDevice
      }, 'high', {
        memoryManager: this.memoryManager
      });
      throw error;
    }
  };
  // === ĐẶT Ở ĐẦU FILE (CHỈ 1 LẦN) ===
  const DEFAULT_SPECTRAL_FILTER = Object.freeze({
    subBass: 0.5,
    bass: 0.5,
    subMid: 0.5,
    midLow: 0.5,
    midHigh: 0.5,
    high: 0.5,
    subTreble: 0.5,
    air: 0.5,
    vocalPresence: 0.5,
    transientEnergy: 0.5,
    spectralComplexity: 0.5
  });
  // Optimizer - chỉ định nghĩa 1 lần
  const crystalToneOptimizerV2 = (freq, voiceType, spectral, profile, specComplex, absPitch, cpuLoad) => {
    const clarityFactor = profile === 'vocal' || profile === 'karaokeDynamic' ? 1.15 : profile === 'proNatural' ? 1.1 : 1.0;
    const vocalClarity = spectral.vocalPresence > 0.65 ? 1.1 : 0.95;
    const clarityBoost = Math.min(1.25, clarityFactor * vocalClarity * (1.0 + specComplex * 0.15));
    const bassResonance = profile === 'bassHeavy' ? 0.9 : profile === 'vocal' ? 0.8 : 0.85;
    const bassClarity = Math.max(0.8, Math.min(1.2, 1.0 - (spectral.bass * 0.3)));
    const bassFactor = bassResonance * bassClarity * (1.0 - absPitch * 0.1);
    const transientSculpt = profile === 'rockMetal' ? 1.1 : profile === 'bassHeavy' ? 1.0 : 0.85;
    let transientFactor = Math.min(1.15, spectral.transientEnergy * transientSculpt * (1.0 - absPitch * 0.15));
    if (cpuLoad > 0.8) transientFactor *= 0.7;
    if (absPitch > 0.5) transientFactor *= 0.85;
    const freqNorm = freq / 1200;
    const purityFilter = 1 / (1 + freqNorm * freqNorm) * clarityBoost;
    const maskingThreshold = Math.pow(10, -specComplex / 20) * purityFilter * 1.3;
    const filterTuning = voiceType === 'high' ? 0.9 : voiceType === 'low' ? 1.1 : 1.0;
    const pitchShiftImpact = absPitch > 0.5 ? 0.85 : 1.0;
    const totalToneFactor = clarityBoost * bassFactor * transientFactor * maskingThreshold * filterTuning * pitchShiftImpact;
    return Math.max(0.75, Math.min(1.25, totalToneFactor));
  };
  Jungle.prototype.setFilterParams = function({
    lowPassFreq,
    highPassFreq,
    notchFreq,
    filterQ,
    notchQ,
    lowShelfGain,
    highShelfGain,
    outputGain
  }) {
    try {
      const currentTime = this.context.currentTime;
      const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
      if (!this.context || !(this.context instanceof AudioContext) || this.context.state === 'closed') {
        throw new Error('Invalid or closed AudioContext');
      }
      const rampStart = currentTime + 0.005;
      const spectral = this.spectralProfile || DEFAULT_SPECTRAL_FILTER;
      const specComplex = spectral.spectralComplexity || 0.5;
      const currentPitch = this.currentPitchMult || 0;
      const absPitch = Math.abs(currentPitch);
      let genreFactor = 1.0;
      switch (this.currentGenre) {
        case 'EDM':
        case 'Drum & Bass':
          genreFactor = 1.15;
          break;
        case 'Hip-Hop':
          genreFactor = 1.1;
          break;
        case 'Pop':
          genreFactor = 1.0;
          break;
        case 'Bolero':
          genreFactor = 0.85;
          break;
        case 'Classical/Jazz':
          genreFactor = 0.8;
          break;
        case 'Rock/Metal':
          genreFactor = 1.1;
          break;
        case 'Karaoke':
          genreFactor = 0.9;
          break;
      }
      const cpuLoad = this.getCPULoad ? this.getCPULoad() : 0.5;
      const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
      const isOverloaded = cpuLoad > 0.8 || isLowPowerDevice;
      const qualityMode = isOverloaded ? 'low' : this.qualityMode || 'high';
      const deviceAdaptFactor = Math.max(0.65, Math.min(1.0, 1.0 - (cpuLoad * 0.2) * (isLowPowerDevice ? 0.35 : 0.1)));
      const rms = this.rms || 0.1;
      const limiterFactor = (rms > 0.15 || spectral.transientEnergy > 0.8) ? 0.8 : 0.95;
      let voiceType = 'middle';
      let fundamentalFreq = 440;
      if (this.polyphonicPitches?.length > 0) {
        fundamentalFreq = this.polyphonicPitches[0]?.frequency || fundamentalFreq;
      }
      if (fundamentalFreq <= 240) voiceType = 'low';
      else if (fundamentalFreq <= 480) voiceType = 'middle';
      else voiceType = 'high';
      const profile = this.profile || 'proNatural';
      const toneFactor = crystalToneOptimizerV2(fundamentalFreq, voiceType, spectral, profile, specComplex, absPitch, cpuLoad);
      const isGenreBoost = ['Pop', 'Karaoke', 'EDM'].includes(this.currentGenre);
      const transientBoost = spectral.transientEnergy > 0.6 && isGenreBoost ? 1.2 + (this.transientBoost || 0) * 1.2 : 1.0;
      const subBassAdjust = spectral.subBass < 0.4 ? 1.6 : spectral.subBass > 0.7 ? -0.7 : 0;
      const trebleAdjust = spectral.air > 0.8 || spectral.subTreble > 0.8 ? -1.2 : (voiceType === 'high' ? -0.3 : 0);
      const noiseReduction = this.noiseLevel?.level > 0.7 || this.wienerGain < 0.8 ? 1.2 : 1.0;
      const maxPitchShift = voiceType === 'high' ? 0.5 : 0.8;
      const adjustedPitchMult = Math.max(-maxPitchShift, Math.min(maxPitchShift, currentPitch));
      const absAdjustedPitch = Math.abs(adjustedPitchMult);
      let bufferTimeFactor = qualityMode === 'high' ? 1.4 : 0.9;
      if (specComplex > 0.7 || absAdjustedPitch > 0.3) bufferTimeFactor *= 1.15;
      this.bufferTime = Math.max(this.fadeTime * 2.2, this.bufferTime * bufferTimeFactor * deviceAdaptFactor);
      if (absAdjustedPitch > 0.2 || specComplex > 0.7 || voiceType === 'high') {
        const bufferOptions = {
          fadeType: 'bezier',
          smoothness: voiceType === 'high' ? 1.4 : 1.2,
          vibrance: voiceType === 'high' ? 0.75 : 0.55,
          pitchShift: adjustedPitchMult,
          isVocal: this.isVocal,
          spectralProfile: spectral,
          qualityMode,
          vocalPresence: spectral.vocalPresence
        };
        try {
          this.fadeBuffer = getFadeBuffer(this.context, this.bufferTime, this.fadeTime, bufferOptions, this.memoryManager);
          if (!this.fadeBuffer) throw new Error("Fade buffer null");
          this.memoryManager?.pruneCache(this.memoryManager.getDynamicMaxSize?.() || 100);
        } catch (bufErr) {
          console.error("Failed to update fade buffer", bufErr);
        }
      }
      const applyParam = (param, value) => {
        if (param && Number.isFinite(value)) {
          const safeTime = rampStart + (qualityMode === 'low' ? 0 : this.rampTime * deviceAdaptFactor);
          param.cancelScheduledValues(currentTime);
          if (qualityMode === 'low') {
            param.setValueAtTime(value, safeTime);
          } else {
            try {
              param.linearRampToValueAtTime(value, safeTime);
            } catch (e) {
              param.setValueAtTime(value, safeTime);
            }
          }
        }
      };
      // Low-pass filter
      if (lowPassFreq !== undefined && this.lowPassFilter?.frequency) {
        this.lowPassFreq = Math.max(20, Math.min(20000, lowPassFreq));
        this.lowPassFreq = spectral.air > 0.7 || voiceType === 'high' ? Math.min(this.lowPassFreq, 15000) : this.lowPassFreq;
        if (specComplex > 0.7 && absAdjustedPitch > 0.5) this.lowPassFreq *= 0.95;
        applyParam(this.lowPassFilter.frequency, this.lowPassFreq * toneFactor);
      }
      // High-pass filter
      if (highPassFreq !== undefined && this.highPassFilter?.frequency) {
        this.highPassFreq = Math.max(20, Math.min(20000, highPassFreq));
        this.highPassFreq = spectral.subBass > 0.6 ? Math.max(this.highPassFreq, 60) : this.highPassFreq;
        if (voiceType === 'high') this.highPassFreq = Math.max(this.highPassFreq, 90);
        applyParam(this.highPassFilter.frequency, this.highPassFreq * toneFactor);
      }
      // Notch filter
      if (notchFreq !== undefined && this.notchFilter?.frequency) {
        this.notchFreq = Math.max(20, Math.min(20000, notchFreq));
        this.notchFreq = this.noiseLevel?.midFreq > 0.5 || voiceType === 'high' ? 4200 : this.notchFreq;
        applyParam(this.notchFilter.frequency, this.notchFreq * toneFactor);
      }
      if (notchQ !== undefined && this.notchFilter?.Q) {
        this.notchQ = Math.max(0.1, Math.min(10, notchQ));
        this.notchQ *= noiseReduction * (voiceType === 'high' ? 0.75 : 0.95);
        applyParam(this.notchFilter.Q, this.notchQ * toneFactor);
      }
      // Low-shelf filter
      if (lowShelfGain !== undefined && this.lowShelfGain?.gain && this.subBassFilter?.gain) {
        const adjustedLowShelfGain = (lowShelfGain + subBassAdjust * genreFactor * (voiceType === 'high' ? 0.65 : 0.9)) * limiterFactor * toneFactor;
        applyParam(this.lowShelfGain.gain, Math.min(3.5, adjustedLowShelfGain));
        applyParam(this.subBassFilter.gain, Math.min(3.5, adjustedLowShelfGain * 0.45));
      }
      // High-shelf filter
      if (highShelfGain !== undefined && this.highShelfGain?.gain && this.subTrebleFilter?.gain) {
        const adjustedHighShelfGain = (highShelfGain + trebleAdjust + (transientBoost > 1.2 ? 0.7 : 0) + (voiceType === 'high' ? 0.3 : 0)) * limiterFactor * toneFactor;
        applyParam(this.highShelfGain.gain, Math.min(3.5, adjustedHighShelfGain));
        applyParam(this.subTrebleFilter.gain, Math.min(3.5, adjustedHighShelfGain * 0.45));
      }
      // Output gain
      if (outputGain !== undefined && this.outputGain?.gain) {
        const adjustedOutputGain = outputGain * (1 + absAdjustedPitch * 0.1) * (voiceType === 'high' ? 0.95 : 1.0) * limiterFactor * toneFactor;
        applyParam(this.outputGain.gain, Math.min(3.5, adjustedOutputGain));
      }
      // De-essing
      if (this.deEsser?.gain) {
        const deEssGain = (spectral.air > 0.8 || spectral.subTreble > 0.8 || voiceType === 'high') ? -2.5 : -1.2;
        applyParam(this.deEsser.gain, deEssGain);
      }
      // Formant adjustment
      if (this.formantFilter1 && this.formantFilter2) {
        let f1Freq = 450,
          f2Freq = 1900,
          formantGain = 2.5,
          formantQ = 0.85;
        const vpFactor = spectral.vocalPresence * 0.1;
        if (voiceType === 'high') {
          f1Freq = 560 * (1 + vpFactor);
          f2Freq = 2300 * (1 + vpFactor);
          formantGain = 2.2;
          formantQ = 0.55;
        } else if (voiceType === 'middle') {
          f1Freq = 450 * (1 + vpFactor);
          f2Freq = 1900 * (1 + vpFactor);
          formantGain = 2.7;
          formantQ = 0.85;
        } else {
          f1Freq = 340 * (1 + vpFactor);
          f2Freq = 1500 * (1 + vpFactor);
          formantGain = 3.0;
          formantQ = 1.1;
        }
        if (absAdjustedPitch > 0.3) {
          const pitchShiftFactor = Math.pow(2, adjustedPitchMult * 0.45);
          f1Freq *= pitchShiftFactor;
          f2Freq *= pitchShiftFactor;
          formantGain = Math.max(1.8, formantGain - absAdjustedPitch * 0.2);
        }
        formantGain *= limiterFactor * toneFactor;
        applyParam(this.formantFilter1.frequency, f1Freq * toneFactor);
        applyParam(this.formantFilter1.gain, Math.min(3.5, formantGain));
        applyParam(this.formantFilter1.Q, formantQ * toneFactor);
        applyParam(this.formantFilter2.frequency, f2Freq * toneFactor);
        applyParam(this.formantFilter2.gain, Math.min(3.5, formantGain));
        applyParam(this.formantFilter2.Q, formantQ * toneFactor);
      }
      // Quality Prediction Recommendations (ĐẦY ĐỦ)
      if (this.qualityPrediction?.recommendations) {
        this.qualityPrediction.recommendations.forEach(rec => {
          if (typeof rec !== 'string') return;
          if (rec.includes("Reduce sub-bass") && this.lowShelfGain?.gain && this.subBassFilter?.gain) {
            const reducedLowShelfGain = Math.max(this.lowShelfGain.gain.value - 1.2, 0);
            const reducedSubBassGain = Math.max(this.subBassFilter.gain.value - 0.6, 0);
            applyParam(this.lowShelfGain.gain, Math.min(3.5, reducedLowShelfGain * limiterFactor * toneFactor));
            applyParam(this.subBassFilter.gain, Math.min(3.5, reducedSubBassGain * limiterFactor * toneFactor));
          }
          if (rec.includes("Reduce treble/sub-treble") && this.highShelfGain?.gain && this.subTrebleFilter?.gain) {
            const reducedHighShelfGain = Math.max(this.highShelfGain.gain.value - (voiceType === 'high' ? 1.0 : 1.2), 0);
            const reducedSubTrebleGain = Math.max(this.subTrebleFilter.gain.value - (voiceType === 'high' ? 0.5 : 0.6), 0);
            applyParam(this.highShelfGain.gain, Math.min(3.5, reducedHighShelfGain * limiterFactor * toneFactor));
            applyParam(this.subTrebleFilter.gain, Math.min(3.5, reducedSubTrebleGain * limiterFactor * toneFactor));
          }
          if (rec.includes("Apply noise reduction") && this.notchFilter?.Q && this.notchFilter?.frequency) {
            applyParam(this.notchFilter.Q, this.notchQ * (voiceType === 'high' ? 1.2 : 1.6));
            applyParam(this.notchFilter.frequency, voiceType === 'high' ? 4200 : 3800);
          }
          if (rec.includes("Boost vocal clarity") && this.highMidFilter?.gain && this.formantFilter1?.gain && this.formantFilter2?.gain) {
            applyParam(this.highMidFilter.gain, Math.min(3.5, (this.highMidFilter.gain.value + (voiceType === 'high' ? 1.6 : 1.2)) * limiterFactor * toneFactor));
            applyParam(this.formantFilter1.gain, Math.min(3.5, (this.formantFilter1.gain.value + 0.3) * limiterFactor * toneFactor));
            applyParam(this.formantFilter2.gain, Math.min(3.5, (this.formantFilter2.gain.value + 0.3) * limiterFactor * toneFactor));
          }
        });
      }
      // Harmonic enhancement
      if (this.polyphonicPitches?.length > 0 && this.highMidFilter?.frequency && this.highMidFilter?.gain) {
        const dominantPitch = this.polyphonicPitches[0]?.frequency || fundamentalFreq;
        const targetFreq = Math.min(dominantPitch * (voiceType === 'high' ? 2.0 : 1.8), 3200);
        applyParam(this.highMidFilter.frequency, targetFreq * toneFactor);
        applyParam(this.highMidFilter.gain, Math.min(3.5, (this.highMidFilter.gain.value + (voiceType === 'high' ? 1.6 : 1.2)) * limiterFactor * toneFactor));
      }
      // Lưu voice profile
      if (this.memoryManager) {
        this.memoryManager.buffers.set('voiceProfile', {
          voiceType,
          fundamentalFreq,
          vocalPresence: spectral.vocalPresence,
          toneFactor,
          timestamp: Date.now(),
          expiry: Date.now() + 8000
        });
        this.memoryManager.pruneCache(this.memoryManager.getDynamicMaxSize?.() || 100);
      }
      if (isDebug) {
        console.debug('Filter parameters set successfully with CrystalToneOptimizerV2', {
          lowPassFreq: this.lowPassFreq,
          highPassFreq: this.highPassFreq,
          notchFreq: this.notchFreq,
          notchQ: this.notchQ,
          lowShelfGain,
          highShelfGain,
          outputGain,
          spectralProfile: spectral,
          qualityMode,
          cpuLoad,
          isLowPowerDevice,
          voiceType,
          fundamentalFreq,
          limiterFactor,
          deviceAdaptFactor,
          toneFactor,
          transientBoost,
          subBassAdjust,
          trebleAdjust,
          noiseReduction
        });
      }
    } catch (error) {
      console.error('Error setting filter parameters with CrystalToneOptimizerV2:', error, {
        lowPassFreq,
        highPassFreq,
        notchFreq,
        filterQ,
        notchQ,
        lowShelfGain,
        highShelfGain,
        outputGain,
        spectralProfile: this.spectralProfile,
        qualityMode,
        voiceType,
        limiterFactor,
        toneFactor
      });
    }
  };
  Jungle.prototype.setSoundProfile = function(profile) {
    try {
      this.currentProfile = profile;
      const currentTime = this.context.currentTime;
      // --- CHUẨN HÓA SPECTRAL PROFILE (Zero-GC Validation) ---
      const spectral = this.spectralProfile || {
        subBass: 0.5,
        bass: 0.5,
        subMid: 0.5,
        midLow: 0.5,
        midHigh: 0.5,
        high: 0.5,
        subTreble: 0.5,
        air: 0.5,
        vocalPresence: 0.5,
        transientEnergy: 0.5,
        instruments: {},
        chroma: null,
        spectralFlux: 0.5,
        spectralEntropy: 0.5,
        harmonicRatio: 0.5
      };
      const genreFactor = {
        'EDM': 1.2,
        'Drum & Bass': 1.2,
        'Hip-Hop': 1.1,
        'Pop': 1.0,
        'Bolero': 0.9,
        'Classical/Jazz': 0.8,
        'Rock/Metal': 1.0,
        'Karaoke': 0.9
      } [this.currentGenre] || 1.0;
      // === KHỞI TẠO BIẾN GỐC + ĐỒNG BỘ HOÀN TOÀN TRÁNH TEMPORAL DEAD ZONE ===
      let warmthBoost = 0.9;
      let subBassBoost = 0.2;
      let subMidBoost = 0.6;
      let midBoost = 0.3;
      let trebleReduction = 0.8;
      let harmonicBoost = 0.6;
      let transientBoostAdjust = 0.6;
      let smartWarmthAdjust = 1.2;
      let bassCutFreq = 45;
      let trebleCutFreq = 15000;
      let f1Freq = 440;
      let f2Freq = 1850;
      let formantGain = 3.2;
      let formantQ = 0.9;
      // UI-BRIDGE WAITING SLOTS: Cổng chờ kết nối thanh UI trượt chỉnh tay (Bass/Treble/Mid/Air) lưu nhớ cấu hình riêng sau này
      const uiBridge = this.customUiOffsets || {
        bass: 0,
        treble: 0,
        mid: 0,
        air: 0,
        warmth: 0,
        clarity: 0,
        vocalClarity: 0,
        depth: 0
      };
      // === LỚP CẢM BIẾN PHÂN TÍCH NGỮ CẢNH THỜI GIAN THỰC ===
      const contextAnalyzer = this.initializeContextAnalyzer();
      const startTime = performance.now();
      const musicContext = contextAnalyzer.analyze({
        spectralProfile: spectral,
        tempoMemory: this.tempoMemory,
        currentGenre: this.currentGenre,
        currentKey: this.currentKey,
        polyphonicPitches: this.polyphonicPitches,
        noiseLevel: this.noiseLevel,
        qualityPrediction: this.qualityPrediction,
        isVocal: this.isVocal
      });
      const songStructure = this.analyzeSongStructure({
        spectralProfile: spectral,
        tempoMemory: this.tempoMemory,
        polyphonicPitches: this.polyphonicPitches,
        currentGenre: this.currentGenre
      });
      // STATIC DEVICE ADAPTATION: Điều chỉnh lưới FFTSize theo tải xử lý thực tế của thiết bị
      const processingTime = performance.now() - startTime;
      let fftSize = 2048;
      let enableSubharmonic = true;
      let enableAdvancedDeEsser = true;
      let enableCNNTransient = true;
      if (processingTime > 16) {
        fftSize = processingTime > 30 ? 512 : 1024;
        enableSubharmonic = processingTime < 25;
        enableAdvancedDeEsser = processingTime < 20;
        enableCNNTransient = processingTime < 22;
        console.debug('High CPU load detected, optimizing performance...');
      }
      this.setFFTSize(fftSize);
      // Tối ưu hóa độ lợi bộ lọc Wiener thích nghi dải cao
      this.wienerGain = (spectral.subTreble > 0.6 || spectral.air > 0.6) ? 0.95 : 0.93;
      this.noiseLevel = {
        level: (spectral.subTreble > 0.6 || spectral.air > 0.6) ? 0.35 : 0.25,
        midFreq: (spectral.subTreble > 0.6 || spectral.air > 0.6) ? 5000 : 3500,
        lowFreq: spectral.subBass > 0.7 ? 200 : 150
      };
      if (musicContext.spectralComplexity > 0.65) {
        this.wienerGain = Math.max(0.90, this.wienerGain - 0.02);
      }
      if (musicContext.transientEnergy < 0.35) {
        this.noiseLevel.level = Math.min(0.40, this.noiseLevel.level + 0.05);
      }
      // Khóa lag pha thời gian thực dựa vào thuộc tính làm mượt Bezier
      this.fadeTime = musicContext.fadeTime || (0.35 * (this.isVocal ? 1.1 : 1.0));
      this.bufferTime = musicContext.bufferTime || (0.55 * (1 + Math.abs(this.currentPitchMult || 0) * 0.35));
      this.fadeBuffer = getFadeBuffer(this.context, this.bufferTime, this.fadeTime, {
        fadeType: musicContext.fadeType || 'bezier',
        smoothness: musicContext.smoothness || 2.0,
        vibrance: musicContext.vibrance || 0.9,
        pitchShift: this.currentPitchMult,
        isVocal: this.isVocal,
        spectralProfile: spectral,
        currentGenre: this.currentGenre,
        noiseLevel: this.noiseLevel,
        wienerGain: this.wienerGain,
        polyphonicPitches: this.polyphonicPitches
      }, this.memoryManager);
      // --- ĐOẠN ĐỒNG BỘ GAIN CHỐNG NHỎ TIẾNG (AUTO GAIN STAGING PHI TUYẾN) ---
      if (!this.outputGain?.gain) throw new Error("outputGain is not initialized");
      const currentAbsPitch = Math.abs(this.currentPitchMult || 0);
      let dynamicGain = this.currentProfile ? 0.8 : 0.7;
      if (currentAbsPitch > 0) {
        dynamicGain += (currentAbsPitch * 0.15);
      }
      // Áp dụng giới hạn mềm bảo vệ đỉnh sóng (Headroom Safe Cap) chống méo vỡ tiếng
      const rawFinalGain = dynamicGain * genreFactor;
      const finalGain = Math.min(1.15, Math.tanh(rawFinalGain * 1.05) * 1.1);
      this.outputGain.gain.linearRampToValueAtTime(finalGain, currentTime + (this.rampTime || 0.1));
      this.setPan(0);
      // --- PHÂN TÍCH CHỈ SỐ CẢM NHẬN PHỔ (PERCEPTUAL SPECTRAL SEPARATION) ---
      const pitchMult = this.currentPitchMult || 0;
      const absPitchMult = Math.abs(pitchMult);
      const dynamicFactor = Math.min(1 + absPitchMult * 0.25, 1.25);
      const warmthIndex = (spectral.bass + spectral.subMid) / 2 - (spectral.high + spectral.subTreble) / 2;
      const needsWarmth = warmthIndex < 0.5;
      const subBassIndex = (spectral.subBass + spectral.bass) / 2;
      const needsSubBass = subBassIndex < 0.7;
      const subMidIndex = spectral.subMid;
      const needsSubMid = subMidIndex < 0.7;
      const midIndex = (spectral.midLow + spectral.midHigh) / 2;
      const needsMid = midIndex < 0.7;
      const trebleIndex = (spectral.high + spectral.subTreble + spectral.air) / 3;
      const needsTrebleReduction = trebleIndex > 0.5;
      const isPiercing = trebleIndex > 0.55 || spectral.subTreble > 0.65 || spectral.air > 0.65;
      const isMuddy = (spectral.subMid > 0.55 || spectral.midLow > 0.55 || spectral.bass > 0.65);
      const muddyIndex = Math.max(0, (spectral.subMid - 0.5 + spectral.midLow - 0.5) * 1.5);
      const clarityIndex = (spectral.midHigh + spectral.high + spectral.air) / 3;
      const transparencyFactor = isMuddy ? Math.max(0.55, 1.0 - muddyIndex * 0.65) : 1.0;
      const presenceBoost = clarityIndex < 0.5 ? (0.5 - clarityIndex) * 1.5 + 1.0 : 1.0;
      const airNaturalBoost = clarityIndex > 0.6 ? 1.15 : (clarityIndex < 0.4 ? 1.35 : 1.05);
      const transientDamping = Math.min(1.0, 1.15 / (1.0 + (spectral.transientEnergy || 0.5) * (spectral.spectralFlux || 0.5)));
      warmthBoost = needsWarmth ? Math.min(3.0, (0.5 - warmthIndex) * 4.8) : 0.9;
      subBassBoost = needsSubBass ? Math.min(3.2, (0.7 - subBassIndex) * 5.8) : 0.2;
      subMidBoost = needsSubMid ? Math.min(3.0, (0.7 - subMidIndex) * 5.8) : 0.6;
      midBoost = needsMid ? Math.min(3.0, (0.7 - midIndex) * 5.8) : 0.3;
      trebleReduction = isPiercing ? Math.min(4.5, (trebleIndex - 0.5) * 6.5) : 0.8;
      smartWarmthAdjust = (this.isVocal || spectral.vocalPresence > 0.65) ? 1.5 : 1.2;
      if (spectral.spectralEntropy > 0.65) smartWarmthAdjust *= 0.75;
      if (['Bolero', 'Classical/Jazz', 'Karaoke'].includes(this.currentGenre)) {
        smartWarmthAdjust *= 1.6;
        subMidBoost *= 1.5;
      } else if (['EDM', 'Drum & Bass', 'Hip-Hop'].includes(this.currentGenre)) {
        subBassBoost *= 1.4;
      }
      // === THỰC THI 6 KHỐI CHỨC NĂNG ĐỊNH HÌNH VẬT LÝ (STATIC PIPELINE PROTECTED) ===
      if (this.harmonicExciter) {
        const excitement = spectral.harmonicRatio > 0.7 || this.isVocal ? 0.7 + Math.tanh(spectral.transientEnergy) * 1.8 : 0.4;
        this.harmonicExciter.gain.value = excitement;
        this.harmonicExciter.frequency.value = 8000 + spectral.air * 4000;
      }
      if (enableSubharmonic && this.subharmonicEnhancer && needsSubBass) {
        const phaseAlign = Math.sin(currentTime * 0.3) * 0.12 + 0.88;
        // Sử dụng mảng phân bổ tĩnh đã tính toán thay vì tái khởi tạo mảng động liên tục gây rác GC
        if (!this._staticSubCurve) this._staticSubCurve = new Float32Array(512);
        for (let i = 0; i < 512; i++) {
          const x = (i - 256) / 256;
          this._staticSubCurve[i] = Math.sin(3.141592653589793 * x * 1.1) * subBassBoost * phaseAlign * 1.15;
        }
        this.subharmonicEnhancer.curve = this._staticSubCurve;
      }
      if (this.isVocal && spectral.vocalPresence > 0.75 && this.breathPreserver) {
        const breathEnergy = spectral.air > 0.65 ? 1.8 : 1.0;
        this.breathPreserver.gain.linearRampToValueAtTime(breathEnergy * 0.9, currentTime + 0.1);
        this.breathPreserver.frequency.value = 12000 + spectral.air * 3000;
      }
      if (this.microDynamics && enableCNNTransient) {
        const microGain = 1.0 + spectral.transientEnergy * 2.8 + (spectral.instruments?.guitar ? 1.5 : 0);
        this.microDynamics.threshold.value = -48 - spectral.transientEnergy * 18;
        this.microDynamics.ratio.value = 1.8 + microGain * 0.4;
        this.microDynamics.attack.value = 0.0015;
        this.microDynamics.release.value = 0.08;
      }
      if (pitchMult !== 0 && this.artifactPredictor && this.formantCorrector) {
        const predicted = Math.abs(pitchMult) > 6 ? Math.pow(Math.abs(pitchMult) / 12, 2.2) * 0.28 : 0;
        this.artifactPredictor.gain.linearRampToValueAtTime(1.0 + predicted * 2.8, currentTime + 0.02);
        this.formantCorrector.delayTime.setValueAtTime(0.0008 + predicted * 0.0012, currentTime);
      }
      if (enableCNNTransient && this.transientShaperVocal && this.transientShaperDrums) {
        const vocalT = this.isVocal ? spectral.vocalPresence : 0;
        const drumT = spectral.transientEnergy > 0.7 ? 1.5 : 0.8;
        this.transientShaperVocal.attack.value = 0.002 + vocalT * 0.008;
        this.transientShaperVocal.release.value = 0.12 - vocalT * 0.06;
        this.transientShaperDrums.attack.value = 0.001;
        this.transientShaperDrums.release.value = 0.05 + drumT * 0.03;
        this.transientShaperDrums.gain.value = drumT * 1.8;
      }
      const noiseFactor = this.noiseLevel.level > 0.45 || this.wienerGain < 0.9 ? 2.4 : 1.3;
      let notchQ = this.notchQ * noiseFactor * 4.5;
      let notchFreq = (this.noiseLevel.level > 0.3 || spectral.subTreble > 0.6) ? 6000 : 5000;
      transientBoostAdjust = enableCNNTransient && spectral.transientEnergy > 0.55 ? 0.8 : 0.6;
      const transientGenres = ["EDM", "Drum & Bass", "Hip-Hop", "Rock/Metal"];
      const isTransientGenre = transientGenres.includes(this.currentGenre);
      let polyphonicAdjust = 0;
      if (this.polyphonicPitches && this.polyphonicPitches.length > 0) {
        polyphonicAdjust = this.polyphonicPitches.length > 1 ? 1.4 : 1.2;
      } else {
        const chromaVariance = spectral.chroma?.reduce((sum, val) => sum + val * val, 0) / (spectral.chroma?.length || 1);
        polyphonicAdjust = chromaVariance > 0.15 ? 0.9 : 0.2;
      }
      harmonicBoost = 0.6 + warmthBoost * 0.4 + (spectral.instruments?.guitar || spectral.instruments?.piano ? 0.5 : 0.3) + polyphonicAdjust + (spectral.harmonicRatio > 0.65 ? 0.4 : 0.2);
      const subharmonicGain = enableSubharmonic && needsSubBass && (this.currentGenre === "EDM" || this.currentGenre === "Hip-Hop") ? 3.0 : 1.4;
      if (enableSubharmonic && this.subharmonicEnhancer) {
        if (!this._staticGainCurve) this._staticGainCurve = new Float32Array(512);
        for (let i = 0; i < 512; i++) {
          const x = (i - 256) / 256;
          this._staticGainCurve[i] = Math.sin(3.141592653589793 * x * 1.1) * subharmonicGain * 0.35;
        }
        this.subharmonicEnhancer.curve = this._staticGainCurve;
        if (this.subBassFilter && this.subMidFilter) {
          this.subBassFilter.disconnect();
          this.subBassFilter.connect(this.subharmonicEnhancer);
          this.subharmonicEnhancer.connect(this.subMidFilter);
        }
      }
      // === THUẬT TOÁN PITCH V5.9 SMART-AI: KIỂM SOÁT BÙ TRỪ FORMANT PHI TUYẾN CHUYÊN SÂU ===
      if (pitchMult !== 0) {
        const shiftIntensity = Math.min(absPitchMult / 12, 1.0);
        const genre = this.currentGenre || "Default";
        const baseSubBass = spectral.subBass || 0.5;
        let genreScale = 1.0;
        if (absPitchMult >= 1.0) {
          if (genre === "Karaoke" || genre === "Jazz" || genre === "Classical") genreScale = 0.92;
          else if (genre === "Rock" || genre === "Metal") genreScale = 0.95;
          else if (genre === "EDM" || genre === "Drum & Bass") genreScale = 1.08;
        }
        const perceptualIntensity = shiftIntensity * genreScale;
        if (pitchMult < 0) {
          // --- HẠ TONE PITCH DOWN: GIỮ ĐỘ DÀY TỰ NHIÊN - BASS TRONG VẮT LAN TỎA KHÔNG Ú Ú ĐỤC MUD ---
          const down = perceptualIntensity;
          const formantComp = 1.0 + down * 0.55 + Math.pow(down, 2) * 0.25;
          f1Freq *= formantComp;
          f2Freq *= (formantComp * 1.02);
          // Khử hoàn toàn tần số ám đục vùng 300-500Hz khi giọng hạ thấp
          const mudReduction = down * 4.2 + Math.pow(down, 1.8) * 2.8;
          const dynamicBassCut = Math.log1p(down * 6.0) * 1.8 * 0.6;
          subMidBoost = Math.max(0.01, subMidBoost - mudReduction);
          subBassBoost = Math.max(0.01, subBassBoost - dynamicBassCut);
          // NÂNG CẤP: Boost nhẹ dải Mid-High (tần số giọng thật) và tạo độ lan tỏa tự nhiên thông qua warmthSpread
          const warmthSpread = Math.pow(down, 1.4) * 3.5;
          warmthBoost = Math.max(0.5, warmthBoost + warmthSpread - down * 0.4);
          midBoost += down * 1.5; // Giữ độ thoát cho tiếng ca không bị mờ tối
          bassCutFreq = Math.max(32, Math.min(38, bassCutFreq));
          // Bù đắp dải gió Air nhuyễn mịn để tăng cường độ rõ nét
          const airBoost = Math.pow(down, 1.6) * 6.5;
          trebleReduction = Math.max(0.01, trebleReduction - airBoost);
          this.wienerGain = Math.min(0.999, (this.wienerGain || 1.0) + down * 0.18);
          harmonicBoost += down * 3.2;
        } else {
          // --- NÂNG TONE PITCH UP: TRẢ LẠI SỨC SỐNG DẢI TRẦM LAN TỎA - KHÔNG CHÓI GẮT THIẾU MÀU ---
          const up = perceptualIntensity;
          const bodyComp = 1.0 - up * 0.45;
          f1Freq *= bodyComp;
          f2Freq *= (bodyComp * 1.05);
          const isHeavyBass = (baseSubBass > 0.6);
          const smartBassCap = isHeavyBass ? 1.2 : 3.8;
          const spreadFactor = Math.pow(up, 1.2);
          subBassBoost += spreadFactor * smartBassCap;
          warmthBoost += spreadFactor * (smartBassCap * 0.85);
          formantGain = Math.max(4.0, (formantGain || 0) + up * 3.0);
          formantQ = Math.max(1.2, (formantQ || 0) + up * 0.75);
          // NÂNG CẤP: Khi nâng tone cao quá ngưỡng (Pitch > 6), tự động hãm độ rít dải cao cực mịn để giữ màu ấm tự nhiên
          const piercingMitigator = absPitchMult > 6 ? 0.65 : 1.0;
          trebleReduction += up * 2.5 * (1 - Math.pow(up, 0.5) * 0.4) * piercingMitigator;
          midBoost += up * 2.2;
          this.delayTime = Math.min((this.delayTime || 0.02) * (1 + up * 0.1), 0.065);
        }
        const baseDelayDrift = 1 + absPitchMult * 0.06;
        this.delayTime = Math.min((this.delayTime || 0.02) * baseDelayDrift, 0.075);
      }
      const smartRatio = (baseRatio) => Math.min(baseRatio + absPitchMult * 0.8, baseRatio * 1.1);
      const wienerCompressionAdjust = this.wienerGain < 0.9 ? 1.2 * (1 - this.wienerGain) : 0.1;
      let panAdjust = pitchMult * (this.currentGenre === "EDM" || this.currentGenre === "Pop" ? 0.08 : 0.04);
      // Gọi bộ xử lý trung tâm, nạp đầy đủ tham số mắc xích (Tích hợp roomProfile không Reverb ảo)
      const userFeedbackAdjust = this.applyUserFeedback();
      const optimizedParams = this.optimizeSoundProfile({
        profile,
        musicContext,
        spectral,
        genreFactor,
        warmthBoost,
        subBassBoost,
        subMidBoost,
        midBoost,
        trebleReduction,
        transientBoostAdjust,
        polyphonicAdjust,
        harmonicBoost,
        songStructure,
        userFeedbackAdjust,
        roomProfile: this.roomProfile
      });
      const applyProfile = () => {
        // === CHỐT HẠ ACOUSTIC TRANSPARENCY - ĐỘ TRONG SUỐT THỰC TẾ ===
        const transparencyGain = this.calculateAcousticTransparencyGain();
        this.boostGain.gain.cancelScheduledValues(currentTime);
        this.boostGain.gain.setValueAtTime(this.boostGain.gain.value * transparencyGain, currentTime);
        // === DYNAMIC PEAK GUARDIAN PRO - KIỂM SOÁT VỠ TIẾNG LI TI BIÊN ĐỘ ===
        this.applyDynamicPeakGuardian();
        // === KHÓA CHẶT LỖI POP/CLICK KHI ĐỔI PROFILE NHANH (Mạch xả mượt toàn dải) ===
        const filters = [
          this.highPassFilter?.frequency, this.lowShelfGain?.gain, this.subBassFilter?.gain,
          this.subMidFilter?.gain, this.midBassFilter?.gain, this.midShelfGain?.gain,
          this.highMidFilter?.gain, this.highShelfGain?.gain, this.subTrebleFilter?.gain,
          this.airFilter?.gain, this.lowPassFilter?.frequency, this.compressor?.threshold,
          this.compressor?.ratio, this.notchFilter?.frequency, this.notchFilter?.Q,
          this.panner?.pan, this.outputGain?.gain
        ];
        for (let i = 0; i < filters.length; i++) {
          const param = filters[i];
          if (param) {
            param.cancelScheduledValues(currentTime);
            param.setValueAtTime(param.value, currentTime);
          }
        }
        // Chốt chặn an toàn kiểm tra tồn tại Node phần cứng
        if (!this.highPassFilter?.frequency) throw new Error("highPassFilter is not initialized");
        if (!this.lowShelfGain?.gain) throw new Error("lowShelfGain is not initialized");
        if (!this.subBassFilter?.gain) throw new Error("subBassFilter is not initialized");
        if (!this.subMidFilter?.gain) throw new Error("subMidFilter is not initialized");
        if (!this.midBassFilter?.gain) throw new Error("midBassFilter is not initialized");
        if (!this.midShelfGain?.gain) throw new Error("midShelfGain is not initialized");
        if (!this.highMidFilter?.gain) throw new Error("highMidFilter is not initialized");
        if (!this.highShelfGain?.gain) throw new Error("highShelfGain is not initialized");
        if (!this.subTrebleFilter?.gain) throw new Error("subTrebleFilter is not initialized");
        if (!this.airFilter?.gain) throw new Error("airFilter is not initialized");
        if (!this.lowPassFilter?.frequency) throw new Error("lowPassFilter is not initialized");
        if (!this.compressor?.threshold) throw new Error("compressor is not initialized");
        if (!this.notchFilter?.frequency) throw new Error("notchFilter is not initialized");
        if (!this.panner?.pan) throw new Error("panner is not initialized");
        // Đồng bộ nạp thông số nền tảng (Bản đồ dải trượt mượt tuyến tính)
        this.highPassFilter.frequency.linearRampToValueAtTime(optimizedParams.bassCutFreq || bassCutFreq, currentTime + (this.rampTime || 0.1));
        this.lowShelfGain.gain.linearRampToValueAtTime(optimizedParams.lowShelfGain || (9 + subBassBoost + warmthBoost + subharmonicGain), currentTime + (this.rampTime || 0.1));
        this.subBassFilter.gain.linearRampToValueAtTime(optimizedParams.subBassGain || (4 + subBassBoost + subharmonicGain), currentTime + (this.rampTime || 0.1));
        this.subMidFilter.gain.linearRampToValueAtTime(optimizedParams.subMidGain || (5.5 + subMidBoost + warmthBoost * smartWarmthAdjust), currentTime + (this.rampTime || 0.1));
        this.midBassFilter.gain.linearRampToValueAtTime(optimizedParams.midBassGain || (4.2 + warmthBoost), currentTime + (this.rampTime || 0.1));
        this.midShelfGain.gain.linearRampToValueAtTime(optimizedParams.midShelfGain || (6.2 + midBoost), currentTime + (this.rampTime || 0.1));
        this.highMidFilter.gain.linearRampToValueAtTime(optimizedParams.highMidGain || (4.5 + midBoost + harmonicBoost), currentTime + (this.rampTime || 0.1));
        this.highShelfGain.gain.linearRampToValueAtTime(optimizedParams.highShelfGain || (0.8 - trebleReduction + harmonicBoost + (isTransientGenre ? transientBoostAdjust : 0)), currentTime + (this.rampTime || 0.1));
        this.subTrebleFilter.gain.linearRampToValueAtTime(optimizedParams.subTrebleGain || (0.6 - trebleReduction + harmonicBoost + (isTransientGenre ? transientBoostAdjust : 0)), currentTime + (this.rampTime || 0.1));
        this.airFilter.gain.linearRampToValueAtTime(optimizedParams.airGain || (0.6 + harmonicBoost - trebleReduction), currentTime + (this.rampTime || 0.1));
        this.lowPassFilter.frequency.linearRampToValueAtTime(optimizedParams.trebleCutFreq || (trebleCutFreq - trebleReduction * 1200), currentTime + (this.rampTime || 0.1));
        this.compressor.threshold.linearRampToValueAtTime(optimizedParams.compressorThreshold || (-18 * dynamicFactor), currentTime + (this.rampTime || 0.1));
        this.compressor.ratio.linearRampToValueAtTime(optimizedParams.compressorRatio || smartRatio(4.5 + wienerCompressionAdjust), currentTime + (this.rampTime || 0.1));
        this.compressor.attack.linearRampToValueAtTime(optimizedParams.compressorAttack || 0.007, currentTime + (this.rampTime || 0.1));
        this.compressor.release.linearRampToValueAtTime(optimizedParams.compressorRelease || 0.28, currentTime + (this.rampTime || 0.1));
        this.notchFilter.frequency.linearRampToValueAtTime(optimizedParams.notchFreq || notchFreq, currentTime + (this.rampTime || 0.1));
        this.notchFilter.Q.linearRampToValueAtTime(optimizedParams.notchQ || notchQ, currentTime + (this.rampTime || 0.1));
        this.panner.pan.linearRampToValueAtTime(optimizedParams.panAdjust || panAdjust, currentTime + (this.rampTime || 0.1));
        // === HỆ THỐNG CÁC HÀM CON NỘI BỘ TRÍ TUỆ NHÂN TẠO (GIỮ NGUYÊN XƯƠNG SỐNG) ===
        const applyCommonProfileSettings = (vocalTypeFactor = 1.0, genreAdjust = 1.0, deEsserGain = -8) => {
          this.lowShelfGain.gain.linearRampToValueAtTime(optimizedParams.lowShelfGain || (8.5 + subBassBoost + warmthBoost * genreAdjust + userFeedbackAdjust.bass), currentTime + (this.rampTime || 0.1));
          this.subBassFilter.gain.linearRampToValueAtTime(optimizedParams.subBassGain || (4 + subBassBoost * genreAdjust + userFeedbackAdjust.bass), currentTime + (this.rampTime || 0.1));
          this.subMidFilter.gain.linearRampToValueAtTime(optimizedParams.subMidGain || ((5.5 + subMidBoost + warmthBoost) * vocalTypeFactor * genreAdjust + userFeedbackAdjust.mid), currentTime + (this.rampTime || 0.1));
          this.midBassFilter.gain.linearRampToValueAtTime(optimizedParams.midBassGain || (4 + warmthBoost * genreAdjust + userFeedbackAdjust.mid), currentTime + (this.rampTime || 0.1));
          this.midShelfGain.gain.linearRampToValueAtTime(optimizedParams.midShelfGain || ((6.2 + midBoost) * vocalTypeFactor * genreAdjust * songStructure.structureFactor + userFeedbackAdjust.mid), currentTime + (this.rampTime || 0.1));
          this.highMidFilter.gain.linearRampToValueAtTime(optimizedParams.highMidGain || ((4.5 + midBoost + harmonicBoost) * vocalTypeFactor * genreAdjust + userFeedbackAdjust.mid), currentTime + (this.rampTime || 0.1));
          this.highShelfGain.gain.linearRampToValueAtTime(optimizedParams.highShelfGain || (0.8 - trebleReduction + harmonicBoost * genreAdjust + (isTransientGenre ? transientBoostAdjust : 0) + userFeedbackAdjust.treble), currentTime + (this.rampTime || 0.1));
          this.subTrebleFilter.gain.linearRampToValueAtTime(optimizedParams.subTrebleGain || ((0.6 - trebleReduction + harmonicBoost) * vocalTypeFactor * genreAdjust + (isTransientGenre ? transientBoostAdjust : 0) + userFeedbackAdjust.treble), currentTime + (this.rampTime || 0.1));
          this.airFilter.gain.linearRampToValueAtTime(optimizedParams.airGain || (0.6 + harmonicBoost - trebleReduction * genreAdjust + userFeedbackAdjust.treble), currentTime + (this.rampTime || 0.1));
          this.notchFilter.frequency.linearRampToValueAtTime(optimizedParams.notchFreq || notchFreq, currentTime + (this.rampTime || 0.1));
          this.notchFilter.Q.linearRampToValueAtTime(optimizedParams.notchQ || notchQ, currentTime + (this.rampTime || 0.1));
          if (this.deEsser?.gain) {
            this.deEsser.gain.linearRampToValueAtTime(optimizedParams.deEsserGain || deEsserGain, currentTime + (this.rampTime || 0.1));
          }
        };
        const applyVocalClassification = () => {
          let vocalTypeFactor = this.isVocal ? 1.5 : 1.0;
          let voiceType = 'middle';
          let fundamentalFreq = (this.polyphonicPitches && this.polyphonicPitches.length > 0) ? (this.polyphonicPitches[0]?.frequency || 440) : 440;
          if (fundamentalFreq <= 240) {
            voiceType = 'low';
            vocalTypeFactor = 1.6;
            f1Freq = optimizedParams.f1Freq || (340 + (spectral.vocalPresence || 0) * 60);
            f2Freq = optimizedParams.f2Freq || (1550 + (spectral.vocalPresence || 0) * 250);
            formantGain = optimizedParams.formantGain || (4.0 * vocalTypeFactor * songStructure.structureFactor);
            formantQ = optimizedParams.formantQ || (1.2 * vocalTypeFactor);
          } else if (fundamentalFreq <= 480) {
            voiceType = 'middle';
            vocalTypeFactor = 1.0;
            f1Freq = optimizedParams.f1Freq || (450 + (spectral.vocalPresence || 0) * 60);
            f2Freq = optimizedParams.f2Freq || (1950 + (spectral.vocalPresence || 0) * 250);
            formantGain = optimizedParams.formantGain || (3.6 * vocalTypeFactor * songStructure.structureFactor);
            formantQ = optimizedParams.formantQ || (0.9 * vocalTypeFactor);
          } else {
            voiceType = 'high';
            vocalTypeFactor = 0.7;
            f1Freq = optimizedParams.f1Freq || (580 + (spectral.vocalPresence || 0) * 60);
            f2Freq = optimizedParams.f2Freq || (2350 + (spectral.vocalPresence || 0) * 250);
            formantGain = optimizedParams.formantGain || (2.8 * vocalTypeFactor * songStructure.structureFactor);
            formantQ = optimizedParams.formantQ || (0.6 * vocalTypeFactor);
          }
          return {
            vocalTypeFactor,
            voiceType,
            fundamentalFreq
          };
        };
        const applyGenreAndStructureAdjustments = (vocalTypeFactor) => {
          let genreAdjust = 1.0;
          if (this.currentGenre === 'Bolero') {
            genreAdjust = 1.5;
            warmthBoost *= 1.7;
            subMidBoost *= 1.6;
            trebleReduction *= 0.6;
          } else if (['EDM', 'Pop'].includes(this.currentGenre)) {
            genreAdjust = 0.85;
            transientBoostAdjust *= 1.4;
            if (optimizedParams.subTrebleGain !== undefined) {
              optimizedParams.subTrebleGain *= 1.1;
            }
          } else if (this.currentGenre === 'Rock/Metal') {
            genreAdjust = 1.2;
            harmonicBoost *= 1.5;
            midBoost *= 1.4;
          } else if (this.currentGenre === 'Karaoke') {
            genreAdjust = 1.3;
            vocalTypeFactor *= 1.4;
            warmthBoost *= 1.4;
          }
          if (songStructure.section === 'chorus') {
            midBoost *= 1.4;
            harmonicBoost *= 1.4;
            optimizedParams.compressorRatio = smartRatio((optimizedParams.compressorRatio || 4.5) * 1.2);
            optimizedParams.formantGain = (optimizedParams.formantGain || 3.2) * 0.85;
          } else if (songStructure.section === 'bridge') {
            optimizedParams.highMidGain = (optimizedParams.highMidGain || 4.5) * 1.2;
            optimizedParams.subTrebleGain = (optimizedParams.subTrebleGain || 0.6) * 1.05;
          } else if (songStructure.section === 'intro') {
            warmthBoost *= 0.8;
            optimizedParams.formantGain = (optimizedParams.formantGain || 3.2) * 0.7;
          }
          return genreAdjust;
        };
        const applyNoiseHandling = () => {
          let deEsserGain = -8;
          const safeAir = (typeof spectral.air === 'number') ? spectral.air : 0.5;
          if (enableAdvancedDeEsser && (spectral.spectralFlux > 0.55 || safeAir > 0.65 || spectral.vocalPresence > 0.7)) {
            deEsserGain = -12 - (spectral.spectralFlux - 0.55) * 10;
            notchFreq = optimizedParams.notchFreq || (6500 + safeAir * 1000);
            notchQ = optimizedParams.notchQ || (notchQ * 2.5);
            if (spectral.spectralEntropy < 0.5) {
              deEsserGain -= 3;
              if (optimizedParams.subTrebleGain !== undefined) {
                optimizedParams.subTrebleGain *= 0.85;
              }
            }
          } else if (this.noiseLevel.level > 0.45) {
            notchFreq = optimizedParams.notchFreq || (4500 + (this.noiseLevel.midFreq / 5000) * 2200);
            notchQ = optimizedParams.notchQ || (notchQ * 2.5);
          }
          if (songStructure.section === 'chorus' && spectral.vocalPresence > 0.7) {
            deEsserGain -= 3;
            notchFreq = optimizedParams.notchFreq || 7000;
          }
          if (profile === "bassHeavy" && spectral.subBass > 0.7) {
            this.wienerGain = Math.max(0.88, this.wienerGain - 0.03);
          }
          return deEsserGain;
        };
        const applyCNNTransientDetection = () => {
          if (!enableCNNTransient) return {
            vocalTransient: 0.5,
            instrumentTransient: 0.5
          };
          const vocalTransient = spectral.vocalPresence > 0.7 ? Math.min(0.8, spectral.transientEnergy * 1.2) : 0.4;
          const instrumentTransient = (spectral.instruments.guitar || spectral.instruments.drums) ? Math.min(0.8, spectral.transientEnergy * 1.1) : 0.4;
          return {
            vocalTransient,
            instrumentTransient
          };
        };
        const {
          vocalTransient,
          instrumentTransient
        } = applyCNNTransientDetection();
        const {
          vocalTypeFactor
        } = applyVocalClassification();
        const genreAdjust = applyGenreAndStructureAdjustments(vocalTypeFactor);
        const deEsserGain = applyNoiseHandling();
        // Kích hoạt nạp bộ tham số định hình chung trước khi phân phối về các cấu hình Profile riêng biệt ở Phần 2
        applyCommonProfileSettings(vocalTypeFactor, genreAdjust, deEsserGain);
        // =================================================================
        // === PHẦN 2: HỆ THỐNG ĐIỀU PHỐI 8 PROFILE VẬT LÝ VÀ PHÂN PHỐI NĂNG LƯỢNG PHI TUYẾN ===
        // =================================================================
        if (profile === "warm") {
          const {
            vocalTypeFactor,
            voiceType,
            fundamentalFreq
          } = applyVocalClassification();
          const genreAdjust = applyGenreAndStructureAdjustments(vocalTypeFactor);
          const deEsserGain = applyNoiseHandling();
          applyCommonProfileSettings(vocalTypeFactor, genreAdjust, deEsserGain);
          // Phân tích đặc trưng phổ động cho cấu hình ấm áp, chân thực
          const spectralFlux = spectral.spectralFlux || 0.5;
          const spectralEntropy = spectral.spectralEntropy || 0.5;
          const harmonicRatio = spectral.harmonicRatio || 0.5;
          const transientEnergy = spectral.transientEnergy || 0.5;
          const warmthPresence = spectral.warmthPresence || 0.5;
          // Khóa cứng kích thước lưới FFTSize tĩnh thông minh tránh lag pha cơ học
          let fftSize = 2048;
          if (spectralEntropy > 0.7 || warmthPresence > 0.75) {
            fftSize = 4096;
          } else if (spectralFlux < 0.35 && warmthPresence < 0.5) {
            fftSize = 1024;
          }
          this.setFFTSize(fftSize);
          // Căn chỉnh pha tuyến tính dải trầm và trung cao bảo vệ mạch pha nguyên bản (Không tạo node mới)
          if (this.phaseAligner && typeof this.phaseAligner.frequency?.setValueAtTime === 'function') {
            this.phaseAligner.frequency.setValueAtTime(120, currentTime);
            this.phaseAligner.Q.setValueAtTime(0.707, currentTime);
          }
          if (this.midPhaseAligner && typeof this.midPhaseAligner.frequency?.setValueAtTime === 'function') {
            this.midPhaseAligner.frequency.setValueAtTime(2500, currentTime);
            this.midPhaseAligner.Q.setValueAtTime(0.707, currentTime);
          }
          // Cảm biến xung lực Transient thông minh từ AI mã nguồn nâng cấp
          const {
            vocalTransient,
            instrumentTransient
          } = applyCNNTransientDetection();
          const transientBoost = (vocalTransient > 0.65 || instrumentTransient > 0.65) ? 1.3 : 1.0;
          // Hệ số kích hài tự nhiên tạo độ dày ấm kết hợp cổng chờ tinh chỉnh UI
          const harmonicEnhanceFactor = 1.5 + (harmonicRatio > 0.65 ? 0.4 : 0.2) + (warmthPresence > 0.7 ? 0.5 : 0) + (uiBridge.harmonicRichness || 0) * 0.5;
          const instrumentClarity = (spectral.instruments?.guitar || spectral.instruments?.piano || spectral.instruments?.strings) ? 1.5 : 1.2;
          // Bộ nén dải động mượt mà bọc qua hàm smartRatio bảo vệ dải trung trầm
          const dynamicCompressionRatio = smartRatio(3.2 + (warmthPresence > 0.75 ? 0.6 : 0));
          const compressorAttack = songStructure.section === 'chorus' ? 0.005 : 0.007;
          const compressorRelease = songStructure.section === 'chorus' ? 0.25 : 0.32;
          // === PHỤC HỒI DYNAMIC EQ & SIDECHAIN KHÔNG SINH RÁC (FIX MEMORY LEAK) ===
          // Thay vì tạo node mới liên tục gây sập RAM, ta nạp trực tiếp độ lợi EQ vào mạch xả tĩnh tương ứng
          const warmthEqDelta = warmthPresence > 0.65 ? 2.5 : 0;
          const vocalEqDelta = spectral.vocalPresence > 0.6 ? 2.0 : 0;
          // Tích hợp độ nén mượt Sidechain dập dải đục trực tiếp vào hệ số khuếch tán Formant ca sĩ
          let sidechainVocalMod = 1.0;
          if (this.isVocal && spectral.vocalPresence > 0.65) {
            sidechainVocalMod = 0.88 * transparencyFactor; // Ép nhẹ trung trầm nền giúp giọng ca thoát sạch ra ngoài
          }
          // Bộ kiểm soát treble chống rít Sibilance Guard phi tuyến nâng cao
          let dynamicDeEsserGain = deEsserGain;
          if (spectralFlux > 0.55 || spectral.air > 0.65) {
            dynamicDeEsserGain = -11 - (spectralFlux - 0.55) * 8;
            if (this.deEsser?.frequency) {
              this.deEsser.frequency.setValueAtTime(7100 + spectral.air * 900, currentTime);
              this.deEsser.Q.setValueAtTime(2.7, currentTime);
            }
          }
          // THUẬT TOÁN LÀM MỊN THAM SỐ TUYẾN TÍNH CHỐNG TIẾNG NỔ POP/CLICK CƠ HỌC
          const smoothParamUpdate = (param, targetValue, timeConstant = 0.09) => {
            if (param && Number.isFinite(targetValue)) {
              param.cancelScheduledValues(currentTime);
              param.setValueAtTime(param.value, currentTime);
              param.linearRampToValueAtTime(targetValue, currentTime + timeConstant);
            }
          };
          // Phân phối năng lượng thông minh thích nghi sâu sắc theo ngữ cảnh bài hát kết hợp UI Bridge
          if (warmthPresence > 0.75) {
            // Cấu hình Warmth-heavy: Âm trầm ấm sâu lắng, lan tỏa rộng mở, giọng ca quyện chặtbeat
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (10.5 + subBassBoost + warmthBoost * 0.9 + userFeedbackAdjust.bass + uiBridge.bass * 0.6));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (5.5 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.5));
            smoothParamUpdate(this.subMidFilter.gain, (optimizedParams.subMidGain || (7.0 + subMidBoost + warmthBoost * smartWarmthAdjust * 0.8 + userFeedbackAdjust.mid + uiBridge.mid * 0.5)) + warmthEqDelta);
            smoothParamUpdate(this.midBassFilter.gain, optimizedParams.midBassGain || (6.0 + warmthBoost * 0.8 + userFeedbackAdjust.bass + uiBridge.warmth * 0.4));
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (6.5 + midBoost * songStructure.structureFactor + userFeedbackAdjust.clarity + uiBridge.mid * 0.6));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (5.0 + midBoost + harmonicEnhanceFactor + instrumentClarity + userFeedbackAdjust.clarity * 0.6 + uiBridge.mid * 0.4)) + vocalEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.5 - trebleReduction * 0.8 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.5));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (0.4 - trebleReduction * 0.8 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.4 + harmonicEnhanceFactor * 0.7 - trebleReduction + userFeedbackAdjust.treble + uiBridge.air * 0.7));
            // --- ĐỒNG BỘ PITCH CẢM BIẾN V5.9 CHỐNG TỐI KHI HẠ TONE ---
            f1Freq = optimizedParams.f1Freq || (380 * (1 + spectral.vocalPresence * 0.15) * (pitchMult < 0 ? 1.05 : 1.0));
            f2Freq = optimizedParams.f2Freq || (1600 * (1 + spectral.vocalPresence * 0.15) * (pitchMult < 0 ? 1.03 : 1.0));
            notchFreq = optimizedParams.notchFreq || 4800;
          } else if (spectral.vocalPresence > 0.65) {
            // Cấu hình Vocal-heavy: Đẩy bật độ trong trẻo trung âm ca sĩ đứng cạnh nhạc cụ thật
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (10.0 + subBassBoost + warmthBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.5));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (5.0 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.4));
            smoothParamUpdate(this.subMidFilter.gain, (optimizedParams.subMidGain || (7.2 + subMidBoost + warmthBoost * smartWarmthAdjust + userFeedbackAdjust.mid + uiBridge.mid * 0.6)) + warmthEqDelta);
            smoothParamUpdate(this.midBassFilter.gain, optimizedParams.midBassGain || (5.5 + warmthBoost + userFeedbackAdjust.bass + uiBridge.warmth * 0.5));
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (6.8 + midBoost * songStructure.structureFactor * 1.1 + userFeedbackAdjust.clarity + uiBridge.vocalClarity * 0.6));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (5.2 + midBoost + harmonicEnhanceFactor * 1.1 + instrumentClarity + userFeedbackAdjust.clarity * 0.7 + uiBridge.mid * 0.5)) + vocalEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.6 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.5));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (0.5 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.5 + harmonicEnhanceFactor * 0.8 - trebleReduction + userFeedbackAdjust.treble + uiBridge.air * 0.8));
            f1Freq = optimizedParams.f1Freq || (420 * (1 + spectral.vocalPresence * 0.15));
            f2Freq = optimizedParams.f2Freq || (1800 * (1 + spectral.vocalPresence * 0.15));
            notchFreq = optimizedParams.notchFreq || 5200;
          } else {
            // Cấu hình Cân bằng tự nhiên (Balanced warm mix)
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (10.2 + subBassBoost + warmthBoost * 0.9 + userFeedbackAdjust.bass + uiBridge.bass * 0.5));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (5.2 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.4));
            smoothParamUpdate(this.subMidFilter.gain, (optimizedParams.subMidGain || (7.1 + subMidBoost + warmthBoost * smartWarmthAdjust * 0.9 + userFeedbackAdjust.mid + uiBridge.mid * 0.5)) + warmthEqDelta);
            smoothParamUpdate(this.midBassFilter.gain, optimizedParams.midBassGain || (5.8 + warmthBoost * 0.9 + userFeedbackAdjust.bass + uiBridge.warmth * 0.4));
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (6.6 + midBoost * songStructure.structureFactor + userFeedbackAdjust.clarity + uiBridge.mid * 0.5));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (5.1 + midBoost + harmonicEnhanceFactor + instrumentClarity + userFeedbackAdjust.clarity * 0.6 + uiBridge.mid * 0.4)) + vocalEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.5 - trebleReduction * 0.8 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (0.4 - trebleReduction * 0.8 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.4 + harmonicEnhanceFactor * 0.7 - trebleReduction + userFeedbackAdjust.treble + uiBridge.air * 0.6));
            f1Freq = optimizedParams.f1Freq || (400 * (1 + spectral.vocalPresence * 0.15));
            f2Freq = optimizedParams.f2Freq || (1700 * (1 + spectral.vocalPresence * 0.15));
            notchFreq = optimizedParams.notchFreq || 5000;
          }
          // Cấu trúc nhìn trước (Look-ahead) tăng lực đẩy dải trung trầm khi vào Điệp khúc (Chorus)
          if (songStructure.section === 'chorus') {
            smoothParamUpdate(this.subMidFilter.gain, this.subMidFilter.gain.value * 1.3);
            smoothParamUpdate(this.highMidFilter.gain, this.highMidFilter.gain.value * 1.25);
            smoothParamUpdate(this.compressor.ratio, dynamicCompressionRatio * 1.15);
          } else if (songStructure.section === 'bridge') {
            smoothParamUpdate(this.midBassFilter.gain, this.midBassFilter.gain.value * 1.15);
            smoothParamUpdate(this.highMidFilter.gain, this.highMidFilter.gain.value * 1.1);
          }
          // Cập nhật tham số Compressor tĩnh mượt mà không vỡ tiếng
          smoothParamUpdate(this.compressor.ratio, optimizedParams.compressorRatio || dynamicCompressionRatio);
          smoothParamUpdate(this.compressor.attack, optimizedParams.compressorAttack || compressorAttack);
          smoothParamUpdate(this.compressor.release, optimizedParams.compressorRelease || compressorRelease);
          smoothParamUpdate(this.compressor.threshold, optimizedParams.compressorThreshold || -18);
          if (this.deEsser?.gain) {
            smoothParamUpdate(this.deEsser.gain, optimizedParams.deEsserGain || dynamicDeEsserGain);
          }
          // Áp dụng định hình Formant bảo vệ màu sắc nguyên bản ca sĩ kết hợp hệ số Sidechain mượt
          smoothParamUpdate(this.formantFilter1.frequency, optimizedParams.f1Freq || f1Freq);
          smoothParamUpdate(this.formantFilter1.gain, (optimizedParams.formantGain || (3.5 * vocalTypeFactor)) * sidechainVocalMod);
          smoothParamUpdate(this.formantFilter1.Q, optimizedParams.formantQ || (1.0 * vocalTypeFactor));
          smoothParamUpdate(this.formantFilter2.frequency, optimizedParams.f2Freq || f2Freq);
          smoothParamUpdate(this.formantFilter2.gain, (optimizedParams.formantGain || (3.5 * vocalTypeFactor)) * sidechainVocalMod);
          smoothParamUpdate(this.formantFilter2.Q, optimizedParams.formantQ || (1.0 * vocalTypeFactor));
          smoothParamUpdate(this.notchFilter.frequency, optimizedParams.notchFreq || notchFreq);
          smoothParamUpdate(this.notchFilter.Q, optimizedParams.notchQ || (notchQ * 2.2));
          // Đảm bảo tính trung thực thực tế: Giữ trường âm cân bằng ở trung tâm, không làm rộng kiểu thính phòng vang ảo
          smoothParamUpdate(this.panner.pan, 0);
          if (this.memoryManager) {
            const cacheKey = 'warmProfile';
            if (this.memoryManager.buffers.has(cacheKey)) this.memoryManager.buffers.delete(cacheKey);
            this.memoryManager.buffers.set(cacheKey, {
              voiceType,
              fundamentalFreq,
              warmthPresence: spectral.warmthPresence,
              timestamp: Date.now(),
              expiry: Date.now() + 10000
            });
            this.memoryManager.pruneCache(100);
          }
        } else if (profile === "bright") {
          const {
            vocalTypeFactor,
            voiceType,
            fundamentalFreq
          } = applyVocalClassification();
          const genreAdjust = applyGenreAndStructureAdjustments(vocalTypeFactor);
          const deEsserGain = applyNoiseHandling();
          applyCommonProfileSettings(vocalTypeFactor, genreAdjust, deEsserGain);
          const spectralFlux = spectral.spectralFlux || 0.5;
          const spectralEntropy = spectral.spectralEntropy || 0.5;
          const harmonicRatio = spectral.harmonicRatio || 0.5;
          const transientEnergy = spectral.transientEnergy || 0.5;
          const treblePresence = spectral.treblePresence || 0.5;
          let fftSize = 2048;
          if (spectralEntropy > 0.65 || treblePresence > 0.7) {
            fftSize = 4096;
          } else if (spectralFlux < 0.4 && treblePresence < 0.5) {
            fftSize = 1024;
          }
          this.setFFTSize(fftSize);
          if (this.phaseAligner && typeof this.phaseAligner.frequency?.setValueAtTime === 'function') {
            this.phaseAligner.frequency.setValueAtTime(100, currentTime);
            this.phaseAligner.Q.setValueAtTime(0.707, currentTime);
          }
          if (this.midPhaseAligner && typeof this.midPhaseAligner.frequency?.setValueAtTime === 'function') {
            this.midPhaseAligner.frequency.setValueAtTime(3500, currentTime);
            this.midPhaseAligner.Q.setValueAtTime(0.707, currentTime);
          }
          const {
            vocalTransient,
            instrumentTransient
          } = applyCNNTransientDetection();
          const transientBoost = (vocalTransient > 0.6 || instrumentTransient > 0.6) ? 1.5 : 1.0;
          const harmonicEnhanceFactor = 1.6 + (harmonicRatio > 0.6 ? 0.4 : 0.2) + (treblePresence > 0.7 ? 0.5 : 0) + (uiBridge.treble || 0) * 0.4;
          const instrumentClarity = (spectral.instruments?.strings || spectral.instruments?.cymbals || spectral.instruments?.piano) ? 1.6 : 1.2;
          const dynamicCompressionRatio = smartRatio(3.0 + (treblePresence > 0.75 ? 0.5 : 0));
          const compressorAttack = songStructure.section === 'chorus' ? 0.004 : 0.006;
          const compressorRelease = songStructure.section === 'chorus' ? 0.22 : 0.28;
          // Tích hợp dynamicEQ đẩy dải trung cao sắc nét nhuyễn mịn vào thẳng mạch xả tĩnh
          const trebleEqDelta = treblePresence > 0.65 ? 2.5 : 0;
          const vocalEqDelta = spectral.vocalPresence > 0.6 ? 2.2 : 0;
          let sidechainVocalMod = 1.0;
          if (this.isVocal && spectral.vocalPresence > 0.65) {
            sidechainVocalMod = 0.92 * transparencyFactor;
          }
          let dynamicDeEsserGain = deEsserGain;
          if (spectralFlux > 0.5 || spectral.air > 0.6) {
            dynamicDeEsserGain = -10 - (spectralFlux - 0.5) * 7;
            if (this.deEsser?.frequency) {
              this.deEsser.frequency.setValueAtTime(7000 + spectral.air * 1000, currentTime);
              this.deEsser.Q.setValueAtTime(2.6, currentTime);
            }
          }
          const smoothParamUpdate = (param, targetValue, timeConstant = 0.1) => {
            if (param && Number.isFinite(targetValue)) {
              param.cancelScheduledValues(currentTime);
              param.setValueAtTime(param.value, currentTime);
              param.linearRampToValueAtTime(targetValue, currentTime + timeConstant);
            }
          };
          if (treblePresence > 0.75) {
            // Cấu hình Treble-heavy: Dải cao tơi sáng lung linh, trong vắt tinh khiết không chói rít
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (8.2 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.4));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (3.8 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.3));
            smoothParamUpdate(this.subMidFilter.gain, optimizedParams.subMidGain || (5.8 + subMidBoost + warmthBoost * smartWarmthAdjust * 0.8 + userFeedbackAdjust.mid + uiBridge.mid * 0.4));
            smoothParamUpdate(this.midBassFilter.gain, optimizedParams.midBassGain || (4.2 + warmthBoost * 0.8 + userFeedbackAdjust.bass + uiBridge.warmth * 0.3));
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (8.0 + midBoost * songStructure.structureFactor + userFeedbackAdjust.clarity + uiBridge.mid * 0.5));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (6.5 + midBoost + harmonicEnhanceFactor + instrumentClarity + userFeedbackAdjust.clarity * 0.7 + uiBridge.vocalClarity * 0.5)) + vocalEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, (optimizedParams.highShelfGain || (1.2 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.7)) + trebleEqDelta);
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (1.0 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.6));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (1.0 + harmonicEnhanceFactor * 0.8 + userFeedbackAdjust.treble + uiBridge.air * 0.8));
            // --- ĐỒNG BỘ PITCH CẢM BIẾN V5.9 CHỐNG CHÓI RÍT KHI NÂNG TONE CAO > 6 ---
            const piercingMitigator = absPitchMult > 6 ? 0.92 : 1.0;
            f1Freq = optimizedParams.f1Freq || (450 * (1 + spectral.vocalPresence * 0.15) * piercingMitigator);
            f2Freq = optimizedParams.f2Freq || (2100 * (1 + spectral.vocalPresence * 0.15) * piercingMitigator);
            notchFreq = optimizedParams.notchFreq || 6500;
          } else if (spectral.vocalPresence > 0.65) {
            // Cấu hình Vocal-heavy Bright
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (8.0 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.4));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (3.5 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.3));
            smoothParamUpdate(this.subMidFilter.gain, optimizedParams.subMidGain || (6.0 + subMidBoost + warmthBoost * smartWarmthAdjust + userFeedbackAdjust.mid + uiBridge.mid * 0.4));
            smoothParamUpdate(this.midBassFilter.gain, optimizedParams.midBassGain || (4.0 + warmthBoost + userFeedbackAdjust.bass + uiBridge.warmth * 0.3));
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (8.2 + midBoost * songStructure.section === 'chorus' ? 1.1 : 1.0 + userFeedbackAdjust.clarity + uiBridge.vocalClarity * 0.6));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (6.8 + midBoost + harmonicEnhanceFactor * 1.1 + instrumentClarity + userFeedbackAdjust.clarity * 0.8 + uiBridge.mid * 0.5)) + vocalEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, (optimizedParams.highShelfGain || (1.0 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.6)) + trebleEqDelta);
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (0.8 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.5));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.8 + harmonicEnhanceFactor * 0.9 + userFeedbackAdjust.treble + uiBridge.air * 0.9));
            f1Freq = optimizedParams.f1Freq || (480 * (1 + spectral.vocalPresence * 0.15));
            f2Freq = optimizedParams.f2Freq || (2200 * (1 + spectral.vocalPresence * 0.15));
            notchFreq = optimizedParams.notchFreq || 6200;
          } else {
            // Cấu hình Cân bằng tươi tắn (Balanced bright mix)
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (8.1 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.4));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (3.6 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.3));
            smoothParamUpdate(this.subMidFilter.gain, optimizedParams.subMidGain || (5.9 + subMidBoost + warmthBoost * smartWarmthAdjust * 0.9 + userFeedbackAdjust.mid + uiBridge.mid * 0.4));
            smoothParamUpdate(this.midBassFilter.gain, optimizedParams.midBassGain || (4.1 + warmthBoost + userFeedbackAdjust.bass + uiBridge.warmth * 0.3));
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (8.1 + midBoost * songStructure.structureFactor + userFeedbackAdjust.clarity + uiBridge.mid * 0.5));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (6.6 + midBoost + harmonicEnhanceFactor + instrumentClarity + userFeedbackAdjust.clarity * 0.7 + uiBridge.mid * 0.5)) + vocalEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, (optimizedParams.highShelfGain || (1.1 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.6)) + trebleEqDelta);
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (0.9 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.5));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.9 + harmonicEnhanceFactor * 0.8 + userFeedbackAdjust.treble + uiBridge.air * 0.8));
            f1Freq = optimizedParams.f1Freq || (460 * (1 + spectral.vocalPresence * 0.15));
            f2Freq = optimizedParams.f2Freq || (2000 * (1 + spectral.vocalPresence * 0.15));
            notchFreq = optimizedParams.notchFreq || 6300;
          }
          if (songStructure.section === 'chorus') {
            smoothParamUpdate(this.highMidFilter.gain, this.highMidFilter.gain.value * 1.35);
            smoothParamUpdate(this.highShelfGain.gain, this.highShelfGain.gain.value * 1.3);
            smoothParamUpdate(this.compressor.ratio, dynamicCompressionRatio * 1.1);
          } else if (songStructure.section === 'bridge') {
            smoothParamUpdate(this.highMidFilter.gain, this.highMidFilter.gain.value * 1.2);
            smoothParamUpdate(this.subTrebleFilter.gain, this.subTrebleFilter.gain.value * 1.15);
          }
          smoothParamUpdate(this.compressor.ratio, optimizedParams.compressorRatio || dynamicCompressionRatio);
          smoothParamUpdate(this.compressor.attack, optimizedParams.compressorAttack || compressorAttack);
          smoothParamUpdate(this.compressor.release, optimizedParams.compressorRelease || compressorRelease);
          smoothParamUpdate(this.compressor.threshold, optimizedParams.compressorThreshold || -16);
          if (this.deEsser?.gain) {
            smoothParamUpdate(this.deEsser.gain, optimizedParams.deEsserGain || dynamicDeEsserGain);
          }
          smoothParamUpdate(this.formantFilter1.frequency, optimizedParams.f1Freq || f1Freq);
          smoothParamUpdate(this.formantFilter1.gain, (optimizedParams.formantGain || (3.0 * vocalTypeFactor)) * sidechainVocalMod);
          smoothParamUpdate(this.formantFilter1.Q, optimizedParams.formantQ || (0.8 * vocalTypeFactor));
          smoothParamUpdate(this.formantFilter2.frequency, optimizedParams.f2Freq || f2Freq);
          smoothParamUpdate(this.formantFilter2.gain, (optimizedParams.formantGain || (3.0 * vocalTypeFactor)) * sidechainVocalMod);
          smoothParamUpdate(this.formantFilter2.Q, optimizedParams.formantQ || (0.8 * vocalTypeFactor));
          smoothParamUpdate(this.notchFilter.frequency, optimizedParams.notchFreq || notchFreq);
          smoothParamUpdate(this.notchFilter.Q, optimizedParams.notchQ || (notchQ * 2.0));
          smoothParamUpdate(this.panner.pan, 0);
          if (this.memoryManager) {
            const cacheKey = 'brightProfile';
            if (this.memoryManager.buffers.has(cacheKey)) this.memoryManager.buffers.delete(cacheKey);
            this.memoryManager.buffers.set(cacheKey, {
              voiceType,
              fundamentalFreq,
              treblePresence: spectral.treblePresence,
              timestamp: Date.now(),
              expiry: Date.now() + 10000
            });
            this.memoryManager.pruneCache(100);
          }
        } else if (profile === "bassHeavy") {
          const {
            vocalTypeFactor,
            voiceType,
            fundamentalFreq
          } = applyVocalClassification();
          const genreAdjust = applyGenreAndStructureAdjustments(vocalTypeFactor);
          const deEsserGain = applyNoiseHandling();
          applyCommonProfileSettings(vocalTypeFactor, genreAdjust, deEsserGain);
          const spectralFlux = spectral.spectralFlux || 0.5;
          const spectralEntropy = spectral.spectralEntropy || 0.5;
          const harmonicRatio = spectral.harmonicRatio || 0.5;
          const transientEnergy = spectral.transientEnergy || 0.5;
          const bassPresence = spectral.bassPresence || 0.5;
          let fftSize = 2048;
          if (spectralEntropy > 0.7 || bassPresence > 0.75) {
            fftSize = 4096;
          } else if (spectralFlux < 0.35 && bassPresence < 0.5) {
            fftSize = 1024;
          }
          this.setFFTSize(fftSize);
          if (this.phaseAligner && typeof this.phaseAligner.frequency?.setValueAtTime === 'function') {
            this.phaseAligner.frequency.setValueAtTime(80, currentTime);
            this.phaseAligner.Q.setValueAtTime(0.707, currentTime);
          }
          if (this.midPhaseAligner && typeof this.midPhaseAligner.frequency?.setValueAtTime === 'function') {
            this.midPhaseAligner.frequency.setValueAtTime(2500, currentTime);
            this.midPhaseAligner.Q.setValueAtTime(0.707, currentTime);
          }
          const {
            vocalTransient,
            instrumentTransient
          } = applyCNNTransientDetection();
          const transientBoost = (instrumentTransient > 0.65 || transientEnergy > 0.7) ? 1.4 : 1.0;
          const harmonicEnhanceFactor = 1.5 + (harmonicRatio > 0.65 ? 0.4 : 0.2) + (bassPresence > 0.7 ? 0.5 : 0) + (uiBridge.bass || 0) * 0.6;
          const instrumentClarity = (spectral.instruments?.drums || spectral.instruments?.bass) ? 1.5 : 1.2;
          const dynamicCompressionRatio = smartRatio(4.2 + (bassPresence > 0.75 ? 0.8 : 0));
          const compressorAttack = songStructure.section === 'chorus' ? 0.0025 : 0.0035;
          const compressorRelease = songStructure.section === 'chorus' ? 0.22 : 0.28;
          // NÂNG CẤP BASS PHI TUYẾN: Trích xuất màng lọc dập đục và bù dải trầm qua Soft-Limiter cố định
          const bassEqDelta = bassPresence > 0.65 ? 2.5 : 0;
          const vocalEqDelta = spectral.vocalPresence > 0.6 ? 2.0 : 0;
          let sidechainVocalMod = 1.0;
          if (this.isVocal && spectral.vocalPresence > 0.65) {
            sidechainVocalMod = 0.85 * transparencyFactor;
          }
          let dynamicDeEsserGain = deEsserGain;
          if (spectralFlux > 0.55 || spectral.air > 0.65) {
            dynamicDeEsserGain = -12 - (spectralFlux - 0.55) * 8;
            if (this.deEsser?.frequency) {
              this.deEsser.frequency.setValueAtTime(7200 + spectral.air * 900, currentTime);
              this.deEsser.Q.setValueAtTime(2.8, currentTime);
            }
          }
          const smoothParamUpdate = (param, targetValue, timeConstant = 0.09) => {
            if (param && Number.isFinite(targetValue)) {
              param.cancelScheduledValues(currentTime);
              param.setValueAtTime(param.value, currentTime);
              param.linearRampToValueAtTime(targetValue, currentTime + timeConstant);
            }
          };
          if (bassPresence > 0.75) {
            // --- NÂNG CẤP BASS BUM BUM LAN TỎA SÂU THẲM PHI TUYẾN QUA MATH.TANH CHỐNG VỠ BIÊN ĐỘ ---
            const rawLowShelf = optimizedParams.lowShelfGain || (11.5 + subBassBoost + subharmonicGain * 0.8 + userFeedbackAdjust.bass + uiBridge.bass * 0.8);
            const rawSubBass = optimizedParams.subBassGain || (6.5 + subBassBoost + subharmonicGain * 0.8 + userFeedbackAdjust.bass + uiBridge.bass * 0.7);
            smoothParamUpdate(this.lowShelfGain.gain, Math.tanh(rawLowShelf / 12) * 11.5);
            smoothParamUpdate(this.subBassFilter.gain, (Math.tanh(rawSubBass / 7) * 6.5) + bassEqDelta);
            smoothParamUpdate(this.subMidFilter.gain, (optimizedParams.subMidGain || (6.5 + subMidBoost + warmthBoost * smartWarmthAdjust * 0.7 + userFeedbackAdjust.mid + uiBridge.mid * 0.4)) * transparencyFactor);
            smoothParamUpdate(this.midBassFilter.gain, (optimizedParams.midBassGain || (5.8 + warmthBoost * 0.7 + userFeedbackAdjust.bass + uiBridge.warmth * 0.4)) * transparencyFactor);
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (6.0 + midBoost * songStructure.structureFactor + userFeedbackAdjust.clarity + uiBridge.mid * 0.5));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (4.5 + midBoost + harmonicEnhanceFactor + instrumentClarity + userFeedbackAdjust.clarity * 0.6 + uiBridge.mid * 0.4)) + vocalEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.4 - trebleReduction * 0.8 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (0.3 - trebleReduction * 0.8 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.3 + harmonicEnhanceFactor * 0.7 - trebleReduction + userFeedbackAdjust.treble + uiBridge.air * 0.5));
            f1Freq = optimizedParams.f1Freq || (300 * (1 + (spectral.vocalPresence || 0) * 0.15));
            f2Freq = optimizedParams.f2Freq || (1500 * (1 + (spectral.vocalPresence || 0) * 0.15));
            notchFreq = optimizedParams.notchFreq || 4800;
          } else if (spectral.vocalPresence > 0.65) {
            // Cấu hình Vocal-heavy Bass
            const rawLowShelf = optimizedParams.lowShelfGain || (10.8 + subBassBoost + subharmonicGain * 0.9 + userFeedbackAdjust.bass + uiBridge.bass * 0.7);
            const rawSubBass = optimizedParams.subBassGain || (6.0 + subBassBoost + subharmonicGain * 0.9 + userFeedbackAdjust.bass + uiBridge.bass * 0.6);
            smoothParamUpdate(this.lowShelfGain.gain, Math.tanh(rawLowShelf / 11) * 10.8);
            smoothParamUpdate(this.subBassFilter.gain, (Math.tanh(rawSubBass / 6.5) * 6.0) + bassEqDelta);
            smoothParamUpdate(this.subMidFilter.gain, (optimizedParams.subMidGain || (6.8 + subMidBoost + warmthBoost * smartWarmthAdjust + userFeedbackAdjust.mid + uiBridge.mid * 0.5)) * transparencyFactor);
            smoothParamUpdate(this.midBassFilter.gain, (optimizedParams.midBassGain || (5.5 + warmthBoost * 0.8 + userFeedbackAdjust.bass + uiBridge.warmth * 0.4)) * transparencyFactor);
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (6.5 + midBoost * songStructure.structureFactor * 1.1 + userFeedbackAdjust.clarity + uiBridge.vocalClarity * 0.5));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (5.0 + midBoost + harmonicEnhanceFactor * 1.1 + instrumentClarity + userFeedbackAdjust.clarity * 0.7 + uiBridge.mid * 0.4)) + vocalEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.5 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (0.4 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.4 + harmonicEnhanceFactor * 0.8 - trebleReduction + userFeedbackAdjust.treble + uiBridge.air * 0.6));
            f1Freq = optimizedParams.f1Freq || (350 * (1 + (spectral.vocalPresence || 0) * 0.15));
            f2Freq = optimizedParams.f2Freq || (1700 * (1 + (spectral.vocalPresence || 0) * 0.15));
            notchFreq = optimizedParams.notchFreq || 5200;
          } else {
            // Cấu hình Cân bằng Bass nẩy chắc gọn gàng (Sử dụng hệ số transientDamping bảo vệ pha)
            const rawLowShelf = optimizedParams.lowShelfGain || (11.2 + subBassBoost + subharmonicGain + userFeedbackAdjust.bass + uiBridge.bass * 0.7);
            const rawSubBass = optimizedParams.subBassGain || (6.2 + subBassBoost + subharmonicGain + userFeedbackAdjust.bass + uiBridge.bass * 0.6);
            smoothParamUpdate(this.lowShelfGain.gain, Math.tanh(rawLowShelf / 11.5) * 11.2 * transientDamping);
            smoothParamUpdate(this.subBassFilter.gain, (Math.tanh(rawSubBass / 6.8) * 6.2 * transientDamping) + bassEqDelta);
            smoothParamUpdate(this.subMidFilter.gain, (optimizedParams.subMidGain || (6.6 + subMidBoost + warmthBoost * smartWarmthAdjust * 0.8 + userFeedbackAdjust.mid + uiBridge.mid * 0.4)) * transparencyFactor);
            smoothParamUpdate(this.midBassFilter.gain, (optimizedParams.midBassGain || (5.6 + warmthBoost + userFeedbackAdjust.bass + uiBridge.warmth * 0.4)) * transparencyFactor);
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (6.2 + midBoost * songStructure.structureFactor + userFeedbackAdjust.clarity + uiBridge.mid * 0.4));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (4.8 + midBoost + harmonicEnhanceFactor + instrumentClarity + userFeedbackAdjust.clarity * 0.6 + uiBridge.mid * 0.4)) + vocalEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.4 - trebleReduction * 0.8 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (0.3 - trebleReduction * 0.8 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.3 + harmonicEnhanceFactor * 0.7 - trebleReduction + userFeedbackAdjust.treble + uiBridge.air * 0.5));
            f1Freq = optimizedParams.f1Freq || (320 * (1 + (spectral.vocalPresence || 0) * 0.15));
            f2Freq = optimizedParams.f2Freq || (1600 * (1 + (spectral.vocalPresence || 0) * 0.15));
            notchFreq = optimizedParams.notchFreq || 5000;
          }
          if (songStructure.section === 'chorus') {
            smoothParamUpdate(this.lowShelfGain.gain, this.lowShelfGain.gain.value * 1.3);
            smoothParamUpdate(this.subBassFilter.gain, this.subBassFilter.gain.value * 1.25);
            smoothParamUpdate(this.compressor.ratio, dynamicCompressionRatio * 1.15);
          } else if (songStructure.section === 'bridge') {
            smoothParamUpdate(this.subBassFilter.gain, this.subBassFilter.gain.value * 1.15);
            smoothParamUpdate(this.highMidFilter.gain, this.highMidFilter.gain.value * 1.1);
          }
          smoothParamUpdate(this.compressor.ratio, optimizedParams.compressorRatio || dynamicCompressionRatio);
          smoothParamUpdate(this.compressor.attack, optimizedParams.compressorAttack || compressorAttack);
          smoothParamUpdate(this.compressor.release, optimizedParams.compressorRelease || compressorRelease);
          smoothParamUpdate(this.compressor.threshold, optimizedParams.compressorThreshold || -15);
          if (this.deEsser?.gain) {
            smoothParamUpdate(this.deEsser.gain, optimizedParams.deEsserGain || dynamicDeEsserGain);
          }
          smoothParamUpdate(this.formantFilter1.frequency, optimizedParams.f1Freq || f1Freq);
          smoothParamUpdate(this.formantFilter1.gain, (optimizedParams.formantGain || (3.2 * vocalTypeFactor)) * sidechainVocalMod);
          smoothParamUpdate(this.formantFilter1.Q, optimizedParams.formantQ || (0.9 * vocalTypeFactor));
          smoothParamUpdate(this.formantFilter2.frequency, optimizedParams.f2Freq || f2Freq);
          smoothParamUpdate(this.formantFilter2.gain, (optimizedParams.formantGain || (3.2 * vocalTypeFactor)) * sidechainVocalMod);
          smoothParamUpdate(this.formantFilter2.Q, optimizedParams.formantQ || (0.9 * vocalTypeFactor));
          smoothParamUpdate(this.notchFilter.frequency, optimizedParams.notchFreq || notchFreq);
          smoothParamUpdate(this.notchFilter.Q, optimizedParams.notchQ || (notchQ * 2.2));
          smoothParamUpdate(this.panner.pan, 0);
          if (this.memoryManager) {
            const cacheKey = 'bassProfile';
            if (this.memoryManager.buffers.has(cacheKey)) this.memoryManager.buffers.delete(cacheKey);
            this.memoryManager.buffers.set(cacheKey, {
              voiceType,
              fundamentalFreq,
              bassPresence: spectral.bassPresence,
              timestamp: Date.now(),
              expiry: Date.now() + 10000
            });
            this.memoryManager.pruneCache(100);
          }
        } else if (profile === "vocal") {
          const {
            vocalTypeFactor,
            voiceType,
            fundamentalFreq
          } = applyVocalClassification();
          const genreAdjust = applyGenreAndStructureAdjustments(vocalTypeFactor);
          const deEsserGain = applyNoiseHandling();
          applyCommonProfileSettings(vocalTypeFactor, genreAdjust, deEsserGain);
          const spectralFlux = spectral.spectralFlux || 0.5;
          const spectralEntropy = spectral.spectralEntropy || 0.5;
          const harmonicRatio = spectral.harmonicRatio || 0.5;
          const transientEnergy = spectral.transientEnergy || 0.5;
          const vocalPresence = spectral.vocalPresence || 0.5;
          let fftSize = 2048;
          if (spectralEntropy > 0.7 || vocalPresence > 0.75) {
            fftSize = 4096;
          } else if (spectralFlux < 0.35 && !this.isVocal) {
            fftSize = 1024;
          }
          this.setFFTSize(fftSize);
          if (this.phaseAligner && typeof this.phaseAligner.frequency?.setValueAtTime === 'function') {
            this.phaseAligner.frequency.setValueAtTime(120, currentTime);
            this.phaseAligner.Q.setValueAtTime(0.707, currentTime);
          }
          if (this.midPhaseAligner && typeof this.midPhaseAligner.frequency?.setValueAtTime === 'function') {
            this.midPhaseAligner.frequency.setValueAtTime(3000, currentTime);
            this.midPhaseAligner.Q.setValueAtTime(0.707, currentTime);
          }
          const {
            vocalTransient,
            instrumentTransient
          } = applyCNNTransientDetection();
          const transientBoost = (vocalTransient > 0.65) ? 1.3 : 1.0;
          const harmonicEnhanceFactor = 1.4 + (harmonicRatio > 0.65 ? 0.4 : 0.2) + (vocalPresence > 0.7 ? 0.3 : 0) + (uiBridge.vocalClarity || 0) * 0.5;
          const instrumentClarity = (spectral.instruments?.guitar || spectral.instruments?.piano) ? 1.3 : 1.0;
          const dynamicCompressionRatio = smartRatio(3.5 + (vocalPresence > 0.75 ? 0.6 : 0));
          const compressorAttack = songStructure.section === 'chorus' ? 0.003 : 0.0045;
          const compressorRelease = songStructure.section === 'chorus' ? 0.2 : 0.25;
          // Bộ cân bằng động (Dynamic EQ) đẩy dải hiện diện của trung âm rõ nét nằm gọn vào beat
          const vocalEqDelta = vocalPresence > 0.65 ? 3.0 : 0;
          let sidechainVocalMod = 1.0;
          if (this.isVocal && vocalPresence > 0.65) {
            sidechainVocalMod = 1.05 * transparencyFactor; // Tối ưu hóa độ dày giọng ca, giúp ca sĩ quyện chặt nhạc nền
          }
          let dynamicDeEsserGain = deEsserGain;
          if (spectralFlux > 0.6 || spectral.air > 0.7) {
            dynamicDeEsserGain = -13 - (spectralFlux - 0.6) * 9;
            if (this.deEsser?.frequency) {
              this.deEsser.frequency.setValueAtTime(7500 + spectral.air * 1000, currentTime);
              this.deEsser.Q.setValueAtTime(3.0, currentTime);
            }
          }
          const smoothParamUpdate = (param, targetValue, timeConstant = 0.08) => {
            if (param && Number.isFinite(targetValue)) {
              param.cancelScheduledValues(currentTime);
              param.setValueAtTime(param.value, currentTime);
              param.linearRampToValueAtTime(targetValue, currentTime + timeConstant);
            }
          };
          if (spectral.bass > 0.65) {
            // Cấu hình Bass-heavy Vocals: Kiểm soát chặt dải trầm nâng đỡ cho ca sĩ
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (8.8 + subBassBoost + warmthBoost * 0.7 + userFeedbackAdjust.bass + uiBridge.bass * 0.4));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (4.5 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.3));
            smoothParamUpdate(this.subMidFilter.gain, optimizedParams.subMidGain || (7.5 + subMidBoost + warmthBoost * smartWarmthAdjust * 0.8 + userFeedbackAdjust.vocalClarity + uiBridge.mid * 0.4));
            smoothParamUpdate(this.midBassFilter.gain, optimizedParams.midBassGain || (4.8 + warmthBoost * 0.7 + userFeedbackAdjust.bass + uiBridge.warmth * 0.3));
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (8.5 + midBoost * songStructure.structureFactor + userFeedbackAdjust.vocalClarity + uiBridge.vocalClarity * 0.7));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (7.0 + midBoost + harmonicEnhanceFactor + instrumentClarity + userFeedbackAdjust.clarity * 0.7 + uiBridge.mid * 0.5)) + vocalEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.6 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (0.4 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.4 + harmonicEnhanceFactor * 0.7 - trebleReduction + userFeedbackAdjust.treble + uiBridge.air * 0.6));
            f1Freq = optimizedParams.f1Freq || (500 * (1 + vocalPresence * 0.15));
            f2Freq = optimizedParams.f2Freq || (2200 * (1 + vocalPresence * 0.15));
            notchFreq = optimizedParams.notchFreq || 5500;
          } else if (spectral.midHigh > 0.65) {
            // Cấu hình Mid-high dominant: Tách bạch rõ ràng giọng ca hát chuẩn mực hi-fi
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (8.5 + subBassBoost + warmthBoost * 0.8 + userFeedbackAdjust.bass + uiBridge.bass * 0.4));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (4.2 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.3));
            smoothParamUpdate(this.subMidFilter.gain, optimizedParams.subMidGain || (7.0 + subMidBoost + warmthBoost * smartWarmthAdjust + userFeedbackAdjust.vocalClarity + uiBridge.mid * 0.5));
            smoothParamUpdate(this.midBassFilter.gain, optimizedParams.midBassGain || (4.5 + warmthBoost * 0.8 + userFeedbackAdjust.bass + uiBridge.warmth * 0.3));
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (8.8 + midBoost * songStructure.structureFactor * 1.2 + userFeedbackAdjust.vocalClarity + uiBridge.vocalClarity * 0.8));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (7.2 + midBoost + harmonicEnhanceFactor * 1.2 + instrumentClarity + userFeedbackAdjust.clarity * 0.8 + uiBridge.mid * 0.6)) + vocalEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.7 - trebleReduction * 0.6 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.5));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (0.5 - trebleReduction * 0.6 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.5 + harmonicEnhanceFactor * 0.8 - trebleReduction + userFeedbackAdjust.treble + uiBridge.air * 0.8));
            f1Freq = optimizedParams.f1Freq || (530 * (1 + vocalPresence * 0.15));
            f2Freq = optimizedParams.f2Freq || (2400 * (1 + vocalPresence * 0.15));
            notchFreq = optimizedParams.notchFreq || 6000;
          } else {
            // Cấu hình Vocal chuẩn tự nhiên (Balanced vocal mix)
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (8.6 + subBassBoost + warmthBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.4));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (4.3 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.3));
            smoothParamUpdate(this.subMidFilter.gain, optimizedParams.subMidGain || (7.6 + subMidBoost + warmthBoost * smartWarmthAdjust + userFeedbackAdjust.vocalClarity + uiBridge.mid * 0.5));
            smoothParamUpdate(this.midBassFilter.gain, optimizedParams.midBassGain || (4.6 + warmthBoost + userFeedbackAdjust.bass + uiBridge.warmth * 0.3));
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (8.6 + midBoost * songStructure.structureFactor + userFeedbackAdjust.vocalClarity + uiBridge.vocalClarity * 0.7));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (7.1 + midBoost + harmonicEnhanceFactor + instrumentClarity + userFeedbackAdjust.clarity * 0.7 + uiBridge.mid * 0.5)) + vocalEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.6 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (0.4 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.4 + harmonicEnhanceFactor * 0.7 - trebleReduction + userFeedbackAdjust.treble + uiBridge.air * 0.7));
            f1Freq = optimizedParams.f1Freq || (520 * (1 + vocalPresence * 0.15));
            f2Freq = optimizedParams.f2Freq || (2300 * (1 + vocalPresence * 0.15));
            notchFreq = optimizedParams.notchFreq || 5800;
          }
          if (songStructure.section === 'chorus') {
            smoothParamUpdate(this.midShelfGain.gain, this.midShelfGain.gain.value * 1.4);
            smoothParamUpdate(this.highMidFilter.gain, this.highMidFilter.gain.value * 1.3);
            smoothParamUpdate(this.compressor.ratio, dynamicCompressionRatio * 1.2);
          } else if (songStructure.section === 'bridge') {
            smoothParamUpdate(this.highMidFilter.gain, this.highMidFilter.gain.value * 1.2);
            smoothParamUpdate(this.subTrebleFilter.gain, this.subTrebleFilter.gain.value * 1.15);
          }
          smoothParamUpdate(this.compressor.ratio, optimizedParams.compressorRatio || dynamicCompressionRatio);
          smoothParamUpdate(this.compressor.attack, optimizedParams.compressorAttack || compressorAttack);
          smoothParamUpdate(this.compressor.release, optimizedParams.compressorRelease || compressorRelease);
          smoothParamUpdate(this.compressor.threshold, optimizedParams.compressorThreshold || -15);
          if (this.deEsser?.gain) {
            smoothParamUpdate(this.deEsser.gain, optimizedParams.deEsserGain || dynamicDeEsserGain);
          }
          smoothParamUpdate(this.formantFilter1.frequency, optimizedParams.f1Freq || f1Freq);
          smoothParamUpdate(this.formantFilter1.gain, (optimizedParams.formantGain || (3.5 * vocalTypeFactor)) * sidechainVocalMod);
          smoothParamUpdate(this.formantFilter1.Q, optimizedParams.formantQ || (1.0 * vocalTypeFactor));
          smoothParamUpdate(this.formantFilter2.frequency, optimizedParams.f2Freq || f2Freq);
          smoothParamUpdate(this.formantFilter2.gain, (optimizedParams.formantGain || (3.5 * vocalTypeFactor)) * sidechainVocalMod);
          smoothParamUpdate(this.formantFilter2.Q, optimizedParams.formantQ || (1.0 * vocalTypeFactor));
          smoothParamUpdate(this.notchFilter.frequency, optimizedParams.notchFreq || notchFreq);
          smoothParamUpdate(this.notchFilter.Q, optimizedParams.notchQ || (notchQ * 2.5));
          smoothParamUpdate(this.panner.pan, 0);
          if (this.memoryManager) {
            const cacheKey = 'voiceProfile';
            if (this.memoryManager.buffers.has(cacheKey)) this.memoryManager.buffers.delete(cacheKey);
            this.memoryManager.buffers.set(cacheKey, {
              voiceType,
              fundamentalFreq,
              vocalPresence: spectral.vocalPresence,
              timestamp: Date.now(),
              expiry: Date.now() + 10000
            });
            this.memoryManager.pruneCache(100);
          }
        } else if (profile === "proNatural") {
          const {
            vocalTypeFactor,
            voiceType,
            fundamentalFreq
          } = applyVocalClassification();
          const genreAdjust = applyGenreAndStructureAdjustments(vocalTypeFactor);
          const deEsserGain = applyNoiseHandling();
          applyCommonProfileSettings(vocalTypeFactor, genreAdjust, deEsserGain);
          const spectralFlux = spectral.spectralFlux || 0.5;
          const spectralEntropy = spectral.spectralEntropy || 0.5;
          const harmonicRatio = spectral.harmonicRatio || 0.5;
          const transientEnergy = spectral.transientEnergy || 0.5;
          const vocalPresence = spectral.vocalPresence || 0.5;
          let fftSize = 2048;
          if (spectralEntropy > 0.65 || vocalPresence > 0.7) {
            fftSize = 4096;
          } else if (spectralFlux < 0.4 && !this.isVocal) {
            fftSize = 1024;
          }
          this.setFFTSize(fftSize);
          if (this.phaseAligner && typeof this.phaseAligner.frequency?.setValueAtTime === 'function') {
            this.phaseAligner.frequency.setValueAtTime(100, currentTime);
            this.phaseAligner.Q.setValueAtTime(0.707, currentTime);
          }
          if (this.midPhaseAligner && typeof this.midPhaseAligner.frequency?.setValueAtTime === 'function') {
            this.midPhaseAligner.frequency.setValueAtTime(2500, currentTime);
            this.midPhaseAligner.Q.setValueAtTime(0.707, currentTime);
          }
          const {
            vocalTransient,
            instrumentTransient
          } = applyCNNTransientDetection();
          const transientBoost = (vocalTransient > 0.6 || instrumentTransient > 0.6) ? 1.2 : 1.0;
          const harmonicEnhanceFactor = 1.3 + (harmonicRatio > 0.6 ? 0.3 : 0.2) + (this.polyphonicPitches?.length > 1 ? 0.2 : 0) + (uiBridge.clarity || 0) * 0.4;
          const instrumentClarity = (spectral.instruments?.guitar || spectral.instruments?.piano || spectral.instruments?.strings) ? 1.4 : 1.0;
          const dynamicCompressionRatio = smartRatio(3.0 + (vocalPresence > 0.7 ? 0.5 : 0));
          const compressorAttack = songStructure.section === 'chorus' ? 0.005 : 0.007;
          const compressorRelease = songStructure.section === 'chorus' ? 0.28 : 0.32;
          // NẬP ĐIỀU CHỈNH ĐỘNG KHÔNG GÂY SAI PHA (Tần số trung thực của đáp tuyến phòng nghe thực tế)
          const vocalEqDelta = vocalPresence > 0.6 ? 2.2 : 0;
          let sidechainVocalMod = 1.0;
          if (this.isVocal && vocalPresence > 0.6) {
            sidechainVocalMod = 1.0 * transparencyFactor;
          }
          let dynamicDeEsserGain = deEsserGain;
          if (spectralFlux > 0.5 || spectral.air > 0.6) {
            dynamicDeEsserGain = -10 - (spectralFlux - 0.5) * 6;
            if (this.deEsser?.frequency) {
              this.deEsser.frequency.setValueAtTime(7000 + spectral.air * 800, currentTime);
              this.deEsser.Q.setValueAtTime(2.5, currentTime);
            }
          }
          const smoothParamUpdate = (param, targetValue, timeConstant = 0.1) => {
            if (param && Number.isFinite(targetValue)) {
              param.cancelScheduledValues(currentTime);
              param.setValueAtTime(param.value, currentTime);
              param.linearRampToValueAtTime(targetValue, currentTime + timeConstant);
            }
          };
          if (spectral.bass > 0.6) {
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (9.5 + subBassBoost + warmthBoost * 0.9 + userFeedbackAdjust.bass + uiBridge.bass * 0.5));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (4.8 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.4));
            smoothParamUpdate(this.subMidFilter.gain, optimizedParams.subMidGain || (6.8 + subMidBoost + warmthBoost * smartWarmthAdjust * 0.8 + userFeedbackAdjust.mid + uiBridge.mid * 0.4));
            smoothParamUpdate(this.midBassFilter.gain, optimizedParams.midBassGain || (5.2 + warmthBoost * 0.9 + userFeedbackAdjust.bass + uiBridge.warmth * 0.4));
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (7.5 + midBoost * songStructure.structureFactor + userFeedbackAdjust.clarity + uiBridge.mid * 0.5));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (6.0 + midBoost + harmonicEnhanceFactor + instrumentClarity + userFeedbackAdjust.clarity * 0.6 + uiBridge.mid * 0.4)) + vocalEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.7 - trebleReduction * 0.8 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (0.5 - trebleReduction * 0.8 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.5 + harmonicEnhanceFactor * 0.7 - trebleReduction + userFeedbackAdjust.treble + uiBridge.air * 0.6));
            f1Freq = optimizedParams.f1Freq || (400 * (1 + vocalPresence * 0.15));
            f2Freq = optimizedParams.f2Freq || (1700 * (1 + vocalPresence * 0.15));
            notchFreq = optimizedParams.notchFreq || 4800;
          } else if (spectral.midHigh > 0.6) {
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (9.0 + subBassBoost + warmthBoost * 0.8 + userFeedbackAdjust.bass + uiBridge.bass * 0.4));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (4.5 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.3));
            smoothParamUpdate(this.subMidFilter.gain, optimizedParams.subMidGain || (7.0 + subMidBoost + warmthBoost * smartWarmthAdjust + userFeedbackAdjust.mid + uiBridge.mid * 0.4));
            smoothParamUpdate(this.midBassFilter.gain, optimizedParams.midBassGain || (5.0 + warmthBoost * 0.8 + userFeedbackAdjust.bass + uiBridge.warmth * 0.3));
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (7.8 + midBoost * songStructure.structureFactor * 1.1 + userFeedbackAdjust.clarity + uiBridge.clarity * 0.5));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (6.2 + midBoost + harmonicEnhanceFactor * 1.1 + instrumentClarity + userFeedbackAdjust.clarity * 0.7 + uiBridge.mid * 0.5)) + vocalEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.8 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (0.6 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.6 + harmonicEnhanceFactor * 0.8 - trebleReduction + userFeedbackAdjust.treble + uiBridge.air * 0.7));
            f1Freq = optimizedParams.f1Freq || (450 * (1 + vocalPresence * 0.15));
            f2Freq = optimizedParams.f2Freq || (1900 * (1 + vocalPresence * 0.15));
            notchFreq = optimizedParams.notchFreq || 5200;
          } else {
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (9.2 + subBassBoost + warmthBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.4));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (4.6 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.3));
            smoothParamUpdate(this.subMidFilter.gain, optimizedParams.subMidGain || (6.9 + subMidBoost + warmthBoost * smartWarmthAdjust + userFeedbackAdjust.mid + uiBridge.mid * 0.4));
            smoothParamUpdate(this.midBassFilter.gain, optimizedParams.midBassGain || (5.1 + warmthBoost + userFeedbackAdjust.bass + uiBridge.warmth * 0.3));
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (7.6 + midBoost * songStructure.structureFactor + userFeedbackAdjust.clarity + uiBridge.mid * 0.4));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (6.1 + midBoost + harmonicEnhanceFactor + instrumentClarity + userFeedbackAdjust.clarity * 0.6 + uiBridge.mid * 0.4)) + vocalEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.7 - trebleReduction * 0.8 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (0.5 - trebleReduction * 0.8 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.5 + harmonicEnhanceFactor * 0.7 - trebleReduction + userFeedbackAdjust.treble + uiBridge.air * 0.6));
            f1Freq = optimizedParams.f1Freq || (430 * (1 + vocalPresence * 0.15));
            f2Freq = optimizedParams.f2Freq || (1800 * (1 + vocalPresence * 0.15));
            notchFreq = optimizedParams.notchFreq || 5000;
          }
          if (songStructure.section === 'chorus') {
            smoothParamUpdate(this.midShelfGain.gain, this.midShelfGain.gain.value * 1.25);
            smoothParamUpdate(this.highMidFilter.gain, this.highMidFilter.gain.value * 1.2);
            smoothParamUpdate(this.compressor.ratio, dynamicCompressionRatio * 1.1);
          } else if (songStructure.section === 'bridge') {
            smoothParamUpdate(this.highMidFilter.gain, this.highMidFilter.gain.value * 1.15);
            smoothParamUpdate(this.subTrebleFilter.gain, this.subTrebleFilter.gain.value * 1.1);
          }
          smoothParamUpdate(this.compressor.ratio, optimizedParams.compressorRatio || dynamicCompressionRatio);
          smoothParamUpdate(this.compressor.attack, optimizedParams.compressorAttack || compressorAttack);
          smoothParamUpdate(this.compressor.release, optimizedParams.compressorRelease || compressorRelease);
          smoothParamUpdate(this.compressor.threshold, optimizedParams.compressorThreshold || -17);
          if (this.deEsser?.gain) {
            smoothParamUpdate(this.deEsser.gain, optimizedParams.deEsserGain || dynamicDeEsserGain);
          }
          smoothParamUpdate(this.formantFilter1.frequency, optimizedParams.f1Freq || f1Freq);
          smoothParamUpdate(this.formantFilter1.gain, (optimizedParams.formantGain || (3.0 * vocalTypeFactor)) * sidechainVocalMod);
          smoothParamUpdate(this.formantFilter1.Q, optimizedParams.formantQ || (0.8 * vocalTypeFactor));
          smoothParamUpdate(this.formantFilter2.frequency, optimizedParams.f2Freq || f2Freq);
          smoothParamUpdate(this.formantFilter2.gain, (optimizedParams.formantGain || (3.0 * vocalTypeFactor)) * sidechainVocalMod);
          smoothParamUpdate(this.formantFilter2.Q, optimizedParams.formantQ || (0.8 * vocalTypeFactor));
          smoothParamUpdate(this.notchFilter.frequency, optimizedParams.notchFreq || notchFreq);
          smoothParamUpdate(this.notchFilter.Q, optimizedParams.notchQ || (notchQ * 2.0));
          smoothParamUpdate(this.panner.pan, 0);
          if (this.memoryManager) {
            const cacheKey = 'voiceProfile';
            if (this.memoryManager.buffers.has(cacheKey)) this.memoryManager.buffers.delete(cacheKey);
            this.memoryManager.buffers.set(cacheKey, {
              voiceType,
              fundamentalFreq,
              vocalPresence: spectral.vocalPresence,
              timestamp: Date.now(),
              expiry: Date.now() + 10000
            });
            this.memoryManager.pruneCache(100);
          }
        } else if (profile === "karaokeDynamic") {
          const {
            vocalTypeFactor,
            voiceType,
            fundamentalFreq
          } = applyVocalClassification();
          const genreAdjust = applyGenreAndStructureAdjustments(vocalTypeFactor);
          const deEsserGain = applyNoiseHandling();
          applyCommonProfileSettings(vocalTypeFactor, genreAdjust, deEsserGain);
          // Phân tích năng lượng phổ thời gian thực cho Karaoke chuyên nghiệp
          const spectralFlux = spectral.spectralFlux || 0.5;
          const spectralEntropy = spectral.spectralEntropy || 0.5;
          const harmonicRatio = spectral.harmonicRatio || 0.5;
          const transientEnergy = spectral.transientEnergy || 0.5;
          const instrumentalPresence = spectral.instrumentalPresence || 0.5;
          // Thích nghi lưới FFTSize tĩnh chống méo pha dải trung
          let fftSize = 2048;
          if (spectralEntropy > 0.6 || transientEnergy > 0.6) {
            fftSize = 4096;
          } else if (spectralFlux < 0.4 && instrumentalPresence < 0.5) {
            fftSize = 1024;
          }
          this.setFFTSize(fftSize);
          // Định hình bộ căn chỉnh pha tĩnh (Static Phase Alignment) bảo vệ độ chắc khỏe của Bass và Mid
          if (this.phaseAligner && typeof this.phaseAligner.frequency?.setValueAtTime === 'function') {
            this.phaseAligner.frequency.setValueAtTime(90, currentTime);
            this.phaseAligner.Q.setValueAtTime(0.707, currentTime);
          }
          if (this.midPhaseAligner && typeof this.midPhaseAligner.frequency?.setValueAtTime === 'function') {
            this.midPhaseAligner.frequency.setValueAtTime(2800, currentTime);
            this.midPhaseAligner.Q.setValueAtTime(0.707, currentTime);
          }
          const {
            instrumentTransient
          } = applyCNNTransientDetection();
          const transientBoost = (instrumentTransient > 0.6 || transientEnergy > 0.65) ? 1.4 : 1.0;
          // Tích hợp cổng chờ UI Bridge đẩy chi tiết nhạc cụ sinh động
          const harmonicEnhanceFactor = 1.3 + (harmonicRatio > 0.6 ? 0.4 : 0.2) + (spectral.instruments?.guitar || spectral.instruments?.piano ? 0.4 : 0) + (uiBridge.clarity || 0) * 0.4;
          const instrumentClarity = (spectral.instruments?.guitar || spectral.instruments?.drums || spectral.instruments?.piano) ? 1.6 : 1.2;
          const dynamicCompressionRatio = smartRatio(3.8 + (instrumentalPresence > 0.7 ? 0.5 : 0));
          const compressorAttack = songStructure.section === 'chorus' ? 0.0035 : 0.005;
          const compressorRelease = songStructure.section === 'chorus' ? 0.22 : 0.28;
          // === ĐỊNH HƯỚNG LẠI DYNAMIC EQ & SIDECHAIN SẠCH RÁC (ZERO-MEMORY LEAK) ===
          // Thay vì tạo node vật lý, ta chuyển đổi năng lượng thành hệ số tăng giảm trực tiếp trên mạch xả tĩnh
          const instrumentEqDelta = instrumentalPresence > 0.6 ? 2.8 : 0;
          let sidechainVocalMod = 1.0;
          if (this.isVocal && spectral.vocalPresence > 0.65) {
            sidechainVocalMod = 0.9 * transparencyFactor; // Dập nhẹ dải đục trung trầm giúp giọng hát nằm gọn quyện chặt beat
          }
          let dynamicDeEsserGain = deEsserGain;
          if (spectralFlux > 0.55 || spectral.air > 0.65) {
            dynamicDeEsserGain = -12 - (spectralFlux - 0.55) * 8;
            if (this.deEsser?.frequency) {
              this.deEsser.frequency.setValueAtTime(7200 + spectral.air * 1000, currentTime);
              this.deEsser.Q.setValueAtTime(2.8, currentTime);
            }
          }
          const smoothParamUpdate = (param, targetValue, timeConstant = 0.09) => {
            if (param && Number.isFinite(targetValue)) {
              param.cancelScheduledValues(currentTime);
              param.setValueAtTime(param.value, currentTime);
              param.linearRampToValueAtTime(targetValue, currentTime + timeConstant);
            }
          };
          if (spectral.bass > 0.65) {
            // Cấu hình Bass-heavy Karaoke Mix: Bass nẩy chắc, tròn trịa, trung âm rõ nét thoát tiếng
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (9.0 + subBassBoost + warmthBoost * 0.8 + userFeedbackAdjust.bass + uiBridge.bass * 0.6));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (4.8 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.5));
            smoothParamUpdate(this.subMidFilter.gain, optimizedParams.subMidGain || (7.8 + subMidBoost + warmthBoost * smartWarmthAdjust * 0.9 + userFeedbackAdjust.vocalClarity + uiBridge.mid * 0.5));
            smoothParamUpdate(this.midBassFilter.gain, optimizedParams.midBassGain || (5.0 + warmthBoost * 0.8 + userFeedbackAdjust.bass + uiBridge.warmth * 0.4));
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (8.8 + midBoost * songStructure.structureFactor + userFeedbackAdjust.vocalClarity + uiBridge.vocalClarity * 0.6));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (7.2 + midBoost + harmonicEnhanceFactor + instrumentClarity + userFeedbackAdjust.clarity * 0.7 + uiBridge.mid * 0.4)) + instrumentEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.7 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.5));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (0.5 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.5 + harmonicEnhanceFactor * 0.8 - trebleReduction + userFeedbackAdjust.treble + uiBridge.air * 0.7));
            // ĐỒNG BỘ THUẬT TOÁN PITCH V5.9 SMART-AI: Giữ độ dày thực và mở rộng hơi dải trầm khi hạ giọng
            f1Freq = optimizedParams.f1Freq || (400 * (1 + instrumentalPresence * 0.15) * (pitchMult < 0 ? 1.04 : 1.0));
            f2Freq = optimizedParams.f2Freq || (1800 * (1 + instrumentalPresence * 0.15) * (pitchMult < 0 ? 1.02 : 1.0));
            notchFreq = optimizedParams.notchFreq || 5500;
          } else if (spectral.midHigh > 0.65) {
            // Cấu hình Mid-high dominant Karaoke
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (8.5 + subBassBoost + warmthBoost * 0.9 + userFeedbackAdjust.bass + uiBridge.bass * 0.5));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (4.5 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.4));
            smoothParamUpdate(this.subMidFilter.gain, optimizedParams.subMidGain || (8.0 + subMidBoost + warmthBoost * smartWarmthAdjust + userFeedbackAdjust.vocalClarity + uiBridge.mid * 0.6));
            smoothParamUpdate(this.midBassFilter.gain, optimizedParams.midBassGain || (4.8 + warmthBoost * 0.9 + userFeedbackAdjust.bass + uiBridge.warmth * 0.4));
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (9.0 + midBoost * songStructure.structureFactor * 1.2 + userFeedbackAdjust.vocalClarity + uiBridge.vocalClarity * 0.7));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (7.5 + midBoost + harmonicEnhanceFactor * 1.2 + instrumentClarity + userFeedbackAdjust.clarity * 0.8 + uiBridge.mid * 0.5)) + instrumentEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.8 - trebleReduction * 0.6 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.6));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (0.6 - trebleReduction * 0.6 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.6 + harmonicEnhanceFactor * 0.9 - trebleReduction + userFeedbackAdjust.treble + uiBridge.air * 0.8));
            f1Freq = optimizedParams.f1Freq || (450 * (1 + instrumentalPresence * 0.15));
            f2Freq = optimizedParams.f2Freq || (2000 * (1 + instrumentalPresence * 0.15));
            notchFreq = optimizedParams.notchFreq || 6000;
          } else {
            // Cấu hình Karaoke linh hoạt cân bằng sống động
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (8.8 + subBassBoost + warmthBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.5));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (4.6 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.4));
            smoothParamUpdate(this.subMidFilter.gain, optimizedParams.subMidGain || (7.9 + subMidBoost + warmthBoost * smartWarmthAdjust + userFeedbackAdjust.vocalClarity + uiBridge.mid * 0.5));
            smoothParamUpdate(this.midBassFilter.gain, optimizedParams.midBassGain || (4.9 + warmthBoost + userFeedbackAdjust.bass + uiBridge.warmth * 0.4));
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (8.9 + midBoost * songStructure.structureFactor + userFeedbackAdjust.vocalClarity + uiBridge.vocalClarity * 0.6));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (7.3 + midBoost + harmonicEnhanceFactor + instrumentClarity + userFeedbackAdjust.clarity * 0.7 + uiBridge.mid * 0.4)) + instrumentEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.7 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.5));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (0.5 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.5 + harmonicEnhanceFactor * 0.8 - trebleReduction + userFeedbackAdjust.treble + uiBridge.air * 0.7));
            f1Freq = optimizedParams.f1Freq || (430 * (1 + instrumentalPresence * 0.15));
            f2Freq = optimizedParams.f2Freq || (1800 * (1 + instrumentalPresence * 0.15));
            notchFreq = optimizedParams.notchFreq || 5800;
          }
          if (songStructure.section === 'chorus') {
            smoothParamUpdate(this.midShelfGain.gain, this.midShelfGain.gain.value * 1.35);
            smoothParamUpdate(this.highMidFilter.gain, this.highMidFilter.gain.value * 1.25);
            smoothParamUpdate(this.compressor.ratio, dynamicCompressionRatio * 1.15);
          } else if (songStructure.section === 'bridge') {
            smoothParamUpdate(this.highMidFilter.gain, this.highMidFilter.gain.value * 1.15);
            smoothParamUpdate(this.subTrebleFilter.gain, this.subTrebleFilter.gain.value * 1.1);
          }
          smoothParamUpdate(this.compressor.ratio, optimizedParams.compressorRatio || dynamicCompressionRatio);
          smoothParamUpdate(this.compressor.attack, optimizedParams.compressorAttack || compressorAttack);
          smoothParamUpdate(this.compressor.release, optimizedParams.compressorRelease || compressorRelease);
          smoothParamUpdate(this.compressor.threshold, optimizedParams.compressorThreshold || -14);
          if (this.deEsser?.gain) {
            smoothParamUpdate(this.deEsser.gain, optimizedParams.deEsserGain || dynamicDeEsserGain);
          }
          smoothParamUpdate(this.formantFilter1.frequency, optimizedParams.f1Freq || f1Freq);
          smoothParamUpdate(this.formantFilter1.gain, (optimizedParams.formantGain || (3.2 * vocalTypeFactor)) * sidechainVocalMod);
          smoothParamUpdate(this.formantFilter1.Q, optimizedParams.formantQ || (0.9 * vocalTypeFactor));
          smoothParamUpdate(this.formantFilter2.frequency, optimizedParams.f2Freq || f2Freq);
          smoothParamUpdate(this.formantFilter2.gain, (optimizedParams.formantGain || (3.2 * vocalTypeFactor)) * sidechainVocalMod);
          smoothParamUpdate(this.formantFilter2.Q, optimizedParams.formantQ || (0.9 * vocalTypeFactor));
          smoothParamUpdate(this.notchFilter.frequency, optimizedParams.notchFreq || notchFreq);
          smoothParamUpdate(this.notchFilter.Q, optimizedParams.notchQ || (notchQ * 2.2));
          smoothParamUpdate(this.panner.pan, 0);
          if (this.memoryManager) {
            const cacheKey = 'instrumentProfile';
            if (this.memoryManager.buffers.has(cacheKey)) this.memoryManager.buffers.delete(cacheKey);
            this.memoryManager.buffers.set(cacheKey, {
              voiceType,
              fundamentalFreq,
              instrumentalPresence: spectral.instrumentalPresence,
              timestamp: Date.now(),
              expiry: Date.now() + 10000
            });
            this.memoryManager.pruneCache(100);
          }
        } else if (profile === "rockMetal") {
          const {
            vocalTypeFactor,
            voiceType,
            fundamentalFreq
          } = applyVocalClassification();
          const genreAdjust = applyGenreAndStructureAdjustments(vocalTypeFactor);
          const deEsserGain = applyNoiseHandling();
          applyCommonProfileSettings(vocalTypeFactor, genreAdjust, deEsserGain);
          const spectralFlux = spectral.spectralFlux || 0.5;
          const spectralEntropy = spectral.spectralEntropy || 0.5;
          const harmonicRatio = spectral.harmonicRatio || 0.5;
          const transientEnergy = spectral.transientEnergy || 0.5;
          const vocalPresence = spectral.vocalPresence || 0.5;
          let fftSize = 2048;
          if (spectralEntropy > 0.7 || transientEnergy > 0.65) {
            fftSize = 4096;
          } else if (spectralFlux < 0.35 && !this.isVocal) {
            fftSize = 1024;
          }
          this.setFFTSize(fftSize);
          if (this.phaseAligner && typeof this.phaseAligner.frequency?.setValueAtTime === 'function') {
            this.phaseAligner.frequency.setValueAtTime(80, currentTime);
            this.phaseAligner.Q.setValueAtTime(0.707, currentTime);
          }
          if (this.midPhaseAligner && typeof this.midPhaseAligner.frequency?.setValueAtTime === 'function') {
            this.midPhaseAligner.frequency.setValueAtTime(3000, currentTime);
            this.midPhaseAligner.Q.setValueAtTime(0.707, currentTime);
          }
          const {
            vocalTransient,
            instrumentTransient
          } = applyCNNTransientDetection();
          const transientBoost = (instrumentTransient > 0.65 || transientEnergy > 0.7) ? 1.5 : 1.0;
          // Tích hợp cổng chờ UI Bridge cho dải trung cao gai góc uy lực đặc trưng Rock/Metal
          const harmonicEnhanceFactor = 1.5 + (harmonicRatio > 0.7 ? 0.5 : 0.2) + (spectral.instruments?.guitar ? 0.6 : 0) + (uiBridge.harmonicRichness || 0) * 0.6;
          const instrumentClarity = (spectral.instruments?.guitar || spectral.instruments?.drums) ? 1.8 : 1.2;
          const dynamicCompressionRatio = smartRatio(4.2 + (vocalPresence > 0.7 ? 0.8 : 0));
          const compressorAttack = songStructure.section === 'chorus' ? 0.003 : 0.005;
          const compressorRelease = songStructure.section === 'chorus' ? 0.2 : 0.28;
          // Nạp trực tiếp tham số EQ guitar gai góc uy lực vào mạch xả tĩnh trung cao
          const guitarEqDelta = spectral.instruments?.guitar ? 3.0 : 0;
          let sidechainVocalMod = 1.0;
          if (this.isVocal && vocalPresence > 0.65) {
            sidechainVocalMod = 0.85 * transparencyFactor; // Đẩy nén dập đục mạnh hơn để giữ vocal sắc sảo trên nền distortion dày đặc
          }
          let dynamicDeEsserGain = deEsserGain;
          if (spectralFlux > 0.6 || spectral.air > 0.7) {
            dynamicDeEsserGain = -14 - (spectralFlux - 0.6) * 10;
            if (this.deEsser?.frequency) {
              this.deEsser.frequency.setValueAtTime(7500 + spectral.air * 1200, currentTime);
              this.deEsser.Q.setValueAtTime(3.0, currentTime);
            }
          }
          const smoothParamUpdate = (param, targetValue, timeConstant = 0.08) => {
            if (param && Number.isFinite(targetValue)) {
              param.cancelScheduledValues(currentTime);
              param.setValueAtTime(param.value, currentTime);
              param.linearRampToValueAtTime(targetValue, currentTime + timeConstant);
            }
          };
          if (spectral.bass > 0.7) {
            // Cấu hình Bass-heavy Rock: Giữ vững lực kick drum căng tràn, guitar bass nẩy chắc dứt khoát
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (10.2 + subBassBoost + warmthBoost * 0.7 + subharmonicGain + userFeedbackAdjust.bass + uiBridge.bass * 0.7));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (5.5 + subBassBoost + subharmonicGain + userFeedbackAdjust.bass + uiBridge.bass * 0.6));
            smoothParamUpdate(this.subMidFilter.gain, (optimizedParams.subMidGain || (6.5 + subMidBoost + warmthBoost * smartWarmthAdjust * 0.8 + userFeedbackAdjust.mid + uiBridge.mid * 0.4)) * transparencyFactor);
            smoothParamUpdate(this.midBassFilter.gain, (optimizedParams.midBassGain || (5.0 + warmthBoost * 0.7 + userFeedbackAdjust.bass + uiBridge.warmth * 0.3)) * transparencyFactor);
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (7.5 + midBoost * songStructure.structureFactor + userFeedbackAdjust.mid + uiBridge.mid * 0.5));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (6.0 + midBoost + harmonicEnhanceFactor + instrumentClarity + userFeedbackAdjust.clarity * 0.7 + uiBridge.mid * 0.5)) + guitarEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.7 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.5));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleFilter || (0.5 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.4 + harmonicEnhanceFactor * 0.7 - trebleReduction + userFeedbackAdjust.air + uiBridge.air * 0.6));
            // ĐỒNG BỘ THUẬT TOÁN PITCH V5.9 CHỐNG BỊ NGHẸT TIẾNG KHI HẠ TONE SÂU VỚI GUITAR DISTORTION
            f1Freq = optimizedParams.f1Freq || (400 * (1 + vocalPresence * 0.15) * (pitchMult < 0 ? 1.06 : 1.0));
            f2Freq = optimizedParams.f2Freq || (1800 * (1 + vocalPresence * 0.15) * (pitchMult < 0 ? 1.03 : 1.0));
            notchFreq = optimizedParams.notchFreq || 5000;
          } else if (spectral.midHigh > 0.7) {
            // Cấu hình Mid-high dominant: Đẩy rực dải trung cao cho solo guitar bứt phá
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (9.0 + subBassBoost + warmthBoost * 0.8 + subharmonicGain + userFeedbackAdjust.bass + uiBridge.bass * 0.6));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (4.8 + subBassBoost + subharmonicGain + userFeedbackAdjust.bass + uiBridge.bass * 0.5));
            smoothParamUpdate(this.subMidFilter.gain, (optimizedParams.subMidGain || (7.0 + subMidBoost + warmthBoost * smartWarmthAdjust + userFeedbackAdjust.mid + uiBridge.mid * 0.4)) * transparencyFactor);
            smoothParamUpdate(this.midBassFilter.gain, (optimizedParams.midBassGain || (4.8 + warmthBoost * 0.8 + userFeedbackAdjust.bass + uiBridge.warmth * 0.4)) * transparencyFactor);
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (8.0 + midBoost * songStructure.structureFactor * 1.3 + userFeedbackAdjust.mid + uiBridge.mid * 0.6));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (6.5 + midBoost + harmonicEnhanceFactor * 1.3 + instrumentClarity + userFeedbackAdjust.clarity * 0.8 + uiBridge.mid * 0.6)) + guitarEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.9 - trebleReduction * 0.6 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.6));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (0.7 - trebleReduction * 0.6 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.5));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.6 + harmonicEnhanceFactor * 0.8 - trebleReduction + userFeedbackAdjust.air + uiBridge.air * 0.7));
            f1Freq = optimizedParams.f1Freq || (480 * (1 + vocalPresence * 0.15));
            f2Freq = optimizedParams.f2Freq || (2200 * (1 + vocalPresence * 0.15));
            notchFreq = optimizedParams.notchFreq || 6000;
          } else {
            // Cấu hình Rock/Metal toàn dải cân bằng uy lực đầy đặn
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (9.5 + subBassBoost + warmthBoost + subharmonicGain + userFeedbackAdjust.bass + uiBridge.bass * 0.6));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (5.0 + subBassBoost + subharmonicGain + userFeedbackAdjust.bass + uiBridge.bass * 0.5));
            smoothParamUpdate(this.subMidFilter.gain, (optimizedParams.subMidGain || (6.8 + subMidBoost + warmthBoost * smartWarmthAdjust + userFeedbackAdjust.mid + uiBridge.mid * 0.4)) * transparencyFactor);
            smoothParamUpdate(this.midBassFilter.gain, (optimizedParams.midBassGain || (5.0 + warmthBoost + userFeedbackAdjust.bass + uiBridge.warmth * 0.3)) * transparencyFactor);
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (7.8 + midBoost * songStructure.structureFactor + userFeedbackAdjust.mid + uiBridge.mid * 0.5));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (6.2 + midBoost + harmonicEnhanceFactor + instrumentClarity + userFeedbackAdjust.clarity * 0.7 + uiBridge.mid * 0.5)) + guitarEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.8 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.5));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleGain || (0.6 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.5 + harmonicEnhanceFactor * 0.7 - trebleReduction + userFeedbackAdjust.air + uiBridge.air * 0.6));
            f1Freq = optimizedParams.f1Freq || (450 * (1 + vocalPresence * 0.15));
            f2Freq = optimizedParams.f2Freq || (2000 * (1 + vocalPresence * 0.15));
            notchFreq = optimizedParams.notchFreq || 5500;
          }
          if (songStructure.section === 'chorus') {
            smoothParamUpdate(this.midShelfGain.gain, this.midShelfGain.gain.value * 1.4);
            smoothParamUpdate(this.highMidFilter.gain, this.highMidFilter.gain.value * 1.3);
            smoothParamUpdate(this.compressor.ratio, dynamicCompressionRatio * 1.2);
          } else if (songStructure.section === 'bridge') {
            smoothParamUpdate(this.highMidFilter.gain, this.highMidFilter.gain.value * 1.2);
            smoothParamUpdate(this.subTrebleFilter.gain, this.subTrebleFilter.gain.value * 1.15);
          }
          smoothParamUpdate(this.compressor.ratio, optimizedParams.compressorRatio || dynamicCompressionRatio);
          smoothParamUpdate(this.compressor.attack, optimizedParams.compressorAttack || compressorAttack);
          smoothParamUpdate(this.compressor.release, optimizedParams.compressorRelease || compressorRelease);
          smoothParamUpdate(this.compressor.threshold, optimizedParams.compressorThreshold || -15);
          if (this.deEsser?.gain) {
            smoothParamUpdate(this.deEsser.gain, optimizedParams.deEsserGain || dynamicDeEsserGain);
          }
          smoothParamUpdate(this.formantFilter1.frequency, optimizedParams.f1Freq || f1Freq);
          smoothParamUpdate(this.formantFilter1.gain, (optimizedParams.formantGain || (3.5 * vocalTypeFactor)) * sidechainVocalMod);
          smoothParamUpdate(this.formantFilter1.Q, optimizedParams.formantQ || (1.0 * vocalTypeFactor));
          smoothParamUpdate(this.formantFilter2.frequency, optimizedParams.f2Freq || f2Freq);
          smoothParamUpdate(this.formantFilter2.gain, (optimizedParams.formantGain || (3.5 * vocalTypeFactor)) * sidechainVocalMod);
          smoothParamUpdate(this.formantFilter2.Q, optimizedParams.formantQ || (1.0 * vocalTypeFactor));
          smoothParamUpdate(this.notchFilter.frequency, optimizedParams.notchFreq || notchFreq);
          smoothParamUpdate(this.notchFilter.Q, optimizedParams.notchQ || (notchQ * 2.5));
          smoothParamUpdate(this.panner.pan, 0);
          if (this.memoryManager) {
            const cacheKey = 'voiceProfile';
            if (this.memoryManager.buffers.has(cacheKey)) this.memoryManager.buffers.delete(cacheKey);
            this.memoryManager.buffers.set(cacheKey, {
              voiceType,
              fundamentalFreq,
              vocalPresence: spectral.vocalPresence,
              timestamp: Date.now(),
              expiry: Date.now() + 10000
            });
            this.memoryManager.pruneCache(100);
          }
        } else if (profile === "smartStudio") {
          const {
            vocalTypeFactor,
            voiceType,
            fundamentalFreq
          } = applyVocalClassification();
          const genreAdjust = applyGenreAndStructureAdjustments(vocalTypeFactor);
          const deEsserGain = applyNoiseHandling();
          applyCommonProfileSettings(vocalTypeFactor, genreAdjust, deEsserGain);
          const spectralFlux = spectral.spectralFlux || 0.5;
          const spectralEntropy = spectral.spectralEntropy || 0.5;
          const harmonicRatio = spectral.harmonicRatio || 0.5;
          const transientEnergy = spectral.transientEnergy || 0.5;
          const vocalPresence = spectral.vocalPresence || 0.5;
          let fftSize = 2048;
          if (spectralEntropy > 0.65 || vocalPresence > 0.7) {
            fftSize = 4096;
          } else if (spectralFlux < 0.4 && !this.isVocal) {
            fftSize = 1024;
          }
          this.setFFTSize(fftSize);
          if (this.phaseAligner && typeof this.phaseAligner.frequency?.setValueAtTime === 'function') {
            this.phaseAligner.frequency.setValueAtTime(100, currentTime);
            this.phaseAligner.Q.setValueAtTime(0.707, currentTime);
          }
          if (this.midPhaseAligner && typeof this.midPhaseAligner.frequency?.setValueAtTime === 'function') {
            this.midPhaseAligner.frequency.setValueAtTime(2500, currentTime);
            this.midPhaseAligner.Q.setValueAtTime(0.707, currentTime);
          }
          const {
            vocalTransient,
            instrumentTransient
          } = applyCNNTransientDetection();
          const transientBoost = (vocalTransient > 0.6 || instrumentTransient > 0.6) ? 1.3 : 1.0;
          // Tích hợp hệ số kích hài tự nhiên và cổng chờ UI Bridge cho cấu hình Studio độ chi tiết cao
          const harmonicEnhanceFactor = 1.2 + (harmonicRatio > 0.65 ? 0.4 : 0.2) + (this.polyphonicPitches?.length > 1 ? 0.3 : 0) + (uiBridge.clarity || 0) * 0.5;
          const instrumentClarity = (spectral.instruments?.guitar || spectral.instruments?.piano) ? 1.5 : 1.0;
          const dynamicCompressionRatio = smartRatio(3.5 + (vocalPresence > 0.7 ? 0.5 : 0));
          const compressorAttack = songStructure.section === 'chorus' ? 0.004 : 0.006;
          const compressorRelease = songStructure.section === 'chorus' ? 0.25 : 0.3;
          // Nạp trực tiếp hệ số bù trừ dập đục của phòng thu thực tế vào mạch trung âm
          const vocalEqDelta = vocalPresence > 0.6 ? 2.5 : 0;
          let sidechainVocalMod = 1.0;
          if (this.isVocal && vocalPresence > 0.6) {
            sidechainVocalMod = 1.0 * transparencyFactor; // Đảm bảo độ khô chân thực tuyệt đối, triệt tiêu vang ảo
          }
          let dynamicDeEsserGain = deEsserGain;
          if (spectralFlux > 0.55 || spectral.air > 0.65) {
            dynamicDeEsserGain = -12 - (spectralFlux - 0.55) * 8;
            if (this.deEsser?.frequency) {
              this.deEsser.frequency.setValueAtTime(7000 + spectral.air * 1000, currentTime);
              this.deEsser.Q.setValueAtTime(2.5, currentTime);
            }
          }
          const smoothParamUpdate = (param, targetValue, timeConstant = 0.1) => {
            if (param && Number.isFinite(targetValue)) {
              param.cancelScheduledValues(currentTime);
              param.setValueAtTime(param.value, currentTime);
              param.linearRampToValueAtTime(targetValue, currentTime + timeConstant);
            }
          };
          if (spectral.bass > 0.65) {
            // Cấu hình Bass-heavy Studio mix: Kiểm soát dải tần sắc nét, phẳng và trong suốt
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (9.8 + subBassBoost + warmthBoost * 0.8 + userFeedbackAdjust.bass + uiBridge.bass * 0.5));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (4.8 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.4));
            smoothParamUpdate(this.subMidFilter.gain, optimizedParams.subMidGain || (6.2 + subMidBoost + warmthBoost * smartWarmthAdjust * 0.9 + userFeedbackAdjust.mid + uiBridge.mid * 0.4));
            smoothParamUpdate(this.midBassFilter.gain, optimizedParams.midBassGain || (4.8 + warmthBoost * 0.8 + userFeedbackAdjust.bass + uiBridge.warmth * 0.3));
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (6.8 + midBoost * songStructure.structureFactor + userFeedbackAdjust.mid + uiBridge.mid * 0.5));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (5.0 + midBoost + harmonicEnhanceFactor + instrumentClarity + userFeedbackAdjust.clarity * 0.6 + uiBridge.mid * 0.4)) + vocalEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.5 - trebleReduction * 0.8 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleFilter || (0.3 - trebleReduction * 0.8 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.3 + harmonicEnhanceFactor * 0.8 - trebleReduction + userFeedbackAdjust.air + uiBridge.air * 0.6));
            f1Freq = optimizedParams.f1Freq || (340 * (1 + vocalPresence * 0.15));
            f2Freq = optimizedParams.f2Freq || (1650 * (1 + vocalPresence * 0.15));
            notchFreq = optimizedParams.notchFreq || 4500;
          } else if (spectral.midHigh > 0.65) {
            // Cấu hình Mid-high dominant Studio mix
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (8.8 + subBassBoost + warmthBoost * 0.9 + userFeedbackAdjust.bass + uiBridge.bass * 0.5));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (4.2 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.4));
            smoothParamUpdate(this.subMidFilter.gain, optimizedParams.subMidGain || (6.8 + subMidBoost + warmthBoost * smartWarmthAdjust + userFeedbackAdjust.mid + uiBridge.mid * 0.4));
            smoothParamUpdate(this.midBassFilter.gain, optimizedParams.midBassGain || (4.5 + warmthBoost * 0.9 + userFeedbackAdjust.bass + uiBridge.warmth * 0.3));
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (7.5 + midBoost * songStructure.structureFactor * 1.2 + userFeedbackAdjust.mid + uiBridge.mid * 0.6));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (5.8 + midBoost + harmonicEnhanceFactor * 1.2 + instrumentClarity + userFeedbackAdjust.clarity * 0.7 + uiBridge.mid * 0.5)) + vocalEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.7 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleFilter || (0.5 - trebleReduction * 0.7 + harmonicEnhanceFactor + transientBoost + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.5 + harmonicEnhanceFactor * 0.9 - trebleReduction + userFeedbackAdjust.air + uiBridge.air * 0.7));
            f1Freq = optimizedParams.f1Freq || (450 * (1 + vocalPresence * 0.15));
            f2Freq = optimizedParams.f2Freq || (2100 * (1 + vocalPresence * 0.15));
            notchFreq = optimizedParams.notchFreq || 5500;
          } else {
            // Cấu hình Studio chuẩn mực tham chiếu phẳng, chân thực sắc nét
            smoothParamUpdate(this.lowShelfGain.gain, optimizedParams.lowShelfGain || (9.2 + subBassBoost + warmthBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.5));
            smoothParamUpdate(this.subBassFilter.gain, optimizedParams.subBassGain || (4.5 + subBassBoost + userFeedbackAdjust.bass + uiBridge.bass * 0.4));
            smoothParamUpdate(this.subMidFilter.gain, optimizedParams.subMidGain || (6.5 + subMidBoost + warmthBoost * smartWarmthAdjust + userFeedbackAdjust.mid + uiBridge.mid * 0.4));
            smoothParamUpdate(this.midBassFilter.gain, optimizedParams.midBassGain || (4.8 + warmthBoost + userFeedbackAdjust.bass + uiBridge.warmth * 0.3));
            smoothParamUpdate(this.midShelfGain.gain, optimizedParams.midShelfGain || (7.2 + midBoost * songStructure.structureFactor + userFeedbackAdjust.mid + uiBridge.mid * 0.5));
            smoothParamUpdate(this.highMidFilter.gain, (optimizedParams.highMidGain || (5.5 + midBoost + harmonicEnhanceFactor + instrumentClarity + userFeedbackAdjust.clarity * 0.6 + uiBridge.mid * 0.4)) + vocalEqDelta);
            smoothParamUpdate(this.highShelfGain.gain, optimizedParams.highShelfGain || (0.6 - trebleReduction * 0.8 + harmonicEnhanceFactor + (isTransientGenre ? transientBoost : 0) + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.subTrebleFilter.gain, optimizedParams.subTrebleFilter || (0.4 - trebleReduction * 0.8 + harmonicEnhanceFactor + (isTransientGenre ? transientBoost : 0) + userFeedbackAdjust.treble + uiBridge.treble * 0.4));
            smoothParamUpdate(this.airFilter.gain, optimizedParams.airGain || (0.4 + harmonicEnhanceFactor * 0.8 - trebleReduction + userFeedbackAdjust.air + uiBridge.air * 0.6));
            f1Freq = optimizedParams.f1Freq || (420 * (1 + vocalPresence * 0.15));
            f2Freq = optimizedParams.f2Freq || (1900 * (1 + vocalPresence * 0.15));
            notchFreq = optimizedParams.notchFreq || 5000;
          }
          if (songStructure.section === 'chorus') {
            smoothParamUpdate(this.midShelfGain.gain, this.midShelfGain.gain.value * 1.3);
            smoothParamUpdate(this.highMidFilter.gain, this.highMidFilter.gain.value * 1.2);
            smoothParamUpdate(this.compressor.ratio, dynamicCompressionRatio * 1.15);
          } else if (songStructure.section === 'bridge') {
            smoothParamUpdate(this.highMidFilter.gain, this.highMidFilter.gain.value * 1.15);
            smoothParamUpdate(this.subTrebleFilter.gain, this.subTrebleFilter.gain.value * 1.1);
          }
          smoothParamUpdate(this.compressor.ratio, optimizedParams.compressorRatio || dynamicCompressionRatio);
          smoothParamUpdate(this.compressor.attack, optimizedParams.compressorAttack || compressorAttack);
          smoothParamUpdate(this.compressor.release, optimizedParams.compressorRelease || compressorRelease);
          smoothParamUpdate(this.compressor.threshold, optimizedParams.compressorThreshold || -16);
          if (this.deEsser?.gain) {
            smoothParamUpdate(this.deEsser.gain, optimizedParams.deEsserGain || dynamicDeEsserGain);
          }
          smoothParamUpdate(this.formantFilter1.frequency, optimizedParams.f1Freq || f1Freq);
          smoothParamUpdate(this.formantFilter1.gain, (optimizedParams.formantGain || (3.0 * vocalTypeFactor)) * sidechainVocalMod);
          smoothParamUpdate(this.formantFilter1.Q, optimizedParams.formantQ || (0.8 * vocalTypeFactor));
          smoothParamUpdate(this.formantFilter2.frequency, optimizedParams.f2Freq || f2Freq);
          smoothParamUpdate(this.formantFilter2.gain, (optimizedParams.formantGain || (3.0 * vocalTypeFactor)) * sidechainVocalMod);
          smoothParamUpdate(this.formantFilter2.Q, optimizedParams.formantQ || (0.8 * vocalTypeFactor));
          smoothParamUpdate(this.notchFilter.frequency, optimizedParams.notchFreq || notchFreq);
          smoothParamUpdate(this.notchFilter.Q, optimizedParams.notchQ || (notchQ * 2.0));
          smoothParamUpdate(this.panner.pan, 0);
          if (this.memoryManager) {
            const cacheKey = 'voiceProfile';
            if (this.memoryManager.buffers.has(cacheKey)) this.memoryManager.buffers.delete(cacheKey);
            this.memoryManager.buffers.set(cacheKey, {
              voiceType,
              fundamentalFreq,
              vocalPresence: spectral.vocalPresence,
              timestamp: Date.now(),
              expiry: Date.now() + 10000
            });
            this.memoryManager.pruneCache(100);
          }
        }
        // === HỆ THỐNG ĐIỀU KHIỂN FORMANT V5.8 NÂNG CAO: TÁCH BẠCH & SẮC NÉT ===
        if (!this.formantFilter1?.frequency || !this.formantFilter2?.frequency) {
          throw new Error("Formant filters (1 or 2) are not initialized");
        }
        const rampEnd = currentTime + (this.rampTime || 0.05);
        // Khóa cứng tham số (Hard-Cap Protection) tránh dải tần vượt ngưỡng gây chói xé tiếng
        const safeF1 = Math.max(200, Math.min(1200, f1Freq));
        const safeF2 = Math.max(1000, Math.min(3500, f2Freq));
        const safeFormantGain = Math.max(0, Math.min(6.5, formantGain));
        const safeFormantQ = Math.max(0.3, Math.min(3.5, formantQ));
        // Áp dụng Ramp mượt tuyến tính lên hệ thống Formant tĩnh cố định bảo vệ mạch pha nguyên bản
        this.formantFilter1.frequency.linearRampToValueAtTime(safeF1, rampEnd);
        this.formantFilter1.gain.linearRampToValueAtTime(safeFormantGain, rampEnd);
        this.formantFilter1.Q.linearRampToValueAtTime(safeFormantQ, rampEnd);
        this.formantFilter2.frequency.linearRampToValueAtTime(safeF2, rampEnd);
        this.formantFilter2.gain.linearRampToValueAtTime(safeFormantGain * 0.85, rampEnd);
        this.formantFilter2.Q.linearRampToValueAtTime(safeFormantQ * 1.15, rampEnd);
        // === LỚP XỬ LÝ KHUYẾN NGHỊ CHẤT LƯỢNG PHỔ (PRO QUALITY PREDICTION RECOMMENDATIONS) ===
        const recommendations = this.qualityPrediction?.recommendations || [];
        const recLength = recommendations.length;
        for (let i = 0; i < recLength; i++) {
          try {
            const rec = recommendations[i];
            if (typeof rec !== 'string') continue;
            // Chốt chặn an toàn tuyệt đối chống Underflow / Null Pointer trước khi thực hiện Ramp
            if (rec.includes("Reduce sub-bass")) {
              if (this.subBassFilter?.gain && this.lowShelfGain?.gain) {
                this.subBassFilter.gain.linearRampToValueAtTime(Math.max(this.subBassFilter.gain.value - 0.8, 0), rampEnd);
                this.lowShelfGain.gain.linearRampToValueAtTime(Math.max(this.lowShelfGain.gain.value - 0.8, 0), rampEnd);
              }
            }
            if (rec.includes("Reduce treble/sub-treble")) {
              if (this.highShelfGain?.gain && this.subTrebleFilter?.gain) {
                this.highShelfGain.gain.linearRampToValueAtTime(Math.max(this.highShelfGain.gain.value - 0.8, 0), rampEnd);
                this.subTrebleFilter.gain.linearRampToValueAtTime(Math.max(this.subTrebleFilter.gain.value - 0.8, 0), rampEnd);
              }
              if (this.deEsser?.gain) {
                this.deEsser.gain.linearRampToValueAtTime(-8, rampEnd);
              }
            }
            if (rec.includes("Apply noise reduction")) {
              if (this.notchFilter?.Q && this.notchFilter?.frequency) {
                this.notchFilter.Q.linearRampToValueAtTime(this.notchQ * 4.5, rampEnd);
                this.notchFilter.frequency.linearRampToValueAtTime(6000, rampEnd);
              }
            }
            if (rec.includes("Boost instrument frequencies")) {
              const instrumentBoost = (this.polyphonicPitches?.length || 0) > 1 ? 2.2 : 1.8;
              if (this.subMidFilter?.gain && this.highMidFilter?.gain) {
                this.subMidFilter.gain.linearRampToValueAtTime(this.subMidFilter.gain.value + instrumentBoost, rampEnd);
                this.highMidFilter.gain.linearRampToValueAtTime(this.highMidFilter.gain.value + instrumentBoost, rampEnd);
              }
            }
            if (rec.includes("Apply soft compression")) {
              if (this.compressor?.ratio && this.compressor?.attack && this.compressor?.release) {
                const currentRatio = this.compressor.ratio.value;
                this.compressor.ratio.linearRampToValueAtTime(smartRatio(currentRatio + 0.8), rampEnd);
                this.compressor.attack.linearRampToValueAtTime(0.008, rampEnd);
                this.compressor.release.linearRampToValueAtTime(0.32, rampEnd);
              }
            }
            if (rec.includes("Increase transient shaping")) {
              if (this.subTrebleFilter?.gain && this.highShelfGain?.gain) {
                const tBoost = this.transientBoost || 0;
                this.subTrebleFilter.gain.linearRampToValueAtTime(this.subTrebleFilter.gain.value + 0.6 + (tBoost * 0.6), rampEnd);
                this.highShelfGain.gain.linearRampToValueAtTime(this.highShelfGain.gain.value + 0.5 + (tBoost * 0.5), rampEnd);
              }
            }
          } catch (recError) {
            // Chốt chặn an toàn vòng lặp: Không cho phép lỗi cục bộ làm gián đoạn luồng xử lý chính
            console.warn("Quality Recommendation failed to apply safely:", recError);
          }
        }
        // Bù đắp lượng Vitamin hòa âm nắn biên phổ phi tuyến mềm mại
        const safeHarmonicBoost = typeof harmonicBoost === 'number' ? harmonicBoost : 0;
        this.setBoost(optimizedParams.boost || (0.7 + safeHarmonicBoost));
        this.applyVitamin(profile, pitchMult, absPitchMult);
        // Đóng băng cập nhật cấu trúc đặc trưng phổ cho các chu kỳ quét tiếp theo
        this.spectralProfile = {
          ...spectral,
          spectralFlux: spectral.spectralFlux || 0.5,
          spectralEntropy: spectral.spectralEntropy || 0.5,
          harmonicRatio: spectral.harmonicRatio || 0.5
        };
        // === HỆ THỐNG QUẢN LÝ BỘ NHỚ LÀM SẠCH CACHE TÍCH CỰC (ZERO-GC CACHING) ===
        if (this.memoryManager) {
          const cacheKey = 'soundProfile';
          if (this.memoryManager.buffers.has(cacheKey)) {
            this.memoryManager.buffers.delete(cacheKey);
          }
          this.memoryManager.buffers.set(cacheKey, {
            profile,
            settings: Object.freeze({
              ...optimizedParams
            }), // Đóng băng Object chặn đứng hoàn toàn rủi ro dính leak tham chiếu
            timestamp: Date.now(),
            expiry: Date.now() + 10000
          });
          // Kích hoạt giải phóng vùng nhớ đệm dứt khoát khi RAM chạm ngưỡng tải
          this.memoryManager.pruneCache(80);
        }
        console.debug('Sound profile set successfully with advanced optimization', {
          profile,
          spectralProfile: this.spectralProfile,
          currentGenre: this.currentGenre,
          musicContext,
          songStructure,
          optimizedParams
        });
      };
      applyProfile();
    } catch (error) {
      // === MẠCH KHÔI PHỤC SỰ CỐ KHẨN CẤP (FALLBACK EMERGENCY ENGINE) ===
      if (typeof handleError === 'function') {
        handleError("CRITICAL: Error setting sound profile, reverting to safety state:", error, {
          profile,
          spectralProfile: this.spectralProfile
        });
      } else {
        console.error("CRITICAL: Error setting sound profile:", error);
      }
      // Kích hoạt cơ chế tự bảo vệ phần cứng chặn đứng lỗi rít cháy loa dải treble ngoài ý muốn
      if (typeof this.emergencyReset === 'function') {
        this.emergencyReset();
      }
    }
  };

  function hashSongStructure(obj) {
    if (!obj) return "0";
    const s = obj.spectralProfile || {};
    const t = obj.tempoMemory || {};
    const identity = [
      ensureFinite(s.subBass, 0.5),
      ensureFinite(s.high, 0.5),
      ensureFinite(s.transientEnergy, 0.5),
      ensureFinite(t.current, 120),
      String(obj.currentGenre || ''),
      Array.isArray(obj.polyphonicPitches) ? obj.polyphonicPitches.length : 0
    ].join('|');
    let hash = 0;
    for (let i = 0; i < identity.length; i++) {
      hash = ((hash << 5) - hash) + identity.charCodeAt(i);
      hash |= 0;
    }
    if (Array.isArray(s.chroma)) {
      let chromaSum = 0;
      for (let j = 0; j < s.chroma.length; j++) {
        chromaSum += ensureFinite(s.chroma[j], 0);
      }
      hash = (hash ^ (chromaSum * 100)) | 0;
    }
    return (hash >>> 0).toString(36);
  }
  // === ĐẶT Ở ĐẦU FILE (Duy nhất 1 lần) ===
  const DEFAULT_SPECTRAL_ANALYZER = Object.freeze({
    subBass: 0.5,
    bass: 0.5,
    subMid: 0.5,
    midLow: 0.5,
    midHigh: 0.5,
    high: 0.5,
    subTreble: 0.5,
    air: 0.5,
    vocalPresence: 0.5,
    transientEnergy: 0.5,
    instruments: {},
    spectralFlux: 0.5,
    spectralEntropy: 0.5,
    harmonicRatio: 0.5,
    // Luôn khởi tạo Float32Array để tránh lỗi null pointer về sau
    chroma: new Float32Array(12).fill(0.5)
  });
  const EMPTY_CHORUS_SCORES = new Float32Array(4); // [0:chorus, 1:intro, 2:bridge, 3:verse]
  Jungle.prototype.analyzeSongStructure = function({
    spectralProfile,
    tempoMemory,
    polyphonicPitches,
    currentGenre
  }) {
    const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
    // Zero-GC: Sử dụng object tĩnh mặc định nếu spectralProfile bị thiếu
    const spectral = spectralProfile || DEFAULT_SPECTRAL_ANALYZER;
    const validatedSpectral = {
      subBass: ensureFinite(spectral.subBass, 0.5),
      bass: ensureFinite(spectral.bass, 0.5),
      subMid: ensureFinite(spectral.subMid, 0.5),
      midLow: ensureFinite(spectral.midLow, 0.5),
      midHigh: ensureFinite(spectral.midHigh, 0.5),
      high: ensureFinite(spectral.high, 0.5),
      subTreble: ensureFinite(spectral.subTreble, 0.5),
      air: ensureFinite(spectral.air, 0.5),
      transientEnergy: ensureFinite(spectral.transientEnergy, 0.5),
      instruments: typeof spectral.instruments === 'object' ? spectral.instruments : {},
      spectralFlux: ensureFinite(spectral.spectralFlux, 0.5),
      spectralEntropy: ensureFinite(spectral.spectralEntropy, 0.5),
      harmonicRatio: ensureFinite(spectral.harmonicRatio, 0.5),
      chroma: Array.isArray(spectral.chroma) && spectral.chroma.length === 12 ? new Float32Array(spectral.chroma.map(v => ensureFinite(v, 0.5))) : new Float32Array(12).fill(0.5)
    };
    const validatedTempoMemory = tempoMemory || {
      current: 120,
      previous: 120
    };
    const validatedPolyphonicPitches = Array.isArray(polyphonicPitches) ? polyphonicPitches : [];
    const validatedCurrentGenre = typeof currentGenre === 'string' ? currentGenre.toLowerCase() : 'unknown';
    try {
      const cpuLoad = this.getCPULoad ? ensureFinite(this.getCPULoad(), 0.5) : 0.5;
      const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
      const cpuLoadAdjust = cpuLoad > 0.85 || isLowPowerDevice ? 0.85 : 1.0;
      const cacheKey = `songStructure_${hashSongStructure({ spectralProfile, tempoMemory, polyphonicPitches, currentGenre })}`;
      if (this.memoryManager?.get) {
        const cachedStructure = this.memoryManager.get(cacheKey);
        if (cachedStructure && cachedStructure.metadata?.timestamp > Date.now() - 1000 && cachedStructure.metadata?.expiry > Date.now()) {
          if (isDebug) console.debug(`Using cached song structure for key: ${cacheKey}`, cachedStructure);
          return cachedStructure;
        }
      }
      const lastInputHash = this.memoryManager?.get('lastInputHash');
      const currentInputHash = hashSongStructure({
        spectralProfile,
        tempoMemory,
        polyphonicPitches,
        currentGenre
      });
      if (lastInputHash === currentInputHash && this.memoryManager?.get('lastStructure')) {
        const lastStructure = this.memoryManager.get('lastStructure');
        if (isDebug) console.debug(`Reusing last structure due to similar input`, lastStructure);
        return lastStructure;
      }
      // Metrics calculation
      const tempoChange = validatedTempoMemory.current && validatedTempoMemory.previous ? Math.abs(ensureFinite(validatedTempoMemory.current, 120) - ensureFinite(validatedTempoMemory.previous, 120)) / ensureFinite(validatedTempoMemory.previous, 120) : 0;
      const energy = (validatedSpectral.subBass + validatedSpectral.bass + validatedSpectral.subMid + validatedSpectral.midLow + validatedSpectral.midHigh + validatedSpectral.high) / 6;
      const energyChange = this.memoryManager?.get('lastEnergy') ? Math.abs(energy - ensureFinite(this.memoryManager.get('lastEnergy'), 0.5)) / (ensureFinite(this.memoryManager.get('lastEnergy'), 0.5) || 1) : 0;
      const transientDensity = validatedSpectral.transientEnergy;
      const instrumentPresence = Object.values(validatedSpectral.instruments).reduce((sum, val) => sum + ensureFinite(val, 0), 0) / (Object.keys(validatedSpectral.instruments).length || 1);
      const spectralFlux = validatedSpectral.spectralFlux;
      const spectralEntropy = validatedSpectral.spectralEntropy;
      const harmonicRatio = validatedSpectral.harmonicRatio;
      const chromaPresence = validatedSpectral.chroma.reduce((sum, val) => sum + val, 0) / 12;
      const lastChroma = this.memoryManager?.get('lastChroma') || new Float32Array(12).fill(0.5);
      let chromaFlux = 0;
      for (let i = 0; i < 12; i++) {
        chromaFlux += Math.abs(validatedSpectral.chroma[i] - lastChroma[i]);
      }
      chromaFlux /= 12;
      const genreAdjust = validatedCurrentGenre.includes('edm') || validatedCurrentGenre.includes('pop') ? 1.2 : validatedCurrentGenre.includes('classical') ? 0.8 : 1.0;
      const pitchAdjust = validatedPolyphonicPitches.length > 2 ? 1.2 : validatedPolyphonicPitches.length === 0 ? 0.8 : 1.0;
      // Decision Tree - Zero-GC
      EMPTY_CHORUS_SCORES.fill(0);
      EMPTY_CHORUS_SCORES[0] += energyChange * 2.0 * genreAdjust; // chorus
      EMPTY_CHORUS_SCORES[0] += transientDensity * 1.5 * genreAdjust;
      EMPTY_CHORUS_SCORES[0] += tempoChange * 1.0 * genreAdjust;
      EMPTY_CHORUS_SCORES[0] += spectralFlux * 1.2;
      EMPTY_CHORUS_SCORES[0] += instrumentPresence * 1.0 * genreAdjust;
      EMPTY_CHORUS_SCORES[0] += chromaPresence * 1.5 * genreAdjust;
      EMPTY_CHORUS_SCORES[0] += chromaFlux * 1.2;
      EMPTY_CHORUS_SCORES[1] += (1 - energy) * 2.0 / genreAdjust; // intro
      EMPTY_CHORUS_SCORES[1] += (1 - instrumentPresence) * 1.5 / genreAdjust;
      EMPTY_CHORUS_SCORES[1] += (1 - spectralFlux) * 1.2;
      EMPTY_CHORUS_SCORES[1] += (1 - transientDensity) * 1.0 / genreAdjust;
      EMPTY_CHORUS_SCORES[1] += (1 - chromaPresence) * 1.5 / genreAdjust;
      EMPTY_CHORUS_SCORES[1] += (1 - chromaFlux) * 1.2;
      EMPTY_CHORUS_SCORES[2] += (1 - transientDensity) * 1.5 / genreAdjust; // bridge
      EMPTY_CHORUS_SCORES[2] += instrumentPresence * 1.2 * genreAdjust;
      EMPTY_CHORUS_SCORES[2] += harmonicRatio * 1.0;
      EMPTY_CHORUS_SCORES[2] += (1 - energyChange) * 1.0 / genreAdjust;
      EMPTY_CHORUS_SCORES[2] += chromaFlux * 1.5;
      EMPTY_CHORUS_SCORES[2] += (1 - chromaPresence) * 1.0;
      EMPTY_CHORUS_SCORES[3] += (1 - Math.abs(energy - 0.5)) * 1.5; // verse
      EMPTY_CHORUS_SCORES[3] += (1 - Math.abs(transientDensity - 0.5)) * 1.2;
      EMPTY_CHORUS_SCORES[3] += spectralEntropy * 1.0;
      EMPTY_CHORUS_SCORES[3] += (1 - tempoChange) * 0.8;
      EMPTY_CHORUS_SCORES[3] += (1 - Math.abs(chromaPresence - 0.5)) * 1.2;
      EMPTY_CHORUS_SCORES[3] += (1 - chromaFlux) * 1.0;
      // History prediction
      const history = this.memoryManager?.get('songStructureHistory') || [];
      const lastSection = history.length > 0 ? history[history.length - 1]?.section : null;
      if (lastSection === 'chorus') EMPTY_CHORUS_SCORES[3] += 0.5;
      if (lastSection === 'intro') EMPTY_CHORUS_SCORES[3] += 0.5;
      if (lastSection === 'bridge') EMPTY_CHORUS_SCORES[0] += 0.5;
      // Chọn section
      let maxScore = EMPTY_CHORUS_SCORES[0];
      let section = 'chorus';
      if (EMPTY_CHORUS_SCORES[1] > maxScore) {
        maxScore = EMPTY_CHORUS_SCORES[1];
        section = 'intro';
      }
      if (EMPTY_CHORUS_SCORES[2] > maxScore) {
        maxScore = EMPTY_CHORUS_SCORES[2];
        section = 'bridge';
      }
      if (EMPTY_CHORUS_SCORES[3] > maxScore) {
        maxScore = EMPTY_CHORUS_SCORES[3];
        section = 'verse';
      }
      const confidence = maxScore / (maxScore + 1);
      const factorMap = {
        chorus: 1.4,
        intro: 0.8,
        bridge: 1.2,
        verse: 1.0
      };
      let structureFactor = factorMap[section] * pitchAdjust * cpuLoadAdjust;
      structureFactor = Math.max(0.5, Math.min(2.0, ensureFinite(structureFactor, 1.0)));
      const result = {
        section,
        structureFactor,
        confidence
      };
      // Lưu cache
      if (this.memoryManager && typeof this.memoryManager.set === 'function') {
        try {
          this.memoryManager.set(cacheKey, result, 'high', {
            timestamp: Date.now(),
            expiry: Date.now() + 10000
          });
          this.memoryManager.set('lastStructure', result, 'high', {
            timestamp: Date.now()
          });
          this.memoryManager.set('lastInputHash', currentInputHash, 'low', {
            timestamp: Date.now()
          });
          this.memoryManager.set('lastChroma', validatedSpectral.chroma, 'low', {
            timestamp: Date.now()
          });
          let historyArr = this.memoryManager.get('songStructureHistory') || [];
          historyArr.push({
            section,
            structureFactor,
            confidence,
            timestamp: Date.now(),
            chroma: validatedSpectral.chroma
          });
          if (historyArr.length > 50) historyArr.shift();
          this.memoryManager.set('songStructureHistory', historyArr, 'low', {
            timestamp: Date.now()
          });
          this.memoryManager.pruneCache(this.memoryManager.getDynamicMaxSize?.() || 100);
        } catch (error) {
          handleError('Failed to store song structure', error, {
            cacheKey
          }, 'low', {
            memoryManager: this.memoryManager
          });
        }
      }
      if (isDebug) {
        console.debug(`Song structure analysis result`, {
          section,
          structureFactor,
          confidence,
          chromaPresence,
          chromaFlux,
          cpuLoad
        });
      }
      return result;
    } catch (error) {
      handleError('Error analyzing song structure', error, {
        spectralProfile,
        tempoMemory,
        polyphonicPitches,
        currentGenre
      }, 'high', {
        memoryManager: this.memoryManager
      });
      return {
        section: 'verse',
        structureFactor: 1.0,
        confidence: 0.5
      };
    }
  };
  /**
   * Simple hash function (standalone - không dùng this)
   */
  function hashContext(obj) {
    if (!obj) return "0";
    const s = obj.spectralProfile || {};
    const identity = [
      ensureFinite(s.transientEnergy, 0.5),
      obj.isVocal ? 1 : 0,
      Array.isArray(obj.polyphonicPitches) ? obj.polyphonicPitches.length : 0,
      ensureFinite(obj.noiseLevel, 0.5),
      ensureFinite(obj.qualityPrediction, 0.5)
    ].join('|');
    let hash = 0;
    for (let i = 0; i < identity.length; i++) {
      hash = ((hash << 5) - hash) + identity.charCodeAt(i);
      hash |= 0;
    }
    if (Array.isArray(s.chroma)) {
      let chromaSum = 0;
      for (let j = 0; j < s.chroma.length; j++) {
        chromaSum += ensureFinite(s.chroma[j], 0);
      }
      hash = (hash ^ (chromaSum * 100)) | 0;
    }
    return (hash >>> 0).toString(36);
  }
  /**
   * Initialize Context Analyzer - ĐÃ FIX THIS CONTEXT + ZERO-GC + DEFAULT_SPECTRAL
   */
  Jungle.prototype.initializeContextAnalyzer = function() {
    const self = this; // Capture this để dùng bên trong closure
    return {
      analyze: (context = {}, memoryManager) => {
        // Kiểm tra đầu vào
        if (!context || typeof context !== 'object') {
          handleError('Invalid context', new Error('Context must be an object'), {}, 'high', {
            memoryManager
          });
          return null;
        }
        const {
          spectralProfile = DEFAULT_SPECTRAL_ANALYZER, // ← Sử dụng DEFAULT ở đây
            tempoMemory = {},
            currentGenre = 'unknown',
            currentKey = 'unknown',
            polyphonicPitches = [],
            noiseLevel = 0.5,
            qualityPrediction = 0.5,
            isVocal = false
        } = context;
        const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
        // Tinh hoa: cache 1s ngắn hơn + hashKey atomic
        const cacheKey = `contextAnalysis_${hashContext(context)}`;
        if (memoryManager && typeof memoryManager.get === 'function') {
          const cachedResult = memoryManager.get(cacheKey);
          if (cachedResult && cachedResult.metadata?.timestamp > Date.now() - 1000 && cachedResult.metadata?.expiry > Date.now()) {
            if (isDebug) console.debug(`Retrieved cached analysis for key: ${cacheKey}`, cachedResult);
            return cachedResult;
          }
        }
        try {
          // Tính spectralComplexity – tinh hoa for loop nhanh hơn
          let spectralComplexity = 0.5;
          if (spectralProfile.chroma && Array.isArray(spectralProfile.chroma) && spectralProfile.chroma.length > 0) {
            let sumSq = 0;
            for (let i = 0; i < spectralProfile.chroma.length; i++) {
              const val = ensureFinite(spectralProfile.chroma[i], 0);
              sumSq += val * val;
            }
            spectralComplexity = sumSq / spectralProfile.chroma.length;
          }
          spectralComplexity = Math.max(0, Math.min(1, ensureFinite(spectralComplexity, 0.5)));
          // Lấy các tham số khác
          const transientEnergy = ensureFinite(spectralProfile.transientEnergy, 0.5);
          const vocalPresence = isVocal ? 1.0 : ensureFinite(spectralProfile.vocalPresence, 0.5);
          const harmonicComplexity = ensureFinite(polyphonicPitches.length, 0) > 1 ? 1.3 : 1.0;
          // Kiểm tra CPU load - DÙNG self để fix this
          const cpuLoad = self.getCPULoad ? ensureFinite(self.getCPULoad(), 0.5) : 0.5;
          const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
          const cpuLoadAdjust = cpuLoad > 0.9 || isLowPowerDevice ? 0.85 : 1.0;
          // Tính fadeTime
          const minFadeTime = 0.005;
          const baseFadeTime = 0.4 * (vocalPresence > 0.7 ? 1.4 : 1.0);
          const noiseAdjust = noiseLevel > 0.7 ? 1.2 : 1.0;
          const qualityAdjust = qualityPrediction > 0.7 ? 1.1 : 1.0;
          let fadeTime = Math.max(minFadeTime, baseFadeTime * (1.0 + 0.3 * spectralComplexity + 0.2 * transientEnergy + 0.3 * vocalPresence) * noiseAdjust * qualityAdjust * cpuLoadAdjust);
          fadeTime = Math.min(1.5, fadeTime);
          fadeTime = ensureFinite(fadeTime, minFadeTime);
          // Tính bufferTime - DÙNG self
          const bufferTime = ensureFinite(self.calculateBufferTime?.(spectralComplexity, transientEnergy, vocalPresence) || 0.2, 0.2);
          // Các tham số khác
          const fadeType = 'bezier';
          const smoothnessBase = spectralComplexity > 0.7 ? 2.2 : 1.9;
          const smoothness = ensureFinite(smoothnessBase * (noiseLevel > 0.7 ? 1.1 : 1.0) * cpuLoadAdjust, 1.9);
          const vibranceBase = harmonicComplexity > 1.0 ? 0.95 : 0.85;
          const vibrance = ensureFinite(vibranceBase * (qualityPrediction > 0.7 ? 1.05 : 1.0) * cpuLoadAdjust, 0.85);
          // Kết quả
          const result = {
            fadeTime,
            bufferTime,
            fadeType,
            smoothness,
            vibrance,
            spectralComplexity,
            transientEnergy,
            vocalPresence,
            harmonicComplexity
          };
          // Lưu vào MemoryManager
          if (memoryManager && typeof memoryManager.set === 'function') {
            try {
              memoryManager.set(cacheKey, result, 'normal', {
                timestamp: Date.now()
              });
              // Tinh hoa: history chỉ lưu dữ liệu thô + shift()
              let analysisHistory = memoryManager.get('analysisHistory') || [];
              analysisHistory.push({
                f: fadeTime,
                b: bufferTime,
                t: Date.now()
              });
              if (analysisHistory.length > 10) analysisHistory.shift();
              memoryManager.set('analysisHistory', analysisHistory, 'low');
              if (isDebug) console.debug(`Stored analysis for key: ${cacheKey}`, result);
            } catch (error) {
              handleError('Failed to store analysis', error, {
                cacheKey,
                result
              }, 'low', {
                memoryManager
              });
            }
          }
          // Debug log
          if (isDebug) {
            console.debug(`Context analysis result`, {
              input: {
                spectralProfile,
                isVocal,
                polyphonicPitchesLength: polyphonicPitches.length,
                noiseLevel,
                qualityPrediction,
                cpuLoad,
                isLowPowerDevice
              },
              output: result
            });
          }
          return result;
        } catch (error) {
          handleError('Error analyzing context', error, {
            context
          }, 'high', {
            memoryManager
          });
          return null;
        }
      }
    };
  };
  /**
   * Helper function to calculate bufferTime based on qualityMode and context
   */
  Jungle.prototype.calculateBufferTime = function(spectralComplexity = 0.5, transientEnergy = 0.5, vocalPresence = 0.5, options = {}) {
    try {
      // Chuẩn hóa đầu vào
      spectralComplexity = ensureFinite(spectralComplexity, 0.5);
      transientEnergy = ensureFinite(transientEnergy, 0.5);
      vocalPresence = ensureFinite(vocalPresence, 0.5);
      const currentPitchMult = ensureFinite(this.currentPitchMult, 0);
      // Chuẩn hóa options
      const spectralWeight = ensureFinite(options.spectralWeight, 0.2);
      const transientWeight = ensureFinite(options.transientWeight, 0.3);
      const vocalWeight = ensureFinite(options.vocalWeight, 0.2);
      const pitchThreshold = ensureFinite(options.pitchThreshold, 0.3);
      const pitchFactor = ensureFinite(options.pitchFactor, 1.5);
      const minBufferTime = ensureFinite(options.minBufferTime, 0.1);
      const maxBufferTime = ensureFinite(options.maxBufferTime, 2.0);
      // Kiểm tra CPU load
      const cpuLoad = this.getCPULoad ? ensureFinite(this.getCPULoad(), 0.5) : 0.5;
      const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
      const cpuLoadAdjust = (cpuLoad > 0.92 || isLowPowerDevice) ? 0.8 : 1.0;
      // Tính baseBufferTime
      const baseBufferTime = this.qualityMode === 'high' ? 0.8 : 0.4;
      // Tính pitchAdjust
      const pitchAdjust = Math.abs(currentPitchMult) > pitchThreshold ? pitchFactor : 1.0;
      // Tính bufferTime
      let bufferTime = baseBufferTime * (1.0 + spectralWeight * spectralComplexity + transientWeight * transientEnergy + vocalWeight * vocalPresence) * pitchAdjust * cpuLoadAdjust;
      // Giới hạn bufferTime
      bufferTime = Math.max(minBufferTime, Math.min(maxBufferTime, bufferTime));
      bufferTime = ensureFinite(bufferTime, minBufferTime);
      // Debug log gọn
      const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
      if (isDebug) {
        console.debug(`Calculated bufferTime: ${bufferTime.toFixed(4)}s`, {
          spectralComplexity,
          transientEnergy,
          vocalPresence,
          currentPitchMult,
          qualityMode: this.qualityMode,
          cpuLoad,
          isLowPowerDevice
        });
      }
      return bufferTime;
    } catch (error) {
      handleError('Error calculating bufferTime', error, {
        spectralComplexity,
        transientEnergy,
        vocalPresence,
        qualityMode: this.qualityMode
      }, 'high', {
        memoryManager: options.memoryManager
      });
      return ensureFinite(options.minBufferTime, 0.1);
    }
  };
  /**
   * Calculates max cache size based on device memory and current load
   */
  Jungle.prototype.calculateMaxCacheSize = function() {
    const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
    try {
      // Lấy thông tin thiết bị
      const deviceMemory = navigator.deviceMemory || (navigator.hardwareConcurrency ? Math.max(2, navigator.hardwareConcurrency / 2) : 4);
      const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
      // Lấy CPU load
      const cpuLoad = this.getCPULoad ? ensureFinite(this.getCPULoad(), 0.5) : 0.5;
      // Tính kích thước cơ bản (25MB per GB device memory)
      let baseCacheSize = deviceMemory * 25;
      baseCacheSize = Math.min(100, baseCacheSize);
      // Điều chỉnh động theo CPU và thiết bị
      const loadAdjust = cpuLoad > 0.9 ? 0.6 : cpuLoad > 0.7 ? 0.85 : 1.0;
      const deviceAdjust = isLowPowerDevice ? 0.8 : 1.0;
      let adjustedCacheSize = baseCacheSize * loadAdjust * deviceAdjust;
      // Tích hợp thống kê từ MemoryManager
      let cacheStats = {
        hitRate: 0.5,
        totalSize: 0
      };
      if (this.memoryManager && typeof this.memoryManager.getCacheStats === 'function') {
        cacheStats = this.memoryManager.getCacheStats();
        if (cacheStats.hitRate > 0.8 && cacheStats.totalSize < adjustedCacheSize * 0.9) {
          adjustedCacheSize *= 1.15; // Tăng khi hit rate cao
        }
        if (cacheStats.hitRate < 0.3 || cacheStats.totalSize > adjustedCacheSize * 1.2) {
          adjustedCacheSize *= 0.85; // Giảm khi áp lực cao
        }
      }
      // Giới hạn cuối cùng
      adjustedCacheSize = Math.max(10, Math.min(100, ensureFinite(adjustedCacheSize, 50)));
      // Debug log
      if (isDebug) {
        console.debug('Calculated max cache size', {
          deviceMemory,
          isLowPowerDevice,
          cpuLoad,
          baseCacheSize,
          loadAdjust,
          deviceAdjust,
          cacheStats: {
            hitRate: cacheStats.hitRate,
            totalSize: cacheStats.totalSize
          },
          finalCacheSize: adjustedCacheSize
        });
      }
      return adjustedCacheSize;
    } catch (error) {
      handleError('Error calculating max cache size', error, {
        deviceMemory: navigator.deviceMemory,
        hardwareConcurrency: navigator.hardwareConcurrency
      }, 'medium', {
        memoryManager: this.memoryManager
      });
      return 50; // Fallback an toàn
    }
  };
  /**
   * Generates a cache signature for security.
   * Đã chuyển thành method của Jungle.prototype để fix lỗi this context
   */
  Jungle.prototype.generateCacheSignature = function(cacheKey, context = {}) {
    const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
    try {
      // Tinh hoa: simplifiedContext gọn nhẹ giảm CPU/RAM
      const simplifiedContext = {
        k: cacheKey,
        t: Math.floor(Date.now() / 2000), // Gom nhóm 2s tăng hit rate
        s: context.songStructure?.section || '',
        p: context.spectralProfile ? (ensureFinite(context.spectralProfile.subBass, 0.5) + ensureFinite(context.spectralProfile.high, 0.5)) : 1.0
      };
      const inputString = `${simplifiedContext.k}|${simplifiedContext.t}|${simplifiedContext.s}|${simplifiedContext.p}`;
      // Tinh hoa: FNV-1a chuẩn với Math.imul + unsigned
      let hash = 2166136261;
      for (let i = 0; i < inputString.length; i++) {
        hash ^= inputString.charCodeAt(i);
        hash = Math.imul(hash, 16777619);
      }
      const signature = (hash >>> 0).toString(36);
      // Collision check + debug
      if (this.memoryManager && typeof this.memoryManager.get === 'function') {
        const existing = this.memoryManager.get(signature);
        if (existing && isDebug) {
          console.debug('Cache signature collision detected', {
            signature,
            cacheKey,
            context: {
              songStructure: context.songStructure?.section
            },
            existingEntry: existing
          });
        }
      }
      // Debug log
      if (isDebug) {
        console.debug('Generated cache signature', {
          cacheKey,
          signature,
          context: {
            spectralProfile: context.spectralProfile ? {
              subBass: context.spectralProfile.subBass,
              high: context.spectralProfile.high
            } : null,
            songStructure: context.songStructure
          },
          cacheSize: this.memoryManager?.getCacheStats?.()?.totalSize || 0
        });
      }
      return signature;
    } catch (error) {
      handleError('Error generating cache signature', error, {
        cacheKey
      }, 'medium', {
        memoryManager: this.memoryManager
      });
      return (Math.random() * 1000000000).toString(36); // Fallback signature
    }
  };
  /**
   * BẢNG TỪ KHÓA ĐỒNG NHẤT (Sử dụng chung cho cả phân tích và logic)
   * Đặt ở đầu file để đạt hiệu suất cao nhất
   */
  const FEEDBACK_KEYWORDS = Object.freeze({
    bass: {
      plus: ['more bass', 'bass bùm bùm', 'trầm hơn', 'mạnh bass', 'deep', 'boomy', 'rumbly'],
      minus: ['too much bass', 'bịch bịch', 'quá trầm']
    },
    treble: {
      plus: ['more treble', 'treble trong trẻo', 'sáng hơn'],
      minus: ['too bright', 'too much treble', 'chói', 'chói tai', 'screech', 'harsh', 'bright']
    },
    mid: {
      plus: ['more mid', 'nhạc cụ rõ', 'giữa rõ hơn'],
      minus: ['muddy', 'too much mid', 'đục', 'mờ đục', 'unclear']
    },
    clarity: {
      plus: ['not clear', 'more clarity', 'mượt mà']
    },
    vocal: {
      plus: ['more vocal clarity', 'vocal tự nhiên', 'giọng rõ', 'ấm giọng', 'clear voice', 'vocal', 'singer']
    },
    distortion: {
      minus: ['less distortion', 'rè', 'xe xe']
    },
    warmth: {
      plus: ['ấm áp', 'tự nhiên', 'mượt mà']
    },
    harmonic: {
      plus: ['giàu cảm xúc', 'hòa âm phong phú']
    },
    loud: {
      plus: ['to quá', 'loud', 'overpower']
    },
    quiet: {
      plus: ['nhỏ quá', 'quiet', 'low volume']
    }
  });
  /**
   * Phân tích ngữ nghĩa: Dùng chung bảng FEEDBACK_KEYWORDS - Tốc độ O(1)
   */
  Jungle.prototype.analyzeFeedbackSemantics = function(feedback) {
    for (const category in FEEDBACK_KEYWORDS) {
      const terms = FEEDBACK_KEYWORDS[category];
      // Kiểm tra logic cộng hoặc trừ
      const found = (terms.plus?.some(t => feedback.includes(t)) || terms.minus?.some(t => feedback.includes(t)));
      if (found) return category;
    }
    return 'unknown';
  };
  /**
   * ReceiveUserFeedback: Trùm Cuối v17.5
   * Đã hợp nhất logic, Zero-GC, chống spam, ổn định Chrome Storage
   */
  Jungle.prototype.receiveUserFeedback = function(feedback) {
    if (!this.memoryManager) return;
    const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
    if (!feedback || typeof feedback !== 'string') return;
    const normalized = feedback.toLowerCase().trim();
    if (normalized.length === 0) return;
    // Phân tích ngữ nghĩa nhanh ngay lúc nhận
    const category = this.analyzeFeedbackSemantics(normalized);
    const now = Date.now();
    const data = {
      f: normalized,
      t: now,
      e: now + 60000,
      c: category,
      s: this.memoryManager.get('lastStructure')?.section || 'unknown'
    };
    // Chống spam (chỉ nhận mỗi 5s)
    const list = this.memoryManager.buffers.get('userFeedback') || [];
    if (list.length > 0 && list[list.length - 1].f === normalized && (now - list[list.length - 1].t < 5000)) return;
    list.push(data);
    if (list.length > 20) list.shift(); // Tối ưu: giữ 20 feedback gần nhất
    this.memoryManager.buffers.set('userFeedback', list, {
      priority: 'medium'
    });
    this.memoryManager.pruneCache(this.calculateMaxCacheSize?.() || 50);
    // Xử lý Chrome Storage bất đồng bộ (An toàn)
    if (typeof chrome !== 'undefined' && chrome.storage?.local) {
      chrome.storage.local.get(['userFeedback'], (res) => {
        if (chrome.runtime.lastError) return;
        const stored = res.userFeedback || [];
        stored.push({
          f: normalized,
          t: now,
          e: now + 60000,
          c: category,
          s: data.s
        });
        if (stored.length > 30) stored.shift();
        chrome.storage.local.set({
          userFeedback: stored
        });
      });
    }
  };
  /**
   * applyUserFeedback: Trùm Cuối v17.6 - Zero-GC Synchronous Processor
   * Logic đồng bộ hoàn toàn, không async storage, hiệu năng cao nhất.
   */
  Jungle.prototype.applyUserFeedback = function() {
    const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
    try {
      const feedbackList = this.memoryManager?.buffers.get('userFeedback') || [];
      const spectral = this.spectralProfile || {
        bass: 0.5,
        midHigh: 0.5,
        air: 0.5,
        vocalPresence: 0.5,
        transientEnergy: 0.5,
        spectralFlux: 0.5,
        spectralComplexity: 0.5
      };
      const cpuLoad = this.getCPULoad ? ensureFinite(this.getCPULoad(), 0.5) : 0.5;
      const cpuLoadAdjust = (cpuLoad > 0.9 || (navigator.hardwareConcurrency < 4) || (navigator.deviceMemory < 4)) ? 0.8 : 1.0;
      const songStructure = this.memoryManager?.get('lastStructure') || {
        section: 'unknown'
      };
      const isChorus = songStructure.section === 'chorus';
      const cacheKey = this.generateCacheSignature?.('feedbackAdjustments', {
        songStructure,
        len: feedbackList.length,
        cpuLoad
      }) || `fba_${this.contextId}`;
      const cached = this.memoryManager?.get(cacheKey);
      if (cached?.timestamp > Date.now() - 15000) return cached.adjustments;
      const adj = {
        bass: 0,
        treble: 0,
        mid: 0,
        clarity: 0,
        vocalClarity: 0,
        distortion: 0,
        warmth: 0,
        air: 0,
        subBass: 0,
        harmonicRichness: 0
      };
      const getIntensity = (f) => (f.includes('very') || f.includes('rất') || f.includes('quá') ? 1.5 : (f.includes('hơi') || f.includes('nhẹ') ? 0.8 : 1.0));
      // --- XỬ LÝ FEEDBACK BẰNG VÒNG LẶP (Zero-GC) ---
      for (let i = 0; i < feedbackList.length; i++) {
        const f = feedbackList[i];
        if (f.e < Date.now()) continue;
        const text = f.f;
        const intensity = getIntensity(text);
        // Logic xử lý bass
        if (text.includes('bass')) {
          const mod = FEEDBACK_KEYWORDS.bass.plus.some(k => text.includes(k)) ? 1 : -1;
          adj.bass += 1.5 * intensity * mod * (spectral.bass < 0.7 ? 1.2 : 1.0);
          adj.subBass += 1.2 * intensity * mod;
        }
        // Logic xử lý treble
        if (text.includes('treble') || text.includes('chói')) {
          const mod = FEEDBACK_KEYWORDS.treble.plus.some(k => text.includes(k)) ? 1 : -1;
          adj.treble += 1.5 * intensity * mod * (spectral.air < 0.7 ? 1.2 : 1.0);
          adj.air += 1.0 * intensity * mod;
        }
        // Logic xử lý mid
        if (text.includes('mid') || text.includes('đục') || text.includes('muddy')) {
          const mod = FEEDBACK_KEYWORDS.mid.plus.some(k => text.includes(k)) ? 1 : -1;
          adj.mid += 1.5 * intensity * mod * (spectral.midHigh < 0.7 ? 1.2 : 1.0);
        }
        // Logic xử lý vocal
        if (text.includes('vocal')) {
          adj.vocalClarity += 2.0 * intensity * (spectral.vocalPresence < 0.7 ? 1.3 : 1.0);
          adj.clarity += 0.8 * intensity;
        }
        // Logic Distortion
        if (text.includes('rè') || text.includes('distort')) {
          adj.distortion -= 2.0 * intensity;
        }
        // Logic Warmth
        if (text.includes('ấm') || text.includes('mượt')) {
          adj.warmth += 1.2 * intensity;
        }
      }
      // --- TINH CHỈNH TỰ ĐỘNG ---
      if ((spectral.transientEnergy || 0) > 0.7) {
        adj.clarity += 0.5;
        adj.vocalClarity += 0.5;
      }
      if ((spectral.spectralComplexity || 0) > 0.7) adj.distortion -= 0.5;
      if (isChorus) {
        adj.vocalClarity += 0.7;
        adj.clarity += 0.5;
        adj.warmth += 0.3;
      }
      // --- CÂN BẰNG GIÁ TRỊ ---
      for (const k in adj) adj[k] = Math.max(-4.0, Math.min(4.0, adj[k] * cpuLoadAdjust));
      this.memoryManager?.set(cacheKey, {
        adjustments: adj,
        timestamp: Date.now()
      }, 'high');
      this.memoryManager?.pruneCache(this.calculateMaxCacheSize?.() || 100);
      return adj;
    } catch (e) {
      if (isDebug) console.error('Feedback Error:', e);
      return {
        bass: 0,
        treble: 0,
        mid: 0,
        clarity: 0,
        vocalClarity: 0,
        distortion: 0,
        warmth: 0,
        air: 0,
        subBass: 0,
        harmonicRichness: 0
      };
    }
  };
  Jungle.prototype.spectralRestorationAI = function(baseParams, validatedSpectral, fftAnalysis, fundamentalFreq, at2040Config, quantizationLevel, cpuLoad) {
    // Tối ưu hiệu năng: Khóa helper nội hàm dạng phẳng, triệt tiêu hoàn toàn rác RAM (Zero-GC)
    const quantize = (value, precision) => Math.round(value / precision) * precision;
    // --- 🪐 TẦNG BẢO VỆ PHẦN CỨNG: TỰ CO GIÃN THEO TẢI CPU (CHỐNG NÓNG MÁY TUYỆT ĐỐI) ---
    const safeCPU = Number.isFinite(cpuLoad) ? cpuLoad : 0.5;
    // Cơ chế sập rào bảo vệ (Graceful Degradation): Nếu CPU quá tải > 85%, trả ngay tham số an toàn, chống lọt jitter
    if (safeCPU > 0.85) {
      return baseParams;
    }
    // Điều tiết độ sâu toán học phi tuyến dựa theo tài nguyên CPU còn trống
    const computationalDepth = safeCPU > 0.6 ? 0.55 : 1.0;
    // Trích xuất các chỉ số phổ nền tảng để phục vụ cảm biến
    const muddyIndex = Math.max(0, (validatedSpectral.subMid - 0.48) + (validatedSpectral.midLow - 0.48));
    const flux = validatedSpectral.spectralFlux || 0.5;
    // --- 🪐 🛡️ MẠCH CẢM BIẾN HI-RES / STUDIO MASTER ĐỘC LẬP (CHỐNG BỊ LỐ) ---
    // CƠ CHẾ: Nếu dải siêu cao (Air/Treble) đã căng đầy, nền trung trầm phẳng sạch (muddyIndex cực thấp) 
    // và dải động chuyển động mượt mà ổn định (flux cao) -> Đây đích thị là nguồn thu âm cao cấp Hi-Res.
    const isStudioMasterSource = validatedSpectral.air > 0.52 && validatedSpectral.high > 0.52 && muddyIndex < 0.03 && flux > 0.48;
    if (isStudioMasterSource) {
      // Đạt chuẩn tinh khiết tuyệt đối: Ngắt toàn bộ thuật toán phục chế, trả về mạch Pass-Through gốc 100%
      // Giữ nguyên tính toàn vẹn của file Master, CPU tiêu tốn chu kỳ này hạ về đúng 0%
      return baseParams;
    }
    // --- 🔬 1. THUẬT TOÁN VÁ PHỔ "CONTENT-AWARE" (HARMONIC NODES INPAINTING) ---
    const highEndDeficit = Math.max(0, 0.45 - ((validatedSpectral.high + validatedSpectral.subTreble + validatedSpectral.air) / 3));
    const safeFundamental = Number.isFinite(fundamentalFreq) && fundamentalFreq > 30 ? fundamentalFreq : 440;
    if (highEndDeficit > 0.05) {
      // Tìm vị trí chính xác của bậc hài âm đích nơi dải phổ bắt đầu bị cắt rách (~16kHz)
      const harmonicOrder = Math.max(2, Math.min(14, Math.round(16000 / safeFundamental)));
      // Giả lập phục hồi năng lượng hài âm theo quy luật bình phương nghịch đảo vật lý
      const harmonicEnergyRecovery = (1.0 / Math.sqrt(harmonicOrder)) * highEndDeficit * 3.8 * computationalDepth;
      // Tự động "đẻ" và bù đắp các nút sóng hài dải cao cực kỳ tinh khiết
      baseParams.highShelfGain = quantize(baseParams.highShelfGain + (0.55 * harmonicEnergyRecovery * at2040Config.clarityBoost), quantizationLevel);
      baseParams.subTrebleGain = quantize(baseParams.subTrebleGain + (0.45 * harmonicEnergyRecovery * at2040Config.clarityBoost), quantizationLevel);
      baseParams.airGain = quantize(baseParams.airGain + (0.85 * harmonicEnergyRecovery * at2040Config.clarityBoost), quantizationLevel);
      // Photoshop Fill: Ép trần tần số cắt phần cứng mở toang băng thông dựa trên mức độ rách phổ
      baseParams.trebleCutFreq = quantize(Math.max(baseParams.trebleCutFreq, 16000 + (highEndDeficit * 9000 * computationalDepth)), quantizationLevel);
    }
    // --- 🎛️ 2. MẠCH MÀI SẮC ĐỘNG LỰC TRANSIENT (DYNAMIC KINETIC SHARPENING) ---
    const transientEnergy = validatedSpectral.transientEnergy || 0.5;
    // Nhận diện nguồn nhạc bị bẹt, mất lực nảy do quá trình nén thu âm chất lượng kém (Over-compressed source)
    if (flux < 0.42 && transientEnergy < 0.42) {
      const sharpeningFactor = (0.5 - ((flux + transientEnergy) / 2)) * 2.5 * computationalDepth;
      // Siết chặt Ratio và hạ ngưỡng Compressor để kích hoạt mạch Exciter đẩy lực đập nảy tanh tách
      baseParams.compressorRatio = quantize(baseParams.compressorRatio * (1.0 + sharpeningFactor * 0.35), quantizationLevel);
      baseParams.highMidGain = quantize(baseParams.highMidGain + (0.75 * sharpeningFactor * at2040Config.transientSculpt), quantizationLevel);
      baseParams.boost = quantize(baseParams.boost + (0.35 * sharpeningFactor), quantizationLevel);
    }
    // --- 🌊 3. CƠ CHẾ KIỂM SOÁT ĐA TẦNG PHI TUYẾN CHỐNG NỔ SÓNG (ADAPTIVE KNEE LIMITER) ---
    if (baseParams.lowShelfGain > 5.0 || baseParams.subBassGain > 3.5 || baseParams.midShelfGain > 5.5) {
      // Hàm nắn biên độ Sigmoid Soft-Knee: Giữ lực bass sâu mộc mạc nhưng tuyệt đối không cho chạm đỉnh clipping
      const softKneeSaturator = (gain, limit) => Math.tanh(gain / limit) * limit;
      baseParams.lowShelfGain = quantize(softKneeSaturator(baseParams.lowShelfGain, 9.5), quantizationLevel);
      baseParams.subBassGain = quantize(softKneeSaturator(baseParams.subBassGain, 5.5), quantizationLevel);
      baseParams.subMidGain = quantize(softKneeSaturator(baseParams.subMidGain, 6.5), quantizationLevel);
      baseParams.midShelfGain = quantize(softKneeSaturator(baseParams.midShelfGain, 7.0), quantizationLevel);
      // Neo cứng thời gian xả nén an toàn để màng loa không bị hiện tượng run méo tiếng cơ học
      baseParams.compressorRelease = quantize(Math.max(baseParams.compressorRelease, 0.12), quantizationLevel);
    }
    // --- 🎤 4. MA TRẬN BÓC TÁCH KHÔNG GIAN ÂM THANH (AUDITORY DE-MASKING MATRIX) ---
    if (muddyIndex > 0.08) {
      const deMaskingScale = muddyIndex * 1.5 * computationalDepth;
      // Chủ động khoét bớt vùng dải âm ám đục của nhạc cụ đang che lấp giọng hát
      baseParams.subMidGain = quantize(baseParams.subMidGain - (0.55 * deMaskingScale), quantizationLevel);
      baseParams.midBassGain = quantize(baseParams.midBassGain - (0.45 * deMaskingScale), quantizationLevel);
      // Đẩy mạnh trường bù trừ dải Formant để kéo Vocal nổi hẳn lên bề mặt phổ thanh sạch
      baseParams.formantGain = quantize(baseParams.formantGain + (0.85 * deMaskingScale * at2040Config.emotionalVector), quantizationLevel);
      baseParams.notchQ = quantize(baseParams.notchQ * (1.0 + deMaskingScale * 0.2), quantizationLevel); // Thu hẹp bộ lọc sibilance chống chói gắt
    }
    return baseParams;
  };
  Jungle.prototype.hashOptimizationInput = function(obj) {
    // Chỉ hash các thuộc tính quan trọng thay vì stringify toàn bộ
    // Cách này cực nhanh và không tạo rác
    const s = obj.spectralProfile || {};
    const identity = [
      obj.profile,
      obj.songStructure?.section || 'none',
      ensureFinite(obj.musicContext?.spectralComplexity, 0.5),
      // Nếu roomProfile có các thuộc tính cố định, hãy hash chúng thay vì stringify
      ensureFinite(obj.roomProfile?.coherence, 1.0)
    ].join('|');
    let hash = 0;
    for (let i = 0; i < identity.length; i++) {
      hash = ((hash << 5) - hash) + identity.charCodeAt(i);
      hash |= 0;
    }
    return (hash >>> 0).toString(36);
  };
  Jungle.prototype.optimizeSoundProfile = function({
    profile,
    musicContext,
    spectral,
    genreFactor,
    warmthBoost,
    subBassBoost,
    subMidBoost,
    midBoost,
    trebleReduction,
    transientBoostAdjust,
    polyphonicAdjust,
    harmonicBoost,
    songStructure,
    userFeedbackAdjust,
    roomProfile
  }) {
    const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
    try {
      // --- [VALIDATE AUDIO CONTEXT - Chống Crash] ---
      if (!this.context || !(this.context instanceof AudioContext) || this.context.state === 'closed') {
        throw new Error('Invalid or closed AudioContext');
      }
      // 🪐 ĐỒNG BỘ NỀN TẢNG: Ép cấu hình chạy ngầm về proNatural nếu bị rỗng
      const activeProfile = profile || 'proNatural';
      // --- [VALIDATE SPECTRAL - Khử rác Zero-GC] ---
      const spectralDefaults = {
        subBass: 0.5,
        bass: 0.5,
        subMid: 0.5,
        midLow: 0.5,
        midHigh: 0.5,
        high: 0.5,
        subTreble: 0.5,
        air: 0.5,
        vocalPresence: 0.5,
        transientEnergy: 0.5,
        spectralFlux: 0.5,
        spectralEntropy: 0.5,
        harmonicRatio: 0.5,
        spl: 0
      };
      const validatedSpectral = {};
      const keys = Object.keys(spectralDefaults);
      for (let i = 0; i < keys.length; i++) {
        const key = keys[i];
        const val = spectral?.[key];
        validatedSpectral[key] = (Number.isFinite(val) ? Math.max(0, Math.min(1, val)) : spectralDefaults[key]);
      }
      // --- [TỐI ƯU TÀI NGUYÊN: CPU & DEVICE ADAPTATION] ---
      const cpuLoad = this.getCPULoad ? (Number.isFinite(this.getCPULoad()) ? this.getCPULoad() : 0.5) : 0.5;
      const isLowPowerDevice = (navigator.hardwareConcurrency || 4) < 4;
      const deviceAdaptFactor = Math.max(0.65, Math.min(1.0, 1.0 - (cpuLoad * 0.2) * (isLowPowerDevice ? 0.35 : 0.1)));
      const harmonicOrderMax = cpuLoad > 0.8 ? 3 : (isLowPowerDevice ? 5 : 8);
      const spectralAttentionScale = cpuLoad > 0.8 ? 0.7 : 1.0;
      // --- [PHÂN TÍCH FFT & SPECTRAL BALANCE] ---
      const fftAnalysis = this._analyser ? this.getFFTAnalysis() : null;
      const subBassEnergy = fftAnalysis?.subBassEnergy || validatedSpectral.subBass;
      const highFreqEnergy = fftAnalysis?.highFreqEnergy || validatedSpectral.air;
      const transientEnergy = fftAnalysis?.transientEnergy || validatedSpectral.transientEnergy;
      const spectralCoherence = fftAnalysis?.spectralCoherence || 0.5;
      const transientDensity = fftAnalysis?.transientDensity || 0.5;
      // === [PERCEPTUAL SPECTRAL DISCRIMINATION - CHỐNG "ÁM" GIỌNG] ===
      const isMuddy = (validatedSpectral.subMid > 0.55 || validatedSpectral.midLow > 0.55 || validatedSpectral.bass > 0.65);
      const muddyIndex = Math.max(0, (validatedSpectral.subMid - 0.5 + validatedSpectral.midLow - 0.5) * 1.5);
      const clarityIndex = (validatedSpectral.midHigh + validatedSpectral.high + validatedSpectral.air) / 3;
      const transparencyFactor = isMuddy ? Math.max(0.55, 1.0 - muddyIndex * 0.65) : 1.0;
      const presenceBoost = clarityIndex < 0.5 ? (0.5 - clarityIndex) * 1.5 + 1.0 : 1.0;
      const airNaturalBoost = clarityIndex > 0.6 ? 1.15 : (clarityIndex < 0.4 ? 1.35 : 1.05);
      const transientDamping = Math.min(1.0, 1.15 / (1.0 + transientEnergy * validatedSpectral.spectralFlux));
      // === [THUẬT TOÁN ĐIỀU BIẾN KHÔNG GIAN SÂN KHẤU TRUNG THỰC] ===
      let stereoWidth = 1.0;
      // 🪐 ĐỒNG BỘ KHÓA CHẾT STEREO: Nếu là proNatural, ép phẳng băng 1.0 (Bit-Perfect), bỏ qua kéo dãn không gian
      if (activeProfile === 'proNatural') {
        stereoWidth = 1.0;
      } else {
        if (songStructure?.section === 'chorus') {
          stereoWidth = 1.06 + (clarityIndex * 0.02);
        } else if (songStructure?.section === 'bridge') {
          stereoWidth = 1.03;
        } else {
          stereoWidth = 1.0;
        }
      }
      // 🪐 ĐỒNG BỘ KHÓA MẠCH THU HẸP BASS: Không tự ý nén dải trầm của profile mộc proNatural
      if (activeProfile !== 'proNatural' && subBassEnergy > 0.7) {
        stereoWidth = Math.max(1.0, stereoWidth * 0.95);
      }
      // --- [KHỞI TẠO AT2040PUREGENIXV2 CONFIG] ---
      const at2040Config = {
        enabled: validatedSpectral.vocalPresence > 0.45 || activeProfile === 'vocal' || activeProfile === 'karaokeDynamic' || Math.abs(this.currentPitchMult || 0) > 0,
        formantScale: Math.max(0.85, Math.min(1.15, 1.0 + (this.currentPitchMult || 0) * 0.008)),
        harmonicBoost: activeProfile === 'bassHeavy' ? 1.15 : (activeProfile === 'vocal' ? 1.0 : 1.1),
        transientSculpt: activeProfile === 'rockMetal' || activeProfile === 'bassHeavy' ? 1.2 : 0.9,
        phaseLockFactor: this.qualityMode === 'high' ? 1.1 : 0.9,
        emotionalVector: activeProfile === 'warm' ? 0.85 : (activeProfile === 'rockMetal' ? 1.1 : 1.0),
        deviceAdaptFactor,
        clarityBoost: activeProfile === 'vocal' || activeProfile === 'karaokeDynamic' ? 1.25 : 1.0,
        melodySynthesisFactor: activeProfile === 'proNatural' || activeProfile === 'karaokeDynamic' ? 1.3 : 1.1,
        pitchShiftFactor: Math.abs(this.currentPitchMult || 0) > 0.5 ? 0.9 : 1.0,
        roomCoherenceFactor: roomProfile?.coherence || 1.0
      };
      // --- [LÕI THUẬT TOÁN: AT2040ENHANCE - Tái tạo âm thanh phi tuyến] ---
      const at2040Enhance = (f, prof, emotional, transient, vocal) => {
        const melodySynthesis = at2040Config.melodySynthesisFactor;
        let melodyFactor = 0;
        const fundamental = f || 440;
        const harmonicOrder = harmonicOrderMax;
        const stepFreqMult = 1 + (this.currentPitchMult || 0) * 0.005;
        for (let i = 1; i <= harmonicOrder; i++) {
          const harmonicFreq = fundamental * i * stepFreqMult;
          const wavelet = Math.exp(-Math.pow(harmonicFreq / 120, 2) / 0.18) * Math.cos(6.283185307179586 * harmonicFreq);
          melodyFactor += wavelet * (1 / (i * 1.05)) * melodySynthesis;
        }
        melodyFactor = Math.max(0.8, Math.min(1.2, melodyFactor));
        const sigma = prof === 'bassHeavy' ? 0.4 : (prof === 'vocal' ? 0.25 : 0.3);
        let quantumBass = 0;
        const bassWaveletBase = Math.exp(-Math.pow(fundamental / 90, 2) / (2 * Math.pow(sigma, 2)));
        for (let i = 1; i <= harmonicOrder; i++) {
          const waveletCoeff = bassWaveletBase * Math.cos(6.283185307179586 * fundamental * i);
          const harmonicSeries = Math.sin(6.283185307179586 * fundamental * i * i) / (i * 1.1);
          quantumBass += waveletCoeff * harmonicSeries * at2040Config.harmonicBoost;
        }
        quantumBass = Math.tanh(quantumBass * 1.4) * 1.15;
        quantumBass = Math.max(0.8, Math.min(1.2, quantumBass));
        const vocalPresence = prof === 'vocal' ? 1.1 : (prof === 'warm' ? 0.9 : 0.85);
        let vocalFormant = (180 + 2200) * vocalPresence * at2040Config.clarityBoost;
        let midGain = validatedSpectral.midHigh > 0.65 ? 0.6 : 0.5;
        let trebleQ = validatedSpectral.air > 0.65 ? 0.55 : 0.45;
        if (validatedSpectral.bass > 0.65) {
          midGain *= 0.85;
          trebleQ *= 0.85;
        }
        let entanglement = Math.max(0.8, Math.min(1.2, Math.sqrt(Math.abs(vocalFormant * midGain * trebleQ)) / 10));
        const purityFilter = 1 / (1 + Math.pow(fundamental / 1400, 2)) * at2040Config.clarityBoost;
        const maskingThreshold = Math.pow(10, -(validatedSpectral.spl || 0) / 20) * purityFilter * 1.2;
        const phaseDiff = fftAnalysis ? Math.atan2(fftAnalysis.imag || 0, fftAnalysis.real || 1) : 0;
        const phaseCoherence = Math.cos(phaseDiff) * at2040Config.phaseLockFactor * 1.25;
        const sculptFactor = prof === 'rockMetal' ? 1.3 : (prof === 'bassHeavy' ? 1.1 : 0.85);
        let transientSculpt = transient * sculptFactor * at2040Config.clarityBoost;
        if (cpuLoad > 0.8) transientSculpt *= 0.65;
        if (validatedSpectral.transientEnergy > 0.65) transientSculpt *= 0.8;
        if (Math.abs(this.currentPitchMult || 0) > 0.5) transientSculpt *= 0.9;
        const toneAlignment = songStructure?.section === 'chorus' ? 1.2 : (songStructure?.section === 'verse' ? 1.0 : 1.1);
        const masterFormant = at2040Config.formantScale * (1 + (this.currentPitchMult || 0) * 0.01) * toneAlignment;
        const emotionalVector = emotional === 'calm' ? 0.85 : (emotional === 'aggressive' ? 1.1 : 1.0);
        const spectralEnergy = Math.pow(Math.abs(fftAnalysis?.energy || 0.5), 2);
        const prevEnergy = this.memoryManager?.get('prevEnergy') || spectralEnergy;
        const spectralFluxAt = Math.abs(spectralEnergy - prevEnergy) / (spectralEnergy + 0.001);
        const spectralAttention = 1 / (1 + Math.exp(-(spectralEnergy * spectralFluxAt * 0.8 * spectralAttentionScale)));
        this.memoryManager?.set('prevEnergy', spectralEnergy, 'low');
        const timbreCurve = 0.0006 * Math.pow(fundamental, 3) + 0.006 * Math.pow(fundamental, 2) + 0.06 * fundamental + 1.1;
        const emotionTimbre = emotionalVector * (timbreCurve / 1000) * at2040Config.melodySynthesisFactor;
        const pitchShiftImpact = Math.abs(this.currentPitchMult || 0) > 0.5 ? 0.85 : 1.0;
        const totalGainFactor = (melodyFactor * quantumBass * entanglement * maskingThreshold * emotionalVector * masterFormant * spectralAttention * emotionTimbre * pitchShiftImpact) / (phaseCoherence + transientSculpt + 0.1);
        return Math.max(0.75, Math.min(1.25, totalGainFactor));
      };
      // --- [LOGIC CACHE & HASHING TỐI ƯU] ---
      const now = Date.now();
      const inputHash = this.hashOptimizationInput({
        spectralProfile: validatedSpectral,
        songStructure,
        userFeedbackAdjust,
        profile: activeProfile,
        musicContext,
        roomProfile
      });
      const mem = this.memoryManager;
      const lastInputHash = mem?.get('lastOptimizeInputHash');
      const optimizedParamsEntry = mem?.get('optimizedParams');
      if (lastInputHash === inputHash && optimizedParamsEntry && (optimizedParamsEntry.timestamp > now - 3500)) {
        const cachedParams = optimizedParamsEntry.params;
        if (this.outputGain?.gain) {
          const currentTime = this.context.currentTime;
          const rampTime = isLowPowerDevice ? 0.03 : (0.06 * at2040Config.deviceAdaptFactor);
          const gainNode = this.outputGain.gain;
          gainNode.cancelScheduledValues(currentTime);
          gainNode.setValueAtTime(gainNode.value, currentTime);
          gainNode.linearRampToValueAtTime(cachedParams.masterGain * at2040Config.pitchShiftFactor, currentTime + rampTime);
        }
        return cachedParams;
      }
      // --- [LOGIC DỰ ĐOÁN LỊCH SỬ (History Adjust)] ---
      let historyAdjust = {
        formantGain: 0,
        midShelfGain: 0
      };
      const history = this.memoryManager?.get('songStructureHistory') || [];
      const lastSection = history.length > 0 ? history[history.length - 1]?.section : null;
      const sectionHistoryWeight = history.length > 2 ? history.slice(-3).reduce((acc, h) => acc + (h.section === songStructure?.section ? 0.2 : 0), 0) : 0;
      if (lastSection === 'chorus') {
        historyAdjust = {
          formantGain: 0.5 * at2040Config.emotionalVector * (1 + sectionHistoryWeight),
          midShelfGain: 0.4 * at2040Config.emotionalVector * (1 + sectionHistoryWeight)
        };
      } else if (lastSection === 'bridge') {
        historyAdjust = {
          formantGain: 0.3 * at2040Config.emotionalVector * (1 + sectionHistoryWeight),
          midShelfGain: 0.3 * at2040Config.emotionalVector * (1 + sectionHistoryWeight)
        };
      }
      // === [MÔ HÌNH DỰ ĐOÁN VÀ ĐIỀU CHỈNH ĐỘNG DẢI TẦN - DEEP LEARNING MODEL SIMULATION] ===
      const deepLearningModel = {
        predict: (input) => {
          const {
            spectralComplexity,
            vocalPresence,
            harmonicComplexity
          } = musicContext;
          const trebleIndex = (validatedSpectral.high + validatedSpectral.subTreble + validatedSpectral.air) / 3;
          const isPiercing = trebleIndex > 0.45 || highFreqEnergy > 0.6 || (userFeedbackAdjust?.distortion < -1.0);
          const dynamicTrebleReduction = isPiercing ? Math.min(5.0, (trebleIndex - 0.45) * 6.5 + (userFeedbackAdjust?.treble || 0)) * at2040Config.deviceAdaptFactor : (trebleReduction + (userFeedbackAdjust?.treble || 0)) * at2040Config.deviceAdaptFactor * 0.9;
          let fundamentalFreq = 440;
          if (this.polyphonicPitches && this.polyphonicPitches.length > 0) {
            fundamentalFreq = this.polyphonicPitches[0]?.frequency || fundamentalFreq;
          }
          const isHighVocal = fundamentalFreq > 480;
          const vocalTransient = vocalPresence > 0.65 ? Math.min(1.0, transientEnergy * at2040Config.transientSculpt * (1 + transientDensity * 0.2) * (validatedSpectral.bass > 0.65 ? 0.85 : 1.0)) : 0.5;
          const instrumentTransient = (validatedSpectral.instruments?.guitar || validatedSpectral.instruments?.drums) ? Math.min(1.0, transientEnergy * at2040Config.transientSculpt * (1 + transientDensity * 0.1) * (validatedSpectral.midHigh > 0.65 ? 1.0 : 0.9)) : 0.5;
          const transientAdjust = (vocalTransient + instrumentTransient) / 2 * at2040Config.transientSculpt;
          const formantParams = (typeof this.preserveFormant === 'function') ? this.preserveFormant(this.currentPitchMult || 0, fundamentalFreq, vocalPresence, validatedSpectral) : {
            freq: 430,
            gain: 2.8,
            q: 0.9
          };
          if (at2040Config.enabled) {
            const entanglementFactor = validatedSpectral.bass > 0.65 ? 0.85 : 1.0;
            formantParams.freq = Math.min(formantParams.freq * at2040Config.formantScale * entanglementFactor, 460);
            formantParams.gain = Math.min(formantParams.gain * at2040Config.emotionalVector, 3.5);
            formantParams.q = Math.max(formantParams.q * (at2040Config.phaseLockFactor || 0.9), 0.85);
            let masterFormant = at2040Config.formantScale * (1 + (this.currentPitchMult || 0) * 0.01);
            masterFormant = Math.max(0.8, Math.min(1.2, masterFormant));
            if (validatedSpectral.bass > 0.65) masterFormant *= 0.85;
            const formantClarityBoost = transparencyFactor * (1.0 + (1.0 - clarityIndex) * 0.3);
            masterFormant *= formantClarityBoost * (presenceBoost > 1.0 ? 1.05 : 1.0);
            masterFormant = Math.max(0.85, Math.min(1.25, masterFormant));
            formantParams.gain *= masterFormant * 0.8 * at2040Config.pitchShiftFactor;
            if (Math.abs(this.currentPitchMult || 0) > 0.5) {
              formantParams.gain *= 0.9;
              formantParams.q *= 1.1;
            }
          }
          const quantizationLevel = isLowPowerDevice || cpuLoad > 0.8 ? 0.08 : 0.008;
          const quantize = (value, precision) => Math.round(value / precision) * precision;
          const masterGain = Math.max(0.65, Math.min(0.85, 0.7 * (clarityIndex > 0.6 ? 0.95 : 1.0) * at2040Config.emotionalVector * at2040Config.deviceAdaptFactor * at2040Config.pitchShiftFactor));
          let baseParams = {
            bassCutFreq: quantize(26, quantizationLevel),
            trebleCutFreq: quantize(16000 - dynamicTrebleReduction * 1300, quantizationLevel),
            lowShelfGain: quantize((8.0 + subBassBoost + warmthBoost + (userFeedbackAdjust?.bass || 0) + (userFeedbackAdjust?.subBass || 0)) * masterGain * Math.max(0.9, transientDamping), quantizationLevel),
            subBassGain: quantize((4.0 + subBassBoost + (userFeedbackAdjust?.bass || 0) + (userFeedbackAdjust?.subBass || 0)) * masterGain * at2040Config.harmonicBoost * (transientEnergy > 0.6 ? 1.25 : 1.05) * Math.max(0.85, transientDamping), quantizationLevel),
            subMidGain: quantize((5.5 + subMidBoost + warmthBoost + (userFeedbackAdjust?.mid || 0) + (userFeedbackAdjust?.warmth || 0)) * masterGain * Math.tanh(transparencyFactor * 1.2), quantizationLevel),
            midBassGain: quantize((4.0 + warmthBoost + (userFeedbackAdjust?.mid || 0)) * masterGain * Math.tanh(transparencyFactor * 1.1), quantizationLevel),
            midShelfGain: quantize((5.8 + midBoost + (userFeedbackAdjust?.mid || 0) + (userFeedbackAdjust?.clarity || 0) * 0.5 + historyAdjust.midShelfGain) * masterGain * presenceBoost, quantizationLevel),
            highMidGain: quantize((4.5 + midBoost + harmonicBoost + transientAdjust + (userFeedbackAdjust?.clarity || 0) * 0.5) * masterGain * presenceBoost, quantizationLevel),
            highShelfGain: quantize((0.35 - dynamicTrebleReduction + harmonicBoost + (userFeedbackAdjust?.treble || 0)) * masterGain, quantizationLevel),
            subTrebleGain: quantize((0.2 - dynamicTrebleReduction + harmonicBoost + (userFeedbackAdjust?.treble || 0)) * masterGain, quantizationLevel),
            airGain: quantize((0.25 + harmonicBoost - dynamicTrebleReduction + (userFeedbackAdjust?.air || 0)) * masterGain * airNaturalBoost, quantizationLevel),
            compressorThreshold: quantize(-24, quantizationLevel),
            compressorRatio: quantize(4.5 * (subBassEnergy > 0.7 ? 1.35 : 1.0) * at2040Config.emotionalVector * at2040Config.pitchShiftFactor, quantizationLevel),
            compressorAttack: quantize(0.0012, quantizationLevel),
            compressorRelease: quantize(transientEnergy > 0.65 ? 0.08 : 0.16, quantizationLevel),
            notchFreq: quantize(isHighVocal ? 7300 : 6600, quantizationLevel),
            notchQ: quantize(3.5 * at2040Config.phaseLockFactor, quantizationLevel),
            f1Freq: quantize(formantParams.freq, quantizationLevel),
            f2Freq: quantize(formantParams.freq * 4.2 * at2040Config.formantScale, quantizationLevel),
            formantGain: quantize((formantParams.gain + (userFeedbackAdjust?.vocalClarity || 0) * 0.4 + historyAdjust.formantGain) * masterGain, quantizationLevel),
            formantQ: quantize(formantParams.q, quantizationLevel),
            deEsserGain: quantize(-18, quantizationLevel),
            boost: quantize(0.8 + harmonicBoost * at2040Config.harmonicBoost, quantizationLevel),
            panAdjust: quantize((songStructure?.section === 'chorus' ? 0.15 : 0.05) + (clarityIndex * 0.1), quantizationLevel),
            stereoWidth: quantize(stereoWidth, quantizationLevel),
            minFadeLength: 1024,
            fadeTime: 0.02,
            bufferTime: 0.04,
            masterGain: masterGain
          };
          const safeSpectralFlux = (typeof ensureFinite === 'function') ? ensureFinite(validatedSpectral.spectralFlux, 0.5) : (validatedSpectral.spectralFlux || 0.5);
          const safeSpectralEntropy = (typeof ensureFinite === 'function') ? ensureFinite(validatedSpectral.spectralEntropy, 0.5) : (validatedSpectral.spectralEntropy || 0.5);
          const safeHarmonicRatio = (typeof ensureFinite === 'function') ? ensureFinite(validatedSpectral.harmonicRatio, 0.5) : (validatedSpectral.harmonicRatio || 0.5);
          if (vocalPresence > 0.7 || transientEnergy > 0.65 || safeSpectralFlux > 0.6 || highFreqEnergy > 0.7 || userFeedbackAdjust?.distortion < -1.0 || spectralCoherence < 0.4) {
            baseParams.deEsserGain = quantize(-20 - (safeSpectralFlux - 0.6) * 12, quantizationLevel);
            baseParams.notchFreq = quantize(isHighVocal ? 7400 : 6700, quantizationLevel);
            baseParams.notchQ = quantize(3.8 * (userFeedbackAdjust?.distortion < -1.0 ? 1.3 : 1.0) * at2040Config.phaseLockFactor, quantizationLevel);
            const trebleMult = 0.55 * at2040Config.emotionalVector;
            baseParams.highShelfGain *= trebleMult;
            baseParams.subTrebleGain *= trebleMult;
            baseParams.airGain *= trebleMult;
            if (spectralCoherence < 0.4) {
              baseParams.formantGain *= 0.65 * at2040Config.emotionalVector;
              baseParams.compressorRatio *= 0.75;
            }
          }
          if (safeSpectralFlux > 0.65) {
            baseParams.compressorAttack = quantize(0.0011, quantizationLevel);
            baseParams.highMidGain += 0.2 * masterGain * at2040Config.transientSculpt;
          }
          if (safeSpectralEntropy > 0.55) {
            baseParams.midShelfGain += 0.1 * masterGain * at2040Config.emotionalVector;
            baseParams.formantGain += 0.1 * masterGain * at2040Config.emotionalVector;
            baseParams.subBassGain *= 0.85 * at2040Config.deviceAdaptFactor;
          }
          if (safeHarmonicRatio > 0.65) {
            baseParams.harmonicExciterGain = quantize((baseParams.harmonicExciterGain || 0) + 0.4 * masterGain * at2040Config.harmonicBoost, quantizationLevel);
            baseParams.highMidGain += 0.1 * masterGain * at2040Config.harmonicBoost;
            baseParams.airGain += 0.05 * masterGain * at2040Config.emotionalVector;
          }
          const lookAheadWeight = songStructure?.section === 'chorus' && vocalPresence > 0.65 ? 1.25 : (songStructure?.section === 'verse' ? 1.0 : (songStructure?.section === 'bridge' ? 1.15 : 1.0));
          if (songStructure?.section === 'chorus') {
            baseParams.formantGain = quantize(Math.min(3.5, baseParams.formantGain + 0.6 * lookAheadWeight * at2040Config.emotionalVector) * masterGain, quantizationLevel);
            baseParams.midShelfGain += 0.4 * lookAheadWeight * masterGain * at2040Config.emotionalVector;
            baseParams.highMidGain += 0.3 * lookAheadWeight * masterGain * at2040Config.transientSculpt;
            baseParams.subBassGain -= 0.3 * lookAheadWeight * masterGain * at2040Config.deviceAdaptFactor;
            baseParams.compressorRatio *= 1.2 * lookAheadWeight * at2040Config.pitchShiftFactor;
            if (safeSpectralFlux > 0.65) baseParams.highShelfGain -= 0.005 * spectralCoherence;
          } else if (songStructure?.section === 'verse') {
            baseParams.subMidGain += 0.5 * lookAheadWeight * masterGain * at2040Config.emotionalVector;
            baseParams.formantGain += 0.3 * lookAheadWeight * masterGain * at2040Config.emotionalVector;
            baseParams.highMidGain += 0.2 * lookAheadWeight * masterGain * at2040Config.transientSculpt;
          } else if (songStructure?.section === 'bridge') {
            baseParams.lowShelfGain -= 0.5 * lookAheadWeight * masterGain * at2040Config.deviceAdaptFactor;
            baseParams.subBassGain -= 0.4 * lookAheadWeight * masterGain * at2040Config.deviceAdaptFactor;
            baseParams.highMidGain += 0.3 * lookAheadWeight * masterGain * at2040Config.transientSculpt;
            baseParams.formantGain += 0.4 * lookAheadWeight * masterGain * at2040Config.emotionalVector;
          }
          if (subBassEnergy > 0.7 || userFeedbackAdjust?.bass > 1.1) {
            baseParams.compressorRatio *= 1.3 * at2040Config.pitchShiftFactor;
            baseParams.compressorAttack = quantize(0.0011, quantizationLevel);
            baseParams.subBassGain *= 0.75 * masterGain * at2040Config.deviceAdaptFactor;
            baseParams.lowShelfGain *= 0.8 * masterGain * at2040Config.deviceAdaptFactor;
            baseParams.midBassGain *= 0.7 * masterGain * at2040Config.deviceAdaptFactor;
            baseParams.subBassGain += 0.2 * (validatedSpectral.transientEnergy > 0.65 ? 1.1 : 1.0) * masterGain * at2040Config.harmonicBoost * transientDamping;
            if (subBassEnergy > 0.7) {
              baseParams.subBassGain *= at2040Config.deviceAdaptFactor * 1.02;
              baseParams.panAdjust += 0.03 * spectralCoherence;
            }
          }
          // MAP KIẾN TRÚC 8 CẤU HÌNH VẬT LÝ
          const profileWeights = {
            warm: {
              lowShelf: 1.8,
              subBass: 1.0,
              subMid: 1.2,
              highShelf: 0.6,
              compressor: 0.7,
              formantScale: 1.0,
              transientSculpt: 0.85,
              clarityBoost: 1.0,
              melodySynthesis: 1.1
            },
            bright: {
              highShelf: 0.25,
              subTreble: 0.25,
              air: 0.25,
              deEsser: -20,
              compressorRelease: 0.18,
              formantScale: 1.1,
              transientSculpt: 1.1,
              clarityBoost: 1.2,
              melodySynthesis: 1.2
            },
            bassHeavy: {
              lowShelf: 2.1,
              subBass: 1.8,
              subMid: 0.5,
              compressor: 1.4,
              highShelf: 0.6,
              formantScale: 0.9,
              transientSculpt: 1.1,
              clarityBoost: 0.85,
              melodySynthesis: 1.0
            },
            vocal: {
              subMid: 1.2,
              midShelf: 1.3,
              highMid: 1.0,
              formant: 0.6,
              compressor: -14,
              formantScale: 1.0,
              transientSculpt: 0.95,
              clarityBoost: 1.25,
              melodySynthesis: 1.3
            },
            // ProNatural: Bản đồ phẳng lỳ, tối ưu độ mộc phòng thu chuẩn Hi-Fi Monitor
            proNatural: {
              lowShelf: 1.0,
              subMid: 0.7,
              midShelf: 0.7,
              compressor: 0.65,
              formantScale: 1.0,
              transientSculpt: 0.85,
              clarityBoost: 1.1,
              melodySynthesis: 1.35
            },
            karaokeDynamic: {
              subMid: 1.3,
              midShelf: 1.5,
              highMid: 1.2,
              formant: 0.8,
              compressor: -12,
              formantScale: 1.1,
              transientSculpt: 1.1,
              clarityBoost: 1.25,
              melodySynthesis: 1.35
            },
            rockMetal: {
              lowShelf: 1.2,
              subBass: 1.0,
              midShelf: 0.9,
              highMid: 0.7,
              compressor: 1.3,
              formantScale: 0.9,
              transientSculpt: 1.2,
              clarityBoost: 1.0,
              melodySynthesis: 1.0
            },
            smartStudio: {
              lowShelf: 1.5,
              subBass: 1.2,
              midShelf: 0.9,
              highMid: 0.7,
              compressor: 1.2,
              formantScale: 1.0,
              transientSculpt: 1.1,
              clarityBoost: 1.1,
              melodySynthesis: 1.25
            }
          };
          // 🪐 ĐỒNG BỘ FALLBACK WEIGHTS: Trục dự phòng cuối cùng chuyển từ smartStudio sang proNatural
          const weights = profileWeights[activeProfile] || profileWeights.proNatural;
          switch (activeProfile) {
            case 'warm':
              baseParams.lowShelfGain += weights.lowShelf * masterGain * at2040Config.emotionalVector;
              baseParams.subBassGain += weights.subBass * masterGain * at2040Config.harmonicBoost;
              baseParams.subMidGain += weights.subMid * masterGain * at2040Config.emotionalVector;
              baseParams.f1Freq = quantize(340 * at2040Config.formantScale, quantizationLevel);
              baseParams.f2Freq = quantize(1400 * at2040Config.formantScale, quantizationLevel);
              baseParams.highShelfGain *= weights.highShelf * masterGain * at2040Config.emotionalVector;
              baseParams.subTrebleGain *= weights.highShelf * masterGain * at2040Config.emotionalVector;
              baseParams.airGain *= weights.highShelf * masterGain * at2040Config.emotionalVector;
              baseParams.compressorRatio *= weights.compressor;
              baseParams.warmthBoost = (warmthBoost || 0) + 0.6 * at2040Config.emotionalVector;
              baseParams.subMidGain += 0.1 * (validatedSpectral.vocalPresence > 0.65 ? 1.1 : 1.0) * masterGain * at2040Config.emotionalVector * Math.max(0.7, transparencyFactor);
              break;
            case 'bright':
              baseParams.highShelfGain += weights.highShelf * masterGain * at2040Config.emotionalVector;
              baseParams.subTrebleGain += weights.subTreble * masterGain * at2040Config.emotionalVector;
              baseParams.airGain += weights.air * masterGain * at2040Config.emotionalVector;
              baseParams.f1Freq = quantize(460 * at2040Config.formantScale, quantizationLevel);
              baseParams.f2Freq = quantize(2000 * at2040Config.formantScale, quantizationLevel);
              baseParams.deEsserGain = quantize(weights.deEsser, quantizationLevel);
              baseParams.notchFreq = quantize(6000, quantizationLevel);
              baseParams.notchQ = quantize(2.5 * at2040Config.phaseLockFactor, quantizationLevel);
              baseParams.compressorRelease = quantize(weights.compressorRelease, quantizationLevel);
              baseParams.airGain += 0.05 * (validatedSpectral.midHigh > 0.65 ? 1.0 : 0.9) * masterGain * at2040Config.emotionalVector * airNaturalBoost;
              break;
            case 'bassHeavy':
              baseParams.lowShelfGain += Math.tanh(weights.lowShelf * masterGain * at2040Config.harmonicBoost) * 1.05;
              baseParams.subBassGain += Math.tanh(weights.subBass * masterGain * at2040Config.harmonicBoost) * 1.15;
              baseParams.subMidGain += weights.subMid * masterGain * at2040Config.emotionalVector * transparencyFactor;
              baseParams.f1Freq = quantize(260 * at2040Config.formantScale, quantizationLevel);
              baseParams.f2Freq = quantize(1300 * at2040Config.formantScale, quantizationLevel);
              baseParams.compressorRatio *= weights.compressor;
              baseParams.compressorAttack = quantize(0.0011, quantizationLevel);
              baseParams.highShelfGain *= weights.highShelf * masterGain * at2040Config.emotionalVector;
              baseParams.subTrebleGain *= weights.highShelf * masterGain * at2040Config.emotionalVector;
              baseParams.airGain *= weights.highShelf * masterGain * at2040Config.emotionalVector;
              baseParams.midBassGain *= 0.7 * masterGain * at2040Config.deviceAdaptFactor * transparencyFactor;
              baseParams.subBassGain += 0.2 * (validatedSpectral.transientEnergy > 0.65 ? 1.1 : 1.0) * masterGain * at2040Config.harmonicBoost * transientDamping;
              break;
            case 'vocal':
              baseParams.subMidGain += weights.subMid * masterGain * at2040Config.emotionalVector * transparencyFactor;
              baseParams.midShelfGain += weights.midShelf * masterGain * at2040Config.emotionalVector * presenceBoost;
              baseParams.highMidGain += weights.highMid * masterGain * at2040Config.transientSculpt * presenceBoost;
              baseParams.f1Freq = quantize(520 * at2040Config.formantScale, quantizationLevel);
              baseParams.f2Freq = quantize(2300 * at2040Config.formantScale, quantizationLevel);
              baseParams.formantGain = quantize(Math.min(3.5, baseParams.formantGain + weights.formant) * masterGain * at2040Config.emotionalVector, quantizationLevel);
              baseParams.formantQ = quantize(0.9 * at2040Config.phaseLockFactor, quantizationLevel);
              baseParams.compressorThreshold = quantize(weights.compressor, quantizationLevel);
              baseParams.deEsserGain = quantize(-20, quantizationLevel);
              baseParams.notchQ = quantize(2.8 * at2040Config.phaseLockFactor, quantizationLevel);
              baseParams.formantGain += 0.1 * (validatedSpectral.vocalPresence > 0.65 ? 1.2 : 1.0) * masterGain * at2040Config.emotionalVector;
              break;
            case 'proNatural':
              baseParams.lowShelfGain += weights.lowShelf * masterGain * at2040Config.emotionalVector;
              baseParams.subMidGain += weights.subMid * masterGain * at2040Config.emotionalVector * transparencyFactor;
              baseParams.midShelfGain += weights.midShelf * masterGain * at2040Config.emotionalVector;
              baseParams.f1Freq = quantize(380 * at2040Config.formantScale, quantizationLevel);
              baseParams.f2Freq = quantize(1500 * at2040Config.formantScale, quantizationLevel);
              baseParams.compressorRatio *= weights.compressor;
              baseParams.formantGain += (userFeedbackAdjust?.vocalClarity || 0) * 0.3 * masterGain * at2040Config.emotionalVector;
              baseParams.compressorRelease = quantize(0.35, quantizationLevel);
              baseParams.midShelfGain += 0.05 * (validatedSpectral.midHigh > 0.65 ? 1.0 : 0.9) * masterGain * at2040Config.emotionalVector;
              break;
            case 'karaokeDynamic':
              baseParams.subMidGain += weights.subMid * masterGain * at2040Config.emotionalVector * transparencyFactor;
              baseParams.midShelfGain += weights.midShelf * masterGain * at2040Config.emotionalVector * presenceBoost;
              baseParams.highMidGain += weights.highMid * masterGain * at2040Config.transientSculpt * presenceBoost;
              baseParams.f1Freq = quantize(480 * at2040Config.formantScale, quantizationLevel);
              baseParams.f2Freq = quantize(2200 * at2040Config.formantScale, quantizationLevel);
              baseParams.formantGain = quantize((validatedSpectral.vocalPresence > 0.75 ? 3.4 : 3.2) * masterGain * at2040Config.emotionalVector, quantizationLevel);
              baseParams.deEsserGain = quantize(-20, quantizationLevel);
              baseParams.notchFreq = quantize(7100, quantizationLevel);
              baseParams.compressorThreshold = quantize(weights.compressor, quantizationLevel);
              baseParams.highMidGain += 0.1 * (validatedSpectral.transientEnergy > 0.65 ? 1.1 : 1.0) * masterGain * at2040Config.transientSculpt;
              break;
            case 'rockMetal':
              baseParams.lowShelfGain += weights.lowShelf * masterGain * at2040Config.harmonicBoost;
              baseParams.subBassGain += weights.subBass * masterGain * at2040Config.harmonicBoost;
              baseParams.midShelfGain += weights.midShelf * masterGain * at2040Config.emotionalVector;
              baseParams.highMidGain += (weights.highMid + (transientAdjust || 0)) * masterGain * at2040Config.transientSculpt;
              baseParams.f1Freq = quantize(460 * at2040Config.formantScale, quantizationLevel);
              baseParams.f2Freq = quantize(2000 * at2040Config.formantScale, quantizationLevel);
              baseParams.compressorRatio *= weights.compressor;
              baseParams.compressorAttack = quantize(0.0011, quantizationLevel);
              baseParams.deEsserGain = quantize(-20, quantizationLevel);
              baseParams.highShelfGain *= 0.65 * masterGain * at2040Config.emotionalVector;
              baseParams.highMidGain += 0.2 * (validatedSpectral.harmonicRatio > 0.65 ? 1.1 : 1.0) * masterGain * at2040Config.transientSculpt;
              break;
            case 'smartStudio':
              baseParams.lowShelfGain += (subBassEnergy > 0.65 ? weights.lowShelf : weights.lowShelf * 0.7) * masterGain * at2040Config.harmonicBoost * Math.max(0.9, transientDamping);
              baseParams.subBassGain += (subBassEnergy > 0.65 ? weights.subBass : weights.subBass * 0.7) * masterGain * at2040Config.harmonicBoost * Math.max(0.85, transientDamping);
              baseParams.midShelfGain += (validatedSpectral.midHigh > 0.65 ? weights.midShelf : weights.midShelf * 0.7) * masterGain * at2040Config.emotionalVector * presenceBoost;
              baseParams.highMidGain += (validatedSpectral.midHigh > 0.65 ? weights.highMid : weights.highMid * 0.7) * masterGain * at2040Config.transientSculpt * presenceBoost;
              baseParams.f1Freq = quantize(subBassEnergy > 0.65 ? 280 : (validatedSpectral.midHigh > 0.65 ? 440 : 460) * at2040Config.formantScale, quantizationLevel);
              baseParams.f2Freq = quantize(subBassEnergy > 0.65 ? 1300 : (validatedSpectral.midHigh > 0.65 ? 2100 : 1900) * at2040Config.formantScale, quantizationLevel);
              baseParams.formantGain = quantize(Math.min(3.5, baseParams.formantGain + (userFeedbackAdjust?.vocalClarity || 0) * 0.4) * masterGain * at2040Config.emotionalVector, quantizationLevel);
              baseParams.formantQ = quantize(0.9 * at2040Config.phaseLockFactor, quantizationLevel);
              baseParams.deEsserGain = quantize(validatedSpectral.vocalPresence > 0.75 ? -20 : -18, quantizationLevel);
              baseParams.compressorRatio *= subBassEnergy > 0.65 ? weights.compressor : 1.0;
              baseParams.compressorAttack = quantize(transientEnergy > 0.65 ? 0.0012 : 0.0025, quantizationLevel);
              baseParams.compressorRelease = quantize(transientEnergy > 0.65 ? 0.08 : 0.18, quantizationLevel);
              baseParams.panAdjust = quantize(subBassEnergy > 0.65 ? 0.12 : 0, quantizationLevel);
              if (cpuLoad < 0.8 && subBassEnergy > 0.6) {
                baseParams.harmonicExciterGain = quantize(Math.min(1.6, 0.7 + (userFeedbackAdjust?.harmonicRichness || 0) * 0.5) * masterGain * at2040Config.harmonicBoost, quantizationLevel);
              }
              baseParams.airGain += 0.05 * (validatedSpectral.spectralEntropy > 0.65 ? 1.0 : 0.9) * masterGain * at2040Config.emotionalVector * airNaturalBoost;
              break;
          }
          // === [INTELLIGENT DSP EXTENSIONS INTEGRATION] ===
          if (typeof phaseLinearCorrection === 'function') {
            baseParams = phaseLinearCorrection(baseParams, validatedSpectral, songStructure, cpuLoad, activeProfile, {
              memoryManager: this.memoryManager,
              phaseLockFactor: at2040Config.phaseLockFactor,
              fftAnalysis: fftAnalysis,
              currentPitchMult: this.currentPitchMult || 0
            });
          }
          // --- [USER FEEDBACK ADAPTIVE ADJUSTMENTS] ---
          if (userFeedbackAdjust) {
            if (userFeedbackAdjust.warmth > 0) {
              baseParams.subMidGain += userFeedbackAdjust.warmth * 0.5 * masterGain * at2040Config.emotionalVector;
              baseParams.lowShelfGain += userFeedbackAdjust.warmth * 0.3 * masterGain * at2040Config.harmonicBoost;
            }
            if (userFeedbackAdjust.distortion < -1.0) {
              const distScale = 0.55 * masterGain * at2040Config.emotionalVector;
              baseParams.highShelfGain *= distScale;
              baseParams.subTrebleGain *= distScale;
              baseParams.airGain *= distScale;
              baseParams.formantGain *= 0.65 * masterGain * at2040Config.emotionalVector;
              baseParams.compressorRatio *= 0.75;
              baseParams.deEsserGain = quantize(Math.max(-24, baseParams.deEsserGain - 4), quantizationLevel);
            }
            if (userFeedbackAdjust.clarity > 0) {
              baseParams.midShelfGain += userFeedbackAdjust.clarity * 0.4 * masterGain * at2040Config.emotionalVector * presenceBoost;
              baseParams.highMidGain += userFeedbackAdjust.clarity * 0.4 * masterGain * at2040Config.transientSculpt * presenceBoost;
              baseParams.formantGain += userFeedbackAdjust.clarity * 0.2 * masterGain * at2040Config.emotionalVector;
              if (transientEnergy > 0.65) baseParams.midShelfGain *= 0.92;
            }
            if (userFeedbackAdjust.vocalClarity > 0) {
              baseParams.formantGain += userFeedbackAdjust.vocalClarity * 0.3 * masterGain * at2040Config.emotionalVector;
              baseParams.highMidGain += userFeedbackAdjust.vocalClarity * 0.3 * masterGain * at2040Config.transientSculpt * presenceBoost;
            }
            if (userFeedbackAdjust.bass > 0) {
              baseParams.lowShelfGain += userFeedbackAdjust.bass * 0.6 * masterGain * at2040Config.harmonicBoost * (this.bassGain || 1.0);
              baseParams.subBassGain += userFeedbackAdjust.bass * 0.4 * masterGain * at2040Config.harmonicBoost * (this.bassGain || 1.0);
            }
            if (userFeedbackAdjust.depth > 0) {
              baseParams.lowShelfGain += userFeedbackAdjust.depth * 0.7 * masterGain * at2040Config.harmonicBoost * (this.bassGain || 1.0);
              baseParams.subBassGain += userFeedbackAdjust.depth * 0.5 * masterGain * at2040Config.harmonicBoost * (this.bassGain || 1.0);
              baseParams.bassCutFreq = quantize(22, quantizationLevel);
            }
            if (userFeedbackAdjust.harmonicRichness > 0 && cpuLoad < 0.8) {
              baseParams.harmonicExciterGain = quantize(Math.min(1.6, (baseParams.harmonicExciterGain || 0) + userFeedbackAdjust.harmonicRichness * 0.5) * masterGain * at2040Config.harmonicBoost, quantizationLevel);
              baseParams.subMidGain *= 0.8 * masterGain * at2040Config.emotionalVector;
              baseParams.highMidGain += 0.1 * masterGain * at2040Config.transientSculpt;
            }
          }
          if (typeof roomCorrectionSimulation === 'function') {
            baseParams = roomCorrectionSimulation(baseParams, validatedSpectral, cpuLoad, activeProfile, {
              memoryManager: this.memoryManager,
              fftAnalysis: fftAnalysis,
              currentPitchMult: this.currentPitchMult || 0,
              roomCoherenceFactor: at2040Config.roomCoherenceFactor
            });
          }
          // 🪐 ĐỒNG BỘ SIÊU NÂNG CẤP: Phục hình phổ nát Content-Aware và tự điều chỉnh thuật toán bảo vệ CPU
          baseParams = this.spectralRestorationAI(baseParams, validatedSpectral, fftAnalysis, fundamentalFreq, at2040Config, quantizationLevel, cpuLoad // Truyền trực tiếp tải CPU thời gian thực vào làm biến điều tiết tầng toán học
          );
          baseParams.fadeTime = Math.max((baseParams.minFadeLength || 1024) / (this.context.sampleRate || 44100), 0.025) * at2040Config.deviceAdaptFactor;
          baseParams.bufferTime = baseParams.fadeTime * 2.5 * (1 + Math.abs(this.currentPitchMult || 0) * 0.4) * at2040Config.deviceAdaptFactor;
          // --- [PERCEPTUAL LOUDNESS & AUTO GAIN STAGING RAMPING] ---
          if (this.outputGain && this.outputGain.gain) {
            const currentTime = this.context.currentTime;
            const rampTime = isLowPowerDevice ? 0.03 : 0.06 * at2040Config.deviceAdaptFactor;
            this.outputGain.gain.cancelScheduledValues(currentTime);
            this.outputGain.gain.setValueAtTime(this.outputGain.gain.value, currentTime);
            const f = fundamentalFreq || 440;
            const psychoCurve = 1 / (1 + Math.pow(f / 1300, 2));
            const maskingThreshold = Math.pow(10, -(validatedSpectral.spl || 0) / 20) * psychoCurve * 1.25;
            const phaseDiff = fftAnalysis ? Math.atan2(fftAnalysis.imag || 0, fftAnalysis.real || 1) : 0;
            const phaseCoherence = Math.cos(phaseDiff) * at2040Config.phaseLockFactor * 1.25;
            const rawAdjustedGain = baseParams.masterGain * Math.max(0.75, Math.min(1.25, (maskingThreshold || 1) * phaseCoherence)) * at2040Config.pitchShiftFactor;
            const adjustedGain = Math.tanh(rawAdjustedGain * 1.1) * 0.92;
            this.outputGain.gain.linearRampToValueAtTime(adjustedGain, currentTime + rampTime);
          }
          // --- [INTELLIGENT MEMORYMANAGER CACHING] ---
          if (this.memoryManager) {
            const cachedObj = this.memoryManager.buffers?.get('optimizedParams');
            const cachedParams = cachedObj?.params;
            if (cachedParams && Date.now() < cachedParams.expiry) {
              const baseKeys = Object.keys(baseParams);
              for (let k = 0; k < baseKeys.length; k++) {
                const key = baseKeys[k];
                if (typeof baseParams[key] === 'number' && typeof cachedParams[key] === 'number') {
                  baseParams[key] = cachedParams[key] * 0.6 + baseParams[key] * 0.4;
                }
              }
            }
            const expiry = Date.now() + (songStructure?.section === 'chorus' ? 4000 : 7000);
            this.memoryManager.buffers?.set('optimizedParams', {
              params: {
                ...baseParams,
                expiry
              },
              timestamp: Date.now(),
              expiry,
              priority: 'high'
            });
            this.memoryManager.set('lastOptimizeInputHash', inputHash, 'low', {
              timestamp: Date.now()
            });
            if (this.calculateMaxCacheSize) this.memoryManager.pruneCache(this.calculateMaxCacheSize());
          }
          // --- [FINAL PURE AUDIO ENHANCEMENT FACTOR] ---
          const finalF = fundamentalFreq || 440;
          const emotional = activeProfile === 'warm' ? 'calm' : (activeProfile === 'rockMetal' ? 'aggressive' : 'neutral');
          const transientVal = validatedSpectral.transientEnergy || 0.5;
          const vocalVal = validatedSpectral.vocalPresence || 0.5;
          const at2040Factor = at2040Enhance(finalF, activeProfile, emotional, transientVal, vocalVal);
          const finalClamp = (val) => Math.max(0.75, Math.min(1.25, val));
          baseParams.masterGain *= finalClamp(at2040Factor);
          baseParams.compressorRatio *= finalClamp(at2040Factor);
          baseParams.fadeTime *= finalClamp(at2040Factor);
          return baseParams;
        }
      };
      const optimizedParams = deepLearningModel.predict({
        spectralComplexity: musicContext.spectralComplexity,
        transientEnergy: musicContext.transientEnergy,
        vocalPresence: musicContext.vocalPresence,
        harmonicComplexity: musicContext.harmonicComplexity,
        currentGenre: this.currentGenre,
        polyphonicPitches: this.polyphonicPitches,
        warmthBoost,
        transientBoostAdjust
      });
      if (isDebug) {
        const optimizationScore = (spectralCoherence * 0.4 + transientEnergy * 0.3 + validatedSpectral.vocalPresence * 0.3).toFixed(2);
        console.debug('AT2040PureGenixV2 Finalized:', {
          profile: activeProfile,
          score: optimizationScore,
          params: optimizedParams
        });
      }
      return optimizedParams;
    } catch (error) {
      if (typeof handleError === 'function') {
        handleError('Error optimizing sound profile with AT2040PureGenixV2', error, {
          profile,
          contextId: this.contextId
        }, 'high', {
          memoryManager: this.memoryManager
        });
      }
      this.notifyUIError?.('Failed to optimize sound profile with AT2040PureGenixV2');
      return {
        bassCutFreq: 26,
        trebleCutFreq: 16000,
        lowShelfGain: 8.0,
        subBassGain: 4.0,
        subMidGain: 5.5,
        midBassGain: 4.0,
        midShelfGain: 5.8,
        highMidGain: 4.5,
        highShelfGain: 0.35,
        subTrebleGain: 0.2,
        airGain: 0.25,
        compressorThreshold: -24,
        compressorRatio: 4.5,
        compressorAttack: 0.001,
        compressorRelease: 0.16,
        notchFreq: 6600,
        notchQ: 3.5,
        f1Freq: 430,
        f2Freq: 1806,
        formantGain: 2.8,
        formantQ: 0.9,
        deEsserGain: -18,
        boost: 0.8,
        panAdjust: 0,
        minFadeLength: 1024,
        fadeTime: 0.025,
        bufferTime: 0.04,
        masterGain: 0.7
      };
    }
  };
  /**
   * Hàm hash riêng cho config để đảm bảo Cache chính xác tuyệt đối
   * Chạy cực nhanh vì chỉ lấy các giá trị cần thiết
   */
  Jungle.prototype.hashConfig = function(config) {
    // Ép kiểu array về string dạng "2500,7500" để hash chuẩn
    const freqHash = Array.isArray(config.frequencyRange) ? config.frequencyRange.join(',') : '2500,7500';
    const identity = [
      ensureFinite(config.intensity, 0.15),
      freqHash,
      ensureFinite(config.harmonicOrder, 2),
      ensureFinite(config.transientPreservation, 0.6)
    ].join('|');
    let hash = 0;
    for (let i = 0; i < identity.length; i++) {
      hash = ((hash << 5) - hash) + identity.charCodeAt(i);
      hash |= 0;
    }
    return (hash >>> 0).toString(36);
  };
  /**
   * Apply Harmonic Enhancement with proper node reuse and connection management
   * ĐÃ FIX: Memory Leak + Zero-GC + Cache Key + Disconnect + Glitch Reduction
   */
  Jungle.prototype.applyHarmonicEnhancement = function(config = {}) {
    try {
      const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
      // Validate AudioContext
      if (!this.context || !(this.context instanceof AudioContext) || this.context.state === 'closed') {
        throw new Error('Invalid or closed AudioContext');
      }
      // Initialize config with defaults
      const intensity = ensureFinite(config.intensity, 0.15);
      const frequencyRange = Array.isArray(config.frequencyRange) && config.frequencyRange.length === 2 ? [ensureFinite(config.frequencyRange[0], 2500), ensureFinite(config.frequencyRange[1], 7500)] : [2500, 7500];
      const harmonicOrder = Math.min(ensureFinite(config.harmonicOrder, 2), 5);
      const transientPreservation = ensureFinite(config.transientPreservation, this.currentProfile === 'rockMetal' ? 0.8 : 0.6);
      const phaseLock = this.qualityMode === 'high' || this.qualityMode === 'ultra-high';
      // Get spectral profile - Zero-GC
      const spectralProfile = this.spectralProfile || DEFAULT_SPECTRAL_ANALYZER;
      const isVocal = this.isVocal || this.currentProfile === 'vocal' || this.currentProfile === 'karaokeDynamic';
      const vocalPresence = ensureFinite(spectralProfile.vocalPresence, this.currentProfile === 'vocal' ? 0.8 : 0.5);
      const transientEnergy = ensureFinite(spectralProfile.transientEnergy, this.currentProfile === 'rockMetal' ? 0.7 : 0.5);
      // Calculate harmonic gain
      const harmonicGain = Math.min(intensity * (isVocal ? 1.2 : 1.0), 0.3);
      const harmonicQ = isVocal ? 0.8 : 1.0;
      const freqStep = (frequencyRange[1] - frequencyRange[0]) / harmonicOrder;
      const currentTime = this.context.currentTime;
      const rampTime = ensureFinite(this.rampTime, 0.15) * (1 + intensity * 0.5);
      // Tinh hoa: harmonicPool reuse filter
      if (!this.harmonicPool) this.harmonicPool = [];
      // FIX MEMORY LEAK: Reuse dedicated GainNode
      if (!this._harmonicInputGain) {
        this._harmonicInputGain = this.context.createGain();
      }
      // === KHỞI TẠO MASTER GAIN ĐỂ GIẢM GLITCH (nếu chưa có) ===
      if (!this._harmonicMasterGain) {
        this._harmonicMasterGain = this.context.createGain();
        this._harmonicMasterGain.gain.value = 1.0;
      }
      let lastNode = this._analyser || this._harmonicInputGain;
      // === MUTE MƯỢT TRƯỚC KHI THAY ĐỔI CHAIN ===
      const now = this.context.currentTime;
      // Chỉ thực hiện khi Context đang mở hoặc suspended (không phải closed)
      if (this._harmonicMasterGain && this.context.state !== 'closed') {
        this._harmonicMasterGain.gain.cancelScheduledValues(now);
        this._harmonicMasterGain.gain.setValueAtTime(this._harmonicMasterGain.gain.value, now);
        this._harmonicMasterGain.gain.linearRampToValueAtTime(0.00001, now + 0.006);
      }
      // Ngắt kết nối cũ để tránh stacking nodes
      if (this._lastHarmonicChain) {
        try {
          this._lastHarmonicChain.disconnect();
        } catch (e) {}
      }
      // Xây dựng harmonic chain
      for (let i = 0; i < harmonicOrder; i++) {
        if (!this.harmonicPool[i]) {
          const filter = this.context.createBiquadFilter();
          filter.type = 'peaking';
          this.harmonicPool[i] = filter;
        }
        const filter = this.harmonicPool[i];
        const freq = ensureFinite(frequencyRange[0] + ((i + 1) * freqStep), frequencyRange[0]);
        if (freq > frequencyRange[1]) continue;
        filter.frequency.setTargetAtTime(freq, currentTime, 0.05);
        filter.Q.setTargetAtTime(harmonicQ, currentTime, 0.05);
        filter.gain.setTargetAtTime(harmonicGain * (1 - i * 0.1), currentTime, 0.05);
        lastNode.connect(filter);
        lastNode = filter;
      }
      // Reuse transientFilterNode
      if (transientEnergy < 0.7 && transientPreservation > 0.5) {
        if (!this.transientFilterNode) {
          this.transientFilterNode = this.context.createBiquadFilter();
          this.transientFilterNode.type = 'highshelf';
        }
        this.transientFilterNode.frequency.setTargetAtTime(8000, currentTime, 0.05);
        this.transientFilterNode.gain.setTargetAtTime(transientPreservation * 0.8, currentTime, 0.05);
        lastNode.connect(this.transientFilterNode);
        lastNode = this.transientFilterNode;
        if (isDebug) console.debug('Applied transient preservation filter');
      }
      // Reuse vocalClarityNode
      if (isVocal && vocalPresence < 0.7) {
        if (!this.vocalClarityNode) {
          this.vocalClarityNode = this.context.createBiquadFilter();
          this.vocalClarityNode.type = 'peaking';
        }
        this.vocalClarityNode.frequency.setTargetAtTime(3000, currentTime, 0.05);
        this.vocalClarityNode.Q.setTargetAtTime(1.2, currentTime, 0.05);
        this.vocalClarityNode.gain.setTargetAtTime(vocalPresence * 1.2, currentTime, 0.05);
        lastNode.connect(this.vocalClarityNode);
        lastNode = this.vocalClarityNode;
        if (isDebug) console.debug('Applied vocal clarity filter');
      }
      // Bass control
      if (spectralProfile.bass > 0.7 && this.lowShelfFilter) {
        const bassReduction = Math.min(spectralProfile.bass * 0.8, 0.6);
        this.lowShelfFilter.gain.cancelScheduledValues(currentTime);
        this.lowShelfFilter.gain.setValueAtTime(this.lowShelfFilter.gain.value, currentTime);
        this.lowShelfFilter.gain.linearRampToValueAtTime(bassReduction, currentTime + rampTime);
        if (isDebug) console.debug('Reduced bass to avoid muddiness');
      }
      // Reuse phaseLockGainNode
      if (phaseLock && this.dynamicFormantPitchShift?.phaseLock) {
        if (!this.phaseLockGainNode) {
          this.phaseLockGainNode = this.context.createGain();
        }
        this.phaseLockGainNode.gain.setTargetAtTime(1.0, currentTime, 0.05);
        lastNode.connect(this.phaseLockGainNode);
        lastNode = this.phaseLockGainNode;
        if (isDebug) console.debug('Applied phase-locked processing');
      }
      // === KẾT NỐI CUỐI CÙNG QUA MASTER GAIN ===
      const finalOutput = this.outputGain || this.context.destination;
      lastNode.connect(this._harmonicMasterGain);
      this._harmonicMasterGain.connect(finalOutput);
      // Unmute mượt mà
      this._harmonicMasterGain.gain.cancelScheduledValues(now + 0.008);
      this._harmonicMasterGain.gain.setValueAtTime(0.00001, now + 0.008);
      this._harmonicMasterGain.gain.linearRampToValueAtTime(1.0, now + 0.008 + rampTime * 0.6);
      // Lưu reference để lần sau disconnect
      this._lastHarmonicChain = this._harmonicMasterGain;
      // Memory & UI - Cache key an toàn
      if (this.memoryManager) {
        const cacheKey = `harmonicEnhancement_${this.contextId}_${this.hashConfig(config)}`;
        this.memoryManager.set(cacheKey, {
          intensity,
          frequencyRange,
          harmonicOrder,
          transientPreservation,
          phaseLock,
          harmonicGain,
          harmonicQ,
          timestamp: Date.now(),
          expiry: Date.now() + 15000,
          priority: 'high'
        }, 'high');
        this.memoryManager.pruneCache(this.calculateMaxCacheSize?.() || 32 * 1024 * 1024);
      }
      if (typeof this.notifyUIUpdate === 'function') {
        this.notifyUIUpdate({
          harmonicEnhancement: {
            intensity,
            frequencyRange,
            harmonicOrder,
            transientPreservation,
            phaseLock,
            harmonicGain,
            vocalPresence,
            timestamp: Date.now()
          }
        });
      }
      if (isDebug) console.debug('Harmonic Enhancement Applied Successfully');
      return lastNode;
    } catch (error) {
      handleError('Error applying harmonic enhancement', error, {
        config,
        contextId: this.contextId,
        profile: this.currentProfile
      }, 'high', {
        memoryManager: this.memoryManager
      });
      this.notifyUIError?.('Failed to apply harmonic enhancement');
      return this.outputGain || this.context.destination;
    }
  };
  // === ĐẶT Ở ĐẦU FILE HOẶC NGOÀI CLASS ===
  const FFT_VALID_SIZES = Object.freeze([32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768]);
  const findNearestValidSize = (target) => {
    return FFT_VALID_SIZES.reduce((prev, curr) => Math.abs(curr - target) < Math.abs(prev - target) ? curr : prev);
  };
  /**
   * Set FFT Size with advanced adaptive logic and Zero-GC
   * FIX: Scope issue for isChorus, Memory Leak, Cache Efficiency
   */
  Jungle.prototype.setFFTSize = function(size, {
    devicePerf = 'medium',
    qualityMode = 'medium',
    spectralProfile = {},
    songStructure = {},
    isVocalHeavy = false,
    isVocalFeedback = false,
    transientDensity = 0,
    spectralFlux = 0,
    fftAnalysis = {},
    cpuLoad = 0,
    avgProcessingTime = 0
  } = {}) {
    const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
    // Khởi tạo biến scope an toàn cho catch block
    let isChorus = false;
    try {
      if (!this._analyser) {
        throw new Error('Analyser is not initialized');
      }
      // Tinh hoa: cacheKey với cpuLoad gom nhóm tăng hit
      const cacheKey = this.generateCacheSignature?.('fftSize', {
        spectralProfile,
        songStructure: songStructure.section || 'unknown',
        devicePerf,
        cpuLoad: Math.round(cpuLoad * 10) / 10
      }) || `fftSize_${this.contextId}`;
      // Check cached settings
      const cachedSettings = this.memoryManager?.get(cacheKey);
      if (cachedSettings?.size && FFT_VALID_SIZES.includes(cachedSettings.size) && cachedSettings.expiry > Date.now()) {
        if (this._analyser.fftSize !== cachedSettings.size) {
          this._analyser.fftSize = cachedSettings.size;
        }
        this._analyser.smoothingTimeConstant = cachedSettings.smoothing;
        this._analyser.minDecibels = cachedSettings.minDecibels;
        this._analyser.maxDecibels = cachedSettings.maxDecibels;
        if (isDebug) console.debug('Reused cached FFT settings', {
          cacheKey,
          cachedSettings
        });
        return;
      }
      // Detect device performance
      const hardwareConcurrency = navigator.hardwareConcurrency || 4;
      const deviceMemory = navigator.deviceMemory || 4;
      const effectiveDevicePerf = cpuLoad > 0.80 || hardwareConcurrency < 4 || deviceMemory < 4 ? 'low' : cpuLoad > 0.60 || hardwareConcurrency < 8 ? 'medium' : 'high';
      // Analyze audio context
      const effectiveSpectralProfile = spectralProfile || {
        profile: 'smartStudio',
        vocalPresence: 0.5,
        transientEnergy: 0.5,
        spectralFlux: 0.5,
        bass: 0.5
      };
      const effectiveSongStructure = songStructure || this.memoryManager?.get('lastStructure') || {
        section: 'unknown'
      };
      // Cập nhật giá trị isChorus
      isChorus = effectiveSongStructure.section === 'chorus' || effectiveSongStructure.section === 'bridge';
      const spectralAttention = this.calculateSpectralAttention?.(effectiveSpectralProfile, effectiveSongStructure) || 1.0;
      const transientSculpt = this.calculateTransientSculpt?.(transientDensity, effectiveSpectralProfile.profile) || 1.0;
      // Adjust FFT size
      let targetSize = size;
      let processingScale = 1.0;
      if (avgProcessingTime > 12 || cpuLoad > 0.60) {
        processingScale = Math.max(0.7, 1 - (cpuLoad - 0.60) * 0.5);
        targetSize = findNearestValidSize(size * processingScale);
      }
      if (effectiveDevicePerf === 'low' || qualityMode === 'low') {
        targetSize = Math.min(targetSize, 1024);
      } else if (effectiveDevicePerf === 'medium') {
        targetSize = Math.min(targetSize, 4096);
      } else if (qualityMode === 'high') {
        targetSize = Math.max(targetSize, 2048);
      }
      if (isVocalHeavy || isVocalFeedback || effectiveSpectralProfile.profile === 'vocal' || effectiveSpectralProfile.vocalPresence > 0.7) {
        targetSize = Math.max(targetSize, 2048 * spectralAttention);
      } else if (transientDensity > 0.65 || spectralFlux > 0.7 || effectiveSpectralProfile.profile === 'bassHeavy' || effectiveSpectralProfile.bass > 0.7) {
        targetSize = Math.max(targetSize, 1024 * transientSculpt);
      }
      if (isChorus) {
        targetSize = Math.max(targetSize, 2048 * spectralAttention);
      } else if (effectiveSongStructure.section === 'intro' || effectiveSongStructure.section === 'outro') {
        targetSize = Math.min(targetSize, 1024);
      }
      if (!FFT_VALID_SIZES.includes(targetSize)) {
        targetSize = findNearestValidSize(targetSize);
      }
      const smoothing = (isVocalHeavy || isVocalFeedback) ? 0.55 : 0.65;
      const minDecibels = fftAnalysis.noiseLevel > 0.45 ? -105 : -115;
      const maxDecibels = (transientDensity > 0.65 || spectralFlux > 0.7) ? -35 : -45;
      // Memory management
      const cacheStats = this.memoryManager?.getCacheStats?.() || {
        used: 0,
        limit: 100
      };
      if (cacheStats.used / cacheStats.limit > 0.80) {
        this.memoryManager?.pruneCache(cacheStats.limit * 0.6);
      }
      // Apply settings
      if (this._analyser.fftSize !== targetSize) {
        this._analyser.fftSize = targetSize;
      }
      this._analyser.smoothingTimeConstant = Number.isFinite(smoothing) ? smoothing : 0.65;
      this._analyser.minDecibels = Number.isFinite(minDecibels) ? minDecibels : -115;
      this._analyser.maxDecibels = Number.isFinite(maxDecibels) ? maxDecibels : -45;
      const fftSettings = {
        size: targetSize,
        smoothing,
        minDecibels,
        maxDecibels,
        timestamp: Date.now(),
        expiry: Date.now() + 45000,
        priority: 'high'
      };
      this.memoryManager?.set(cacheKey, fftSettings, 'high');
      this.memoryManager?.pruneCache(this.calculateMaxCacheSize?.() || 50);
      if (isDebug) {
        console.debug('FFT Settings Applied:', {
          size: targetSize,
          smoothing,
          minDecibels,
          maxDecibels
        });
      }
    } catch (e) {
      handleError('Error setting FFT size', e, {
        requestedSize: size
      }, 'high', {
        memoryManager: this.memoryManager
      });
      if (this._analyser) {
        // isChorus giờ đã an toàn để sử dụng ở đây
        const fallbackSize = isVocalHeavy || isChorus ? 2048 : 1024;
        this._analyser.fftSize = fallbackSize;
        this._analyser.smoothingTimeConstant = 0.65;
        this._analyser.minDecibels = -115;
        this._analyser.maxDecibels = -45;
        if (isDebug) console.debug(`Recovered with fallback FFT size: ${fallbackSize}`);
      }
    }
  };
  /**
   * Optimized PhaseLinearCorrection: Trùm Cuối v17.4
   * Bass: Bum Bum (Tight & Punchy) | Treble: Crystal Clear (Smooth & Natural)
   * Tối ưu hóa: Zero-GC (Khử spread operator), Soft-Limiting, Sibilance Guard
   */
  Jungle.prototype.phaseLinearCorrection = function(baseParams, spectralProfile, songStructure, cpuLoad, profile, options = {}) {
    const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
    // Tối ưu hóa: Truy cập trực tiếp object, không tạo object mới (Zero-GC)
    const spectral = spectralProfile || {};
    const fft = options.fftAnalysis || {};
    const memory = options.memoryManager;
    const section = songStructure?.section || 'unknown';
    const phaseLock = options.phaseLockFactor || 1.0;
    // === 1. PHASE & DISTORTION REDUCTION ===
    let phaseDiff = spectral.phaseDiff || 0;
    if (fft.real !== undefined && fft.imag !== undefined) {
      phaseDiff = Math.atan2(fft.imag, fft.real);
      if ((spectral.transientEnergy || 0.5) > 0.8) {
        phaseDiff = (phaseDiff % 6.283185307179586) * 0.97;
      }
    }
    const coherence = fft.spectralCoherence || spectral.spectralCoherence || 0.5;
    const phaseCoherence = Math.cos(phaseDiff) * phaseLock * coherence * (cpuLoad < 0.8 ? 1.5 : 1.0);
    const flux = spectral.spectralFlux || 0.5;
    const fluxImpact = flux > 0.75 ? Math.exp(-flux * 0.65) : 1.0;
    const harmonicImpact = (spectral.harmonicRatio || 0.5) > 0.75 ? 1.2 : 0.8;
    let distortionReduction = Math.max(0.7, fluxImpact * harmonicImpact * (coherence > 0.7 ? 0.78 : 0.88));
    if (coherence < 0.7) distortionReduction *= 0.92;
    if (flux > 0.9) distortionReduction *= 0.88;
    // SpectralAttention
    const energy = Math.pow(Math.abs(fft.energy || 0.5), 2);
    const prevEnergy = memory?.get('prevEnergy') || energy;
    const fluxAt = Math.abs(energy - prevEnergy) / (energy + 0.001);
    const attentionExp = Math.exp(energy * fluxAt * 0.95);
    const spectralAttention = attentionExp / (1 + attentionExp);
    const perceptualSensitivity = (profile === 'smartStudio') ? 1.28 : (profile === 'vocal' ? 1.25 : 1.2);
    const psychoWeight = Math.pow(10, -(spectral.spl || 0) / 20) * perceptualSensitivity;
    distortionReduction *= spectralAttention * psychoWeight * 0.97;
    if (memory) memory.set('prevEnergy', energy, 'low');
    // === 2. BASS QUANTUM SUPERPOSITION (Bum Bum Engine) ===
    if ((spectral.bass || 0.5) > 0.78 || ['bassHeavy', 'rockMetal', 'smartStudio'].includes(profile)) {
      const bassCoherence = phaseCoherence * (section === 'chorus' ? 1.28 : (section === 'verse' ? 1.08 : 1.0));
      // Thêm Damping để tiếng bass nảy (Bum) và không bị ù (Bup)
      const transientDamping = Math.min(1.0, 1.2 / (1 + (spectral.transientEnergy || 0.5)));
      baseParams.lowShelfGain *= Math.max(0.65, bassCoherence * (profile === 'bassHeavy' ? 1.24 : 1.18)) * transientDamping;
      baseParams.subBassGain *= Math.max(0.7, bassCoherence * (profile === 'bassHeavy' ? 1.18 : 1.12)) * transientDamping;
      baseParams.compressorAttack = Math.min(baseParams.compressorAttack || 0.0016, 0.0009 * bassCoherence);
      baseParams.midBassGain *= 0.82 * bassCoherence;
      if ((spectral.subBass || 0.5) > 0.8 && cpuLoad < 0.8) {
        baseParams.subBassGain += 0.07 * distortionReduction * bassCoherence * ((spectral.harmonicRatio || 0.5) > 0.8 ? 1.05 : 1.0);
      }
      const harmonicOrder = cpuLoad > 0.8 ? 2 : 8;
      const freq = (profile === 'bassHeavy' ? 90 : 100);
      const twoPiFreq = 6.283185307179586 * freq;
      const sampleRate = spectral.sampleRate || 48000;
      const sigma = (profile === 'bassHeavy' ? 0.42 : (profile === 'rockMetal' ? 0.38 : 0.3));
      const waveletBase = Math.exp(-Math.pow(freq / 90, 2) / (2 * Math.pow(sigma, 2)));
      let quantumBass = 0;
      for (let i = 1; i <= harmonicOrder; i++) {
        quantumBass += (waveletBase * Math.cos(twoPiFreq * i / sampleRate)) * (Math.sin(twoPiFreq * i * i / sampleRate) / (i * 1.03)) * 1.04;
      }
      // Soft-Clamping để bass tròn, không vỡ tiếng
      quantumBass = Math.tanh(quantumBass * 1.2) * 1.15;
      baseParams.subBassGain *= Math.max(0.7, Math.min(1.38, quantumBass));
      const currentPitchMult = options.currentPitchMult || 0;
      if (Math.abs(currentPitchMult) > 0.5) {
        baseParams.subBassGain *= (1.07 * Math.max(0.7, Math.min(1.35, 1.0 + currentPitchMult * 0.045)));
      }
    }
    // === 3. VOCAL & TREBLE ENTANGLEMENT (Trong trẻo, không sắc) ===
    if ((spectral.vocalPresence || 0) > 0.78 || ['vocal', 'karaokeDynamic', 'smartStudio', 'warm', 'bright'].includes(profile)) {
      const vocalBoost = (profile === 'vocal' ? 1.38 : (profile === 'karaokeDynamic' ? 1.35 : 1.15));
      const midCoherence = phaseCoherence * (section === 'verse' ? 1.18 : 1.0);
      baseParams.midShelfGain += 0.30 * midCoherence * vocalBoost;
      // Sibilance Guard: Nếu flux cao (nhiều treble lộn xộn), giảm gain treble để không rít
      const trebleSafe = flux > 0.8 ? 0.88 : 0.96;
      baseParams.highShelfGain *= Math.min(1.0, midCoherence * (profile === 'bright' ? 0.92 : 0.88) * trebleSafe);
      baseParams.airGain *= Math.min(1.0, midCoherence * 0.84 * trebleSafe);
      baseParams.deEsserGain = Math.max(-30, (baseParams.deEsserGain || -18) * (1 + 0.22 * distortionReduction));
      const vocalPresenceEnt = (profile === 'vocal' ? 1.28 : (profile === 'karaokeDynamic' ? 1.22 : 0.88));
      const midGain = (spectral.midHigh || 0.5) > 0.75 ? 0.54 : 0.48;
      const trebleQ = (spectral.air || 0.5) > 0.75 ? 0.50 : 0.38;
      let entanglement = Math.sqrt(Math.abs((400 + 2300) * vocalPresenceEnt * 1.04 * midGain * trebleQ)) * 1.05;
      baseParams.midShelfGain *= Math.max(0.7, Math.min(1.38, entanglement));
      if ((spectral.transientEnergy || 0.5) > 0.8) {
        baseParams.midShelfGain *= (profile === 'smartStudio' ? 0.78 : 0.82);
      }
    }
    // === 4. MASTERING (Smooth & Natural) ===
    baseParams.compressorRatio *= distortionReduction * phaseCoherence * (flux > 0.8 ? 0.86 : 1.0);
    baseParams.notchQ *= distortionReduction * ((spectral.harmonicRatio || 0.5) > 0.8 ? 1.08 : 1.0);
    if ((spectral.subBass || 0.5) > 0.8) {
      baseParams.panAdjust += 0.065 * phaseCoherence * (coherence > 0.7 ? 1.038 : 1.0);
    }
    const emotionalVector = (profile === 'warm' ? 0.78 : (profile === 'rockMetal' ? 1.25 : (profile === 'bright' ? 1.15 : 1.0)));
    const timbreCurve = (profile === 'warm' ? 1.22 : (profile === 'bright' ? 1.32 : (profile === 'smartStudio' ? 1.18 : 1.0)));
    // Soft-limit master gain để không bao giờ bị méo digital
    const masterGainTarget = baseParams.masterGain * (emotionalVector * timbreCurve * 1.04);
    baseParams.masterGain = Math.tanh(masterGainTarget) * 0.98;
    baseParams.midShelfGain *= (timbreCurve * 0.95);
    // Cache update (vẫn giữ logic 6s)
    if (memory) {
      const now = Date.now();
      if (now - (memory.get(`last_phase_update_${profile}`) || 0) > 6000) {
        memory.set(`phase_${profile}`, {
          coherence,
          distortionReduction,
          phaseDiff,
          timestamp: now
        }, 'high');
        memory.set(`last_phase_update_${profile}`, now, 'low');
      }
    }
    if (isDebug) console.debug('PhaseMaster v17.4 Trùm Cuối Applied', {
      profile,
      ...baseParams
    });
    return baseParams;
  };
  /**
   * Optimized RoomCorrectionSimulation: Zero-GC, Logic ổn định, An toàn bộ nhớ
   */
  Jungle.prototype.roomCorrectionSimulation = function(baseParams, spectralProfile, songStructure, cpuLoad, profile, options = {}) {
    const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
    // Tối ưu hóa: Không dùng Spread operator để đạt Zero-GC
    const spectral = spectralProfile || {};
    const fft = options.fftAnalysis || {};
    const memory = options.memoryManager;
    const section = songStructure?.section || 'unknown';
    // Khởi tạo thông số cơ bản (an toàn với fallback)
    const spectralCoherence = fft.spectralCoherence || spectral.spectralCoherence || 0.5;
    const spectralFlux = spectral.spectralFlux || 0.5;
    const vocalPresence = spectral.vocalPresence || 0.5;
    const transientEnergy = spectral.transientEnergy || 0.5;
    const subBassEnergy = spectral.subBass || 0.5;
    // === 1. PHASE & DISTORTION REDUCTION ===
    let roomCoherence = spectralCoherence * (1 - spectralFlux * 0.3) * (options.roomCoherenceFactor || 1.0);
    const fluxImpact = spectralFlux > 0.75 ? Math.exp(-spectralFlux * 0.65) : 1.0;
    const harmonicImpact = (spectral.harmonicRatio || 0.5) > 0.75 ? 1.2 : 0.8;
    let distortionReduction = Math.max(0.7, fluxImpact * harmonicImpact * (spectralCoherence > 0.7 ? 0.78 : 0.88));
    if (spectralCoherence < 0.7) distortionReduction *= 0.92;
    if (spectralFlux > 0.9) distortionReduction *= 0.88;
    // === 2. BASS QUANTUM SUPERPOSITION (Bum Bum Engine) ===
    // Thêm hệ số Damping để bass gọn, nảy, không bị kéo đuôi (Bup Bup)
    const transientDamping = Math.min(1.0, 1.2 / (1 + transientEnergy));
    baseParams.lowShelfGain *= roomCoherence * (profile === 'bassHeavy' ? 1.09 : 1.07) * transientDamping;
    const psychoacousticRoomSpread = cpuLoad < 0.8 ? 0.035 : 0.022;
    baseParams.subBassGain += psychoacousticRoomSpread * roomCoherence * distortionReduction * 1.04 * transientDamping;
    const sigmaRoom = (profile === 'bassHeavy' ? 0.44 : (profile === 'rockMetal' ? 0.39 : (profile === 'smartStudio' ? 0.28 : 0.25)));
    const harmonicOrderRoom = cpuLoad > 0.8 ? 2 : 9;
    const freq = (profile === 'bassHeavy' ? 85 : 80);
    const twoPiFreq = 6.283185307179586 * freq; // Cache 2*PI
    const sampleRate = spectral.sampleRate || 48000;
    const waveletBase = Math.exp(-Math.pow(freq / 90, 2) / (2 * Math.pow(sigmaRoom, 2)));
    let quantumBassRoom = 0;
    for (let i = 1; i <= harmonicOrderRoom; i++) {
      quantumBassRoom += (waveletBase * Math.cos(twoPiFreq * i / sampleRate)) * (Math.sin(twoPiFreq * i * i / sampleRate) / (i * 1.03)) * 1.05;
    }
    // Tinh hoa: Dùng Math.tanh để nén mềm (Soft-Clipping), tạo độ "tròn" cho bass
    quantumBassRoom = Math.tanh(quantumBassRoom * 1.2) * 1.1;
    quantumBassRoom = Math.max(0.7, Math.min(1.38, quantumBassRoom));
    baseParams.subBassGain *= quantumBassRoom;
    const currentPitchMult = options.currentPitchMult || 0;
    if (Math.abs(currentPitchMult) > 0.5) {
      baseParams.subBassGain *= (1.07 * Math.max(0.7, Math.min(1.38, 1.0 + currentPitchMult * 0.045)));
    }
    // === 3. MID & VOCAL ROOM (Độ trong trẻo) ===
    if (spectralCoherence < 0.7 || ['vocal', 'karaokeDynamic', 'smartStudio'].includes(profile)) {
      const roomVocalBoost = (profile === 'vocal' ? 1.38 : (profile === 'karaokeDynamic' ? 1.34 : 1.15));
      baseParams.midShelfGain += 0.16 * roomCoherence * roomVocalBoost;
      if (transientEnergy > 0.8) baseParams.midShelfGain *= (profile === 'smartStudio' ? 0.77 : 0.81);
    }
    // === 4. TREBLE AIR & SMOOTHING (Chống chói) ===
    baseParams.highShelfGain -= 0.03 * (1 - roomCoherence);
    if (spectralFlux > 0.75) {
      const atcRoomControl = cpuLoad < 0.8 ? 1.038 : 1.0;
      baseParams.highShelfGain -= 0.0008 * roomCoherence * atcRoomControl;
    }
    if (subBassEnergy > 0.8) {
      const immersiveRoom = spectralCoherence > 0.7 ? 1.04 : 1.0;
      baseParams.panAdjust += 0.068 * roomCoherence * immersiveRoom;
    }
    const timbreCurveRoom = (profile === 'warm' ? 1.24 : (profile === 'bright' ? 1.34 : (profile === 'smartStudio' ? 1.20 : 1.0)));
    baseParams.midShelfGain *= timbreCurveRoom * 0.94;
    // === 5. CACHE UPDATE (Tối ưu performance) ===
    if (memory) {
      const now = Date.now();
      const lastUpdate = memory.get(`last_room_update_${profile}`) || 0;
      if (now - lastUpdate > 6000) {
        memory.set(`room_${profile}`, {
          coherence: roomCoherence,
          distortionReduction,
          timestamp: now
        }, 'high');
        memory.set(`last_room_update_${profile}`, now, 'low');
      }
    }
    if (isDebug) {
      console.debug('RoomMaster v17.3 BumBum Applied', {
        profile,
        roomCoherence: roomCoherence.toFixed(4),
        bass: baseParams.subBassGain.toFixed(3)
      });
    }
    return baseParams;
  };
  // === PHẦN EXPORT (KHÔNG CẦN NESTED IIFE) ===
  try {
    if (typeof Jungle === 'undefined') {
      throw new Error('Jungle class is not defined before export');
    }
    if (typeof module !== "undefined" && module.exports) {
      module.exports = Jungle;
    }
    if (typeof window !== "undefined") {
      if (!window.Jungle) {
        window.Jungle = Jungle;
      }
    }
    if (typeof self !== "undefined" && !self.Jungle) {
      self.Jungle = Jungle;
    }
    console.log("[Jungle Audio Module] Loaded successfully (once)");
  } catch (error) {
    if (typeof handleError === 'function') {
      handleError('Critical Export Error', error, {
        context: 'GlobalExport'
      }, 'high');
    } else {
      console.error('Fatal: Jungle could not be exported:', error);
    }
  }
})();
// =============================================
// AJU UI BRIDGE - Real-time Equalizer Controller
// =============================================
Jungle.prototype.setupAjuUIBridge = function() {
  if (this._ajuBridgeInitialized) return;
  this._ajuBridgeInitialized = true;
  const self = this;
  const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
  window.addEventListener('message', function handler(e) {
    if (!e.data || e.data.source !== 'AJU_UI_BRIDGE') return;
    // Debounce + RAF để cực kỳ mượt
    if (self._ajuRafId) cancelAnimationFrame(self._ajuRafId);
    self._ajuRafId = requestAnimationFrame(() => {
      self.applyAjuUIParams(e.data);
    });
  });
  if (isDebug) console.log('[Jungle] AJU UI Bridge initialized - Real-time control ready');
};
Jungle.prototype.applyAjuUIParams = function(payload) {
  if (!this.context || this.context.state === 'closed') return;
  const isDebug = window.location.hostname === 'localhost' || window.location.search.includes('debug=true');
  const safe = (val, def = 0) => (typeof val === 'number' && Number.isFinite(val)) ? val : def;
  const dbToGain = (db) => Math.pow(10, db / 20);
  try {
    const {
      mode = 'simple', simple = {}, pro = {}, masterGain = 0
    } = payload;
    const sp = this.spectralProfile || {};
    const time = this.context.currentTime;
    // 1. Pitch Handling (giữ nguyên)
    if (typeof payload.pitch === 'number') {
      const TargetPitch = safe(payload.pitch, 0);
      if (this.currentPitchMult !== TargetPitch) {
        this.currentPitchMult = TargetPitch;
        const pitchFactor = 1 + Math.abs(TargetPitch) * 0.5;
        const baseBuffer = this.fadeTime ? this.fadeTime * 2.5 : 0.050;
        this.bufferTime = Math.max(this.bufferTime || 0, baseBuffer * pitchFactor);
      }
    }
    // 2. Spectral Mapping
    if (mode === 'simple') {
      const b = safe(simple.bass, 0) / 12;
      const m = safe(simple.mid, 0) / 12;
      const v = safe(simple.vocal, 0) / 12;
      const t = safe(simple.treble, 0) / 12;
      const a = safe(simple.air, 0) / 12;
      sp.subBass = safe(0.5 + b * 1.22, 0.5);
      sp.bass = safe(0.5 + b * 0.95, 0.5);
      sp.subMid = safe(0.5 + b * 0.45 + m * 0.55, 0.5);
      sp.midLow = safe(0.5 + m, 0.5);
      sp.midHigh = safe(0.5 + m * 0.38 + v * 0.62, 0.5);
      sp.high = safe(0.5 + v * 1.12 + t * 0.25, 0.5);
      sp.subTreble = safe(0.5 + t * 1.08, 0.5);
      sp.air = safe(0.5 + a * 1.42, 0.5);
    } else {
      sp.subBass = safe(0.5 + (pro.p31 || 0) / 12, 0.5);
      sp.bass = safe(0.5 + (pro.p62 || 0) / 12, 0.5);
      sp.subMid = safe(0.5 + (pro.p125 || 0) / 12, 0.5);
      sp.midLow = safe(0.5 + (pro.p250 || 0) / 12, 0.5);
      sp.midHigh = safe(0.5 + ((pro.p500 || 0) + (pro.p1k || 0)) / 23, 0.5);
      sp.high = safe(0.5 + (pro.p2k || 0) / 12, 0.5);
      sp.subTreble = safe(0.5 + (pro.p4k || 0) / 12, 0.5);
      sp.air = safe(0.5 + ((pro.p8k || 0) + (pro.p16k || 0)) / 23, 0.5);
    }
    sp.vocalPresence = safe(sp.midHigh * 0.6 + sp.high * 0.4, 0.5);
    sp.transientEnergy = safe(sp.subBass * 0.28 + sp.subTreble * 0.72, 0.5);
    // 3. User Feedback Adjust
    const userFeedbackAdjust = {
      bass: mode === 'simple' ? safe(simple.bass) : ((pro.p31 || 0) + (pro.p62 || 0) + (pro.p125 || 0)) / 2.2,
      mid: mode === 'simple' ? safe(simple.mid) : ((pro.p250 || 0) + (pro.p500 || 0) + (pro.p1k || 0)) / 3,
      treble: mode === 'simple' ? safe(simple.treble) : ((pro.p2k || 0) + (pro.p4k || 0) + (pro.p8k || 0)) / 3,
      air: mode === 'simple' ? safe(simple.air) : safe(pro.p16k),
      vocalClarity: mode === 'simple' ? safe(simple.vocal) * 1.12 : (safe(pro.p1k) + safe(pro.p2k)) * 0.9,
      warmth: mode === 'simple' ? safe(simple.bass) * 0.42 + safe(simple.mid) * 0.58 : ((pro.p125 || 0) + (pro.p250 || 0) + (pro.p500 || 0)) / 1.6
    };
    // 4. Optimize
    const optimized = this.optimizeSoundProfile({
      profile: this.currentProfile || 'proNatural',
      musicContext: {
        spectralComplexity: safe(0.5 + (sp.air + sp.midHigh) * 0.55, 0.6),
        vocalPresence: sp.vocalPresence,
        transientEnergy: sp.transientEnergy,
        harmonicComplexity: 0.72
      },
      spectral: sp,
      genreFactor: 1.0,
      warmthBoost: userFeedbackAdjust.warmth * 0.82,
      subBassBoost: userFeedbackAdjust.bass * 0.78,
      subMidBoost: userFeedbackAdjust.mid * 0.48,
      midBoost: userFeedbackAdjust.mid * 0.68,
      trebleReduction: userFeedbackAdjust.treble < 0 ? Math.abs(userFeedbackAdjust.treble) * 0.85 : 0,
      userFeedbackAdjust,
      songStructure: this.memoryManager?.get('lastStructure') || {
        section: 'unknown'
      },
      roomProfile: {
        coherence: 0.96
      }
    });
    // ==================== DYNAMIC EQ + SMOOTHING ====================
    let dynamicAdjust = {};
    if (this.getRealTimeFrequencyData) {
      const data = this.getRealTimeFrequencyData();
      if (data) {
        const bassEnergy = this.getBandEnergy ? this.getBandEnergy(data, 20, 150) : 0.5;
        const midEnergy = this.getBandEnergy ? this.getBandEnergy(data, 200, 2200) : 0.5;
        const highEnergy = this.getBandEnergy ? this.getBandEnergy(data, 5000, 16000) : 0.5;
        // === SMOOTHING (Làm mượt) ===
        const smoothingFactor = 0.22; // 0.15 ~ 0.3 là đẹp nhất
        this.prevBass = (this.prevBass || bassEnergy) * (1 - smoothingFactor) + bassEnergy * smoothingFactor;
        this.prevMid = (this.prevMid || midEnergy) * (1 - smoothingFactor) + midEnergy * smoothingFactor;
        this.prevHigh = (this.prevHigh || highEnergy) * (1 - smoothingFactor) + highEnergy * smoothingFactor;
        // Dùng giá trị đã mượt để quyết định
        if (this.prevMid > 0.77) {
          dynamicAdjust.midShelfGain = -2.4;
          dynamicAdjust.lowMidGain = -1.6;
        }
        if (this.prevHigh < 0.36) {
          dynamicAdjust.airGain = 1.7;
        }
        if (this.prevBass > 0.76) {
          dynamicAdjust.lowShelfGain = 1.4;
        }
      }
    }
    // 5. Master + Headroom
    const totalBoost = Math.max(0, userFeedbackAdjust.bass) * 0.36 + Math.max(0, userFeedbackAdjust.mid) * 0.19 + Math.max(0, userFeedbackAdjust.vocalClarity) * 0.24;
    const dynamicHeadroomDb = -Math.min(6.5, totalBoost * 0.85);
    if (this.outputGain && this.outputGain.gain) {
      const finalMasterDb = safe(masterGain) + dynamicHeadroomDb;
      const finalMasterLinear = Math.max(0.25, Math.min(2.0, 0.72 * dbToGain(finalMasterDb)));
      this.outputGain.gain.cancelScheduledValues(time);
      this.outputGain.gain.setValueAtTime(this.outputGain.gain.value, time);
      this.outputGain.gain.linearRampToValueAtTime(finalMasterLinear, time + 0.018);
    }
    // 6. Apply filters + Dynamic EQ
    const applyGain = (node, targetValue, defaultValue) => {
      if (!node || !node.gain) return;
      const target = safe(targetValue, defaultValue);
      const delta = Math.abs(node.gain.value - target);
      const rampTime = delta > 5 ? 0.032 : 0.015;
      node.gain.cancelScheduledValues(time);
      node.gain.setValueAtTime(node.gain.value, time);
      node.gain.linearRampToValueAtTime(target, time + rampTime);
    };
    applyGain(this.lowShelfGain, (optimized.lowShelfGain || 4) + (dynamicAdjust.lowShelfGain || 0), 4);
    applyGain(this.midShelfGain, (optimized.midShelfGain || 5) + (dynamicAdjust.midShelfGain || 0), 5);
    applyGain(this.highShelfGain, optimized.highShelfGain, 0.35);
    applyGain(this.airFilter, (optimized.airGain || 0.25) + (dynamicAdjust.airGain || 0), 0.25);
    applyGain(this.formantFilter1, optimized.formantGain, 2.8);
    applyGain(this.formantFilter2, optimized.formantGain * 0.85, 2.4);
    if (this.memoryManager?.set) {
      this.memoryManager.set('lastAppliedAjuParams', {
        mode,
        timestamp: Date.now()
      });
    }
    if (isDebug) {
      console.debug('[AJU Enhanced + Dynamic EQ Smoothed] Applied', {
        mode,
        headroom: dynamicHeadroomDb.toFixed(2) + 'dB'
      });
    }
  } catch (err) {
    console.error('[AJU Spatial DSP Critical Error]:', err);
  }
};